#!/usr/bin/env node
import {createRequire as createHostRequire} from "node:module"; const require = createHostRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require2() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// runtime/core/errors.mjs
function requireThat(condition, code, message, details) {
  if (!condition) throw new WikiError(code, message, details);
}
function relativePath(value, { root = false } = {}) {
  requireThat(typeof value === "string", "path", "A relative path is required.");
  if (root && (value === "" || value === ".")) return "";
  requireThat(
    value.length > 0 && value.length <= 4096 && !/[\\:\x00-\x1f]/.test(value) && !value.split("/").some((p) => !p || p === "." || p === ".."),
    "path",
    "Invalid relative path or traversal.",
    { path: value }
  );
  return value;
}
var WikiError;
var init_errors = __esm({
  "runtime/core/errors.mjs"() {
    WikiError = class extends Error {
      constructor(code, message, details = {}) {
        super(message);
        this.name = "WikiError";
        this.code = code;
        this.details = details;
      }
    };
  }
});

// runtime/adapters/shadow-node.mjs
var shadow_node_exports = {};
__export(shadow_node_exports, {
  openShadowDatabase: () => openShadowDatabase
});
import fs2 from "node:fs/promises";
import path2 from "node:path";
import os2 from "node:os";
import { createHash as createHash2 } from "node:crypto";
import { DatabaseSync as DatabaseSync2 } from "node:sqlite";
async function openShadowDatabase(root, project, { readOnly = false, cacheRoot, maxBytes = 128 * 1024 * 1024, rebuild = false } = {}) {
  requireThat(!readOnly || !rebuild, "read-only", "A read-only query cannot rebuild the database.");
  requireThat(Number.isSafeInteger(maxBytes) && maxBytes >= 1024 && maxBytes <= 1024 * 1024 * 1024, "shadow_budget", "Choose a cache budget between 1 KiB and 1 GiB.");
  const canonical = await fs2.realpath(root);
  const base = path2.resolve(cacheRoot ?? path2.join(os2.homedir(), process.platform === "darwin" ? "Library/Caches" : ".cache", "llmwiki", "shadow"));
  requireThat(!beneath2(canonical, base), "shadow_location", "The local database must remain outside the project.");
  const name = digest(JSON.stringify([canonical, project]));
  let dir = path2.join(base, name), file = path2.join(dir, "shadow.sqlite");
  if (readOnly) {
    try {
      await fs2.lstat(file);
    } catch (e) {
      if (e.code === "ENOENT") return null;
      throw e;
    }
  } else await fs2.mkdir(dir, { recursive: true, mode: 448 });
  const realBase = await fs2.realpath(base), real = await fs2.realpath(dir);
  requireThat(real === path2.join(realBase, name) && !beneath2(canonical, real), "shadow_location", "The database cache must be outside the project without symbolic links.");
  dir = real;
  file = path2.join(dir, "shadow.sqlite");
  let stat;
  try {
    stat = await fs2.lstat(file);
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
  requireThat(!stat || stat.isFile() && !stat.isSymbolicLink(), "shadow_location", "The database must be a regular private file.");
  if (!readOnly && !stat) {
    const handle2 = await fs2.open(file, "wx", 384);
    await handle2.close();
  }
  const db = new DatabaseSync2(file, { readOnly, allowExtension: false });
  try {
    db.exec("PRAGMA busy_timeout=1500; PRAGMA trusted_schema=OFF;");
    if (!readOnly) {
      await fs2.chmod(file, 384);
      db.exec(`
   PRAGMA journal_mode=DELETE;
   PRAGMA secure_delete=ON;
   CREATE TABLE IF NOT EXISTS state (singleton INTEGER PRIMARY KEY CHECK(singleton=1), version INTEGER NOT NULL, generation INTEGER NOT NULL);
   INSERT OR IGNORE INTO state VALUES(1,1,0);
   CREATE TABLE IF NOT EXISTS documents (wiki TEXT NOT NULL, path TEXT NOT NULL, id TEXT NOT NULL, revision TEXT NOT NULL, data TEXT NOT NULL, PRIMARY KEY(wiki,path));
   CREATE INDEX IF NOT EXISTS document_ids ON documents(wiki,id);
  `);
    }
    requireThat(db.prepare("SELECT version FROM state WHERE singleton=1").get()?.version === 1, "shadow_version", "Unsupported shadow database version.");
    requireThat(Object.values(db.prepare("PRAGMA quick_check").get())[0] === "ok", "shadow_corrupt", "The shadow database is corrupt; rebuild the derived cache.");
    if (!readOnly) {
      const pageSize = db.prepare("PRAGMA page_size").get().page_size;
      db.exec("PRAGMA max_page_count=" + Math.ceil((maxBytes * 1.15 + 65536) / pageSize));
    }
  } catch (error) {
    db.close();
    if (rebuild && (error.code === "shadow_corrupt" || [11, 26].includes(error.errcode))) {
      for (const suffix of ["-journal", "-wal", "-shm"]) {
        let present = false;
        try {
          await fs2.lstat(file + suffix);
          present = true;
        } catch (e) {
          if (e.code !== "ENOENT") throw e;
        }
        requireThat(!present, "shadow_busy", "Close active database users before recovering this cache.");
      }
      await fs2.rename(file, file + ".corrupt");
      return openShadowDatabase(root, project, { readOnly: false, cacheRoot, maxBytes });
    }
    throw error;
  }
  return {
    path: file,
    readOnly,
    maxBytes,
    generation: () => db.prepare("SELECT generation FROM state WHERE singleton=1").get().generation,
    documents: (wiki2) => db.prepare("SELECT * FROM documents WHERE wiki=? ORDER BY path").all(wiki2).map((row) => ({ ...row, data: JSON.parse(row.data) })),
    commit(updates, { expected, remove = [], keepWikis = null } = {}) {
      requireThat(!readOnly, "read-only", "The shadow database is read-only.");
      db.exec("BEGIN IMMEDIATE");
      try {
        requireThat(db.prepare("SELECT generation FROM state WHERE singleton=1").get().generation === expected, "shadow_stale", "The shadow database changed during this update. Retry the maintenance action.");
        for (const wiki2 of keepWikis === null ? [] : db.prepare("SELECT DISTINCT wiki FROM documents").all().map((r) => r.wiki).filter((w) => !keepWikis.includes(w))) db.prepare("DELETE FROM documents WHERE wiki=?").run(wiki2);
        for (const r of remove) db.prepare("DELETE FROM documents WHERE wiki=? AND path=?").run(r.wiki, r.path);
        const put = db.prepare("INSERT INTO documents(wiki,path,id,revision,data) VALUES(?,?,?,?,?) ON CONFLICT(wiki,path) DO UPDATE SET id=excluded.id,revision=excluded.revision,data=excluded.data");
        for (const row of updates) put.run(row.wiki, row.path, row.id, row.revision, JSON.stringify(row.data));
        const size = db.prepare("SELECT COALESCE(SUM(length(CAST(data AS BLOB))),0) AS bytes FROM documents").get().bytes;
        requireThat(size <= maxBytes, "shadow_budget", "The structural cache exceeds its configured byte budget.", { bytes: size, maxBytes });
        db.prepare("UPDATE state SET generation=generation+1 WHERE singleton=1").run();
        db.exec("COMMIT");
        return { bytes: size, generation: expected + 1 };
      } catch (error) {
        db.exec("ROLLBACK");
        throw error;
      }
    },
    close: () => db.close()
  };
}
var digest, beneath2;
var init_shadow_node = __esm({
  "runtime/adapters/shadow-node.mjs"() {
    init_errors();
    digest = (s) => createHash2("sha256").update(s).digest("hex");
    beneath2 = (root, file) => file === root || file.startsWith(root + path2.sep);
  }
});

// runtime/compat/reviews.mjs
function createReviews(environment2) {
  (function(global) {
    "use strict";
    const FORMAT = "llmwiki-review/1", ROOT = ".llmwiki/reviews", MAX_TEXT = 2e6;
    const idPattern = /^[a-z0-9-]{20,80}$/i;
    const kinds = ["change", "proposal", "reject", "accept", "comment", "external", "resolve", "reopen", "acknowledge", "partial"];
    const F = () => global.FolderAccess;
    const msg = (key, values) => global.I18n.message(key, values);
    function fail(key) {
      throw global.I18n.error(msg(key));
    }
    function author(value) {
      return typeof value === "string" && value.trim() !== "" && value.length <= 120 && !/[\r\n\x00-\x1f]/.test(value);
    }
    function valid(e) {
      return Boolean((!e?.anchor || Number.isInteger(e.anchor.beforeLine) && Number.isInteger(e.anchor.afterLine) && Array.isArray(e.anchor.before) && Array.isArray(e.anchor.after) && e.anchor.before.every((v) => typeof v === "string") && e.anchor.after.every((v) => typeof v === "string")) && e && e.format === FORMAT && idPattern.test(e.id) && kinds.includes(e.kind) && (author(e.author) || e.kind === "external" && e.author === "") && typeof e.page === "string" && e.page && !e.page.split("/").some((p) => !p || p === ".." || p === "." || p.startsWith(".")) && !/[\\:\x00-\x1f]/.test(e.page) && (e.parent === null || typeof e.parent === "string" && idPattern.test(e.parent)) && idPattern.test(e.thread) && typeof e.base === "string" && e.base.length <= MAX_TEXT && typeof e.text === "string" && e.text.length <= MAX_TEXT && typeof e.message === "string" && e.message.length <= 1e4 && Array.isArray(e.recipients) && e.recipients.length <= 200 && e.recipients.every(author) && typeof e.at === "string" && /Z$/.test(e.at) && Number.isFinite(Date.parse(e.at)));
    }
    function event(values) {
      const id = global.crypto.randomUUID();
      const e = {
        format: FORMAT,
        id,
        kind: values.kind,
        page: values.page,
        author: values.author,
        at: (/* @__PURE__ */ new Date()).toISOString(),
        parent: values.parent || null,
        thread: values.thread || id,
        base: values.base,
        text: values.text,
        message: values.message || "",
        recipients: values.recipients || []
      };
      if (!valid(e)) fail("The change record is incomplete or invalid.");
      return e;
    }
    function reply(parent, kind, by, base, text3, message) {
      if (!valid(parent)) fail("The change record is incomplete or invalid.");
      return event({ page: parent.page, kind, author: by, base, text: text3, message, parent: parent.id, thread: kind === "comment" && ["change", "external", "accept"].includes(parent.kind) ? null : parent.thread, recipients: !parent.author || parent.author === by ? parent.recipients : [parent.author] });
    }
    async function hash(text3) {
      const bytes = await global.crypto.subtle.digest("SHA-256", new TextEncoder().encode(text3));
      return Array.from(new Uint8Array(bytes), (v) => v.toString(16).padStart(2, "0")).join("");
    }
    async function pageFolder(page) {
      return ROOT + "/" + await hash(page);
    }
    async function eventPath(e) {
      return await pageFolder(e.page) + "/" + e.id + ".json";
    }
    async function append(dir, e) {
      if (!valid(e)) fail("The change record is incomplete or invalid.");
      const done = await F().writeFile(dir, await eventPath(e), JSON.stringify(e, null, 2) + "\n", null);
      if (!done.saved) fail("The response could not be recorded. Nothing was sent.");
      return e;
    }
    async function receipt(dir, e) {
      const path5 = await eventPath(e) + ".applied", text3 = JSON.stringify({ id: e.id, digest: await hash(JSON.stringify(e)) });
      try {
        const existing = await F().readFile(dir, path5);
        return existing.text === text3;
      } catch (error) {
        if (error.name !== "NotFoundError") throw error;
      }
      const result = await F().writeFile(dir, path5, text3, null);
      return Boolean(result.saved);
    }
    async function save2(dir, page, expected, text3, by, parent = null) {
      let current = null;
      try {
        current = await F().readFile(dir, page);
      } catch (error) {
        if (error.name !== "NotFoundError") throw error;
      }
      if ((current ? current.text : null) !== (expected ? expected.text : null)) return { saved: false, stale: true };
      if (!parent && current && current.text === text3) return { saved: true, recorded: true, text: text3, mark: current.mark, event: null, unchanged: true };
      const e = parent ? reply(parent, "accept", by, current ? current.text : "", text3, "") : event({ page, kind: "change", author: by, base: current ? current.text : "", text: text3 });
      e.page = page;
      await append(dir, e);
      const done = await F().writeFile(dir, page, text3, current);
      if (!done.saved) return { ...done, event: e, recorded: false };
      let recorded = false;
      try {
        recorded = await receipt(dir, e);
      } catch (_) {
      }
      return { ...done, event: e, recorded };
    }
    async function accept(dir, e, current, by) {
      if (!valid(e)) fail("The change record is incomplete or invalid.");
      if (current.text !== e.text && (["change", "external"].includes(e.kind) || current.text !== e.base)) {
        const journal = await read(dir, e.page), parts = journal.events.filter((p) => p.kind === "partial" && p.parent === e.id && p.text === current.text);
        const proven = parts.some((p) => journal.events.some((a) => a.kind === "accept" && a.parent === p.id && a.text === current.text));
        if (!["proposal", "reject"].includes(e.kind) || !proven) return { saved: false, stale: true };
      }
      return save2(dir, currentPage(await aliases(dir), e.page), current, e.text, by, e);
    }
    async function directory(dir, path5) {
      for (const part of path5.split("/")) dir = await dir.getDirectoryHandle(part);
      return dir;
    }
    async function readOwn(dir, page = null) {
      let root;
      try {
        root = await directory(dir, page ? await pageFolder(page) : ROOT);
      } catch (error) {
        if (error.name === "NotFoundError") return { events: [], incomplete: 0, unreadable: 0, pending: [] };
        throw error;
      }
      const found = [], receipts = /* @__PURE__ */ new Map();
      let incomplete = 0, unreadable = 0;
      async function scan(h, depth) {
        for await (const entry of h.values()) {
          if (entry.kind === "directory") {
            if (depth === 0 && page === null && /^[a-f0-9]{64}$/.test(entry.name)) await scan(entry, 1);
            continue;
          }
          if (!/^[a-z0-9-]{20,80}\.json(?:\.applied)?$/i.test(entry.name)) continue;
          try {
            const f = await entry.getFile();
            if (f.size > MAX_TEXT * 12 + 5e4) {
              unreadable++;
              continue;
            }
            const data = JSON.parse(await f.text());
            if (entry.name.endsWith(".applied")) {
              if (data.id + ".json.applied" === entry.name) receipts.set(data.id, data.digest);
              else unreadable++;
            } else if (valid(data) && data.id + ".json" === entry.name && (!page || data.page === page)) found.push(data);
            else unreadable++;
          } catch (_) {
            unreadable++;
          }
        }
      }
      await scan(root, 0);
      const events = [], pending = [];
      for (const e of found) {
        if (["change", "accept"].includes(e.kind) && receipts.get(e.id) !== await hash(JSON.stringify(e))) {
          incomplete++;
          pending.push(e);
          continue;
        }
        events.push(e);
      }
      events.sort((a, b) => a.at.localeCompare(b.at) || a.id.localeCompare(b.id));
      return { events, incomplete, unreadable, pending };
    }
    const aliasCache = /* @__PURE__ */ new WeakMap();
    async function aliases(dir) {
      const cached = aliasCache.get(dir);
      if (cached && Date.now() - cached.at < 500) return cached.map;
      const map = /* @__PURE__ */ new Map();
      let root;
      try {
        root = await directory(dir, ".llmwiki/path-aliases");
      } catch (e) {
        if (e.name === "NotFoundError") return map;
        throw e;
      }
      for await (const entry of root.values()) if (entry.kind === "file" && entry.name.endsWith(".json")) {
        const data = JSON.parse(await (await entry.getFile()).text());
        if (data.kind !== "consolidated" && typeof data.from === "string" && typeof data.to === "string") map.set(data.from, data.to);
      }
      aliasCache.set(dir, { at: Date.now(), map });
      return map;
    }
    function currentPage(map, page) {
      const visited = /* @__PURE__ */ new Set();
      while (map.has(page)) {
        if (visited.has(page)) fail("The synchronization record cannot be read.");
        visited.add(page);
        page = map.get(page);
      }
      return page;
    }
    async function read(dir, page = null) {
      const result = await readOwn(dir, page);
      if (!page) return result;
      const map = await aliases(dir);
      for (const old of map.keys()) if (old !== page && currentPage(map, old) === page) {
        const prior = await readOwn(dir, old);
        result.events.push(...prior.events);
        result.pending.push(...prior.pending);
        result.incomplete += prior.incomplete;
        result.unreadable += prior.unreadable;
      }
      result.events.sort((a, b) => a.at.localeCompare(b.at) || a.id.localeCompare(b.id));
      return result;
    }
    function threadState(events, thread) {
      const byId = new Map(events.map((e) => [e.id, e])), states = events.filter((e) => e.thread === thread && ["resolve", "reopen"].includes(e.kind)), ancestors = /* @__PURE__ */ new Set();
      for (const state of states) {
        let parent = state.parent;
        const visited = /* @__PURE__ */ new Set();
        while (parent && !visited.has(parent)) {
          visited.add(parent);
          ancestors.add(parent);
          parent = byId.get(parent)?.parent;
        }
      }
      const heads = states.filter((e) => !ancestors.has(e.id));
      return heads.length && heads.every((e) => e.kind === "resolve") ? "resolved" : "open";
    }
    function incoming(events, by, seen) {
      const known = new Set(seen || []);
      const parents = new Map(events.map((e) => [e.id, e]));
      const answered = new Set(events.filter((e) => e.author === by && !["acknowledge", "partial", "comment", "resolve", "reopen"].includes(e.kind) || e.kind === "accept" && parents.get(e.parent) && !["change", "external"].includes(parents.get(e.parent).kind)).map((e) => e.parent));
      return events.filter((e) => e.author !== by && !["accept", "external", "resolve", "acknowledge", "partial"].includes(e.kind) && threadState(events, e.thread) !== "resolved" && !known.has(e.id) && !answered.has(e.id) && (e.kind === "change" || !e.recipients.length || e.recipients.includes(by)));
    }
    async function tasks(events, by, checkpoint2, current, page) {
      const replies = incoming(events, by, checkpoint2?.seen || []).filter((e) => !["change", "external"].includes(e.kind));
      if (!checkpoint2 || checkpoint2.text === current) return replies;
      let change = events.slice().reverse().find((e) => ["change", "accept"].includes(e.kind) && e.text === current && e.base !== e.text);
      if (!change) {
        change = event({ kind: "external", page, author: "", base: checkpoint2.text, text: current });
        change.id = "external-" + await hash(JSON.stringify([page, checkpoint2.text, current]));
        change.thread = change.id;
      }
      return (checkpoint2.seen || []).includes(change.id) ? replies : [change, ...replies];
    }
    function localKey(project, folder, path5, by) {
      return "review/" + [project, folder, String(path5), by || "unnamed"].map(encodeURIComponent).join("/");
    }
    async function checkpoint(key, page, value) {
      if (value) {
        const done = await F().keepDraft(key, page, JSON.stringify(value), "llmwiki-checkpoint/1");
        if (!done) fail("The personal comparison baseline could not be saved.");
        return value;
      }
      const saved = await F().recallDraft(key, page);
      if (!saved) return null;
      try {
        const data = JSON.parse(saved.text);
        return typeof data.text === "string" && Array.isArray(data.seen) ? data : null;
      } catch (_) {
        return null;
      }
    }
    function selectChanges(before, after, selection, revert = false) {
      const hunks = diff(before, after);
      if (!Array.isArray(selection) || !selection.length || new Set(selection).size !== selection.length || selection.some((i) => !Number.isInteger(i) || i < 0 || i >= hunks.length)) fail("Select a valid change.");
      const lines = (revert ? after : before).match(/[^\n]*\n|[^\n]+$/g) || [], next = (revert ? before : after).match(/[^\n]*\n|[^\n]+$/g) || [];
      for (const i of [...selection].sort((a, b) => b - a)) {
        const h = hunks[i], from = revert ? h.afterLine : h.beforeLine, count = revert ? h.after.length : h.before.length, to = revert ? h.beforeLine : h.afterLine, size = revert ? h.before.length : h.after.length;
        lines.splice(from - 1, count, ...next.slice(to - 1, to - 1 + size));
      }
      return lines.join("");
    }
    function diff(before, after) {
      if (before === after) return [];
      const a = before.split(/\r?\n/), b = after.split(/\r?\n/), hunks = [];
      let ai = 0, bi = 0;
      const matches = a.length * b.length <= 4e6 ? global.matchingBlocks(a, b) : [[a.length, b.length, 0]];
      for (const [x, y, size] of matches) {
        if (x > ai || y > bi) hunks.push({ before: a.slice(ai, x), after: b.slice(bi, y), beforeLine: ai + 1, afterLine: bi + 1 });
        ai = x + size;
        bi = y + size;
      }
      return hunks;
    }
    function attribution(before, after, events) {
      const chain = [], used = /* @__PURE__ */ new Set();
      let cursor = after;
      while (cursor !== before) {
        const matches = events.filter((e2) => ["change", "accept"].includes(e2.kind) && e2.base !== e2.text && e2.text === cursor && !used.has(e2.id));
        if (!matches.length) break;
        const e = matches[matches.length - 1];
        used.add(e.id);
        chain.unshift(e);
        cursor = e.base;
      }
      const original = before.split(/\r?\n/), start = cursor.split(/\r?\n/), deleted = /* @__PURE__ */ new Map();
      let lines = start.map(() => ({ author: null, index: null }));
      if (original.length * start.length <= 4e6) for (const [a, b, size] of global.matchingBlocks(original, start)) for (let i = 0; i < size; i++) lines[b + i].index = a + i;
      for (const e of chain) {
        const a = e.base.split(/\r?\n/), b = e.text.split(/\r?\n/), next = b.map(() => ({ author: e, index: null }));
        let old = 0;
        const matches = a.length * b.length <= 4e6 ? global.matchingBlocks(a, b) : [[a.length, b.length, 0]];
        for (const [x, y, size] of matches) {
          for (let i = old; i < x; i++) if (lines[i] && lines[i].index !== null) deleted.set(lines[i].index, e);
          for (let i = 0; i < size; i++) next[y + i] = lines[x + i];
          old = x + size;
        }
        lines = next;
      }
      return diff(before, after).map((h) => {
        const authors = /* @__PURE__ */ new Map();
        let unknown = false;
        for (let i = h.afterLine - 1; i < h.afterLine - 1 + h.after.length; i++) {
          const e = lines[i] && lines[i].author;
          if (e) authors.set(e.id, e);
          else unknown = true;
        }
        for (let i = h.beforeLine - 1; i < h.beforeLine - 1 + h.before.length; i++) {
          const e = deleted.get(i);
          if (e) authors.set(e.id, e);
          else if (!h.after.length) unknown = true;
        }
        return { authors: Array.from(authors.values()), unknown };
      });
    }
    function parseNotice(text3) {
      if (global.headField(text3, "format") !== "llmwiki-notice/1") return null;
      const sections = {}, body = text3.slice(global.parseHead(text3).offset);
      let heading = null, quote = null, width = 0, lines = [];
      for (const line of body.split(/\r?\n/)) {
        const marker = /^ {0,3}(`{3,}|~{3,})/.exec(line);
        if (quote) {
          if (marker && marker[1][0] === quote && marker[1].length >= width) {
            sections[heading] = lines.join("\n");
            quote = null;
          } else lines.push(line);
          continue;
        }
        const h = /^##\s+(warum|vorher|nachher)\s*$/.exec(line);
        if (h) heading = h[1];
        if (marker && heading) {
          quote = marker[1][0];
          width = marker[1].length;
          lines = [];
        }
      }
      return { author: global.headField(text3, "von") || "", at: global.headField(text3, "wann") || "", base: sections.vorher || "", text: sections.nachher || "", message: sections.warum || "" };
    }
    async function notices(dir, text3) {
      const id = global.headField(text3, "id");
      if (typeof id !== "string" || !/^[a-zA-Z0-9_-]+$/.test(id)) return [];
      const found = [];
      for (const top of ["notices", "vermerke"]) {
        let root;
        try {
          root = await directory(dir, top + "/" + id);
        } catch (error) {
          if (error.name === "NotFoundError") continue;
          throw error;
        }
        for await (const entry of root.values()) if (entry.kind === "file" && entry.name.endsWith(".md")) {
          const file = await entry.getFile();
          if (file.size > MAX_TEXT) continue;
          const n = parseNotice(await file.text());
          if (n) found.push(n);
        }
      }
      return found;
    }
    global.WikiReviews = { selectChanges, revertChanges: (before, after, selection) => selectChanges(before, after, selection, true), threadState, aliases, currentPage, event, valid, reply, save: save2, accept, append, read, incoming, tasks, localKey, checkpoint, diff, attribution, hash, eventPath, receipt, parseNotice, notices };
  })(environment2);
  return environment2.WikiReviews;
}
var init_reviews = __esm({
  "runtime/compat/reviews.mjs"() {
  }
});

// runtime/compat/editorsync.mjs
function createSync(environment2) {
  (function(global) {
    "use strict";
    const F = () => global.FolderAccess, R = () => global.WikiReviews;
    const MAX = 2e6;
    const step = (o, key, fn, result) => o.step ? o.step(JSON.stringify(key), fn, result) : fn();
    const side = (o, dir) => dir === o.work ? "work" : "remote";
    function error(key) {
      return global.I18n.error(global.I18n.message(key));
    }
    function contentClearance(value, page = "") {
      const findings = [], seen = /* @__PURE__ */ new Set(), add = (code, field = "") => {
        const key = code + "|" + field;
        if (!seen.has(key)) {
          seen.add(key);
          findings.push({ code, page, ...field ? { field } : {} });
        }
      };
      const secretKey = /^(?:api[_-]?key|access[_-]?token|refresh[_-]?token|token|password|passwort|secret|geheimnis|credential|auth)$/i;
      const deviceKey = /^(?:device[_-]?id|machine[_-]?id|hostname|local[_-]?folder|runner|rechner)$/i;
      const name = (v) => typeof v === "string" && /^[A-Za-z0-9_.-]{1,40}$/.test(v);
      const secret = /-----BEGIN [A-Z ]*PRIVATE KEY-----|\bxox[baprs]-[0-9A-Za-z-]{10,}|\bAKIA[0-9A-Z]{16}\b|\bgh[pousr]_[0-9A-Za-z]{20,}|\bsk-[0-9A-Za-z]{20,}|\bBearer\s+[0-9A-Za-z._~+/-]{20,}/;
      function inspect(v, field = "", depth = 0) {
        if (depth > 32) {
          add("clearance_unreadable", field);
          return;
        }
        if (v && typeof v === "object") {
          for (const [key, part] of Object.entries(v)) {
            if (secretKey.test(key) && part !== null && part !== "" && !name(part)) add("clearance_secret", key);
            if (deviceKey.test(key) && part !== null && part !== "") add("clearance_device", key);
            inspect(part, key, depth + 1);
          }
          return;
        }
        if (typeof v !== "string") return;
        if (secret.test(v)) add("clearance_secret", field);
        const paths = v.replace(/\bhttps?:\/\/[^\s<>"']+/gi, "").replace(/(?<![\p{L}\p{N}_/.~-])[\p{L}\p{N}][\p{L}\p{N}_-]*-\/(?:[\p{L}\p{N}][\p{L}\p{N}_-]*-\/)+[\p{L}\p{N}][\p{L}\p{N}_-]*/gu, "");
        if (/(?:^|[^\w./])\/(?:[\w.-]+\/)+[\w.-]+|(?:^|[^\w])[A-Za-z]:[\\/][\w.\\/-]+|(?:^|[^\w])~\/[\w.-]+/.test(paths)) add("clearance_device_path", field);
        if (/^\s*[\[{]/.test(v)) try {
          inspect(JSON.parse(v), field, depth + 1);
          return;
        } catch {
        }
        if (/^---\r?\n/.test(v)) try {
          const parsed = global.WikiCore?.parseDocument(v) ?? global.parseHead?.(v);
          if (parsed?.head) inspect(parsed.head, field, depth + 1);
        } catch {
          add("clearance_unreadable", field);
        }
        for (const line of v.split(/\r?\n/)) {
          const pair = /^\s*(?:-\s*)?([A-Za-z_][A-Za-z0-9_.-]*)\s*:\s*(.+?)\s*$/.exec(line);
          if (!pair) continue;
          const part = pair[2].replace(/^['"]|['"]$/g, "");
          if (secretKey.test(pair[1]) && !["null", "~", "[]", "{}"].includes(part) && !name(part)) add("clearance_secret", pair[1]);
          if (deviceKey.test(pair[1]) && !["null", "~", ""].includes(part)) add("clearance_device", pair[1]);
        }
      }
      inspect(value);
      return findings;
    }
    function transferVisible(page, kind) {
      const roots = [".llmwiki/reviews", ".llmwiki/evidence", ".llmwiki/shadow/changes", ".llmwiki/shadow/pins", ".llmwiki/path-aliases", ".llmwiki/transfers", ".llmwiki/retirements"];
      return visible(page, kind) || kind === "directory" && roots.some((r) => r === page || r.startsWith(page + "/") || page.startsWith(r + "/")) || kind === "file" && page.endsWith(".json") && (page === ".llmwiki/identity-aliases.json" || roots.some((r) => page.startsWith(r + "/")));
    }
    async function checkClearance(dir, o = null) {
      const findings = [];
      async function walk(folder, prefix = "") {
        for await (const entry of folder.values()) {
          const page = prefix ? prefix + "/" + entry.name : entry.name;
          if (!transferVisible(page, entry.kind)) continue;
          if (entry.kind === "directory") await walk(entry, page);
          else if (entry.kind === "file") {
            const inspect = async () => {
              const file = await peek(dir, page);
              return file ? contentClearance(file.text, page) : [];
            };
            findings.push(...o ? await step(o, ["clearance", side(o, dir), page], inspect) : await inspect());
          }
        }
      }
      await walk(dir);
      return findings;
    }
    function requireClearance(findings) {
      if (!findings.length) return;
      const e = error("Sharing paused. Private values were found in a document or its history. Keep the original private and prepare a cleaned copy before sharing.");
      e.code = "clearance";
      e.details = { findings };
      throw e;
    }
    function visible(path5, kind) {
      return !path5.split("/").some((p) => p.startsWith(".") || ["notices", "vermerke"].includes(p)) && (kind === "directory" || path5 === "schema/FIELDS.json" || /\.md$/i.test(path5));
    }
    async function peek(dir, path5) {
      try {
        return await F().readFile(dir, path5);
      } catch (e) {
        if (e.name === "NotFoundError") return null;
        throw e;
      }
    }
    function text3(seen) {
      return seen ? seen.text : null;
    }
    async function guarded2(o, dir, path5, value, seen) {
      if (!o.alive()) throw error("The folder was disconnected.");
      requireClearance(contentClearance(value, path5));
      const done = await F().writeFile(dir, path5, value, seen);
      if (!done.saved) throw error("The file changed during synchronization. It will be checked again.");
      return done;
    }
    async function statePath(o, page) {
      return ".llmwiki/editor-sync/" + await R().hash(o.identity) + "/" + await R().hash(page) + ".json";
    }
    async function baseline(o, page) {
      const path5 = await statePath(o, page), seen = await peek(o.work, path5);
      let data = null;
      if (seen) {
        data = JSON.parse(seen.text);
        if (data.format !== "llmwiki-editor-sync/1" || data.page !== page || data.identity !== o.identity || !(data.text === null || typeof data.text === "string" && data.text.length <= MAX)) throw error("The synchronization record cannot be read.");
      }
      return { path: path5, seen, data };
    }
    async function record(o, b, page, value, resolved = false) {
      return guarded2(o, o.work, b.path, JSON.stringify({ format: "llmwiki-editor-sync/1", identity: o.identity, page, text: value, resolved }), b.seen);
    }
    async function journal(o, from, to, page) {
      const source2 = await R().read(from, page), target = await R().read(to, page);
      const found = new Map([...target.events, ...target.pending].map((e) => [e.id, e]));
      for (const e of source2.events) {
        if (!o.alive()) throw error("The folder was disconnected.");
        requireClearance(contentClearance(e, page));
        const known = found.get(e.id);
        if (known && JSON.stringify(known) !== JSON.stringify(e)) throw error("The synchronization record cannot be read.");
        if (!known) await R().append(to, e);
        if (["change", "accept"].includes(e.kind) && !await R().receipt(to, e)) throw error("The synchronization record cannot be read.");
      }
      return source2;
    }
    async function transferable(dir, page, base, value) {
      const events = (await R().read(dir, page)).events, queue = [value], visited = /* @__PURE__ */ new Set();
      while (queue.length) {
        const cursor = queue.pop();
        if (cursor === (base ?? "")) return true;
        if (visited.has(cursor)) continue;
        visited.add(cursor);
        for (const e of events) if (["change", "accept"].includes(e.kind) && e.text === cursor && e.text !== e.base) queue.push(e.base);
      }
      return false;
    }
    async function evidence(o, from, to) {
      let root;
      try {
        root = await from.getDirectoryHandle(".llmwiki");
        root = await root.getDirectoryHandle("evidence");
      } catch (e) {
        if (e.name === "NotFoundError") return;
        throw e;
      }
      async function walk(dir, path5) {
        for await (const entry of dir.values()) {
          const name = path5 + "/" + entry.name;
          if (entry.kind === "directory") {
            await walk(entry, name);
            continue;
          }
          if (!entry.name.endsWith(".json")) continue;
          await step(o, ["evidence", side(o, from), name], async () => {
            const source2 = await peek(from, name), target = await peek(to, name);
            if (target) {
              if (target.text !== source2.text) throw error("The synchronization record cannot be read.");
              return;
            }
            await guarded2(o, to, name, source2.text, null);
          });
        }
      }
      await walk(root, ".llmwiki/evidence");
    }
    async function shadowEvidence(o, from, to) {
      for (const kind of ["changes", "pins"]) {
        let root;
        try {
          root = await from.getDirectoryHandle(".llmwiki");
          root = await root.getDirectoryHandle("shadow");
          root = await root.getDirectoryHandle(kind);
        } catch (e) {
          if (e.name === "NotFoundError") continue;
          throw e;
        }
        for await (const entry of root.values()) {
          await step(o, ["shadow", side(o, from), kind, entry.name], async () => {
            if (entry.kind !== "file" || !/^[a-f0-9]{64}\.json$/.test(entry.name)) throw error("The synchronization record cannot be read.");
            const name = ".llmwiki/shadow/" + kind + "/" + entry.name, source2 = await peek(from, name);
            if (!source2 || source2.text.length > MAX || await R().hash(source2.text) !== entry.name.slice(0, -5)) throw error("The synchronization record cannot be read.");
            const data = JSON.parse(source2.text);
            if (!(data.format === "llmwiki-shadow/1" || kind === "changes" && data.format === "llmwiki-shadow-identities/2") || data.kind !== (kind === "pins" ? "quote" : "identities")) throw error("The synchronization record cannot be read.");
            const target = await peek(to, name);
            if (target) {
              if (target.text !== source2.text) throw error("The synchronization record cannot be read.");
              return;
            }
            await guarded2(o, to, name, source2.text, null);
          });
        }
      }
    }
    async function sharedRecords(o, from, to, kind) {
      let root;
      try {
        root = await from.getDirectoryHandle(".llmwiki");
        root = await root.getDirectoryHandle(kind);
      } catch (e) {
        if (e.name === "NotFoundError") return;
        throw e;
      }
      for await (const entry of root.values()) {
        await step(o, ["records", side(o, from), kind, entry.name], async () => {
          if (entry.kind !== "file" || !/^[a-f0-9]{64}\.json$/.test(entry.name)) throw error("The synchronization record cannot be read.");
          const page = ".llmwiki/" + kind + "/" + entry.name, source2 = await peek(from, page);
          if (!source2 || await R().hash(source2.text) !== entry.name.slice(0, -5)) throw error("The synchronization record cannot be read.");
          const data = JSON.parse(source2.text);
          if (data.format !== (kind === "transfers" ? "llmwiki-transfer/1" : "llmwiki-retirement/1")) throw error("The synchronization record cannot be read.");
          const target = await peek(to, page);
          if (target && target.text !== source2.text) throw error("The synchronization record cannot be read.");
          if (!target) await guarded2(o, to, page, source2.text, null);
        });
      }
    }
    async function retireGroups(o, result) {
      const records = /* @__PURE__ */ new Map(), skip = /* @__PURE__ */ new Set();
      for (const dir of [o.work, o.remote]) {
        let root;
        try {
          root = await dir.getDirectoryHandle(".llmwiki");
          root = await root.getDirectoryHandle("retirements");
        } catch (e) {
          if (e.name === "NotFoundError") continue;
          throw e;
        }
        for await (const e of root.values()) {
          if (e.kind !== "file") continue;
          const f = await peek(dir, ".llmwiki/retirements/" + e.name), r = JSON.parse(f.text);
          if (r.format !== "llmwiki-retirement/1" || typeof r.page !== "string" || r.page.split("/").some((p) => !p || p === "." || p === "..") || /[\\:\x00-\x1f]/.test(r.page) || !/^[a-f0-9]{64}$/.test(r.expected) || !/^[a-f0-9-]{36}$/.test(r.stage)) throw error("The synchronization record cannot be read.");
          records.set(e.name, r);
        }
      }
      for (const r of records.values()) {
        const local = await peek(o.work, r.page), remote = await peek(o.remote, r.page), files2 = [local, remote], hashes = await Promise.all(files2.map((f) => f ? R().hash(f.text) : null));
        if (hashes.every((h) => h !== null && h !== r.expected)) continue;
        if (hashes.some((h) => h !== null && h !== r.expected)) {
          if (hashes.some((h) => h === r.expected)) {
            skip.add(r.page);
            result.conflicts.push({ page: r.page, reason: "retirement_changed", base: null, mine: text3(local), theirs: text3(remote) });
          }
          continue;
        }
        skip.add(r.page);
        let pending = false;
        for (const [i, dir] of [o.work, o.remote].entries()) {
          if (!files2[i]) continue;
          const archive = ".llmwiki/retired/" + r.stage + "/" + r.page;
          if (i === 1 && !o.canPublish || !F().archiveFile || F().canArchive && !F().canArchive(dir)) {
            pending = true;
            result.pending++;
            result.pending_details.push({ page: r.page, reason: "host_move_required", archive, expected: r.expected });
            continue;
          }
          await F().archiveFile(dir, r.page, archive, r.expected);
        }
        if (!pending) await record(o, await baseline(o, r.page), r.page, null);
      }
      return skip;
    }
    async function moveAliases(o, result) {
      const all = /* @__PURE__ */ new Map();
      for (const dir of [o.remote, o.work]) {
        let root;
        try {
          root = await dir.getDirectoryHandle(".llmwiki");
          root = await root.getDirectoryHandle("path-aliases");
        } catch (e) {
          if (e.name === "NotFoundError") continue;
          throw e;
        }
        for await (const file of root.values()) if (file.kind === "file" && file.name.endsWith(".json")) {
          const path5 = ".llmwiki/path-aliases/" + file.name, seen = await peek(dir, path5), data = JSON.parse(seen.text);
          if (typeof data.from !== "string" || typeof data.to !== "string" || !data.expected || data.from === data.to) throw error("The synchronization record cannot be read.");
          const known = all.get(data.from);
          if (known && known.seen.text !== seen.text) throw error("The synchronization record cannot be read.");
          all.set(data.from, { data, seen, path: path5 });
        }
      }
      for (const { data, seen, path: path5 } of all.values()) for (const dir of [o.work, ...o.canPublish ? [o.remote] : []]) {
        const prior = await peek(dir, path5);
        if (!prior) await guarded2(o, dir, path5, seen.text, null);
      }
      return all;
    }
    async function identityAliases(o, aliases) {
      const path5 = ".llmwiki/identity-aliases.json", merged = /* @__PURE__ */ new Map();
      function target(p) {
        const seen = /* @__PURE__ */ new Set();
        while (aliases.has(p)) {
          if (seen.has(p)) throw error("The synchronization record cannot be read.");
          seen.add(p);
          p = aliases.get(p).data.to;
        }
        return p;
      }
      for (const dir of [o.remote, o.work]) {
        const file = await peek(dir, path5);
        if (!file) continue;
        const data = JSON.parse(file.text);
        if (data.format !== "llmwiki-identity-aliases/1" || !Array.isArray(data.aliases)) throw error("The synchronization record cannot be read.");
        for (const alias of data.aliases) {
          const value = { ...alias, path: target(alias.path) }, previous = merged.get(alias.id);
          if (previous && JSON.stringify(previous) !== JSON.stringify(value)) throw error("The synchronization record cannot be read.");
          merged.set(alias.id, value);
        }
      }
      if (!merged.size) return;
      const text4 = JSON.stringify({ format: "llmwiki-identity-aliases/1", aliases: [...merged.values()].sort((a, b) => a.id.localeCompare(b.id)) });
      for (const dir of [o.work, ...o.canPublish ? [o.remote] : []]) {
        const seen = await peek(dir, path5);
        if (seen?.text !== text4) await guarded2(o, dir, path5, text4, seen);
      }
    }
    async function retireMoves(o, result, aliases) {
      for (const { data } of aliases.values()) for (const dir of [o.work, ...o.canPublish ? [o.remote] : []]) {
        const old = await peek(dir, data.from);
        if (!old) continue;
        const next = await peek(dir, data.to);
        if (!next || await R().hash(old.text) !== data.expected) {
          result.conflicts.push({ page: data.from, base: null, mine: text3(await peek(o.work, data.from)), theirs: text3(await peek(o.remote, data.from)), move_to: data.to });
          continue;
        }
        if (!F().archiveFile || F().canArchive && !F().canArchive(dir)) {
          result.pending++;
          result.pending_details.push({ page: data.from, reason: "host_move_required", to: data.to, archive: ".llmwiki/moves/" + data.id + "/synced-originals/" + data.from, expected: data.expected });
          continue;
        }
        if (!o.alive()) return;
        await F().archiveFile(dir, data.from, ".llmwiki/moves/" + data.id + "/synced-originals/" + data.from, data.expected);
      }
    }
    const binaryChecks = /* @__PURE__ */ new WeakMap();
    async function binaryAssets(o, result) {
      const visible2 = (path5, kind) => !path5.split("/").some((p) => p.startsWith(".")) && (kind === "directory" || /\.(png|jpe?g|gif|webp|avif|svg|pdf|excalidraw)$/i.test(path5));
      const lists = await Promise.all([F().listFolder(o.work, void 0, { visible: visible2 }), F().listFolder(o.remote, void 0, { visible: visible2 })]);
      let cache = binaryChecks.get(o.work);
      if (!cache) {
        cache = /* @__PURE__ */ new Map();
        binaryChecks.set(o.work, cache);
      }
      const inventory = lists.map((items) => new Map(items.map((f) => [f.name, f])));
      const peek2 = async (dir, page) => {
        try {
          return await F().readBinary(dir, page);
        } catch (e) {
          if (e.name === "NotFoundError") return null;
          throw e;
        }
      };
      for (const page of new Set(lists.flat().map((f) => f.name))) {
        await step(o, ["asset", page], async () => {
          if (!o.alive()) return;
          if (!F().readBinary || !F().writeBinary) {
            result.pending++;
            result.pending_details.push({ page, reason: "binary_capability_required" });
            return;
          }
          const info = inventory.map((items) => items.get(page)), cacheable = info.every((f) => f && Number.isFinite(f.at) && Number.isFinite(f.size)), signature = cacheable ? JSON.stringify(info.map((f) => [f.at, f.size])) : null, key = o.identity + "/" + page, known = cache.get(key);
          if (signature && known?.signature === signature && Date.now() - known.at < 6e4) return;
          cache.delete(key);
          const local = await peek2(o.work, page), remote = await peek2(o.remote, page);
          if (local?.sha256 === remote?.sha256) {
            if (signature) cache.set(key, { signature, at: Date.now() });
            return;
          }
          if (local && remote) {
            result.pending++;
            result.pending_details.push({ page, reason: "asset_conflict", local: local.sha256, remote: remote.sha256 });
            return;
          }
          if (!remote && !o.canPublish) {
            result.pending++;
            result.pending_details.push({ page, reason: "asset_publication_pending" });
            return;
          }
          const source2 = local || remote, target = local ? o.remote : o.work;
          const done = await F().writeBinary(target, page, source2.bytes, null);
          if (!done.saved) throw error("The file changed during synchronization. It will be checked again.");
          if (local) result.published++;
          else result.copied++;
        }, result);
      }
    }
    async function run(options) {
      const o = { alive: () => true, ...options }, result = { copied: 0, published: 0, pending: 0, pending_details: [], conflicts: [] };
      if (!o.alive()) return result;
      if (o.work.isSameEntry && await o.work.isSameEntry(o.remote)) throw error("The shared wiki and working folder must be separate.");
      requireClearance([...await checkClearance(o.remote, o), ...o.canPublish ? await checkClearance(o.work, o) : []]);
      await binaryAssets(o, result);
      await evidence(o, o.remote, o.work);
      if (o.canPublish) await evidence(o, o.work, o.remote);
      await shadowEvidence(o, o.remote, o.work);
      if (o.canPublish) await shadowEvidence(o, o.work, o.remote);
      for (const kind of ["transfers", "retirements"]) {
        await sharedRecords(o, o.remote, o.work, kind);
        if (o.canPublish) await sharedRecords(o, o.work, o.remote, kind);
      }
      const retired = await step(o, ["retire_groups"], () => retireGroups(o, result), result);
      const aliases = await moveAliases(o, result);
      await identityAliases(o, aliases);
      const [local, remote] = await Promise.all([F().listFolder(o.work, void 0, { visible }), F().listFolder(o.remote, void 0, { visible })]);
      const pages = new Map([...local, ...remote].map((f) => [f.name, f]));
      for (const [page, entry] of pages) {
        if (!o.alive()) break;
        await step(o, ["page", page], async () => {
          if (aliases.has(page) || retired.has(page)) return;
          if (entry.size > MAX) {
            result.pending++;
            result.pending_details.push({ page, reason: "size_limit" });
            return;
          }
          const b = await baseline(o, page), l = await peek(o.work, page), r = await peek(o.remote, page), mine = text3(l), theirs = text3(r);
          if (mine !== null && mine.length > MAX || theirs !== null && theirs.length > MAX) {
            result.pending++;
            result.pending_details.push({ page, reason: "size_limit" });
            return;
          }
          await journal(o, o.remote, o.work, page);
          if (o.canPublish) await journal(o, o.work, o.remote, page);
          if (mine === theirs) {
            if (!b.data || b.data.text !== mine || b.data.resolved) await record(o, b, page, mine);
            return;
          }
          const base = b.data?.text;
          if (!b.data && mine === null && theirs !== null || b.data && mine === base && theirs !== null) {
            if (text3(await peek(o.remote, page)) !== theirs) throw error("The file changed during synchronization. It will be checked again.");
            await guarded2(o, o.work, page, theirs, l);
            await record(o, b, page, theirs);
            result.copied++;
            return;
          }
          const remoteClean = b.data ? theirs === base : theirs === null;
          if (remoteClean && mine !== null) {
            if (!o.canPublish) {
              result.pending++;
              result.pending_details.push({ page, reason: "read_only" });
              return;
            }
            if (!b.data?.resolved || theirs !== base) {
              if (!await transferable(o.work, page, theirs, mine)) {
                result.pending++;
                result.pending_details.push({ page, reason: "author_chain_missing", base: base ?? null, mine, theirs });
                return;
              }
            }
            if (text3(await peek(o.work, page)) !== mine) throw error("The file changed during synchronization. It will be checked again.");
            await guarded2(o, o.remote, page, mine, r);
            await record(o, b, page, mine);
            result.published++;
            return;
          }
          result.conflicts.push({ page, base: base ?? null, mine, theirs });
        }, result);
      }
      await step(o, ["retire_moves"], () => retireMoves(o, result, aliases), result);
      return result;
    }
    async function resolve(options, conflict, value, by, message = "") {
      const o = { alive: () => true, ...options }, l = await peek(o.work, conflict.page), r = await peek(o.remote, conflict.page);
      if (!o.alive()) throw error("The folder was disconnected.");
      if (text3(l) !== conflict.mine || text3(r) !== conflict.theirs) throw error("The file changed again. Reopen the comparison before deciding.");
      if (typeof value !== "string" || value.length > MAX) throw error("Choose a version to keep. No file will be deleted.");
      requireClearance([...contentClearance(value, conflict.page), ...await checkClearance(o.remote)]);
      const b = await baseline(o, conflict.page);
      await journal(o, o.remote, o.work, conflict.page);
      let parent = (await R().read(o.remote, conflict.page)).events.slice().reverse().find((e) => ["change", "accept"].includes(e.kind) && e.text === conflict.theirs);
      if (!parent) {
        parent = R().event({ kind: "external", page: conflict.page, author: "", base: conflict.base ?? "", text: conflict.theirs ?? "" });
        await R().append(o.work, parent);
      }
      const accepted = value === conflict.theirs;
      const response = accepted ? null : R().reply(parent, value === conflict.mine ? "reject" : "proposal", by, conflict.theirs ?? "", value, message);
      const saved = await R().save(o.work, conflict.page, l, value, by, accepted ? parent : null);
      if (!saved.saved || !saved.recorded) throw error("The file changed during synchronization. It will be checked again.");
      if (response) await R().append(o.work, response);
      await record(o, b, conflict.page, conflict.theirs, true);
    }
    global.EditorSync = { run, resolve, visible, contentClearance, checkClearance };
  })(environment2);
  return environment2.EditorSync;
}
var init_editorsync = __esm({
  "runtime/compat/editorsync.mjs"() {
  }
});

// runtime/compat/project.mjs
function createProject(environment2) {
  (function(global) {
    "use strict";
    const msg = (key, values) => global.I18n.message(key, values);
    const NAME2 = "llmwiki.project.json";
    const FORMAT = "llmwiki-project/1";
    const ID = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/;
    const ROOT_ICONS = ["folder", "book", "book-open", "user", "users", "briefcase", "library", "archive", "database"];
    function keys(value, required, optional = []) {
      if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((k) => !required.includes(k) && !optional.includes(k)) || required.some((k) => !Object.hasOwn(value, k))) {
        throw global.I18n.error(msg("Unknown or missing project settings."));
      }
    }
    function label(value) {
      return typeof value === "string" && value.trim().length > 0 && value.length <= 240;
    }
    function validate(data) {
      keys(data, ["format", "id", "label", "folders", "connections"], ["editor"]);
      if (Object.hasOwn(data, "editor") && !["builtin", "obsidian", "both"].includes(data.editor)) throw global.I18n.error(msg("Choose an editor."));
      if (data.format !== FORMAT || typeof data.id !== "string" || !ID.test(data.id) || !label(data.label)) throw global.I18n.error(msg("Project ID or name is missing."));
      if (!Array.isArray(data.folders) || data.folders.length > 200) throw global.I18n.error(msg("Choose the project folders."));
      const folders = /* @__PURE__ */ new Map();
      for (const f of data.folders) {
        keys(f, ["id", "label", "kind", "path", "writable", "readers", "writers"], ["icon"]);
        if (f.icon !== void 0 && !ROOT_ICONS.includes(f.icon)) throw new Error("Choose a supported root icon.");
        if (typeof f.id !== "string" || !ID.test(f.id) || folders.has(f.id) || !label(f.label)) throw global.I18n.error(msg("Folder IDs must be unique."));
        if (!["wiki", "work", "source"].includes(f.kind) || typeof f.writable !== "boolean") throw global.I18n.error(msg("Folder type or write permission is missing."));
        if (f.path !== null && (typeof f.path !== "string" || !f.path || /[\\:\x00]/.test(f.path) || f.path !== "." && f.path.split("/").some((p) => !p || p === ".." || p === "."))) throw global.I18n.error(msg("Folder paths must be within the project. External folders are bound on this device."));
        for (const key of ["readers", "writers"]) if (!Array.isArray(f[key]) || f[key].length > 100 || !f[key].every(label)) throw global.I18n.error(msg("Name the people or groups who may access this folder."));
        if (!f.readers.length || f.writable && !f.writers.length) throw global.I18n.error(msg("Name the readers and, when writing is enabled, the writers."));
        folders.set(f.id, f);
      }
      if (!Array.isArray(data.connections) || data.connections.length > 200) throw global.I18n.error(msg("Create at least one connection."));
      const seen = /* @__PURE__ */ new Set();
      for (const c of data.connections) {
        keys(c, ["id", "label", "wiki", "works", "sources", "mode"], ["default_source"]);
        if (c.default_source != null && !c.sources.includes(c.default_source)) throw new Error("Default source must belong to this wiki.");
        if (typeof c.id !== "string" || !ID.test(c.id) || seen.has(c.id) || !label(c.label)) throw global.I18n.error(msg("Connections need unique IDs and names."));
        seen.add(c.id);
        if (!["eigen", "gemeinsam"].includes(c.mode)) throw global.I18n.error(msg("Choose whether others write to the wiki."));
        if (!folders.has(c.wiki) || folders.get(c.wiki).kind !== "wiki") throw global.I18n.error(msg("Choose a wiki for this connection."));
        for (const [key, kind] of [["works", "work"], ["sources", "source"]]) {
          if (!Array.isArray(c[key]) || key === "works" && !c[key].length || new Set(c[key]).size !== c[key].length || c[key].some((id) => !folders.has(id) || folders.get(id).kind !== kind)) throw global.I18n.error(msg("Choose the matching working and source folders."));
        }
        const overlaps = (a, b) => a !== null && b !== null && (a === b || a === "." || b === "." || a.startsWith(b + "/") || b.startsWith(a + "/"));
        const wiki2 = folders.get(c.wiki);
        for (const id of c.works) if (c.mode === "gemeinsam" && overlaps(wiki2.path, folders.get(id).path)) throw global.I18n.error(msg("The shared wiki and working folder must be separate."));
        for (const id of c.sources) {
          const source2 = folders.get(id);
          if ([wiki2, ...c.works.map((k) => folders.get(k))].some((f) => overlaps(source2.path, f.path))) throw global.I18n.error(msg("Sources must not be inside a wiki or working folder, or contain either."));
        }
      }
      return data;
    }
    async function read(root) {
      const seen = await global.FolderAccess.peek(root, NAME2);
      if (seen === null) return { data: null, seen: null };
      if (typeof seen.text !== "string") throw global.I18n.error(msg("No read permission for project settings."));
      if (seen.text.length > 1048576) throw global.I18n.error(msg("Project settings are too large."));
      return { data: validate(JSON.parse(seen.text)), seen };
    }
    async function save2(root, data, seen) {
      validate(data);
      const done = await global.FolderAccess.writeFile(root, NAME2, JSON.stringify(data, null, 2) + "\n", seen);
      if (!done.saved) throw global.I18n.error(msg("Settings were not saved. Reopen them: someone changed them or write permission is missing."));
      return done;
    }
    async function relative(root, dir) {
      const parts = await root.resolve(dir);
      return parts === null ? null : parts.length ? parts.join("/") : ".";
    }
    function bindingKey(project, folder) {
      return "project/" + encodeURIComponent(project) + "/" + encodeURIComponent(folder);
    }
    async function resolve(root, f, project, recall = global.FolderAccess.recallFolder) {
      if (f.path === null) return recall(bindingKey(project, f.id));
      if (!root) return null;
      let dir = root;
      if (f.path !== ".") for (const part of f.path.split("/")) dir = await dir.getDirectoryHandle(part);
      return dir;
    }
    global.ProjectSettings = { NAME: NAME2, FORMAT, ROOT_ICONS, validate, read, save: save2, relative, resolve, bindingKey };
  })(environment2);
  return environment2.ProjectSettings;
}
var init_project = __esm({
  "runtime/compat/project.mjs"() {
  }
});

// runtime/compat/matching.mjs
function placesOf(items) {
  var found = /* @__PURE__ */ new Map();
  for (var index = 0; index < items.length; index += 1) {
    var seen = found.get(items[index]);
    if (seen === void 0) {
      seen = [];
      found.set(items[index], seen);
    }
    seen.push(index);
  }
  return found;
}
function findLongestMatch(a, b, indices, alo, ahi, blo, bhi) {
  var besti = alo;
  var bestj = blo;
  var bestsize = 0;
  var lengths = /* @__PURE__ */ new Map();
  for (var i = alo; i < ahi; i += 1) {
    var next = /* @__PURE__ */ new Map();
    var places = indices.get(a[i]);
    if (places !== void 0) {
      for (var at = 0; at < places.length; at += 1) {
        var j = places[at];
        if (j < blo) {
          continue;
        }
        if (j >= bhi) {
          break;
        }
        var previous = lengths.get(j - 1);
        var k = (previous === void 0 ? 0 : previous) + 1;
        next.set(j, k);
        if (k > bestsize) {
          besti = i - k + 1;
          bestj = j - k + 1;
          bestsize = k;
        }
      }
    }
    lengths = next;
  }
  return [besti, bestj, bestsize];
}
function matchingBlocks(a, b) {
  var indices = placesOf(b);
  var queue = [[0, a.length, 0, b.length]];
  var found = [];
  while (queue.length) {
    var region = queue.pop();
    var alo = region[0];
    var ahi = region[1];
    var blo = region[2];
    var bhi = region[3];
    var match = findLongestMatch(a, b, indices, alo, ahi, blo, bhi);
    var i = match[0];
    var j = match[1];
    var k = match[2];
    if (k) {
      found.push(match);
      if (alo < i && blo < j) {
        queue.push([alo, i, blo, j]);
      }
      if (i + k < ahi && j + k < bhi) {
        queue.push([i + k, ahi, j + k, bhi]);
      }
    }
  }
  found.sort(function(one, other) {
    return one[0] - other[0] || one[1] - other[1] || one[2] - other[2];
  });
  var joined = [];
  var i1 = 0;
  var j1 = 0;
  var k1 = 0;
  for (var index = 0; index < found.length; index += 1) {
    var i2 = found[index][0];
    var j2 = found[index][1];
    var k2 = found[index][2];
    if (i1 + k1 === i2 && j1 + k1 === j2) {
      k1 += k2;
    } else {
      if (k1) {
        joined.push([i1, j1, k1]);
      }
      i1 = i2;
      j1 = j2;
      k1 = k2;
    }
  }
  if (k1) {
    joined.push([i1, j1, k1]);
  }
  joined.push([a.length, b.length, 0]);
  return joined;
}
var init_matching = __esm({
  "runtime/compat/matching.mjs"() {
  }
});

// node_modules/yaml/dist/nodes/identity.js
var require_identity = __commonJS({
  "node_modules/yaml/dist/nodes/identity.js"(exports) {
    "use strict";
    var ALIAS = /* @__PURE__ */ Symbol.for("yaml.alias");
    var DOC = /* @__PURE__ */ Symbol.for("yaml.document");
    var MAP = /* @__PURE__ */ Symbol.for("yaml.map");
    var PAIR = /* @__PURE__ */ Symbol.for("yaml.pair");
    var SCALAR = /* @__PURE__ */ Symbol.for("yaml.scalar");
    var SEQ = /* @__PURE__ */ Symbol.for("yaml.seq");
    var NODE_TYPE = /* @__PURE__ */ Symbol.for("yaml.node.type");
    var isAlias = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === ALIAS;
    var isDocument = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === DOC;
    var isMap2 = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === MAP;
    var isPair = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === PAIR;
    var isScalar = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === SCALAR;
    var isSeq = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === SEQ;
    function isCollection(node) {
      if (node && typeof node === "object")
        switch (node[NODE_TYPE]) {
          case MAP:
          case SEQ:
            return true;
        }
      return false;
    }
    function isNode(node) {
      if (node && typeof node === "object")
        switch (node[NODE_TYPE]) {
          case ALIAS:
          case MAP:
          case SCALAR:
          case SEQ:
            return true;
        }
      return false;
    }
    var hasAnchor = (node) => (isScalar(node) || isCollection(node)) && !!node.anchor;
    exports.ALIAS = ALIAS;
    exports.DOC = DOC;
    exports.MAP = MAP;
    exports.NODE_TYPE = NODE_TYPE;
    exports.PAIR = PAIR;
    exports.SCALAR = SCALAR;
    exports.SEQ = SEQ;
    exports.hasAnchor = hasAnchor;
    exports.isAlias = isAlias;
    exports.isCollection = isCollection;
    exports.isDocument = isDocument;
    exports.isMap = isMap2;
    exports.isNode = isNode;
    exports.isPair = isPair;
    exports.isScalar = isScalar;
    exports.isSeq = isSeq;
  }
});

// node_modules/yaml/dist/visit.js
var require_visit = __commonJS({
  "node_modules/yaml/dist/visit.js"(exports) {
    "use strict";
    var identity = require_identity();
    var BREAK = /* @__PURE__ */ Symbol("break visit");
    var SKIP = /* @__PURE__ */ Symbol("skip children");
    var REMOVE = /* @__PURE__ */ Symbol("remove node");
    function visit(node, visitor) {
      const visitor_ = initVisitor(visitor);
      if (identity.isDocument(node)) {
        const cd = visit_(null, node.contents, visitor_, Object.freeze([node]));
        if (cd === REMOVE)
          node.contents = null;
      } else
        visit_(null, node, visitor_, Object.freeze([]));
    }
    visit.BREAK = BREAK;
    visit.SKIP = SKIP;
    visit.REMOVE = REMOVE;
    function visit_(key, node, visitor, path5) {
      const ctrl = callVisitor(key, node, visitor, path5);
      if (identity.isNode(ctrl) || identity.isPair(ctrl)) {
        replaceNode(key, path5, ctrl);
        return visit_(key, ctrl, visitor, path5);
      }
      if (typeof ctrl !== "symbol") {
        if (identity.isCollection(node)) {
          path5 = Object.freeze(path5.concat(node));
          for (let i = 0; i < node.items.length; ++i) {
            const ci = visit_(i, node.items[i], visitor, path5);
            if (typeof ci === "number")
              i = ci - 1;
            else if (ci === BREAK)
              return BREAK;
            else if (ci === REMOVE) {
              node.items.splice(i, 1);
              i -= 1;
            }
          }
        } else if (identity.isPair(node)) {
          path5 = Object.freeze(path5.concat(node));
          const ck = visit_("key", node.key, visitor, path5);
          if (ck === BREAK)
            return BREAK;
          else if (ck === REMOVE)
            node.key = null;
          const cv = visit_("value", node.value, visitor, path5);
          if (cv === BREAK)
            return BREAK;
          else if (cv === REMOVE)
            node.value = null;
        }
      }
      return ctrl;
    }
    async function visitAsync(node, visitor) {
      const visitor_ = initVisitor(visitor);
      if (identity.isDocument(node)) {
        const cd = await visitAsync_(null, node.contents, visitor_, Object.freeze([node]));
        if (cd === REMOVE)
          node.contents = null;
      } else
        await visitAsync_(null, node, visitor_, Object.freeze([]));
    }
    visitAsync.BREAK = BREAK;
    visitAsync.SKIP = SKIP;
    visitAsync.REMOVE = REMOVE;
    async function visitAsync_(key, node, visitor, path5) {
      const ctrl = await callVisitor(key, node, visitor, path5);
      if (identity.isNode(ctrl) || identity.isPair(ctrl)) {
        replaceNode(key, path5, ctrl);
        return visitAsync_(key, ctrl, visitor, path5);
      }
      if (typeof ctrl !== "symbol") {
        if (identity.isCollection(node)) {
          path5 = Object.freeze(path5.concat(node));
          for (let i = 0; i < node.items.length; ++i) {
            const ci = await visitAsync_(i, node.items[i], visitor, path5);
            if (typeof ci === "number")
              i = ci - 1;
            else if (ci === BREAK)
              return BREAK;
            else if (ci === REMOVE) {
              node.items.splice(i, 1);
              i -= 1;
            }
          }
        } else if (identity.isPair(node)) {
          path5 = Object.freeze(path5.concat(node));
          const ck = await visitAsync_("key", node.key, visitor, path5);
          if (ck === BREAK)
            return BREAK;
          else if (ck === REMOVE)
            node.key = null;
          const cv = await visitAsync_("value", node.value, visitor, path5);
          if (cv === BREAK)
            return BREAK;
          else if (cv === REMOVE)
            node.value = null;
        }
      }
      return ctrl;
    }
    function initVisitor(visitor) {
      if (typeof visitor === "object" && (visitor.Collection || visitor.Node || visitor.Value)) {
        return Object.assign({
          Alias: visitor.Node,
          Map: visitor.Node,
          Scalar: visitor.Node,
          Seq: visitor.Node
        }, visitor.Value && {
          Map: visitor.Value,
          Scalar: visitor.Value,
          Seq: visitor.Value
        }, visitor.Collection && {
          Map: visitor.Collection,
          Seq: visitor.Collection
        }, visitor);
      }
      return visitor;
    }
    function callVisitor(key, node, visitor, path5) {
      if (typeof visitor === "function")
        return visitor(key, node, path5);
      if (identity.isMap(node))
        return visitor.Map?.(key, node, path5);
      if (identity.isSeq(node))
        return visitor.Seq?.(key, node, path5);
      if (identity.isPair(node))
        return visitor.Pair?.(key, node, path5);
      if (identity.isScalar(node))
        return visitor.Scalar?.(key, node, path5);
      if (identity.isAlias(node))
        return visitor.Alias?.(key, node, path5);
      return void 0;
    }
    function replaceNode(key, path5, node) {
      const parent = path5[path5.length - 1];
      if (identity.isCollection(parent)) {
        parent.items[key] = node;
      } else if (identity.isPair(parent)) {
        if (key === "key")
          parent.key = node;
        else
          parent.value = node;
      } else if (identity.isDocument(parent)) {
        parent.contents = node;
      } else {
        const pt = identity.isAlias(parent) ? "alias" : "scalar";
        throw new Error(`Cannot replace node with ${pt} parent`);
      }
    }
    exports.visit = visit;
    exports.visitAsync = visitAsync;
  }
});

// node_modules/yaml/dist/doc/directives.js
var require_directives = __commonJS({
  "node_modules/yaml/dist/doc/directives.js"(exports) {
    "use strict";
    var identity = require_identity();
    var visit = require_visit();
    var escapeChars = {
      "!": "%21",
      ",": "%2C",
      "[": "%5B",
      "]": "%5D",
      "{": "%7B",
      "}": "%7D"
    };
    var escapeTagName = (tn) => tn.replace(/[!,[\]{}]/g, (ch) => escapeChars[ch]);
    var Directives = class _Directives {
      constructor(yaml, tags) {
        this.docStart = null;
        this.docEnd = false;
        this.yaml = Object.assign({}, _Directives.defaultYaml, yaml);
        this.tags = Object.assign({}, _Directives.defaultTags, tags);
      }
      clone() {
        const copy = new _Directives(this.yaml, this.tags);
        copy.docStart = this.docStart;
        return copy;
      }
      /**
       * During parsing, get a Directives instance for the current document and
       * update the stream state according to the current version's spec.
       */
      atDocument() {
        const res = new _Directives(this.yaml, this.tags);
        switch (this.yaml.version) {
          case "1.1":
            this.atNextDocument = true;
            break;
          case "1.2":
            this.atNextDocument = false;
            this.yaml = {
              explicit: _Directives.defaultYaml.explicit,
              version: "1.2"
            };
            this.tags = Object.assign({}, _Directives.defaultTags);
            break;
        }
        return res;
      }
      /**
       * @param onError - May be called even if the action was successful
       * @returns `true` on success
       */
      add(line, onError) {
        if (this.atNextDocument) {
          this.yaml = { explicit: _Directives.defaultYaml.explicit, version: "1.1" };
          this.tags = Object.assign({}, _Directives.defaultTags);
          this.atNextDocument = false;
        }
        const parts = line.trim().split(/[ \t]+/);
        const name = parts.shift();
        switch (name) {
          case "%TAG": {
            if (parts.length !== 2) {
              onError(0, "%TAG directive should contain exactly two parts");
              if (parts.length < 2)
                return false;
            }
            const [handle2, prefix] = parts;
            this.tags[handle2] = prefix;
            return true;
          }
          case "%YAML": {
            this.yaml.explicit = true;
            if (parts.length !== 1) {
              onError(0, "%YAML directive should contain exactly one part");
              return false;
            }
            const [version] = parts;
            if (version === "1.1" || version === "1.2") {
              this.yaml.version = version;
              return true;
            } else {
              const isValid = /^\d+\.\d+$/.test(version);
              onError(6, `Unsupported YAML version ${version}`, isValid);
              return false;
            }
          }
          default:
            onError(0, `Unknown directive ${name}`, true);
            return false;
        }
      }
      /**
       * Resolves a tag, matching handles to those defined in %TAG directives.
       *
       * @returns Resolved tag, which may also be the non-specific tag `'!'` or a
       *   `'!local'` tag, or `null` if unresolvable.
       */
      tagName(source2, onError) {
        if (source2 === "!")
          return "!";
        if (source2[0] !== "!") {
          onError(`Not a valid tag: ${source2}`);
          return null;
        }
        if (source2[1] === "<") {
          const verbatim = source2.slice(2, -1);
          if (verbatim === "!" || verbatim === "!!") {
            onError(`Verbatim tags aren't resolved, so ${source2} is invalid.`);
            return null;
          }
          if (source2[source2.length - 1] !== ">")
            onError("Verbatim tags must end with a >");
          return verbatim;
        }
        const [, handle2, suffix] = source2.match(/^(.*!)([^!]*)$/s);
        if (!suffix)
          onError(`The ${source2} tag has no suffix`);
        const prefix = this.tags[handle2];
        if (prefix) {
          try {
            return prefix + decodeURIComponent(suffix);
          } catch (error) {
            onError(String(error));
            return null;
          }
        }
        if (handle2 === "!")
          return source2;
        onError(`Could not resolve tag: ${source2}`);
        return null;
      }
      /**
       * Given a fully resolved tag, returns its printable string form,
       * taking into account current tag prefixes and defaults.
       */
      tagString(tag) {
        for (const [handle2, prefix] of Object.entries(this.tags)) {
          if (tag.startsWith(prefix))
            return handle2 + escapeTagName(tag.substring(prefix.length));
        }
        return tag[0] === "!" ? tag : `!<${tag}>`;
      }
      toString(doc) {
        const lines = this.yaml.explicit ? [`%YAML ${this.yaml.version || "1.2"}`] : [];
        const tagEntries = Object.entries(this.tags);
        let tagNames;
        if (doc && tagEntries.length > 0 && identity.isNode(doc.contents)) {
          const tags = {};
          visit.visit(doc.contents, (_key, node) => {
            if (identity.isNode(node) && node.tag)
              tags[node.tag] = true;
          });
          tagNames = Object.keys(tags);
        } else
          tagNames = [];
        for (const [handle2, prefix] of tagEntries) {
          if (handle2 === "!!" && prefix === "tag:yaml.org,2002:")
            continue;
          if (!doc || tagNames.some((tn) => tn.startsWith(prefix)))
            lines.push(`%TAG ${handle2} ${prefix}`);
        }
        return lines.join("\n");
      }
    };
    Directives.defaultYaml = { explicit: false, version: "1.2" };
    Directives.defaultTags = { "!!": "tag:yaml.org,2002:" };
    exports.Directives = Directives;
  }
});

// node_modules/yaml/dist/doc/anchors.js
var require_anchors = __commonJS({
  "node_modules/yaml/dist/doc/anchors.js"(exports) {
    "use strict";
    var identity = require_identity();
    var visit = require_visit();
    function anchorIsValid(anchor) {
      if (/[\x00-\x19\s,[\]{}]/.test(anchor)) {
        const sa = JSON.stringify(anchor);
        const msg = `Anchor must not contain whitespace or control characters: ${sa}`;
        throw new Error(msg);
      }
      return true;
    }
    function anchorNames(root) {
      const anchors = /* @__PURE__ */ new Set();
      visit.visit(root, {
        Value(_key, node) {
          if (node.anchor)
            anchors.add(node.anchor);
        }
      });
      return anchors;
    }
    function findNewAnchor(prefix, exclude) {
      for (let i = 1; true; ++i) {
        const name = `${prefix}${i}`;
        if (!exclude.has(name))
          return name;
      }
    }
    function createNodeAnchors(doc, prefix) {
      const aliasObjects = [];
      const sourceObjects = /* @__PURE__ */ new Map();
      let prevAnchors = null;
      return {
        onAnchor: (source2) => {
          aliasObjects.push(source2);
          prevAnchors ?? (prevAnchors = anchorNames(doc));
          const anchor = findNewAnchor(prefix, prevAnchors);
          prevAnchors.add(anchor);
          return anchor;
        },
        /**
         * With circular references, the source node is only resolved after all
         * of its child nodes are. This is why anchors are set only after all of
         * the nodes have been created.
         */
        setAnchors: () => {
          for (const source2 of aliasObjects) {
            const ref = sourceObjects.get(source2);
            if (typeof ref === "object" && ref.anchor && (identity.isScalar(ref.node) || identity.isCollection(ref.node))) {
              ref.node.anchor = ref.anchor;
            } else {
              const error = new Error("Failed to resolve repeated object (this should not happen)");
              error.source = source2;
              throw error;
            }
          }
        },
        sourceObjects
      };
    }
    exports.anchorIsValid = anchorIsValid;
    exports.anchorNames = anchorNames;
    exports.createNodeAnchors = createNodeAnchors;
    exports.findNewAnchor = findNewAnchor;
  }
});

// node_modules/yaml/dist/doc/applyReviver.js
var require_applyReviver = __commonJS({
  "node_modules/yaml/dist/doc/applyReviver.js"(exports) {
    "use strict";
    function applyReviver(reviver, obj, key, val) {
      if (val && typeof val === "object") {
        if (Array.isArray(val)) {
          for (let i = 0, len = val.length; i < len; ++i) {
            const v0 = val[i];
            const v1 = applyReviver(reviver, val, String(i), v0);
            if (v1 === void 0)
              delete val[i];
            else if (v1 !== v0)
              val[i] = v1;
          }
        } else if (val instanceof Map) {
          for (const k of Array.from(val.keys())) {
            const v0 = val.get(k);
            const v1 = applyReviver(reviver, val, k, v0);
            if (v1 === void 0)
              val.delete(k);
            else if (v1 !== v0)
              val.set(k, v1);
          }
        } else if (val instanceof Set) {
          for (const v0 of Array.from(val)) {
            const v1 = applyReviver(reviver, val, v0, v0);
            if (v1 === void 0)
              val.delete(v0);
            else if (v1 !== v0) {
              val.delete(v0);
              val.add(v1);
            }
          }
        } else {
          for (const [k, v0] of Object.entries(val)) {
            const v1 = applyReviver(reviver, val, k, v0);
            if (v1 === void 0)
              delete val[k];
            else if (v1 !== v0)
              val[k] = v1;
          }
        }
      }
      return reviver.call(obj, key, val);
    }
    exports.applyReviver = applyReviver;
  }
});

// node_modules/yaml/dist/nodes/toJS.js
var require_toJS = __commonJS({
  "node_modules/yaml/dist/nodes/toJS.js"(exports) {
    "use strict";
    var identity = require_identity();
    function toJS(value, arg, ctx) {
      if (Array.isArray(value))
        return value.map((v, i) => toJS(v, String(i), ctx));
      if (value && typeof value.toJSON === "function") {
        if (!ctx || !identity.hasAnchor(value))
          return value.toJSON(arg, ctx);
        const data = { aliasCount: 0, count: 1, res: void 0 };
        ctx.anchors.set(value, data);
        ctx.onCreate = (res2) => {
          data.res = res2;
          delete ctx.onCreate;
        };
        const res = value.toJSON(arg, ctx);
        if (ctx.onCreate)
          ctx.onCreate(res);
        return res;
      }
      if (typeof value === "bigint" && !ctx?.keep)
        return Number(value);
      return value;
    }
    exports.toJS = toJS;
  }
});

// node_modules/yaml/dist/nodes/Node.js
var require_Node = __commonJS({
  "node_modules/yaml/dist/nodes/Node.js"(exports) {
    "use strict";
    var applyReviver = require_applyReviver();
    var identity = require_identity();
    var toJS = require_toJS();
    var NodeBase = class {
      constructor(type) {
        Object.defineProperty(this, identity.NODE_TYPE, { value: type });
      }
      /** Create a copy of this node.  */
      clone() {
        const copy = Object.create(Object.getPrototypeOf(this), Object.getOwnPropertyDescriptors(this));
        if (this.range)
          copy.range = this.range.slice();
        return copy;
      }
      /** A plain JavaScript representation of this node. */
      toJS(doc, { mapAsMap, maxAliasCount, onAnchor, reviver } = {}) {
        if (!identity.isDocument(doc))
          throw new TypeError("A document argument is required");
        const ctx = {
          anchors: /* @__PURE__ */ new Map(),
          doc,
          keep: true,
          mapAsMap: mapAsMap === true,
          mapKeyWarned: false,
          maxAliasCount: typeof maxAliasCount === "number" ? maxAliasCount : 100
        };
        const res = toJS.toJS(this, "", ctx);
        if (typeof onAnchor === "function")
          for (const { count, res: res2 } of ctx.anchors.values())
            onAnchor(res2, count);
        return typeof reviver === "function" ? applyReviver.applyReviver(reviver, { "": res }, "", res) : res;
      }
    };
    exports.NodeBase = NodeBase;
  }
});

// node_modules/yaml/dist/nodes/Alias.js
var require_Alias = __commonJS({
  "node_modules/yaml/dist/nodes/Alias.js"(exports) {
    "use strict";
    var anchors = require_anchors();
    var visit = require_visit();
    var identity = require_identity();
    var Node = require_Node();
    var toJS = require_toJS();
    var Alias = class extends Node.NodeBase {
      constructor(source2) {
        super(identity.ALIAS);
        this.source = source2;
        Object.defineProperty(this, "tag", {
          set() {
            throw new Error("Alias nodes cannot have tags");
          }
        });
      }
      /**
       * Resolve the value of this alias within `doc`, finding the last
       * instance of the `source` anchor before this node.
       */
      resolve(doc, ctx) {
        if (ctx?.maxAliasCount === 0)
          throw new ReferenceError("Alias resolution is disabled");
        let nodes;
        if (ctx?.aliasResolveCache) {
          nodes = ctx.aliasResolveCache;
        } else {
          nodes = [];
          visit.visit(doc, {
            Node: (_key, node) => {
              if (identity.isAlias(node) || identity.hasAnchor(node))
                nodes.push(node);
            }
          });
          if (ctx)
            ctx.aliasResolveCache = nodes;
        }
        let found = void 0;
        for (const node of nodes) {
          if (node === this)
            break;
          if (node.anchor === this.source)
            found = node;
        }
        return found;
      }
      toJSON(_arg, ctx) {
        if (!ctx)
          return { source: this.source };
        const { anchors: anchors2, doc, maxAliasCount } = ctx;
        const source2 = this.resolve(doc, ctx);
        if (!source2) {
          const msg = `Unresolved alias (the anchor must be set before the alias): ${this.source}`;
          throw new ReferenceError(msg);
        }
        let data = anchors2.get(source2);
        if (!data) {
          toJS.toJS(source2, null, ctx);
          data = anchors2.get(source2);
        }
        if (data?.res === void 0) {
          const msg = "This should not happen: Alias anchor was not resolved?";
          throw new ReferenceError(msg);
        }
        if (maxAliasCount >= 0) {
          data.count += 1;
          if (data.aliasCount === 0)
            data.aliasCount = getAliasCount(doc, source2, anchors2);
          if (data.count * data.aliasCount > maxAliasCount) {
            const msg = "Excessive alias count indicates a resource exhaustion attack";
            throw new ReferenceError(msg);
          }
        }
        return data.res;
      }
      toString(ctx, _onComment, _onChompKeep) {
        const src = `*${this.source}`;
        if (ctx) {
          anchors.anchorIsValid(this.source);
          if (ctx.options.verifyAliasOrder && !ctx.anchors.has(this.source)) {
            const msg = `Unresolved alias (the anchor must be set before the alias): ${this.source}`;
            throw new Error(msg);
          }
          if (ctx.implicitKey)
            return `${src} `;
        }
        return src;
      }
    };
    function getAliasCount(doc, node, anchors2) {
      if (identity.isAlias(node)) {
        const source2 = node.resolve(doc);
        const anchor = anchors2 && source2 && anchors2.get(source2);
        return anchor ? anchor.count * anchor.aliasCount : 0;
      } else if (identity.isCollection(node)) {
        let count = 0;
        for (const item of node.items) {
          const c = getAliasCount(doc, item, anchors2);
          if (c > count)
            count = c;
        }
        return count;
      } else if (identity.isPair(node)) {
        const kc = getAliasCount(doc, node.key, anchors2);
        const vc = getAliasCount(doc, node.value, anchors2);
        return Math.max(kc, vc);
      }
      return 1;
    }
    exports.Alias = Alias;
  }
});

// node_modules/yaml/dist/nodes/Scalar.js
var require_Scalar = __commonJS({
  "node_modules/yaml/dist/nodes/Scalar.js"(exports) {
    "use strict";
    var identity = require_identity();
    var Node = require_Node();
    var toJS = require_toJS();
    var isScalarValue = (value) => !value || typeof value !== "function" && typeof value !== "object";
    var Scalar = class extends Node.NodeBase {
      constructor(value) {
        super(identity.SCALAR);
        this.value = value;
      }
      toJSON(arg, ctx) {
        return ctx?.keep ? this.value : toJS.toJS(this.value, arg, ctx);
      }
      toString() {
        return String(this.value);
      }
    };
    Scalar.BLOCK_FOLDED = "BLOCK_FOLDED";
    Scalar.BLOCK_LITERAL = "BLOCK_LITERAL";
    Scalar.PLAIN = "PLAIN";
    Scalar.QUOTE_DOUBLE = "QUOTE_DOUBLE";
    Scalar.QUOTE_SINGLE = "QUOTE_SINGLE";
    exports.Scalar = Scalar;
    exports.isScalarValue = isScalarValue;
  }
});

// node_modules/yaml/dist/doc/createNode.js
var require_createNode = __commonJS({
  "node_modules/yaml/dist/doc/createNode.js"(exports) {
    "use strict";
    var Alias = require_Alias();
    var identity = require_identity();
    var Scalar = require_Scalar();
    var defaultTagPrefix = "tag:yaml.org,2002:";
    function findTagObject(value, tagName, tags) {
      if (tagName) {
        const match = tags.filter((t) => t.tag === tagName);
        const tagObj = match.find((t) => !t.format) ?? match[0];
        if (!tagObj)
          throw new Error(`Tag ${tagName} not found`);
        return tagObj;
      }
      return tags.find((t) => t.identify?.(value) && !t.format);
    }
    function createNode(value, tagName, ctx) {
      if (identity.isDocument(value))
        value = value.contents;
      if (identity.isNode(value))
        return value;
      if (identity.isPair(value)) {
        const map = ctx.schema[identity.MAP].createNode?.(ctx.schema, null, ctx);
        map.items.push(value);
        return map;
      }
      if (value instanceof String || value instanceof Number || value instanceof Boolean || typeof BigInt !== "undefined" && value instanceof BigInt) {
        value = value.valueOf();
      }
      const { aliasDuplicateObjects, onAnchor, onTagObj, schema: schema2, sourceObjects } = ctx;
      let ref = void 0;
      if (aliasDuplicateObjects && value && typeof value === "object") {
        ref = sourceObjects.get(value);
        if (ref) {
          ref.anchor ?? (ref.anchor = onAnchor(value));
          return new Alias.Alias(ref.anchor);
        } else {
          ref = { anchor: null, node: null };
          sourceObjects.set(value, ref);
        }
      }
      if (tagName?.startsWith("!!"))
        tagName = defaultTagPrefix + tagName.slice(2);
      let tagObj = findTagObject(value, tagName, schema2.tags);
      if (!tagObj) {
        if (value && typeof value.toJSON === "function") {
          value = value.toJSON();
        }
        if (!value || typeof value !== "object") {
          const node2 = new Scalar.Scalar(value);
          if (ref)
            ref.node = node2;
          return node2;
        }
        tagObj = value instanceof Map ? schema2[identity.MAP] : Symbol.iterator in Object(value) ? schema2[identity.SEQ] : schema2[identity.MAP];
      }
      if (onTagObj) {
        onTagObj(tagObj);
        delete ctx.onTagObj;
      }
      const node = tagObj?.createNode ? tagObj.createNode(ctx.schema, value, ctx) : typeof tagObj?.nodeClass?.from === "function" ? tagObj.nodeClass.from(ctx.schema, value, ctx) : new Scalar.Scalar(value);
      if (tagName)
        node.tag = tagName;
      else if (!tagObj.default)
        node.tag = tagObj.tag;
      if (ref)
        ref.node = node;
      return node;
    }
    exports.createNode = createNode;
  }
});

// node_modules/yaml/dist/nodes/Collection.js
var require_Collection = __commonJS({
  "node_modules/yaml/dist/nodes/Collection.js"(exports) {
    "use strict";
    var createNode = require_createNode();
    var identity = require_identity();
    var Node = require_Node();
    function collectionFromPath(schema2, path5, value) {
      let v = value;
      for (let i = path5.length - 1; i >= 0; --i) {
        const k = path5[i];
        if (typeof k === "number" && Number.isInteger(k) && k >= 0) {
          const a = [];
          a[k] = v;
          v = a;
        } else {
          v = /* @__PURE__ */ new Map([[k, v]]);
        }
      }
      return createNode.createNode(v, void 0, {
        aliasDuplicateObjects: false,
        keepUndefined: false,
        onAnchor: () => {
          throw new Error("This should not happen, please report a bug.");
        },
        schema: schema2,
        sourceObjects: /* @__PURE__ */ new Map()
      });
    }
    var isEmptyPath = (path5) => path5 == null || typeof path5 === "object" && !!path5[Symbol.iterator]().next().done;
    var Collection = class extends Node.NodeBase {
      constructor(type, schema2) {
        super(type);
        Object.defineProperty(this, "schema", {
          value: schema2,
          configurable: true,
          enumerable: false,
          writable: true
        });
      }
      /**
       * Create a copy of this collection.
       *
       * @param schema - If defined, overwrites the original's schema
       */
      clone(schema2) {
        const copy = Object.create(Object.getPrototypeOf(this), Object.getOwnPropertyDescriptors(this));
        if (schema2)
          copy.schema = schema2;
        copy.items = copy.items.map((it) => identity.isNode(it) || identity.isPair(it) ? it.clone(schema2) : it);
        if (this.range)
          copy.range = this.range.slice();
        return copy;
      }
      /**
       * Adds a value to the collection. For `!!map` and `!!omap` the value must
       * be a Pair instance or a `{ key, value }` object, which may not have a key
       * that already exists in the map.
       */
      addIn(path5, value) {
        if (isEmptyPath(path5))
          this.add(value);
        else {
          const [key, ...rest] = path5;
          const node = this.get(key, true);
          if (identity.isCollection(node))
            node.addIn(rest, value);
          else if (node === void 0 && this.schema)
            this.set(key, collectionFromPath(this.schema, rest, value));
          else
            throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
        }
      }
      /**
       * Removes a value from the collection.
       * @returns `true` if the item was found and removed.
       */
      deleteIn(path5) {
        const [key, ...rest] = path5;
        if (rest.length === 0)
          return this.delete(key);
        const node = this.get(key, true);
        if (identity.isCollection(node))
          return node.deleteIn(rest);
        else
          throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
      }
      /**
       * Returns item at `key`, or `undefined` if not found. By default unwraps
       * scalar values from their surrounding node; to disable set `keepScalar` to
       * `true` (collections are always returned intact).
       */
      getIn(path5, keepScalar) {
        const [key, ...rest] = path5;
        const node = this.get(key, true);
        if (rest.length === 0)
          return !keepScalar && identity.isScalar(node) ? node.value : node;
        else
          return identity.isCollection(node) ? node.getIn(rest, keepScalar) : void 0;
      }
      hasAllNullValues(allowScalar) {
        return this.items.every((node) => {
          if (!identity.isPair(node))
            return false;
          const n = node.value;
          return n == null || allowScalar && identity.isScalar(n) && n.value == null && !n.commentBefore && !n.comment && !n.tag;
        });
      }
      /**
       * Checks if the collection includes a value with the key `key`.
       */
      hasIn(path5) {
        const [key, ...rest] = path5;
        if (rest.length === 0)
          return this.has(key);
        const node = this.get(key, true);
        return identity.isCollection(node) ? node.hasIn(rest) : false;
      }
      /**
       * Sets a value in this collection. For `!!set`, `value` needs to be a
       * boolean to add/remove the item from the set.
       */
      setIn(path5, value) {
        const [key, ...rest] = path5;
        if (rest.length === 0) {
          this.set(key, value);
        } else {
          const node = this.get(key, true);
          if (identity.isCollection(node))
            node.setIn(rest, value);
          else if (node === void 0 && this.schema)
            this.set(key, collectionFromPath(this.schema, rest, value));
          else
            throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
        }
      }
    };
    exports.Collection = Collection;
    exports.collectionFromPath = collectionFromPath;
    exports.isEmptyPath = isEmptyPath;
  }
});

// node_modules/yaml/dist/stringify/stringifyComment.js
var require_stringifyComment = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyComment.js"(exports) {
    "use strict";
    var stringifyComment = (str) => str.replace(/^(?!$)(?: $)?/gm, "#");
    function indentComment(comment, indent) {
      if (/^\n+$/.test(comment))
        return comment.substring(1);
      return indent ? comment.replace(/^(?! *$)/gm, indent) : comment;
    }
    var lineComment = (str, indent, comment) => str.endsWith("\n") ? indentComment(comment, indent) : comment.includes("\n") ? "\n" + indentComment(comment, indent) : (str.endsWith(" ") ? "" : " ") + comment;
    exports.indentComment = indentComment;
    exports.lineComment = lineComment;
    exports.stringifyComment = stringifyComment;
  }
});

// node_modules/yaml/dist/stringify/foldFlowLines.js
var require_foldFlowLines = __commonJS({
  "node_modules/yaml/dist/stringify/foldFlowLines.js"(exports) {
    "use strict";
    var FOLD_FLOW = "flow";
    var FOLD_BLOCK = "block";
    var FOLD_QUOTED = "quoted";
    function foldFlowLines(text3, indent, mode = "flow", { indentAtStart, lineWidth = 80, minContentWidth = 20, onFold, onOverflow } = {}) {
      if (!lineWidth || lineWidth < 0)
        return text3;
      if (lineWidth < minContentWidth)
        minContentWidth = 0;
      const endStep = Math.max(1 + minContentWidth, 1 + lineWidth - indent.length);
      if (text3.length <= endStep)
        return text3;
      const folds = [];
      const escapedFolds = {};
      let end = lineWidth - indent.length;
      if (typeof indentAtStart === "number") {
        if (indentAtStart > lineWidth - Math.max(2, minContentWidth))
          folds.push(0);
        else
          end = lineWidth - indentAtStart;
      }
      let split = void 0;
      let prev = void 0;
      let overflow = false;
      let i = -1;
      let escStart = -1;
      let escEnd = -1;
      if (mode === FOLD_BLOCK) {
        i = consumeMoreIndentedLines(text3, i, indent.length);
        if (i !== -1)
          end = i + endStep;
      }
      for (let ch; ch = text3[i += 1]; ) {
        if (mode === FOLD_QUOTED && ch === "\\") {
          escStart = i;
          switch (text3[i + 1]) {
            case "x":
              i += 3;
              break;
            case "u":
              i += 5;
              break;
            case "U":
              i += 9;
              break;
            default:
              i += 1;
          }
          escEnd = i;
        }
        if (ch === "\n") {
          if (mode === FOLD_BLOCK)
            i = consumeMoreIndentedLines(text3, i, indent.length);
          end = i + indent.length + endStep;
          split = void 0;
        } else {
          if (ch === " " && prev && prev !== " " && prev !== "\n" && prev !== "	") {
            const next = text3[i + 1];
            if (next && next !== " " && next !== "\n" && next !== "	")
              split = i;
          }
          if (i >= end) {
            if (split) {
              folds.push(split);
              end = split + endStep;
              split = void 0;
            } else if (mode === FOLD_QUOTED) {
              while (prev === " " || prev === "	") {
                prev = ch;
                ch = text3[i += 1];
                overflow = true;
              }
              const j = i > escEnd + 1 ? i - 2 : escStart - 1;
              if (escapedFolds[j])
                return text3;
              folds.push(j);
              escapedFolds[j] = true;
              end = j + endStep;
              split = void 0;
            } else {
              overflow = true;
            }
          }
        }
        prev = ch;
      }
      if (overflow && onOverflow)
        onOverflow();
      if (folds.length === 0)
        return text3;
      if (onFold)
        onFold();
      let res = text3.slice(0, folds[0]);
      for (let i2 = 0; i2 < folds.length; ++i2) {
        const fold = folds[i2];
        const end2 = folds[i2 + 1] || text3.length;
        if (fold === 0)
          res = `
${indent}${text3.slice(0, end2)}`;
        else {
          if (mode === FOLD_QUOTED && escapedFolds[fold])
            res += `${text3[fold]}\\`;
          res += `
${indent}${text3.slice(fold + 1, end2)}`;
        }
      }
      return res;
    }
    function consumeMoreIndentedLines(text3, i, indent) {
      let end = i;
      let start = i + 1;
      let ch = text3[start];
      while (ch === " " || ch === "	") {
        if (i < start + indent) {
          ch = text3[++i];
        } else {
          do {
            ch = text3[++i];
          } while (ch && ch !== "\n");
          end = i;
          start = i + 1;
          ch = text3[start];
        }
      }
      return end;
    }
    exports.FOLD_BLOCK = FOLD_BLOCK;
    exports.FOLD_FLOW = FOLD_FLOW;
    exports.FOLD_QUOTED = FOLD_QUOTED;
    exports.foldFlowLines = foldFlowLines;
  }
});

// node_modules/yaml/dist/stringify/stringifyString.js
var require_stringifyString = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyString.js"(exports) {
    "use strict";
    var Scalar = require_Scalar();
    var foldFlowLines = require_foldFlowLines();
    var getFoldOptions = (ctx, isBlock) => ({
      indentAtStart: isBlock ? ctx.indent.length : ctx.indentAtStart,
      lineWidth: ctx.options.lineWidth,
      minContentWidth: ctx.options.minContentWidth
    });
    var containsDocumentMarker = (str) => /^(%|---|\.\.\.)/m.test(str);
    function lineLengthOverLimit(str, lineWidth, indentLength) {
      if (!lineWidth || lineWidth < 0)
        return false;
      const limit = lineWidth - indentLength;
      const strLen = str.length;
      if (strLen <= limit)
        return false;
      for (let i = 0, start = 0; i < strLen; ++i) {
        if (str[i] === "\n") {
          if (i - start > limit)
            return true;
          start = i + 1;
          if (strLen - start <= limit)
            return false;
        }
      }
      return true;
    }
    function doubleQuotedString(value, ctx) {
      const json2 = JSON.stringify(value);
      if (ctx.options.doubleQuotedAsJSON)
        return json2;
      const { implicitKey } = ctx;
      const minMultiLineLength = ctx.options.doubleQuotedMinMultiLineLength;
      const indent = ctx.indent || (containsDocumentMarker(value) ? "  " : "");
      let str = "";
      let start = 0;
      for (let i = 0, ch = json2[i]; ch; ch = json2[++i]) {
        if (ch === " " && json2[i + 1] === "\\" && json2[i + 2] === "n") {
          str += json2.slice(start, i) + "\\ ";
          i += 1;
          start = i;
          ch = "\\";
        }
        if (ch === "\\")
          switch (json2[i + 1]) {
            case "u":
              {
                str += json2.slice(start, i);
                const code = json2.substr(i + 2, 4);
                switch (code) {
                  case "0000":
                    str += "\\0";
                    break;
                  case "0007":
                    str += "\\a";
                    break;
                  case "000b":
                    str += "\\v";
                    break;
                  case "001b":
                    str += "\\e";
                    break;
                  case "0085":
                    str += "\\N";
                    break;
                  case "00a0":
                    str += "\\_";
                    break;
                  case "2028":
                    str += "\\L";
                    break;
                  case "2029":
                    str += "\\P";
                    break;
                  default:
                    if (code.substr(0, 2) === "00")
                      str += "\\x" + code.substr(2);
                    else
                      str += json2.substr(i, 6);
                }
                i += 5;
                start = i + 1;
              }
              break;
            case "n":
              if (implicitKey || json2[i + 2] === '"' || json2.length < minMultiLineLength) {
                i += 1;
              } else {
                str += json2.slice(start, i) + "\n\n";
                while (json2[i + 2] === "\\" && json2[i + 3] === "n" && json2[i + 4] !== '"') {
                  str += "\n";
                  i += 2;
                }
                str += indent;
                if (json2[i + 2] === " ")
                  str += "\\";
                i += 1;
                start = i + 1;
              }
              break;
            default:
              i += 1;
          }
      }
      str = start ? str + json2.slice(start) : json2;
      return implicitKey ? str : foldFlowLines.foldFlowLines(str, indent, foldFlowLines.FOLD_QUOTED, getFoldOptions(ctx, false));
    }
    function singleQuotedString(value, ctx) {
      if (ctx.options.singleQuote === false || ctx.implicitKey && value.includes("\n") || /[ \t]\n|\n[ \t]/.test(value))
        return doubleQuotedString(value, ctx);
      const indent = ctx.indent || (containsDocumentMarker(value) ? "  " : "");
      const res = "'" + value.replace(/'/g, "''").replace(/\n+/g, `$&
${indent}`) + "'";
      return ctx.implicitKey ? res : foldFlowLines.foldFlowLines(res, indent, foldFlowLines.FOLD_FLOW, getFoldOptions(ctx, false));
    }
    function quotedString(value, ctx) {
      const { singleQuote } = ctx.options;
      let qs;
      if (singleQuote === false)
        qs = doubleQuotedString;
      else {
        const hasDouble = value.includes('"');
        const hasSingle = value.includes("'");
        if (hasDouble && !hasSingle)
          qs = singleQuotedString;
        else if (hasSingle && !hasDouble)
          qs = doubleQuotedString;
        else
          qs = singleQuote ? singleQuotedString : doubleQuotedString;
      }
      return qs(value, ctx);
    }
    var blockEndNewlines;
    try {
      blockEndNewlines = new RegExp("(^|(?<!\n))\n+(?!\n|$)", "g");
    } catch {
      blockEndNewlines = /\n+(?!\n|$)/g;
    }
    function blockString({ comment, type, value }, ctx, onComment, onChompKeep) {
      const { blockQuote, commentString, lineWidth } = ctx.options;
      if (!blockQuote || /\n[\t ]+$/.test(value)) {
        return quotedString(value, ctx);
      }
      const indent = ctx.indent || (ctx.forceBlockIndent || containsDocumentMarker(value) ? "  " : "");
      const literal = blockQuote === "literal" ? true : blockQuote === "folded" || type === Scalar.Scalar.BLOCK_FOLDED ? false : type === Scalar.Scalar.BLOCK_LITERAL ? true : !lineLengthOverLimit(value, lineWidth, indent.length);
      if (!value)
        return literal ? "|\n" : ">\n";
      let chomp;
      let endStart;
      for (endStart = value.length; endStart > 0; --endStart) {
        const ch = value[endStart - 1];
        if (ch !== "\n" && ch !== "	" && ch !== " ")
          break;
      }
      let end = value.substring(endStart);
      const endNlPos = end.indexOf("\n");
      if (endNlPos === -1) {
        chomp = "-";
      } else if (value === end || endNlPos !== end.length - 1) {
        chomp = "+";
        if (onChompKeep)
          onChompKeep();
      } else {
        chomp = "";
      }
      if (end) {
        value = value.slice(0, -end.length);
        if (end[end.length - 1] === "\n")
          end = end.slice(0, -1);
        end = end.replace(blockEndNewlines, `$&${indent}`);
      }
      let startWithSpace = false;
      let startEnd;
      let startNlPos = -1;
      for (startEnd = 0; startEnd < value.length; ++startEnd) {
        const ch = value[startEnd];
        if (ch === " ")
          startWithSpace = true;
        else if (ch === "\n")
          startNlPos = startEnd;
        else
          break;
      }
      let start = value.substring(0, startNlPos < startEnd ? startNlPos + 1 : startEnd);
      if (start) {
        value = value.substring(start.length);
        start = start.replace(/\n+/g, `$&${indent}`);
      }
      const indentSize = indent ? "2" : "1";
      let header = (startWithSpace ? indentSize : "") + chomp;
      if (comment) {
        header += " " + commentString(comment.replace(/ ?[\r\n]+/g, " "));
        if (onComment)
          onComment();
      }
      if (!literal) {
        const foldedValue = value.replace(/\n+/g, "\n$&").replace(/(?:^|\n)([\t ].*)(?:([\n\t ]*)\n(?![\n\t ]))?/g, "$1$2").replace(/\n+/g, `$&${indent}`);
        let literalFallback = false;
        const foldOptions = getFoldOptions(ctx, true);
        if (blockQuote !== "folded" && type !== Scalar.Scalar.BLOCK_FOLDED) {
          foldOptions.onOverflow = () => {
            literalFallback = true;
          };
        }
        const body = foldFlowLines.foldFlowLines(`${start}${foldedValue}${end}`, indent, foldFlowLines.FOLD_BLOCK, foldOptions);
        if (!literalFallback)
          return `>${header}
${indent}${body}`;
      }
      value = value.replace(/\n+/g, `$&${indent}`);
      return `|${header}
${indent}${start}${value}${end}`;
    }
    function plainString(item, ctx, onComment, onChompKeep) {
      const { type, value } = item;
      const { actualString, implicitKey, indent, indentStep, inFlow } = ctx;
      if (implicitKey && value.includes("\n") || inFlow && /[[\]{},]/.test(value)) {
        return quotedString(value, ctx);
      }
      if (/^[\n\t ,[\]{}#&*!|>'"%@`]|^[?-]$|^[?-][ \t]|[\n:][ \t]|[ \t]\n|[\n\t ]#|[\n\t :]$/.test(value)) {
        return implicitKey || inFlow || !value.includes("\n") ? quotedString(value, ctx) : blockString(item, ctx, onComment, onChompKeep);
      }
      if (!implicitKey && !inFlow && type !== Scalar.Scalar.PLAIN && value.includes("\n")) {
        return blockString(item, ctx, onComment, onChompKeep);
      }
      if (containsDocumentMarker(value)) {
        if (indent === "") {
          ctx.forceBlockIndent = true;
          return blockString(item, ctx, onComment, onChompKeep);
        } else if (implicitKey && indent === indentStep) {
          return quotedString(value, ctx);
        }
      }
      const str = value.replace(/\n+/g, `$&
${indent}`);
      if (actualString) {
        const test = (tag) => tag.default && tag.tag !== "tag:yaml.org,2002:str" && tag.test?.test(str);
        const { compat, tags } = ctx.doc.schema;
        if (tags.some(test) || compat?.some(test))
          return quotedString(value, ctx);
      }
      return implicitKey ? str : foldFlowLines.foldFlowLines(str, indent, foldFlowLines.FOLD_FLOW, getFoldOptions(ctx, false));
    }
    function stringifyString(item, ctx, onComment, onChompKeep) {
      const { implicitKey, inFlow } = ctx;
      const ss = typeof item.value === "string" ? item : Object.assign({}, item, { value: String(item.value) });
      let { type } = item;
      if (type !== Scalar.Scalar.QUOTE_DOUBLE) {
        if (/[\x00-\x08\x0b-\x1f\x7f-\x9f\u{D800}-\u{DFFF}]/u.test(ss.value))
          type = Scalar.Scalar.QUOTE_DOUBLE;
      }
      const _stringify = (_type) => {
        switch (_type) {
          case Scalar.Scalar.BLOCK_FOLDED:
          case Scalar.Scalar.BLOCK_LITERAL:
            return implicitKey || inFlow ? quotedString(ss.value, ctx) : blockString(ss, ctx, onComment, onChompKeep);
          case Scalar.Scalar.QUOTE_DOUBLE:
            return doubleQuotedString(ss.value, ctx);
          case Scalar.Scalar.QUOTE_SINGLE:
            return singleQuotedString(ss.value, ctx);
          case Scalar.Scalar.PLAIN:
            return plainString(ss, ctx, onComment, onChompKeep);
          default:
            return null;
        }
      };
      let res = _stringify(type);
      if (res === null) {
        const { defaultKeyType, defaultStringType } = ctx.options;
        const t = implicitKey && defaultKeyType || defaultStringType;
        res = _stringify(t);
        if (res === null)
          throw new Error(`Unsupported default string type ${t}`);
      }
      return res;
    }
    exports.stringifyString = stringifyString;
  }
});

// node_modules/yaml/dist/stringify/stringify.js
var require_stringify = __commonJS({
  "node_modules/yaml/dist/stringify/stringify.js"(exports) {
    "use strict";
    var anchors = require_anchors();
    var identity = require_identity();
    var stringifyComment = require_stringifyComment();
    var stringifyString = require_stringifyString();
    function createStringifyContext(doc, options) {
      const opt = Object.assign({
        blockQuote: true,
        commentString: stringifyComment.stringifyComment,
        defaultKeyType: null,
        defaultStringType: "PLAIN",
        directives: null,
        doubleQuotedAsJSON: false,
        doubleQuotedMinMultiLineLength: 40,
        falseStr: "false",
        flowCollectionPadding: true,
        indentSeq: true,
        lineWidth: 80,
        minContentWidth: 20,
        nullStr: "null",
        simpleKeys: false,
        singleQuote: null,
        trailingComma: false,
        trueStr: "true",
        verifyAliasOrder: true
      }, doc.schema.toStringOptions, options);
      let inFlow;
      switch (opt.collectionStyle) {
        case "block":
          inFlow = false;
          break;
        case "flow":
          inFlow = true;
          break;
        default:
          inFlow = null;
      }
      return {
        anchors: /* @__PURE__ */ new Set(),
        doc,
        flowCollectionPadding: opt.flowCollectionPadding ? " " : "",
        indent: "",
        indentStep: typeof opt.indent === "number" ? " ".repeat(opt.indent) : "  ",
        inFlow,
        options: opt
      };
    }
    function getTagObject(tags, item) {
      if (item.tag) {
        const match = tags.filter((t) => t.tag === item.tag);
        if (match.length > 0)
          return match.find((t) => t.format === item.format) ?? match[0];
      }
      let tagObj = void 0;
      let obj;
      if (identity.isScalar(item)) {
        obj = item.value;
        let match = tags.filter((t) => t.identify?.(obj));
        if (match.length > 1) {
          const testMatch = match.filter((t) => t.test);
          if (testMatch.length > 0)
            match = testMatch;
        }
        tagObj = match.find((t) => t.format === item.format) ?? match.find((t) => !t.format);
      } else {
        obj = item;
        tagObj = tags.find((t) => t.nodeClass && obj instanceof t.nodeClass);
      }
      if (!tagObj) {
        const name = obj?.constructor?.name ?? (obj === null ? "null" : typeof obj);
        throw new Error(`Tag not resolved for ${name} value`);
      }
      return tagObj;
    }
    function stringifyProps(node, tagObj, { anchors: anchors$1, doc }) {
      if (!doc.directives)
        return "";
      const props = [];
      const anchor = (identity.isScalar(node) || identity.isCollection(node)) && node.anchor;
      if (anchor && anchors.anchorIsValid(anchor)) {
        anchors$1.add(anchor);
        props.push(`&${anchor}`);
      }
      const tag = node.tag ?? (tagObj.default ? null : tagObj.tag);
      if (tag)
        props.push(doc.directives.tagString(tag));
      return props.join(" ");
    }
    function stringify2(item, ctx, onComment, onChompKeep) {
      if (identity.isPair(item))
        return item.toString(ctx, onComment, onChompKeep);
      if (identity.isAlias(item)) {
        if (ctx.doc.directives)
          return item.toString(ctx);
        if (ctx.resolvedAliases?.has(item)) {
          throw new TypeError(`Cannot stringify circular structure without alias nodes`);
        } else {
          if (ctx.resolvedAliases)
            ctx.resolvedAliases.add(item);
          else
            ctx.resolvedAliases = /* @__PURE__ */ new Set([item]);
          item = item.resolve(ctx.doc);
        }
      }
      let tagObj = void 0;
      const node = identity.isNode(item) ? item : ctx.doc.createNode(item, { onTagObj: (o) => tagObj = o });
      tagObj ?? (tagObj = getTagObject(ctx.doc.schema.tags, node));
      const props = stringifyProps(node, tagObj, ctx);
      if (props.length > 0)
        ctx.indentAtStart = (ctx.indentAtStart ?? 0) + props.length + 1;
      const str = typeof tagObj.stringify === "function" ? tagObj.stringify(node, ctx, onComment, onChompKeep) : identity.isScalar(node) ? stringifyString.stringifyString(node, ctx, onComment, onChompKeep) : node.toString(ctx, onComment, onChompKeep);
      if (!props)
        return str;
      return identity.isScalar(node) || str[0] === "{" || str[0] === "[" ? `${props} ${str}` : `${props}
${ctx.indent}${str}`;
    }
    exports.createStringifyContext = createStringifyContext;
    exports.stringify = stringify2;
  }
});

// node_modules/yaml/dist/stringify/stringifyPair.js
var require_stringifyPair = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyPair.js"(exports) {
    "use strict";
    var identity = require_identity();
    var Scalar = require_Scalar();
    var stringify2 = require_stringify();
    var stringifyComment = require_stringifyComment();
    function stringifyPair({ key, value }, ctx, onComment, onChompKeep) {
      const { allNullValues, doc, indent, indentStep, options: { commentString, indentSeq, simpleKeys } } = ctx;
      let keyComment = identity.isNode(key) && key.comment || null;
      if (simpleKeys) {
        if (keyComment) {
          throw new Error("With simple keys, key nodes cannot have comments");
        }
        if (identity.isCollection(key) || !identity.isNode(key) && typeof key === "object") {
          const msg = "With simple keys, collection cannot be used as a key value";
          throw new Error(msg);
        }
      }
      let explicitKey = !simpleKeys && (!key || keyComment && value == null && !ctx.inFlow || identity.isCollection(key) || (identity.isScalar(key) ? key.type === Scalar.Scalar.BLOCK_FOLDED || key.type === Scalar.Scalar.BLOCK_LITERAL : typeof key === "object"));
      ctx = Object.assign({}, ctx, {
        allNullValues: false,
        implicitKey: !explicitKey && (simpleKeys || !allNullValues),
        indent: indent + indentStep
      });
      let keyCommentDone = false;
      let chompKeep = false;
      let str = stringify2.stringify(key, ctx, () => keyCommentDone = true, () => chompKeep = true);
      if (!explicitKey && !ctx.inFlow && str.length > 1024) {
        if (simpleKeys)
          throw new Error("With simple keys, single line scalar must not span more than 1024 characters");
        explicitKey = true;
      }
      if (ctx.inFlow) {
        if (allNullValues || value == null) {
          if (keyCommentDone && onComment)
            onComment();
          return str === "" ? "?" : explicitKey ? `? ${str}` : str;
        }
      } else if (allNullValues && !simpleKeys || value == null && explicitKey) {
        str = `? ${str}`;
        if (keyComment && !keyCommentDone) {
          str += stringifyComment.lineComment(str, ctx.indent, commentString(keyComment));
        } else if (chompKeep && onChompKeep)
          onChompKeep();
        return str;
      }
      if (keyCommentDone)
        keyComment = null;
      if (explicitKey) {
        if (keyComment)
          str += stringifyComment.lineComment(str, ctx.indent, commentString(keyComment));
        str = `? ${str}
${indent}:`;
      } else {
        str = `${str}:`;
        if (keyComment)
          str += stringifyComment.lineComment(str, ctx.indent, commentString(keyComment));
      }
      let vsb, vcb, valueComment;
      if (identity.isNode(value)) {
        vsb = !!value.spaceBefore;
        vcb = value.commentBefore;
        valueComment = value.comment;
      } else {
        vsb = false;
        vcb = null;
        valueComment = null;
        if (value && typeof value === "object")
          value = doc.createNode(value);
      }
      ctx.implicitKey = false;
      if (!explicitKey && !keyComment && identity.isScalar(value))
        ctx.indentAtStart = str.length + 1;
      chompKeep = false;
      if (!indentSeq && indentStep.length >= 2 && !ctx.inFlow && !explicitKey && identity.isSeq(value) && !value.flow && !value.tag && !value.anchor) {
        ctx.indent = ctx.indent.substring(2);
      }
      let valueCommentDone = false;
      const valueStr = stringify2.stringify(value, ctx, () => valueCommentDone = true, () => chompKeep = true);
      let ws = " ";
      if (keyComment || vsb || vcb) {
        ws = vsb ? "\n" : "";
        if (vcb) {
          const cs = commentString(vcb);
          ws += `
${stringifyComment.indentComment(cs, ctx.indent)}`;
        }
        if (valueStr === "" && !ctx.inFlow) {
          if (ws === "\n" && valueComment)
            ws = "\n\n";
        } else {
          ws += `
${ctx.indent}`;
        }
      } else if (!explicitKey && identity.isCollection(value)) {
        const vs0 = valueStr[0];
        const nl0 = valueStr.indexOf("\n");
        const hasNewline = nl0 !== -1;
        const flow = ctx.inFlow ?? value.flow ?? value.items.length === 0;
        if (hasNewline || !flow) {
          let hasPropsLine = false;
          if (hasNewline && (vs0 === "&" || vs0 === "!")) {
            let sp0 = valueStr.indexOf(" ");
            if (vs0 === "&" && sp0 !== -1 && sp0 < nl0 && valueStr[sp0 + 1] === "!") {
              sp0 = valueStr.indexOf(" ", sp0 + 1);
            }
            if (sp0 === -1 || nl0 < sp0)
              hasPropsLine = true;
          }
          if (!hasPropsLine)
            ws = `
${ctx.indent}`;
        }
      } else if (valueStr === "" || valueStr[0] === "\n") {
        ws = "";
      }
      str += ws + valueStr;
      if (ctx.inFlow) {
        if (valueCommentDone && onComment)
          onComment();
      } else if (valueComment && !valueCommentDone) {
        str += stringifyComment.lineComment(str, ctx.indent, commentString(valueComment));
      } else if (chompKeep && onChompKeep) {
        onChompKeep();
      }
      return str;
    }
    exports.stringifyPair = stringifyPair;
  }
});

// node_modules/yaml/dist/log.js
var require_log = __commonJS({
  "node_modules/yaml/dist/log.js"(exports) {
    "use strict";
    var node_process = __require("process");
    function debug(logLevel, ...messages) {
      if (logLevel === "debug")
        console.log(...messages);
    }
    function warn(logLevel, warning) {
      if (logLevel === "debug" || logLevel === "warn") {
        if (typeof node_process.emitWarning === "function")
          node_process.emitWarning(warning);
        else
          console.warn(warning);
      }
    }
    exports.debug = debug;
    exports.warn = warn;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/merge.js
var require_merge = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/merge.js"(exports) {
    "use strict";
    var identity = require_identity();
    var Scalar = require_Scalar();
    var MERGE_KEY = "<<";
    var merge = {
      identify: (value) => value === MERGE_KEY || typeof value === "symbol" && value.description === MERGE_KEY,
      default: "key",
      tag: "tag:yaml.org,2002:merge",
      test: /^<<$/,
      resolve: () => Object.assign(new Scalar.Scalar(Symbol(MERGE_KEY)), {
        addToJSMap: addMergeToJSMap
      }),
      stringify: () => MERGE_KEY
    };
    var isMergeKey = (ctx, key) => (merge.identify(key) || identity.isScalar(key) && (!key.type || key.type === Scalar.Scalar.PLAIN) && merge.identify(key.value)) && ctx?.doc.schema.tags.some((tag) => tag.tag === merge.tag && tag.default);
    function addMergeToJSMap(ctx, map, value) {
      const source2 = resolveAliasValue(ctx, value);
      if (identity.isSeq(source2))
        for (const it of source2.items)
          mergeValue(ctx, map, it);
      else if (Array.isArray(source2))
        for (const it of source2)
          mergeValue(ctx, map, it);
      else
        mergeValue(ctx, map, source2);
    }
    function mergeValue(ctx, map, value) {
      const source2 = resolveAliasValue(ctx, value);
      if (!identity.isMap(source2))
        throw new Error("Merge sources must be maps or map aliases");
      const srcMap = source2.toJSON(null, ctx, Map);
      for (const [key, value2] of srcMap) {
        if (map instanceof Map) {
          if (!map.has(key))
            map.set(key, value2);
        } else if (map instanceof Set) {
          map.add(key);
        } else if (!Object.prototype.hasOwnProperty.call(map, key)) {
          Object.defineProperty(map, key, {
            value: value2,
            writable: true,
            enumerable: true,
            configurable: true
          });
        }
      }
      return map;
    }
    function resolveAliasValue(ctx, value) {
      return ctx && identity.isAlias(value) ? value.resolve(ctx.doc, ctx) : value;
    }
    exports.addMergeToJSMap = addMergeToJSMap;
    exports.isMergeKey = isMergeKey;
    exports.merge = merge;
  }
});

// node_modules/yaml/dist/nodes/addPairToJSMap.js
var require_addPairToJSMap = __commonJS({
  "node_modules/yaml/dist/nodes/addPairToJSMap.js"(exports) {
    "use strict";
    var log = require_log();
    var merge = require_merge();
    var stringify2 = require_stringify();
    var identity = require_identity();
    var toJS = require_toJS();
    function addPairToJSMap(ctx, map, { key, value }) {
      if (identity.isNode(key) && key.addToJSMap)
        key.addToJSMap(ctx, map, value);
      else if (merge.isMergeKey(ctx, key))
        merge.addMergeToJSMap(ctx, map, value);
      else {
        const jsKey = toJS.toJS(key, "", ctx);
        if (map instanceof Map) {
          map.set(jsKey, toJS.toJS(value, jsKey, ctx));
        } else if (map instanceof Set) {
          map.add(jsKey);
        } else {
          const stringKey = stringifyKey(key, jsKey, ctx);
          const jsValue = toJS.toJS(value, stringKey, ctx);
          if (stringKey in map)
            Object.defineProperty(map, stringKey, {
              value: jsValue,
              writable: true,
              enumerable: true,
              configurable: true
            });
          else
            map[stringKey] = jsValue;
        }
      }
      return map;
    }
    function stringifyKey(key, jsKey, ctx) {
      if (jsKey === null)
        return "";
      if (typeof jsKey !== "object")
        return String(jsKey);
      if (identity.isNode(key) && ctx?.doc) {
        const strCtx = stringify2.createStringifyContext(ctx.doc, {});
        strCtx.anchors = /* @__PURE__ */ new Set();
        for (const node of ctx.anchors.keys())
          strCtx.anchors.add(node.anchor);
        strCtx.inFlow = true;
        strCtx.inStringifyKey = true;
        const strKey = key.toString(strCtx);
        if (!ctx.mapKeyWarned) {
          let jsonStr = JSON.stringify(strKey);
          if (jsonStr.length > 40)
            jsonStr = jsonStr.substring(0, 36) + '..."';
          log.warn(ctx.doc.options.logLevel, `Keys with collection values will be stringified due to JS Object restrictions: ${jsonStr}. Set mapAsMap: true to use object keys.`);
          ctx.mapKeyWarned = true;
        }
        return strKey;
      }
      return JSON.stringify(jsKey);
    }
    exports.addPairToJSMap = addPairToJSMap;
  }
});

// node_modules/yaml/dist/nodes/Pair.js
var require_Pair = __commonJS({
  "node_modules/yaml/dist/nodes/Pair.js"(exports) {
    "use strict";
    var createNode = require_createNode();
    var stringifyPair = require_stringifyPair();
    var addPairToJSMap = require_addPairToJSMap();
    var identity = require_identity();
    function createPair(key, value, ctx) {
      const k = createNode.createNode(key, void 0, ctx);
      const v = createNode.createNode(value, void 0, ctx);
      return new Pair(k, v);
    }
    var Pair = class _Pair {
      constructor(key, value = null) {
        Object.defineProperty(this, identity.NODE_TYPE, { value: identity.PAIR });
        this.key = key;
        this.value = value;
      }
      clone(schema2) {
        let { key, value } = this;
        if (identity.isNode(key))
          key = key.clone(schema2);
        if (identity.isNode(value))
          value = value.clone(schema2);
        return new _Pair(key, value);
      }
      toJSON(_, ctx) {
        const pair = ctx?.mapAsMap ? /* @__PURE__ */ new Map() : {};
        return addPairToJSMap.addPairToJSMap(ctx, pair, this);
      }
      toString(ctx, onComment, onChompKeep) {
        return ctx?.doc ? stringifyPair.stringifyPair(this, ctx, onComment, onChompKeep) : JSON.stringify(this);
      }
    };
    exports.Pair = Pair;
    exports.createPair = createPair;
  }
});

// node_modules/yaml/dist/stringify/stringifyCollection.js
var require_stringifyCollection = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyCollection.js"(exports) {
    "use strict";
    var identity = require_identity();
    var stringify2 = require_stringify();
    var stringifyComment = require_stringifyComment();
    function stringifyCollection(collection, ctx, options) {
      const flow = ctx.inFlow ?? collection.flow;
      const stringify3 = flow ? stringifyFlowCollection : stringifyBlockCollection;
      return stringify3(collection, ctx, options);
    }
    function stringifyBlockCollection({ comment, items }, ctx, { blockItemPrefix, flowChars, itemIndent, onChompKeep, onComment }) {
      const { indent, options: { commentString } } = ctx;
      const itemCtx = Object.assign({}, ctx, { indent: itemIndent, type: null });
      let chompKeep = false;
      const lines = [];
      for (let i = 0; i < items.length; ++i) {
        const item = items[i];
        let comment2 = null;
        if (identity.isNode(item)) {
          if (!chompKeep && item.spaceBefore)
            lines.push("");
          addCommentBefore(ctx, lines, item.commentBefore, chompKeep);
          if (item.comment)
            comment2 = item.comment;
        } else if (identity.isPair(item)) {
          const ik = identity.isNode(item.key) ? item.key : null;
          if (ik) {
            if (!chompKeep && ik.spaceBefore)
              lines.push("");
            addCommentBefore(ctx, lines, ik.commentBefore, chompKeep);
          }
        }
        chompKeep = false;
        let str2 = stringify2.stringify(item, itemCtx, () => comment2 = null, () => chompKeep = true);
        if (comment2)
          str2 += stringifyComment.lineComment(str2, itemIndent, commentString(comment2));
        if (chompKeep && comment2)
          chompKeep = false;
        lines.push(blockItemPrefix + str2);
      }
      let str;
      if (lines.length === 0) {
        str = flowChars.start + flowChars.end;
      } else {
        str = lines[0];
        for (let i = 1; i < lines.length; ++i) {
          const line = lines[i];
          str += line ? `
${indent}${line}` : "\n";
        }
      }
      if (comment) {
        str += "\n" + stringifyComment.indentComment(commentString(comment), indent);
        if (onComment)
          onComment();
      } else if (chompKeep && onChompKeep)
        onChompKeep();
      return str;
    }
    function stringifyFlowCollection({ items }, ctx, { flowChars, itemIndent }) {
      const { indent, indentStep, flowCollectionPadding: fcPadding, options: { commentString } } = ctx;
      itemIndent += indentStep;
      const itemCtx = Object.assign({}, ctx, {
        indent: itemIndent,
        inFlow: true,
        type: null
      });
      let reqNewline = false;
      let linesAtValue = 0;
      const lines = [];
      for (let i = 0; i < items.length; ++i) {
        const item = items[i];
        let comment = null;
        if (identity.isNode(item)) {
          if (item.spaceBefore)
            lines.push("");
          addCommentBefore(ctx, lines, item.commentBefore, false);
          if (item.comment)
            comment = item.comment;
        } else if (identity.isPair(item)) {
          const ik = identity.isNode(item.key) ? item.key : null;
          if (ik) {
            if (ik.spaceBefore)
              lines.push("");
            addCommentBefore(ctx, lines, ik.commentBefore, false);
            if (ik.comment)
              reqNewline = true;
          }
          const iv = identity.isNode(item.value) ? item.value : null;
          if (iv) {
            if (iv.comment)
              comment = iv.comment;
            if (iv.commentBefore)
              reqNewline = true;
          } else if (item.value == null && ik?.comment) {
            comment = ik.comment;
          }
        }
        if (comment)
          reqNewline = true;
        let str = stringify2.stringify(item, itemCtx, () => comment = null);
        reqNewline || (reqNewline = lines.length > linesAtValue || str.includes("\n"));
        if (i < items.length - 1) {
          str += ",";
        } else if (ctx.options.trailingComma) {
          if (ctx.options.lineWidth > 0) {
            reqNewline || (reqNewline = lines.reduce((sum, line) => sum + line.length + 2, 2) + (str.length + 2) > ctx.options.lineWidth);
          }
          if (reqNewline) {
            str += ",";
          }
        }
        if (comment)
          str += stringifyComment.lineComment(str, itemIndent, commentString(comment));
        lines.push(str);
        linesAtValue = lines.length;
      }
      const { start, end } = flowChars;
      if (lines.length === 0) {
        return start + end;
      } else {
        if (!reqNewline) {
          const len = lines.reduce((sum, line) => sum + line.length + 2, 2);
          reqNewline = ctx.options.lineWidth > 0 && len > ctx.options.lineWidth;
        }
        if (reqNewline) {
          let str = start;
          for (const line of lines)
            str += line ? `
${indentStep}${indent}${line}` : "\n";
          return `${str}
${indent}${end}`;
        } else {
          return `${start}${fcPadding}${lines.join(" ")}${fcPadding}${end}`;
        }
      }
    }
    function addCommentBefore({ indent, options: { commentString } }, lines, comment, chompKeep) {
      if (comment && chompKeep)
        comment = comment.replace(/^\n+/, "");
      if (comment) {
        const ic = stringifyComment.indentComment(commentString(comment), indent);
        lines.push(ic.trimStart());
      }
    }
    exports.stringifyCollection = stringifyCollection;
  }
});

// node_modules/yaml/dist/nodes/YAMLMap.js
var require_YAMLMap = __commonJS({
  "node_modules/yaml/dist/nodes/YAMLMap.js"(exports) {
    "use strict";
    var stringifyCollection = require_stringifyCollection();
    var addPairToJSMap = require_addPairToJSMap();
    var Collection = require_Collection();
    var identity = require_identity();
    var Pair = require_Pair();
    var Scalar = require_Scalar();
    function findPair(items, key) {
      const k = identity.isScalar(key) ? key.value : key;
      for (const it of items) {
        if (identity.isPair(it)) {
          if (it.key === key || it.key === k)
            return it;
          if (identity.isScalar(it.key) && it.key.value === k)
            return it;
        }
      }
      return void 0;
    }
    var YAMLMap = class extends Collection.Collection {
      static get tagName() {
        return "tag:yaml.org,2002:map";
      }
      constructor(schema2) {
        super(identity.MAP, schema2);
        this.items = [];
      }
      /**
       * A generic collection parsing method that can be extended
       * to other node classes that inherit from YAMLMap
       */
      static from(schema2, obj, ctx) {
        const { keepUndefined, replacer } = ctx;
        const map = new this(schema2);
        const add = (key, value) => {
          if (typeof replacer === "function")
            value = replacer.call(obj, key, value);
          else if (Array.isArray(replacer) && !replacer.includes(key))
            return;
          if (value !== void 0 || keepUndefined)
            map.items.push(Pair.createPair(key, value, ctx));
        };
        if (obj instanceof Map) {
          for (const [key, value] of obj)
            add(key, value);
        } else if (obj && typeof obj === "object") {
          for (const key of Object.keys(obj))
            add(key, obj[key]);
        }
        if (typeof schema2.sortMapEntries === "function") {
          map.items.sort(schema2.sortMapEntries);
        }
        return map;
      }
      /**
       * Adds a value to the collection.
       *
       * @param overwrite - If not set `true`, using a key that is already in the
       *   collection will throw. Otherwise, overwrites the previous value.
       */
      add(pair, overwrite) {
        let _pair;
        if (identity.isPair(pair))
          _pair = pair;
        else if (!pair || typeof pair !== "object" || !("key" in pair)) {
          _pair = new Pair.Pair(pair, pair?.value);
        } else
          _pair = new Pair.Pair(pair.key, pair.value);
        const prev = findPair(this.items, _pair.key);
        const sortEntries = this.schema?.sortMapEntries;
        if (prev) {
          if (!overwrite)
            throw new Error(`Key ${_pair.key} already set`);
          if (identity.isScalar(prev.value) && Scalar.isScalarValue(_pair.value))
            prev.value.value = _pair.value;
          else
            prev.value = _pair.value;
        } else if (sortEntries) {
          const i = this.items.findIndex((item) => sortEntries(_pair, item) < 0);
          if (i === -1)
            this.items.push(_pair);
          else
            this.items.splice(i, 0, _pair);
        } else {
          this.items.push(_pair);
        }
      }
      delete(key) {
        const it = findPair(this.items, key);
        if (!it)
          return false;
        const del = this.items.splice(this.items.indexOf(it), 1);
        return del.length > 0;
      }
      get(key, keepScalar) {
        const it = findPair(this.items, key);
        const node = it?.value;
        return (!keepScalar && identity.isScalar(node) ? node.value : node) ?? void 0;
      }
      has(key) {
        return !!findPair(this.items, key);
      }
      set(key, value) {
        this.add(new Pair.Pair(key, value), true);
      }
      /**
       * @param ctx - Conversion context, originally set in Document#toJS()
       * @param {Class} Type - If set, forces the returned collection type
       * @returns Instance of Type, Map, or Object
       */
      toJSON(_, ctx, Type) {
        const map = Type ? new Type() : ctx?.mapAsMap ? /* @__PURE__ */ new Map() : {};
        if (ctx?.onCreate)
          ctx.onCreate(map);
        for (const item of this.items)
          addPairToJSMap.addPairToJSMap(ctx, map, item);
        return map;
      }
      toString(ctx, onComment, onChompKeep) {
        if (!ctx)
          return JSON.stringify(this);
        for (const item of this.items) {
          if (!identity.isPair(item))
            throw new Error(`Map items must all be pairs; found ${JSON.stringify(item)} instead`);
        }
        if (!ctx.allNullValues && this.hasAllNullValues(false))
          ctx = Object.assign({}, ctx, { allNullValues: true });
        return stringifyCollection.stringifyCollection(this, ctx, {
          blockItemPrefix: "",
          flowChars: { start: "{", end: "}" },
          itemIndent: ctx.indent || "",
          onChompKeep,
          onComment
        });
      }
    };
    exports.YAMLMap = YAMLMap;
    exports.findPair = findPair;
  }
});

// node_modules/yaml/dist/schema/common/map.js
var require_map = __commonJS({
  "node_modules/yaml/dist/schema/common/map.js"(exports) {
    "use strict";
    var identity = require_identity();
    var YAMLMap = require_YAMLMap();
    var map = {
      collection: "map",
      default: true,
      nodeClass: YAMLMap.YAMLMap,
      tag: "tag:yaml.org,2002:map",
      resolve(map2, onError) {
        if (!identity.isMap(map2))
          onError("Expected a mapping for this tag");
        return map2;
      },
      createNode: (schema2, obj, ctx) => YAMLMap.YAMLMap.from(schema2, obj, ctx)
    };
    exports.map = map;
  }
});

// node_modules/yaml/dist/nodes/YAMLSeq.js
var require_YAMLSeq = __commonJS({
  "node_modules/yaml/dist/nodes/YAMLSeq.js"(exports) {
    "use strict";
    var createNode = require_createNode();
    var stringifyCollection = require_stringifyCollection();
    var Collection = require_Collection();
    var identity = require_identity();
    var Scalar = require_Scalar();
    var toJS = require_toJS();
    var YAMLSeq = class extends Collection.Collection {
      static get tagName() {
        return "tag:yaml.org,2002:seq";
      }
      constructor(schema2) {
        super(identity.SEQ, schema2);
        this.items = [];
      }
      add(value) {
        this.items.push(value);
      }
      /**
       * Removes a value from the collection.
       *
       * `key` must contain a representation of an integer for this to succeed.
       * It may be wrapped in a `Scalar`.
       *
       * @returns `true` if the item was found and removed.
       */
      delete(key) {
        const idx = asItemIndex(key);
        if (typeof idx !== "number")
          return false;
        const del = this.items.splice(idx, 1);
        return del.length > 0;
      }
      get(key, keepScalar) {
        const idx = asItemIndex(key);
        if (typeof idx !== "number")
          return void 0;
        const it = this.items[idx];
        return !keepScalar && identity.isScalar(it) ? it.value : it;
      }
      /**
       * Checks if the collection includes a value with the key `key`.
       *
       * `key` must contain a representation of an integer for this to succeed.
       * It may be wrapped in a `Scalar`.
       */
      has(key) {
        const idx = asItemIndex(key);
        return typeof idx === "number" && idx < this.items.length;
      }
      /**
       * Sets a value in this collection. For `!!set`, `value` needs to be a
       * boolean to add/remove the item from the set.
       *
       * If `key` does not contain a representation of an integer, this will throw.
       * It may be wrapped in a `Scalar`.
       */
      set(key, value) {
        const idx = asItemIndex(key);
        if (typeof idx !== "number")
          throw new Error(`Expected a valid index, not ${key}.`);
        const prev = this.items[idx];
        if (identity.isScalar(prev) && Scalar.isScalarValue(value))
          prev.value = value;
        else
          this.items[idx] = value;
      }
      toJSON(_, ctx) {
        const seq = [];
        if (ctx?.onCreate)
          ctx.onCreate(seq);
        let i = 0;
        for (const item of this.items)
          seq.push(toJS.toJS(item, String(i++), ctx));
        return seq;
      }
      toString(ctx, onComment, onChompKeep) {
        if (!ctx)
          return JSON.stringify(this);
        return stringifyCollection.stringifyCollection(this, ctx, {
          blockItemPrefix: "- ",
          flowChars: { start: "[", end: "]" },
          itemIndent: (ctx.indent || "") + "  ",
          onChompKeep,
          onComment
        });
      }
      static from(schema2, obj, ctx) {
        const { replacer } = ctx;
        const seq = new this(schema2);
        if (obj && Symbol.iterator in Object(obj)) {
          let i = 0;
          for (let it of obj) {
            if (typeof replacer === "function") {
              const key = obj instanceof Set ? it : String(i++);
              it = replacer.call(obj, key, it);
            }
            seq.items.push(createNode.createNode(it, void 0, ctx));
          }
        }
        return seq;
      }
    };
    function asItemIndex(key) {
      let idx = identity.isScalar(key) ? key.value : key;
      if (idx && typeof idx === "string")
        idx = Number(idx);
      return typeof idx === "number" && Number.isInteger(idx) && idx >= 0 ? idx : null;
    }
    exports.YAMLSeq = YAMLSeq;
  }
});

// node_modules/yaml/dist/schema/common/seq.js
var require_seq = __commonJS({
  "node_modules/yaml/dist/schema/common/seq.js"(exports) {
    "use strict";
    var identity = require_identity();
    var YAMLSeq = require_YAMLSeq();
    var seq = {
      collection: "seq",
      default: true,
      nodeClass: YAMLSeq.YAMLSeq,
      tag: "tag:yaml.org,2002:seq",
      resolve(seq2, onError) {
        if (!identity.isSeq(seq2))
          onError("Expected a sequence for this tag");
        return seq2;
      },
      createNode: (schema2, obj, ctx) => YAMLSeq.YAMLSeq.from(schema2, obj, ctx)
    };
    exports.seq = seq;
  }
});

// node_modules/yaml/dist/schema/common/string.js
var require_string = __commonJS({
  "node_modules/yaml/dist/schema/common/string.js"(exports) {
    "use strict";
    var stringifyString = require_stringifyString();
    var string = {
      identify: (value) => typeof value === "string",
      default: true,
      tag: "tag:yaml.org,2002:str",
      resolve: (str) => str,
      stringify(item, ctx, onComment, onChompKeep) {
        ctx = Object.assign({ actualString: true }, ctx);
        return stringifyString.stringifyString(item, ctx, onComment, onChompKeep);
      }
    };
    exports.string = string;
  }
});

// node_modules/yaml/dist/schema/common/null.js
var require_null = __commonJS({
  "node_modules/yaml/dist/schema/common/null.js"(exports) {
    "use strict";
    var Scalar = require_Scalar();
    var nullTag = {
      identify: (value) => value == null,
      createNode: () => new Scalar.Scalar(null),
      default: true,
      tag: "tag:yaml.org,2002:null",
      test: /^(?:~|[Nn]ull|NULL)?$/,
      resolve: () => new Scalar.Scalar(null),
      stringify: ({ source: source2 }, ctx) => typeof source2 === "string" && nullTag.test.test(source2) ? source2 : ctx.options.nullStr
    };
    exports.nullTag = nullTag;
  }
});

// node_modules/yaml/dist/schema/core/bool.js
var require_bool = __commonJS({
  "node_modules/yaml/dist/schema/core/bool.js"(exports) {
    "use strict";
    var Scalar = require_Scalar();
    var boolTag = {
      identify: (value) => typeof value === "boolean",
      default: true,
      tag: "tag:yaml.org,2002:bool",
      test: /^(?:[Tt]rue|TRUE|[Ff]alse|FALSE)$/,
      resolve: (str) => new Scalar.Scalar(str[0] === "t" || str[0] === "T"),
      stringify({ source: source2, value }, ctx) {
        if (source2 && boolTag.test.test(source2)) {
          const sv = source2[0] === "t" || source2[0] === "T";
          if (value === sv)
            return source2;
        }
        return value ? ctx.options.trueStr : ctx.options.falseStr;
      }
    };
    exports.boolTag = boolTag;
  }
});

// node_modules/yaml/dist/stringify/stringifyNumber.js
var require_stringifyNumber = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyNumber.js"(exports) {
    "use strict";
    function stringifyNumber({ format, minFractionDigits, tag, value }) {
      if (typeof value === "bigint")
        return String(value);
      const num = typeof value === "number" ? value : Number(value);
      if (!isFinite(num))
        return isNaN(num) ? ".nan" : num < 0 ? "-.inf" : ".inf";
      let n = Object.is(value, -0) ? "-0" : JSON.stringify(value);
      if (!format && minFractionDigits && (!tag || tag === "tag:yaml.org,2002:float") && /^-?\d/.test(n) && !n.includes("e")) {
        let i = n.indexOf(".");
        if (i < 0) {
          i = n.length;
          n += ".";
        }
        let d = minFractionDigits - (n.length - i - 1);
        while (d-- > 0)
          n += "0";
      }
      return n;
    }
    exports.stringifyNumber = stringifyNumber;
  }
});

// node_modules/yaml/dist/schema/core/float.js
var require_float = __commonJS({
  "node_modules/yaml/dist/schema/core/float.js"(exports) {
    "use strict";
    var Scalar = require_Scalar();
    var stringifyNumber = require_stringifyNumber();
    var floatNaN = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      test: /^(?:[-+]?\.(?:inf|Inf|INF)|\.nan|\.NaN|\.NAN)$/,
      resolve: (str) => str.slice(-3).toLowerCase() === "nan" ? NaN : str[0] === "-" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY,
      stringify: stringifyNumber.stringifyNumber
    };
    var floatExp = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      format: "EXP",
      test: /^[-+]?(?:\.[0-9]+|[0-9]+(?:\.[0-9]*)?)[eE][-+]?[0-9]+$/,
      resolve: (str) => parseFloat(str),
      stringify(node) {
        const num = Number(node.value);
        return isFinite(num) ? num.toExponential() : stringifyNumber.stringifyNumber(node);
      }
    };
    var float = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      test: /^[-+]?(?:\.[0-9]+|[0-9]+\.[0-9]*)$/,
      resolve(str) {
        const node = new Scalar.Scalar(parseFloat(str));
        const dot = str.indexOf(".");
        if (dot !== -1 && str[str.length - 1] === "0")
          node.minFractionDigits = str.length - dot - 1;
        return node;
      },
      stringify: stringifyNumber.stringifyNumber
    };
    exports.float = float;
    exports.floatExp = floatExp;
    exports.floatNaN = floatNaN;
  }
});

// node_modules/yaml/dist/schema/core/int.js
var require_int = __commonJS({
  "node_modules/yaml/dist/schema/core/int.js"(exports) {
    "use strict";
    var stringifyNumber = require_stringifyNumber();
    var intIdentify = (value) => typeof value === "bigint" || Number.isInteger(value);
    var intResolve = (str, offset, radix, { intAsBigInt }) => intAsBigInt ? BigInt(str) : parseInt(str.substring(offset), radix);
    function intStringify(node, radix, prefix) {
      const { value } = node;
      if (intIdentify(value) && value >= 0)
        return prefix + value.toString(radix);
      return stringifyNumber.stringifyNumber(node);
    }
    var intOct = {
      identify: (value) => intIdentify(value) && value >= 0,
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "OCT",
      test: /^0o[0-7]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 2, 8, opt),
      stringify: (node) => intStringify(node, 8, "0o")
    };
    var int = {
      identify: intIdentify,
      default: true,
      tag: "tag:yaml.org,2002:int",
      test: /^[-+]?[0-9]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 0, 10, opt),
      stringify: stringifyNumber.stringifyNumber
    };
    var intHex = {
      identify: (value) => intIdentify(value) && value >= 0,
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "HEX",
      test: /^0x[0-9a-fA-F]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 2, 16, opt),
      stringify: (node) => intStringify(node, 16, "0x")
    };
    exports.int = int;
    exports.intHex = intHex;
    exports.intOct = intOct;
  }
});

// node_modules/yaml/dist/schema/core/schema.js
var require_schema = __commonJS({
  "node_modules/yaml/dist/schema/core/schema.js"(exports) {
    "use strict";
    var map = require_map();
    var _null = require_null();
    var seq = require_seq();
    var string = require_string();
    var bool = require_bool();
    var float = require_float();
    var int = require_int();
    var schema2 = [
      map.map,
      seq.seq,
      string.string,
      _null.nullTag,
      bool.boolTag,
      int.intOct,
      int.int,
      int.intHex,
      float.floatNaN,
      float.floatExp,
      float.float
    ];
    exports.schema = schema2;
  }
});

// node_modules/yaml/dist/schema/json/schema.js
var require_schema2 = __commonJS({
  "node_modules/yaml/dist/schema/json/schema.js"(exports) {
    "use strict";
    var Scalar = require_Scalar();
    var map = require_map();
    var seq = require_seq();
    function intIdentify(value) {
      return typeof value === "bigint" || Number.isInteger(value);
    }
    var stringifyJSON = ({ value }) => JSON.stringify(value);
    var jsonScalars = [
      {
        identify: (value) => typeof value === "string",
        default: true,
        tag: "tag:yaml.org,2002:str",
        resolve: (str) => str,
        stringify: stringifyJSON
      },
      {
        identify: (value) => value == null,
        createNode: () => new Scalar.Scalar(null),
        default: true,
        tag: "tag:yaml.org,2002:null",
        test: /^null$/,
        resolve: () => null,
        stringify: stringifyJSON
      },
      {
        identify: (value) => typeof value === "boolean",
        default: true,
        tag: "tag:yaml.org,2002:bool",
        test: /^true$|^false$/,
        resolve: (str) => str === "true",
        stringify: stringifyJSON
      },
      {
        identify: intIdentify,
        default: true,
        tag: "tag:yaml.org,2002:int",
        test: /^-?(?:0|[1-9][0-9]*)$/,
        resolve: (str, _onError, { intAsBigInt }) => intAsBigInt ? BigInt(str) : parseInt(str, 10),
        stringify: ({ value }) => intIdentify(value) ? value.toString() : JSON.stringify(value)
      },
      {
        identify: (value) => typeof value === "number",
        default: true,
        tag: "tag:yaml.org,2002:float",
        test: /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]*)?(?:[eE][-+]?[0-9]+)?$/,
        resolve: (str) => parseFloat(str),
        stringify: stringifyJSON
      }
    ];
    var jsonError = {
      default: true,
      tag: "",
      test: /^/,
      resolve(str, onError) {
        onError(`Unresolved plain scalar ${JSON.stringify(str)}`);
        return str;
      }
    };
    var schema2 = [map.map, seq.seq].concat(jsonScalars, jsonError);
    exports.schema = schema2;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/binary.js
var require_binary = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/binary.js"(exports) {
    "use strict";
    var node_buffer = __require("buffer");
    var Scalar = require_Scalar();
    var stringifyString = require_stringifyString();
    var binary = {
      identify: (value) => value instanceof Uint8Array,
      // Buffer inherits from Uint8Array
      default: false,
      tag: "tag:yaml.org,2002:binary",
      /**
       * Returns a Buffer in node and an Uint8Array in browsers
       *
       * To use the resulting buffer as an image, you'll want to do something like:
       *
       *   const blob = new Blob([buffer], { type: 'image/jpeg' })
       *   document.querySelector('#photo').src = URL.createObjectURL(blob)
       */
      resolve(src, onError) {
        if (typeof node_buffer.Buffer === "function") {
          return node_buffer.Buffer.from(src, "base64");
        } else if (typeof atob === "function") {
          const str = atob(src.replace(/[\n\r]/g, ""));
          const buffer = new Uint8Array(str.length);
          for (let i = 0; i < str.length; ++i)
            buffer[i] = str.charCodeAt(i);
          return buffer;
        } else {
          onError("This environment does not support reading binary tags; either Buffer or atob is required");
          return src;
        }
      },
      stringify({ comment, type, value }, ctx, onComment, onChompKeep) {
        if (!value)
          return "";
        const buf = value;
        let str;
        if (typeof node_buffer.Buffer === "function") {
          str = buf instanceof node_buffer.Buffer ? buf.toString("base64") : node_buffer.Buffer.from(buf.buffer).toString("base64");
        } else if (typeof btoa === "function") {
          let s = "";
          for (let i = 0; i < buf.length; ++i)
            s += String.fromCharCode(buf[i]);
          str = btoa(s);
        } else {
          throw new Error("This environment does not support writing binary tags; either Buffer or btoa is required");
        }
        type ?? (type = Scalar.Scalar.BLOCK_LITERAL);
        if (type !== Scalar.Scalar.QUOTE_DOUBLE) {
          const lineWidth = Math.max(ctx.options.lineWidth - ctx.indent.length, ctx.options.minContentWidth);
          const n = Math.ceil(str.length / lineWidth);
          const lines = new Array(n);
          for (let i = 0, o = 0; i < n; ++i, o += lineWidth) {
            lines[i] = str.substr(o, lineWidth);
          }
          str = lines.join(type === Scalar.Scalar.BLOCK_LITERAL ? "\n" : " ");
        }
        return stringifyString.stringifyString({ comment, type, value: str }, ctx, onComment, onChompKeep);
      }
    };
    exports.binary = binary;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/pairs.js
var require_pairs = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/pairs.js"(exports) {
    "use strict";
    var identity = require_identity();
    var Pair = require_Pair();
    var Scalar = require_Scalar();
    var YAMLSeq = require_YAMLSeq();
    function resolvePairs(seq, onError) {
      if (identity.isSeq(seq)) {
        for (let i = 0; i < seq.items.length; ++i) {
          let item = seq.items[i];
          if (identity.isPair(item))
            continue;
          else if (identity.isMap(item)) {
            if (item.items.length > 1)
              onError("Each pair must have its own sequence indicator");
            const pair = item.items[0] || new Pair.Pair(new Scalar.Scalar(null));
            if (item.commentBefore)
              pair.key.commentBefore = pair.key.commentBefore ? `${item.commentBefore}
${pair.key.commentBefore}` : item.commentBefore;
            if (item.comment) {
              const cn = pair.value ?? pair.key;
              cn.comment = cn.comment ? `${item.comment}
${cn.comment}` : item.comment;
            }
            item = pair;
          }
          seq.items[i] = identity.isPair(item) ? item : new Pair.Pair(item);
        }
      } else
        onError("Expected a sequence for this tag");
      return seq;
    }
    function createPairs(schema2, iterable, ctx) {
      const { replacer } = ctx;
      const pairs2 = new YAMLSeq.YAMLSeq(schema2);
      pairs2.tag = "tag:yaml.org,2002:pairs";
      let i = 0;
      if (iterable && Symbol.iterator in Object(iterable))
        for (let it of iterable) {
          if (typeof replacer === "function")
            it = replacer.call(iterable, String(i++), it);
          let key, value;
          if (Array.isArray(it)) {
            if (it.length === 2) {
              key = it[0];
              value = it[1];
            } else
              throw new TypeError(`Expected [key, value] tuple: ${it}`);
          } else if (it && it instanceof Object) {
            const keys = Object.keys(it);
            if (keys.length === 1) {
              key = keys[0];
              value = it[key];
            } else {
              throw new TypeError(`Expected tuple with one key, not ${keys.length} keys`);
            }
          } else {
            key = it;
          }
          pairs2.items.push(Pair.createPair(key, value, ctx));
        }
      return pairs2;
    }
    var pairs = {
      collection: "seq",
      default: false,
      tag: "tag:yaml.org,2002:pairs",
      resolve: resolvePairs,
      createNode: createPairs
    };
    exports.createPairs = createPairs;
    exports.pairs = pairs;
    exports.resolvePairs = resolvePairs;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/omap.js
var require_omap = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/omap.js"(exports) {
    "use strict";
    var identity = require_identity();
    var toJS = require_toJS();
    var YAMLMap = require_YAMLMap();
    var YAMLSeq = require_YAMLSeq();
    var pairs = require_pairs();
    var YAMLOMap = class _YAMLOMap extends YAMLSeq.YAMLSeq {
      constructor() {
        super();
        this.add = YAMLMap.YAMLMap.prototype.add.bind(this);
        this.delete = YAMLMap.YAMLMap.prototype.delete.bind(this);
        this.get = YAMLMap.YAMLMap.prototype.get.bind(this);
        this.has = YAMLMap.YAMLMap.prototype.has.bind(this);
        this.set = YAMLMap.YAMLMap.prototype.set.bind(this);
        this.tag = _YAMLOMap.tag;
      }
      /**
       * If `ctx` is given, the return type is actually `Map<unknown, unknown>`,
       * but TypeScript won't allow widening the signature of a child method.
       */
      toJSON(_, ctx) {
        if (!ctx)
          return super.toJSON(_);
        const map = /* @__PURE__ */ new Map();
        if (ctx?.onCreate)
          ctx.onCreate(map);
        for (const pair of this.items) {
          let key, value;
          if (identity.isPair(pair)) {
            key = toJS.toJS(pair.key, "", ctx);
            value = toJS.toJS(pair.value, key, ctx);
          } else {
            key = toJS.toJS(pair, "", ctx);
          }
          if (map.has(key))
            throw new Error("Ordered maps must not include duplicate keys");
          map.set(key, value);
        }
        return map;
      }
      static from(schema2, iterable, ctx) {
        const pairs$1 = pairs.createPairs(schema2, iterable, ctx);
        const omap2 = new this();
        omap2.items = pairs$1.items;
        return omap2;
      }
    };
    YAMLOMap.tag = "tag:yaml.org,2002:omap";
    var omap = {
      collection: "seq",
      identify: (value) => value instanceof Map,
      nodeClass: YAMLOMap,
      default: false,
      tag: "tag:yaml.org,2002:omap",
      resolve(seq, onError) {
        const pairs$1 = pairs.resolvePairs(seq, onError);
        const seenKeys = [];
        for (const { key } of pairs$1.items) {
          if (identity.isScalar(key)) {
            if (seenKeys.includes(key.value)) {
              onError(`Ordered maps must not include duplicate keys: ${key.value}`);
            } else {
              seenKeys.push(key.value);
            }
          }
        }
        return Object.assign(new YAMLOMap(), pairs$1);
      },
      createNode: (schema2, iterable, ctx) => YAMLOMap.from(schema2, iterable, ctx)
    };
    exports.YAMLOMap = YAMLOMap;
    exports.omap = omap;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/bool.js
var require_bool2 = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/bool.js"(exports) {
    "use strict";
    var Scalar = require_Scalar();
    function boolStringify({ value, source: source2 }, ctx) {
      const boolObj = value ? trueTag : falseTag;
      if (source2 && boolObj.test.test(source2))
        return source2;
      return value ? ctx.options.trueStr : ctx.options.falseStr;
    }
    var trueTag = {
      identify: (value) => value === true,
      default: true,
      tag: "tag:yaml.org,2002:bool",
      test: /^(?:Y|y|[Yy]es|YES|[Tt]rue|TRUE|[Oo]n|ON)$/,
      resolve: () => new Scalar.Scalar(true),
      stringify: boolStringify
    };
    var falseTag = {
      identify: (value) => value === false,
      default: true,
      tag: "tag:yaml.org,2002:bool",
      test: /^(?:N|n|[Nn]o|NO|[Ff]alse|FALSE|[Oo]ff|OFF)$/,
      resolve: () => new Scalar.Scalar(false),
      stringify: boolStringify
    };
    exports.falseTag = falseTag;
    exports.trueTag = trueTag;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/float.js
var require_float2 = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/float.js"(exports) {
    "use strict";
    var Scalar = require_Scalar();
    var stringifyNumber = require_stringifyNumber();
    var floatNaN = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      test: /^(?:[-+]?\.(?:inf|Inf|INF)|\.nan|\.NaN|\.NAN)$/,
      resolve: (str) => str.slice(-3).toLowerCase() === "nan" ? NaN : str[0] === "-" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY,
      stringify: stringifyNumber.stringifyNumber
    };
    var floatExp = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      format: "EXP",
      test: /^[-+]?(?:[0-9][0-9_]*)?(?:\.[0-9_]*)?[eE][-+]?[0-9]+$/,
      resolve: (str) => parseFloat(str.replace(/_/g, "")),
      stringify(node) {
        const num = Number(node.value);
        return isFinite(num) ? num.toExponential() : stringifyNumber.stringifyNumber(node);
      }
    };
    var float = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      test: /^[-+]?(?:[0-9][0-9_]*)?\.[0-9_]*$/,
      resolve(str) {
        const node = new Scalar.Scalar(parseFloat(str.replace(/_/g, "")));
        const dot = str.indexOf(".");
        if (dot !== -1) {
          const f = str.substring(dot + 1).replace(/_/g, "");
          if (f[f.length - 1] === "0")
            node.minFractionDigits = f.length;
        }
        return node;
      },
      stringify: stringifyNumber.stringifyNumber
    };
    exports.float = float;
    exports.floatExp = floatExp;
    exports.floatNaN = floatNaN;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/int.js
var require_int2 = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/int.js"(exports) {
    "use strict";
    var stringifyNumber = require_stringifyNumber();
    var intIdentify = (value) => typeof value === "bigint" || Number.isInteger(value);
    function intResolve(str, offset, radix, { intAsBigInt }) {
      const sign = str[0];
      if (sign === "-" || sign === "+")
        offset += 1;
      str = str.substring(offset).replace(/_/g, "");
      if (intAsBigInt) {
        switch (radix) {
          case 2:
            str = `0b${str}`;
            break;
          case 8:
            str = `0o${str}`;
            break;
          case 16:
            str = `0x${str}`;
            break;
        }
        const n2 = BigInt(str);
        return sign === "-" ? BigInt(-1) * n2 : n2;
      }
      const n = parseInt(str, radix);
      return sign === "-" ? -1 * n : n;
    }
    function intStringify(node, radix, prefix) {
      const { value } = node;
      if (intIdentify(value)) {
        const str = value.toString(radix);
        return value < 0 ? "-" + prefix + str.substr(1) : prefix + str;
      }
      return stringifyNumber.stringifyNumber(node);
    }
    var intBin = {
      identify: intIdentify,
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "BIN",
      test: /^[-+]?0b[0-1_]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 2, 2, opt),
      stringify: (node) => intStringify(node, 2, "0b")
    };
    var intOct = {
      identify: intIdentify,
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "OCT",
      test: /^[-+]?0[0-7_]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 1, 8, opt),
      stringify: (node) => intStringify(node, 8, "0")
    };
    var int = {
      identify: intIdentify,
      default: true,
      tag: "tag:yaml.org,2002:int",
      test: /^[-+]?[0-9][0-9_]*$/,
      resolve: (str, _onError, opt) => intResolve(str, 0, 10, opt),
      stringify: stringifyNumber.stringifyNumber
    };
    var intHex = {
      identify: intIdentify,
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "HEX",
      test: /^[-+]?0x[0-9a-fA-F_]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 2, 16, opt),
      stringify: (node) => intStringify(node, 16, "0x")
    };
    exports.int = int;
    exports.intBin = intBin;
    exports.intHex = intHex;
    exports.intOct = intOct;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/set.js
var require_set = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/set.js"(exports) {
    "use strict";
    var identity = require_identity();
    var Pair = require_Pair();
    var YAMLMap = require_YAMLMap();
    var YAMLSet = class _YAMLSet extends YAMLMap.YAMLMap {
      constructor(schema2) {
        super(schema2);
        this.tag = _YAMLSet.tag;
      }
      add(key) {
        let pair;
        if (identity.isPair(key))
          pair = key;
        else if (key && typeof key === "object" && "key" in key && "value" in key && key.value === null)
          pair = new Pair.Pair(key.key, null);
        else
          pair = new Pair.Pair(key, null);
        const prev = YAMLMap.findPair(this.items, pair.key);
        if (!prev)
          this.items.push(pair);
      }
      /**
       * If `keepPair` is `true`, returns the Pair matching `key`.
       * Otherwise, returns the value of that Pair's key.
       */
      get(key, keepPair) {
        const pair = YAMLMap.findPair(this.items, key);
        return !keepPair && identity.isPair(pair) ? identity.isScalar(pair.key) ? pair.key.value : pair.key : pair;
      }
      set(key, value) {
        if (typeof value !== "boolean")
          throw new Error(`Expected boolean value for set(key, value) in a YAML set, not ${typeof value}`);
        const prev = YAMLMap.findPair(this.items, key);
        if (prev && !value) {
          this.items.splice(this.items.indexOf(prev), 1);
        } else if (!prev && value) {
          this.items.push(new Pair.Pair(key));
        }
      }
      toJSON(_, ctx) {
        return super.toJSON(_, ctx, Set);
      }
      toString(ctx, onComment, onChompKeep) {
        if (!ctx)
          return JSON.stringify(this);
        if (this.hasAllNullValues(true))
          return super.toString(Object.assign({}, ctx, { allNullValues: true }), onComment, onChompKeep);
        else
          throw new Error("Set items must all have null values");
      }
      static from(schema2, iterable, ctx) {
        const { replacer } = ctx;
        const set2 = new this(schema2);
        if (iterable && Symbol.iterator in Object(iterable))
          for (let value of iterable) {
            if (typeof replacer === "function")
              value = replacer.call(iterable, value, value);
            set2.items.push(Pair.createPair(value, null, ctx));
          }
        return set2;
      }
    };
    YAMLSet.tag = "tag:yaml.org,2002:set";
    var set = {
      collection: "map",
      identify: (value) => value instanceof Set,
      nodeClass: YAMLSet,
      default: false,
      tag: "tag:yaml.org,2002:set",
      createNode: (schema2, iterable, ctx) => YAMLSet.from(schema2, iterable, ctx),
      resolve(map, onError) {
        if (identity.isMap(map)) {
          if (map.hasAllNullValues(true))
            return Object.assign(new YAMLSet(), map);
          else
            onError("Set items must all have null values");
        } else
          onError("Expected a mapping for this tag");
        return map;
      }
    };
    exports.YAMLSet = YAMLSet;
    exports.set = set;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/timestamp.js
var require_timestamp = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/timestamp.js"(exports) {
    "use strict";
    var stringifyNumber = require_stringifyNumber();
    function parseSexagesimal(str, asBigInt) {
      const sign = str[0];
      const parts = sign === "-" || sign === "+" ? str.substring(1) : str;
      const num = (n) => asBigInt ? BigInt(n) : Number(n);
      const res = parts.replace(/_/g, "").split(":").reduce((res2, p) => res2 * num(60) + num(p), num(0));
      return sign === "-" ? num(-1) * res : res;
    }
    function stringifySexagesimal(node) {
      let { value } = node;
      let num = (n) => n;
      if (typeof value === "bigint")
        num = (n) => BigInt(n);
      else if (isNaN(value) || !isFinite(value))
        return stringifyNumber.stringifyNumber(node);
      let sign = "";
      if (value < 0) {
        sign = "-";
        value *= num(-1);
      }
      const _60 = num(60);
      const parts = [value % _60];
      if (value < 60) {
        parts.unshift(0);
      } else {
        value = (value - parts[0]) / _60;
        parts.unshift(value % _60);
        if (value >= 60) {
          value = (value - parts[0]) / _60;
          parts.unshift(value);
        }
      }
      return sign + parts.map((n) => String(n).padStart(2, "0")).join(":").replace(/000000\d*$/, "");
    }
    var intTime = {
      identify: (value) => typeof value === "bigint" || Number.isInteger(value),
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "TIME",
      test: /^[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+$/,
      resolve: (str, _onError, { intAsBigInt }) => parseSexagesimal(str, intAsBigInt),
      stringify: stringifySexagesimal
    };
    var floatTime = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      format: "TIME",
      test: /^[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\.[0-9_]*$/,
      resolve: (str) => parseSexagesimal(str, false),
      stringify: stringifySexagesimal
    };
    var timestamp = {
      identify: (value) => value instanceof Date,
      default: true,
      tag: "tag:yaml.org,2002:timestamp",
      // If the time zone is omitted, the timestamp is assumed to be specified in UTC. The time part
      // may be omitted altogether, resulting in a date format. In such a case, the time part is
      // assumed to be 00:00:00Z (start of day, UTC).
      test: RegExp("^([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})(?:(?:t|T|[ \\t]+)([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2}(\\.[0-9]+)?)(?:[ \\t]*(Z|[-+][012]?[0-9](?::[0-9]{2})?))?)?$"),
      resolve(str) {
        const match = str.match(timestamp.test);
        if (!match)
          throw new Error("!!timestamp expects a date, starting with yyyy-mm-dd");
        const [, year, month, day, hour, minute, second] = match.map(Number);
        const millisec = match[7] ? Number((match[7] + "00").substr(1, 3)) : 0;
        let date = Date.UTC(year, month - 1, day, hour || 0, minute || 0, second || 0, millisec);
        const tz = match[8];
        if (tz && tz !== "Z") {
          let d = parseSexagesimal(tz, false);
          if (Math.abs(d) < 30)
            d *= 60;
          date -= 6e4 * d;
        }
        return new Date(date);
      },
      stringify: ({ value }) => value?.toISOString().replace(/(T00:00:00)?\.000Z$/, "") ?? ""
    };
    exports.floatTime = floatTime;
    exports.intTime = intTime;
    exports.timestamp = timestamp;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/schema.js
var require_schema3 = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/schema.js"(exports) {
    "use strict";
    var map = require_map();
    var _null = require_null();
    var seq = require_seq();
    var string = require_string();
    var binary = require_binary();
    var bool = require_bool2();
    var float = require_float2();
    var int = require_int2();
    var merge = require_merge();
    var omap = require_omap();
    var pairs = require_pairs();
    var set = require_set();
    var timestamp = require_timestamp();
    var schema2 = [
      map.map,
      seq.seq,
      string.string,
      _null.nullTag,
      bool.trueTag,
      bool.falseTag,
      int.intBin,
      int.intOct,
      int.int,
      int.intHex,
      float.floatNaN,
      float.floatExp,
      float.float,
      binary.binary,
      merge.merge,
      omap.omap,
      pairs.pairs,
      set.set,
      timestamp.intTime,
      timestamp.floatTime,
      timestamp.timestamp
    ];
    exports.schema = schema2;
  }
});

// node_modules/yaml/dist/schema/tags.js
var require_tags = __commonJS({
  "node_modules/yaml/dist/schema/tags.js"(exports) {
    "use strict";
    var map = require_map();
    var _null = require_null();
    var seq = require_seq();
    var string = require_string();
    var bool = require_bool();
    var float = require_float();
    var int = require_int();
    var schema2 = require_schema();
    var schema$1 = require_schema2();
    var binary = require_binary();
    var merge = require_merge();
    var omap = require_omap();
    var pairs = require_pairs();
    var schema$2 = require_schema3();
    var set = require_set();
    var timestamp = require_timestamp();
    var schemas = /* @__PURE__ */ new Map([
      ["core", schema2.schema],
      ["failsafe", [map.map, seq.seq, string.string]],
      ["json", schema$1.schema],
      ["yaml11", schema$2.schema],
      ["yaml-1.1", schema$2.schema]
    ]);
    var tagsByName = {
      binary: binary.binary,
      bool: bool.boolTag,
      float: float.float,
      floatExp: float.floatExp,
      floatNaN: float.floatNaN,
      floatTime: timestamp.floatTime,
      int: int.int,
      intHex: int.intHex,
      intOct: int.intOct,
      intTime: timestamp.intTime,
      map: map.map,
      merge: merge.merge,
      null: _null.nullTag,
      omap: omap.omap,
      pairs: pairs.pairs,
      seq: seq.seq,
      set: set.set,
      timestamp: timestamp.timestamp
    };
    var coreKnownTags = {
      "tag:yaml.org,2002:binary": binary.binary,
      "tag:yaml.org,2002:merge": merge.merge,
      "tag:yaml.org,2002:omap": omap.omap,
      "tag:yaml.org,2002:pairs": pairs.pairs,
      "tag:yaml.org,2002:set": set.set,
      "tag:yaml.org,2002:timestamp": timestamp.timestamp
    };
    function getTags(customTags, schemaName, addMergeTag) {
      const schemaTags = schemas.get(schemaName);
      if (schemaTags && !customTags) {
        return addMergeTag && !schemaTags.includes(merge.merge) ? schemaTags.concat(merge.merge) : schemaTags.slice();
      }
      let tags = schemaTags;
      if (!tags) {
        if (Array.isArray(customTags))
          tags = [];
        else {
          const keys = Array.from(schemas.keys()).filter((key) => key !== "yaml11").map((key) => JSON.stringify(key)).join(", ");
          throw new Error(`Unknown schema "${schemaName}"; use one of ${keys} or define customTags array`);
        }
      }
      if (Array.isArray(customTags)) {
        for (const tag of customTags)
          tags = tags.concat(tag);
      } else if (typeof customTags === "function") {
        tags = customTags(tags.slice());
      }
      if (addMergeTag)
        tags = tags.concat(merge.merge);
      return tags.reduce((tags2, tag) => {
        const tagObj = typeof tag === "string" ? tagsByName[tag] : tag;
        if (!tagObj) {
          const tagName = JSON.stringify(tag);
          const keys = Object.keys(tagsByName).map((key) => JSON.stringify(key)).join(", ");
          throw new Error(`Unknown custom tag ${tagName}; use one of ${keys}`);
        }
        if (!tags2.includes(tagObj))
          tags2.push(tagObj);
        return tags2;
      }, []);
    }
    exports.coreKnownTags = coreKnownTags;
    exports.getTags = getTags;
  }
});

// node_modules/yaml/dist/schema/Schema.js
var require_Schema = __commonJS({
  "node_modules/yaml/dist/schema/Schema.js"(exports) {
    "use strict";
    var identity = require_identity();
    var map = require_map();
    var seq = require_seq();
    var string = require_string();
    var tags = require_tags();
    var sortMapEntriesByKey = (a, b) => a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
    var Schema = class _Schema {
      constructor({ compat, customTags, merge, resolveKnownTags, schema: schema2, sortMapEntries, toStringDefaults }) {
        this.compat = Array.isArray(compat) ? tags.getTags(compat, "compat") : compat ? tags.getTags(null, compat) : null;
        this.name = typeof schema2 === "string" && schema2 || "core";
        this.knownTags = resolveKnownTags ? tags.coreKnownTags : {};
        this.tags = tags.getTags(customTags, this.name, merge);
        this.toStringOptions = toStringDefaults ?? null;
        Object.defineProperty(this, identity.MAP, { value: map.map });
        Object.defineProperty(this, identity.SCALAR, { value: string.string });
        Object.defineProperty(this, identity.SEQ, { value: seq.seq });
        this.sortMapEntries = typeof sortMapEntries === "function" ? sortMapEntries : sortMapEntries === true ? sortMapEntriesByKey : null;
      }
      clone() {
        const copy = Object.create(_Schema.prototype, Object.getOwnPropertyDescriptors(this));
        copy.tags = this.tags.slice();
        return copy;
      }
    };
    exports.Schema = Schema;
  }
});

// node_modules/yaml/dist/stringify/stringifyDocument.js
var require_stringifyDocument = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyDocument.js"(exports) {
    "use strict";
    var identity = require_identity();
    var stringify2 = require_stringify();
    var stringifyComment = require_stringifyComment();
    function stringifyDocument(doc, options) {
      const lines = [];
      let hasDirectives = options.directives === true;
      if (options.directives !== false && doc.directives) {
        const dir = doc.directives.toString(doc);
        if (dir) {
          lines.push(dir);
          hasDirectives = true;
        } else if (doc.directives.docStart)
          hasDirectives = true;
      }
      if (hasDirectives)
        lines.push("---");
      const ctx = stringify2.createStringifyContext(doc, options);
      const { commentString } = ctx.options;
      if (doc.commentBefore) {
        if (lines.length !== 1)
          lines.unshift("");
        const cs = commentString(doc.commentBefore);
        lines.unshift(stringifyComment.indentComment(cs, ""));
      }
      let chompKeep = false;
      let contentComment = null;
      if (doc.contents) {
        if (identity.isNode(doc.contents)) {
          if (doc.contents.spaceBefore && hasDirectives)
            lines.push("");
          if (doc.contents.commentBefore) {
            const cs = commentString(doc.contents.commentBefore);
            lines.push(stringifyComment.indentComment(cs, ""));
          }
          ctx.forceBlockIndent = !!doc.comment;
          contentComment = doc.contents.comment;
        }
        const onChompKeep = contentComment ? void 0 : () => chompKeep = true;
        let body = stringify2.stringify(doc.contents, ctx, () => contentComment = null, onChompKeep);
        if (contentComment)
          body += stringifyComment.lineComment(body, "", commentString(contentComment));
        if ((body[0] === "|" || body[0] === ">") && lines[lines.length - 1] === "---") {
          lines[lines.length - 1] = `--- ${body}`;
        } else
          lines.push(body);
      } else {
        lines.push(stringify2.stringify(doc.contents, ctx));
      }
      if (doc.directives?.docEnd) {
        if (doc.comment) {
          const cs = commentString(doc.comment);
          if (cs.includes("\n")) {
            lines.push("...");
            lines.push(stringifyComment.indentComment(cs, ""));
          } else {
            lines.push(`... ${cs}`);
          }
        } else {
          lines.push("...");
        }
      } else {
        let dc = doc.comment;
        if (dc && chompKeep)
          dc = dc.replace(/^\n+/, "");
        if (dc) {
          if ((!chompKeep || contentComment) && lines[lines.length - 1] !== "")
            lines.push("");
          lines.push(stringifyComment.indentComment(commentString(dc), ""));
        }
      }
      return lines.join("\n") + "\n";
    }
    exports.stringifyDocument = stringifyDocument;
  }
});

// node_modules/yaml/dist/doc/Document.js
var require_Document = __commonJS({
  "node_modules/yaml/dist/doc/Document.js"(exports) {
    "use strict";
    var Alias = require_Alias();
    var Collection = require_Collection();
    var identity = require_identity();
    var Pair = require_Pair();
    var toJS = require_toJS();
    var Schema = require_Schema();
    var stringifyDocument = require_stringifyDocument();
    var anchors = require_anchors();
    var applyReviver = require_applyReviver();
    var createNode = require_createNode();
    var directives = require_directives();
    var Document = class _Document {
      constructor(value, replacer, options) {
        this.commentBefore = null;
        this.comment = null;
        this.errors = [];
        this.warnings = [];
        Object.defineProperty(this, identity.NODE_TYPE, { value: identity.DOC });
        let _replacer = null;
        if (typeof replacer === "function" || Array.isArray(replacer)) {
          _replacer = replacer;
        } else if (options === void 0 && replacer) {
          options = replacer;
          replacer = void 0;
        }
        const opt = Object.assign({
          intAsBigInt: false,
          keepSourceTokens: false,
          logLevel: "warn",
          prettyErrors: true,
          strict: true,
          stringKeys: false,
          uniqueKeys: true,
          version: "1.2"
        }, options);
        this.options = opt;
        let { version } = opt;
        if (options?._directives) {
          this.directives = options._directives.atDocument();
          if (this.directives.yaml.explicit)
            version = this.directives.yaml.version;
        } else
          this.directives = new directives.Directives({ version });
        this.setSchema(version, options);
        this.contents = value === void 0 ? null : this.createNode(value, _replacer, options);
      }
      /**
       * Create a deep copy of this Document and its contents.
       *
       * Custom Node values that inherit from `Object` still refer to their original instances.
       */
      clone() {
        const copy = Object.create(_Document.prototype, {
          [identity.NODE_TYPE]: { value: identity.DOC }
        });
        copy.commentBefore = this.commentBefore;
        copy.comment = this.comment;
        copy.errors = this.errors.slice();
        copy.warnings = this.warnings.slice();
        copy.options = Object.assign({}, this.options);
        if (this.directives)
          copy.directives = this.directives.clone();
        copy.schema = this.schema.clone();
        copy.contents = identity.isNode(this.contents) ? this.contents.clone(copy.schema) : this.contents;
        if (this.range)
          copy.range = this.range.slice();
        return copy;
      }
      /** Adds a value to the document. */
      add(value) {
        if (assertCollection(this.contents))
          this.contents.add(value);
      }
      /** Adds a value to the document. */
      addIn(path5, value) {
        if (assertCollection(this.contents))
          this.contents.addIn(path5, value);
      }
      /**
       * Create a new `Alias` node, ensuring that the target `node` has the required anchor.
       *
       * If `node` already has an anchor, `name` is ignored.
       * Otherwise, the `node.anchor` value will be set to `name`,
       * or if an anchor with that name is already present in the document,
       * `name` will be used as a prefix for a new unique anchor.
       * If `name` is undefined, the generated anchor will use 'a' as a prefix.
       */
      createAlias(node, name) {
        if (!node.anchor) {
          const prev = anchors.anchorNames(this);
          node.anchor = // eslint-disable-next-line @typescript-eslint/prefer-nullish-coalescing
          !name || prev.has(name) ? anchors.findNewAnchor(name || "a", prev) : name;
        }
        return new Alias.Alias(node.anchor);
      }
      createNode(value, replacer, options) {
        let _replacer = void 0;
        if (typeof replacer === "function") {
          value = replacer.call({ "": value }, "", value);
          _replacer = replacer;
        } else if (Array.isArray(replacer)) {
          const keyToStr = (v) => typeof v === "number" || v instanceof String || v instanceof Number;
          const asStr = replacer.filter(keyToStr).map(String);
          if (asStr.length > 0)
            replacer = replacer.concat(asStr);
          _replacer = replacer;
        } else if (options === void 0 && replacer) {
          options = replacer;
          replacer = void 0;
        }
        const { aliasDuplicateObjects, anchorPrefix, flow, keepUndefined, onTagObj, tag } = options ?? {};
        const { onAnchor, setAnchors, sourceObjects } = anchors.createNodeAnchors(
          this,
          // eslint-disable-next-line @typescript-eslint/prefer-nullish-coalescing
          anchorPrefix || "a"
        );
        const ctx = {
          aliasDuplicateObjects: aliasDuplicateObjects ?? true,
          keepUndefined: keepUndefined ?? false,
          onAnchor,
          onTagObj,
          replacer: _replacer,
          schema: this.schema,
          sourceObjects
        };
        const node = createNode.createNode(value, tag, ctx);
        if (flow && identity.isCollection(node))
          node.flow = true;
        setAnchors();
        return node;
      }
      /**
       * Convert a key and a value into a `Pair` using the current schema,
       * recursively wrapping all values as `Scalar` or `Collection` nodes.
       */
      createPair(key, value, options = {}) {
        const k = this.createNode(key, null, options);
        const v = this.createNode(value, null, options);
        return new Pair.Pair(k, v);
      }
      /**
       * Removes a value from the document.
       * @returns `true` if the item was found and removed.
       */
      delete(key) {
        return assertCollection(this.contents) ? this.contents.delete(key) : false;
      }
      /**
       * Removes a value from the document.
       * @returns `true` if the item was found and removed.
       */
      deleteIn(path5) {
        if (Collection.isEmptyPath(path5)) {
          if (this.contents == null)
            return false;
          this.contents = null;
          return true;
        }
        return assertCollection(this.contents) ? this.contents.deleteIn(path5) : false;
      }
      /**
       * Returns item at `key`, or `undefined` if not found. By default unwraps
       * scalar values from their surrounding node; to disable set `keepScalar` to
       * `true` (collections are always returned intact).
       */
      get(key, keepScalar) {
        return identity.isCollection(this.contents) ? this.contents.get(key, keepScalar) : void 0;
      }
      /**
       * Returns item at `path`, or `undefined` if not found. By default unwraps
       * scalar values from their surrounding node; to disable set `keepScalar` to
       * `true` (collections are always returned intact).
       */
      getIn(path5, keepScalar) {
        if (Collection.isEmptyPath(path5))
          return !keepScalar && identity.isScalar(this.contents) ? this.contents.value : this.contents;
        return identity.isCollection(this.contents) ? this.contents.getIn(path5, keepScalar) : void 0;
      }
      /**
       * Checks if the document includes a value with the key `key`.
       */
      has(key) {
        return identity.isCollection(this.contents) ? this.contents.has(key) : false;
      }
      /**
       * Checks if the document includes a value at `path`.
       */
      hasIn(path5) {
        if (Collection.isEmptyPath(path5))
          return this.contents !== void 0;
        return identity.isCollection(this.contents) ? this.contents.hasIn(path5) : false;
      }
      /**
       * Sets a value in this document. For `!!set`, `value` needs to be a
       * boolean to add/remove the item from the set.
       */
      set(key, value) {
        if (this.contents == null) {
          this.contents = Collection.collectionFromPath(this.schema, [key], value);
        } else if (assertCollection(this.contents)) {
          this.contents.set(key, value);
        }
      }
      /**
       * Sets a value in this document. For `!!set`, `value` needs to be a
       * boolean to add/remove the item from the set.
       */
      setIn(path5, value) {
        if (Collection.isEmptyPath(path5)) {
          this.contents = value;
        } else if (this.contents == null) {
          this.contents = Collection.collectionFromPath(this.schema, Array.from(path5), value);
        } else if (assertCollection(this.contents)) {
          this.contents.setIn(path5, value);
        }
      }
      /**
       * Change the YAML version and schema used by the document.
       * A `null` version disables support for directives, explicit tags, anchors, and aliases.
       * It also requires the `schema` option to be given as a `Schema` instance value.
       *
       * Overrides all previously set schema options.
       */
      setSchema(version, options = {}) {
        if (typeof version === "number")
          version = String(version);
        let opt;
        switch (version) {
          case "1.1":
            if (this.directives)
              this.directives.yaml.version = "1.1";
            else
              this.directives = new directives.Directives({ version: "1.1" });
            opt = { resolveKnownTags: false, schema: "yaml-1.1" };
            break;
          case "1.2":
          case "next":
            if (this.directives)
              this.directives.yaml.version = version;
            else
              this.directives = new directives.Directives({ version });
            opt = { resolveKnownTags: true, schema: "core" };
            break;
          case null:
            if (this.directives)
              delete this.directives;
            opt = null;
            break;
          default: {
            const sv = JSON.stringify(version);
            throw new Error(`Expected '1.1', '1.2' or null as first argument, but found: ${sv}`);
          }
        }
        if (options.schema instanceof Object)
          this.schema = options.schema;
        else if (opt)
          this.schema = new Schema.Schema(Object.assign(opt, options));
        else
          throw new Error(`With a null YAML version, the { schema: Schema } option is required`);
      }
      // json & jsonArg are only used from toJSON()
      toJS({ json: json2, jsonArg, mapAsMap, maxAliasCount, onAnchor, reviver } = {}) {
        const ctx = {
          anchors: /* @__PURE__ */ new Map(),
          doc: this,
          keep: !json2,
          mapAsMap: mapAsMap === true,
          mapKeyWarned: false,
          maxAliasCount: typeof maxAliasCount === "number" ? maxAliasCount : 100
        };
        const res = toJS.toJS(this.contents, jsonArg ?? "", ctx);
        if (typeof onAnchor === "function")
          for (const { count, res: res2 } of ctx.anchors.values())
            onAnchor(res2, count);
        return typeof reviver === "function" ? applyReviver.applyReviver(reviver, { "": res }, "", res) : res;
      }
      /**
       * A JSON representation of the document `contents`.
       *
       * @param jsonArg Used by `JSON.stringify` to indicate the array index or
       *   property name.
       */
      toJSON(jsonArg, onAnchor) {
        return this.toJS({ json: true, jsonArg, mapAsMap: false, onAnchor });
      }
      /** A YAML representation of the document. */
      toString(options = {}) {
        if (this.errors.length > 0)
          throw new Error("Document with errors cannot be stringified");
        if ("indent" in options && (!Number.isInteger(options.indent) || Number(options.indent) <= 0)) {
          const s = JSON.stringify(options.indent);
          throw new Error(`"indent" option must be a positive integer, not ${s}`);
        }
        return stringifyDocument.stringifyDocument(this, options);
      }
    };
    function assertCollection(contents) {
      if (identity.isCollection(contents))
        return true;
      throw new Error("Expected a YAML collection as document contents");
    }
    exports.Document = Document;
  }
});

// node_modules/yaml/dist/errors.js
var require_errors = __commonJS({
  "node_modules/yaml/dist/errors.js"(exports) {
    "use strict";
    var YAMLError = class extends Error {
      constructor(name, pos, code, message) {
        super();
        this.name = name;
        this.code = code;
        this.message = message;
        this.pos = pos;
      }
    };
    var YAMLParseError = class extends YAMLError {
      constructor(pos, code, message) {
        super("YAMLParseError", pos, code, message);
      }
    };
    var YAMLWarning = class extends YAMLError {
      constructor(pos, code, message) {
        super("YAMLWarning", pos, code, message);
      }
    };
    var prettifyError = (src, lc) => (error) => {
      if (error.pos[0] === -1)
        return;
      error.linePos = error.pos.map((pos) => lc.linePos(pos));
      const { line, col } = error.linePos[0];
      error.message += ` at line ${line}, column ${col}`;
      let ci = col - 1;
      let lineStr = src.substring(lc.lineStarts[line - 1], lc.lineStarts[line]).replace(/[\n\r]+$/, "");
      if (ci >= 60 && lineStr.length > 80) {
        const trimStart = Math.min(ci - 39, lineStr.length - 79);
        lineStr = "\u2026" + lineStr.substring(trimStart);
        ci -= trimStart - 1;
      }
      if (lineStr.length > 80)
        lineStr = lineStr.substring(0, 79) + "\u2026";
      if (line > 1 && /^ *$/.test(lineStr.substring(0, ci))) {
        let prev = src.substring(lc.lineStarts[line - 2], lc.lineStarts[line - 1]);
        if (prev.length > 80)
          prev = prev.substring(0, 79) + "\u2026\n";
        lineStr = prev + lineStr;
      }
      if (/[^ ]/.test(lineStr)) {
        let count = 1;
        const end = error.linePos[1];
        if (end?.line === line && end.col > col) {
          count = Math.max(1, Math.min(end.col - col, 80 - ci));
        }
        const pointer = " ".repeat(ci) + "^".repeat(count);
        error.message += `:

${lineStr}
${pointer}
`;
      }
    };
    exports.YAMLError = YAMLError;
    exports.YAMLParseError = YAMLParseError;
    exports.YAMLWarning = YAMLWarning;
    exports.prettifyError = prettifyError;
  }
});

// node_modules/yaml/dist/compose/resolve-props.js
var require_resolve_props = __commonJS({
  "node_modules/yaml/dist/compose/resolve-props.js"(exports) {
    "use strict";
    function resolveProps(tokens, { flow, indicator, next, offset, onError, parentIndent, startOnNewline }) {
      let spaceBefore = false;
      let atNewline = startOnNewline;
      let hasSpace = startOnNewline;
      let comment = "";
      let commentSep = "";
      let hasNewline = false;
      let reqSpace = false;
      let tab = null;
      let anchor = null;
      let tag = null;
      let newlineAfterProp = null;
      let comma = null;
      let found = null;
      let start = null;
      for (const token of tokens) {
        if (reqSpace) {
          if (token.type !== "space" && token.type !== "newline" && token.type !== "comma")
            onError(token.offset, "MISSING_CHAR", "Tags and anchors must be separated from the next token by white space");
          reqSpace = false;
        }
        if (tab) {
          if (atNewline && token.type !== "comment" && token.type !== "newline") {
            onError(tab, "TAB_AS_INDENT", "Tabs are not allowed as indentation");
          }
          tab = null;
        }
        switch (token.type) {
          case "space":
            if (!flow && (indicator !== "doc-start" || next?.type !== "flow-collection") && token.source.includes("	")) {
              tab = token;
            }
            hasSpace = true;
            break;
          case "comment": {
            if (!hasSpace)
              onError(token, "MISSING_CHAR", "Comments must be separated from other tokens by white space characters");
            const cb = token.source.substring(1) || " ";
            if (!comment)
              comment = cb;
            else
              comment += commentSep + cb;
            commentSep = "";
            atNewline = false;
            break;
          }
          case "newline":
            if (atNewline) {
              if (comment)
                comment += token.source;
              else if (!found || indicator !== "seq-item-ind")
                spaceBefore = true;
            } else
              commentSep += token.source;
            atNewline = true;
            hasNewline = true;
            if (anchor || tag)
              newlineAfterProp = token;
            hasSpace = true;
            break;
          case "anchor":
            if (anchor)
              onError(token, "MULTIPLE_ANCHORS", "A node can have at most one anchor");
            if (token.source.endsWith(":"))
              onError(token.offset + token.source.length - 1, "BAD_ALIAS", "Anchor ending in : is ambiguous", true);
            anchor = token;
            start ?? (start = token.offset);
            atNewline = false;
            hasSpace = false;
            reqSpace = true;
            break;
          case "tag": {
            if (tag)
              onError(token, "MULTIPLE_TAGS", "A node can have at most one tag");
            tag = token;
            start ?? (start = token.offset);
            atNewline = false;
            hasSpace = false;
            reqSpace = true;
            break;
          }
          case indicator:
            if (anchor || tag)
              onError(token, "BAD_PROP_ORDER", `Anchors and tags must be after the ${token.source} indicator`);
            if (found)
              onError(token, "UNEXPECTED_TOKEN", `Unexpected ${token.source} in ${flow ?? "collection"}`);
            found = token;
            atNewline = indicator === "seq-item-ind" || indicator === "explicit-key-ind";
            hasSpace = false;
            break;
          case "comma":
            if (flow) {
              if (comma)
                onError(token, "UNEXPECTED_TOKEN", `Unexpected , in ${flow}`);
              comma = token;
              atNewline = false;
              hasSpace = false;
              break;
            }
          // else fallthrough
          default:
            onError(token, "UNEXPECTED_TOKEN", `Unexpected ${token.type} token`);
            atNewline = false;
            hasSpace = false;
        }
      }
      const last = tokens[tokens.length - 1];
      const end = last ? last.offset + last.source.length : offset;
      if (reqSpace && next && next.type !== "space" && next.type !== "newline" && next.type !== "comma" && (next.type !== "scalar" || next.source !== "")) {
        onError(next.offset, "MISSING_CHAR", "Tags and anchors must be separated from the next token by white space");
      }
      if (tab && (atNewline && tab.indent <= parentIndent || next?.type === "block-map" || next?.type === "block-seq"))
        onError(tab, "TAB_AS_INDENT", "Tabs are not allowed as indentation");
      return {
        comma,
        found,
        spaceBefore,
        comment,
        hasNewline,
        anchor,
        tag,
        newlineAfterProp,
        end,
        start: start ?? end
      };
    }
    exports.resolveProps = resolveProps;
  }
});

// node_modules/yaml/dist/compose/util-contains-newline.js
var require_util_contains_newline = __commonJS({
  "node_modules/yaml/dist/compose/util-contains-newline.js"(exports) {
    "use strict";
    function containsNewline(key) {
      if (!key)
        return null;
      switch (key.type) {
        case "alias":
        case "scalar":
        case "double-quoted-scalar":
        case "single-quoted-scalar":
          if (key.source.includes("\n"))
            return true;
          if (key.end) {
            for (const st of key.end)
              if (st.type === "newline")
                return true;
          }
          return false;
        case "flow-collection":
          for (const it of key.items) {
            for (const st of it.start)
              if (st.type === "newline")
                return true;
            if (it.sep) {
              for (const st of it.sep)
                if (st.type === "newline")
                  return true;
            }
            if (containsNewline(it.key) || containsNewline(it.value))
              return true;
          }
          return false;
        default:
          return true;
      }
    }
    exports.containsNewline = containsNewline;
  }
});

// node_modules/yaml/dist/compose/util-flow-indent-check.js
var require_util_flow_indent_check = __commonJS({
  "node_modules/yaml/dist/compose/util-flow-indent-check.js"(exports) {
    "use strict";
    var utilContainsNewline = require_util_contains_newline();
    function flowIndentCheck(indent, fc, onError) {
      if (fc?.type === "flow-collection") {
        const end = fc.end[0];
        if (end.indent === indent && (end.source === "]" || end.source === "}") && utilContainsNewline.containsNewline(fc)) {
          const msg = "Flow end indicator should be more indented than parent";
          onError(end, "BAD_INDENT", msg, true);
        }
      }
    }
    exports.flowIndentCheck = flowIndentCheck;
  }
});

// node_modules/yaml/dist/compose/util-map-includes.js
var require_util_map_includes = __commonJS({
  "node_modules/yaml/dist/compose/util-map-includes.js"(exports) {
    "use strict";
    var identity = require_identity();
    function mapIncludes(ctx, items, search) {
      const { uniqueKeys } = ctx.options;
      if (uniqueKeys === false)
        return false;
      const isEqual = typeof uniqueKeys === "function" ? uniqueKeys : (a, b) => a === b || identity.isScalar(a) && identity.isScalar(b) && a.value === b.value;
      return items.some((pair) => isEqual(pair.key, search));
    }
    exports.mapIncludes = mapIncludes;
  }
});

// node_modules/yaml/dist/compose/resolve-block-map.js
var require_resolve_block_map = __commonJS({
  "node_modules/yaml/dist/compose/resolve-block-map.js"(exports) {
    "use strict";
    var Pair = require_Pair();
    var YAMLMap = require_YAMLMap();
    var resolveProps = require_resolve_props();
    var utilContainsNewline = require_util_contains_newline();
    var utilFlowIndentCheck = require_util_flow_indent_check();
    var utilMapIncludes = require_util_map_includes();
    var startColMsg = "All mapping items must start at the same column";
    function resolveBlockMap({ composeNode, composeEmptyNode }, ctx, bm, onError, tag) {
      const NodeClass = tag?.nodeClass ?? YAMLMap.YAMLMap;
      const map = new NodeClass(ctx.schema);
      if (ctx.atRoot)
        ctx.atRoot = false;
      let offset = bm.offset;
      let commentEnd = null;
      for (const collItem of bm.items) {
        const { start, key, sep, value } = collItem;
        const keyProps = resolveProps.resolveProps(start, {
          indicator: "explicit-key-ind",
          next: key ?? sep?.[0],
          offset,
          onError,
          parentIndent: bm.indent,
          startOnNewline: true
        });
        const implicitKey = !keyProps.found;
        if (implicitKey) {
          if (key) {
            if (key.type === "block-seq")
              onError(offset, "BLOCK_AS_IMPLICIT_KEY", "A block sequence may not be used as an implicit map key");
            else if ("indent" in key && key.indent !== bm.indent)
              onError(offset, "BAD_INDENT", startColMsg);
          }
          if (!keyProps.anchor && !keyProps.tag && !sep) {
            commentEnd = keyProps.end;
            if (keyProps.comment) {
              if (map.comment)
                map.comment += "\n" + keyProps.comment;
              else
                map.comment = keyProps.comment;
            }
            continue;
          }
          if (keyProps.newlineAfterProp || utilContainsNewline.containsNewline(key)) {
            onError(key ?? start[start.length - 1], "MULTILINE_IMPLICIT_KEY", "Implicit keys need to be on a single line");
          }
        } else if (keyProps.found?.indent !== bm.indent) {
          onError(offset, "BAD_INDENT", startColMsg);
        }
        ctx.atKey = true;
        const keyStart = keyProps.end;
        const keyNode = key ? composeNode(ctx, key, keyProps, onError) : composeEmptyNode(ctx, keyStart, start, null, keyProps, onError);
        if (ctx.schema.compat)
          utilFlowIndentCheck.flowIndentCheck(bm.indent, key, onError);
        ctx.atKey = false;
        if (utilMapIncludes.mapIncludes(ctx, map.items, keyNode))
          onError(keyStart, "DUPLICATE_KEY", "Map keys must be unique");
        const valueProps = resolveProps.resolveProps(sep ?? [], {
          indicator: "map-value-ind",
          next: value,
          offset: keyNode.range[2],
          onError,
          parentIndent: bm.indent,
          startOnNewline: !key || key.type === "block-scalar"
        });
        offset = valueProps.end;
        if (valueProps.found) {
          if (implicitKey) {
            if (value?.type === "block-map" && !valueProps.hasNewline)
              onError(offset, "BLOCK_AS_IMPLICIT_KEY", "Nested mappings are not allowed in compact mappings");
            if (ctx.options.strict && keyProps.start < valueProps.found.offset - 1024)
              onError(keyNode.range, "KEY_OVER_1024_CHARS", "The : indicator must be at most 1024 chars after the start of an implicit block mapping key");
          }
          const valueNode = value ? composeNode(ctx, value, valueProps, onError) : composeEmptyNode(ctx, offset, sep, null, valueProps, onError);
          if (ctx.schema.compat)
            utilFlowIndentCheck.flowIndentCheck(bm.indent, value, onError);
          offset = valueNode.range[2];
          const pair = new Pair.Pair(keyNode, valueNode);
          if (ctx.options.keepSourceTokens)
            pair.srcToken = collItem;
          map.items.push(pair);
        } else {
          if (implicitKey)
            onError(keyNode.range, "MISSING_CHAR", "Implicit map keys need to be followed by map values");
          if (valueProps.comment) {
            if (keyNode.comment)
              keyNode.comment += "\n" + valueProps.comment;
            else
              keyNode.comment = valueProps.comment;
          }
          const pair = new Pair.Pair(keyNode);
          if (ctx.options.keepSourceTokens)
            pair.srcToken = collItem;
          map.items.push(pair);
        }
      }
      if (commentEnd && commentEnd < offset)
        onError(commentEnd, "IMPOSSIBLE", "Map comment with trailing content");
      map.range = [bm.offset, offset, commentEnd ?? offset];
      return map;
    }
    exports.resolveBlockMap = resolveBlockMap;
  }
});

// node_modules/yaml/dist/compose/resolve-block-seq.js
var require_resolve_block_seq = __commonJS({
  "node_modules/yaml/dist/compose/resolve-block-seq.js"(exports) {
    "use strict";
    var YAMLSeq = require_YAMLSeq();
    var resolveProps = require_resolve_props();
    var utilFlowIndentCheck = require_util_flow_indent_check();
    function resolveBlockSeq({ composeNode, composeEmptyNode }, ctx, bs, onError, tag) {
      const NodeClass = tag?.nodeClass ?? YAMLSeq.YAMLSeq;
      const seq = new NodeClass(ctx.schema);
      if (ctx.atRoot)
        ctx.atRoot = false;
      if (ctx.atKey)
        ctx.atKey = false;
      let offset = bs.offset;
      let commentEnd = null;
      for (const { start, value } of bs.items) {
        const props = resolveProps.resolveProps(start, {
          indicator: "seq-item-ind",
          next: value,
          offset,
          onError,
          parentIndent: bs.indent,
          startOnNewline: true
        });
        if (!props.found) {
          if (props.anchor || props.tag || value) {
            if (value?.type === "block-seq")
              onError(props.end, "BAD_INDENT", "All sequence items must start at the same column");
            else
              onError(offset, "MISSING_CHAR", "Sequence item without - indicator");
          } else {
            commentEnd = props.end;
            if (props.comment)
              seq.comment = props.comment;
            continue;
          }
        }
        const node = value ? composeNode(ctx, value, props, onError) : composeEmptyNode(ctx, props.end, start, null, props, onError);
        if (ctx.schema.compat)
          utilFlowIndentCheck.flowIndentCheck(bs.indent, value, onError);
        offset = node.range[2];
        seq.items.push(node);
      }
      seq.range = [bs.offset, offset, commentEnd ?? offset];
      return seq;
    }
    exports.resolveBlockSeq = resolveBlockSeq;
  }
});

// node_modules/yaml/dist/compose/resolve-end.js
var require_resolve_end = __commonJS({
  "node_modules/yaml/dist/compose/resolve-end.js"(exports) {
    "use strict";
    function resolveEnd(end, offset, reqSpace, onError) {
      let comment = "";
      if (end) {
        let hasSpace = false;
        let sep = "";
        for (const token of end) {
          const { source: source2, type } = token;
          switch (type) {
            case "space":
              hasSpace = true;
              break;
            case "comment": {
              if (reqSpace && !hasSpace)
                onError(token, "MISSING_CHAR", "Comments must be separated from other tokens by white space characters");
              const cb = source2.substring(1) || " ";
              if (!comment)
                comment = cb;
              else
                comment += sep + cb;
              sep = "";
              break;
            }
            case "newline":
              if (comment)
                sep += source2;
              hasSpace = true;
              break;
            default:
              onError(token, "UNEXPECTED_TOKEN", `Unexpected ${type} at node end`);
          }
          offset += source2.length;
        }
      }
      return { comment, offset };
    }
    exports.resolveEnd = resolveEnd;
  }
});

// node_modules/yaml/dist/compose/resolve-flow-collection.js
var require_resolve_flow_collection = __commonJS({
  "node_modules/yaml/dist/compose/resolve-flow-collection.js"(exports) {
    "use strict";
    var identity = require_identity();
    var Pair = require_Pair();
    var YAMLMap = require_YAMLMap();
    var YAMLSeq = require_YAMLSeq();
    var resolveEnd = require_resolve_end();
    var resolveProps = require_resolve_props();
    var utilContainsNewline = require_util_contains_newline();
    var utilMapIncludes = require_util_map_includes();
    var blockMsg = "Block collections are not allowed within flow collections";
    var isBlock = (token) => token && (token.type === "block-map" || token.type === "block-seq");
    function resolveFlowCollection({ composeNode, composeEmptyNode }, ctx, fc, onError, tag) {
      const isMap2 = fc.start.source === "{";
      const fcName = isMap2 ? "flow map" : "flow sequence";
      const NodeClass = tag?.nodeClass ?? (isMap2 ? YAMLMap.YAMLMap : YAMLSeq.YAMLSeq);
      const coll = new NodeClass(ctx.schema);
      coll.flow = true;
      const atRoot = ctx.atRoot;
      if (atRoot)
        ctx.atRoot = false;
      if (ctx.atKey)
        ctx.atKey = false;
      let offset = fc.offset + fc.start.source.length;
      for (let i = 0; i < fc.items.length; ++i) {
        const collItem = fc.items[i];
        const { start, key, sep, value } = collItem;
        const props = resolveProps.resolveProps(start, {
          flow: fcName,
          indicator: "explicit-key-ind",
          next: key ?? sep?.[0],
          offset,
          onError,
          parentIndent: fc.indent,
          startOnNewline: false
        });
        if (!props.found) {
          if (!props.anchor && !props.tag && !sep && !value) {
            if (i === 0 && props.comma)
              onError(props.comma, "UNEXPECTED_TOKEN", `Unexpected , in ${fcName}`);
            else if (i < fc.items.length - 1)
              onError(props.start, "UNEXPECTED_TOKEN", `Unexpected empty item in ${fcName}`);
            if (props.comment) {
              if (coll.comment)
                coll.comment += "\n" + props.comment;
              else
                coll.comment = props.comment;
            }
            offset = props.end;
            continue;
          }
          if (!isMap2 && ctx.options.strict && utilContainsNewline.containsNewline(key))
            onError(
              key,
              // checked by containsNewline()
              "MULTILINE_IMPLICIT_KEY",
              "Implicit keys of flow sequence pairs need to be on a single line"
            );
        }
        if (i === 0) {
          if (props.comma)
            onError(props.comma, "UNEXPECTED_TOKEN", `Unexpected , in ${fcName}`);
        } else {
          if (!props.comma)
            onError(props.start, "MISSING_CHAR", `Missing , between ${fcName} items`);
          if (props.comment) {
            let prevItemComment = "";
            loop: for (const st of start) {
              switch (st.type) {
                case "comma":
                case "space":
                  break;
                case "comment":
                  prevItemComment = st.source.substring(1);
                  break loop;
                default:
                  break loop;
              }
            }
            if (prevItemComment) {
              let prev = coll.items[coll.items.length - 1];
              if (identity.isPair(prev))
                prev = prev.value ?? prev.key;
              if (prev.comment)
                prev.comment += "\n" + prevItemComment;
              else
                prev.comment = prevItemComment;
              props.comment = props.comment.substring(prevItemComment.length + 1);
            }
          }
        }
        if (!isMap2 && !sep && !props.found) {
          const valueNode = value ? composeNode(ctx, value, props, onError) : composeEmptyNode(ctx, props.end, sep, null, props, onError);
          coll.items.push(valueNode);
          offset = valueNode.range[2];
          if (isBlock(value))
            onError(valueNode.range, "BLOCK_IN_FLOW", blockMsg);
        } else {
          ctx.atKey = true;
          const keyStart = props.end;
          const keyNode = key ? composeNode(ctx, key, props, onError) : composeEmptyNode(ctx, keyStart, start, null, props, onError);
          if (isBlock(key))
            onError(keyNode.range, "BLOCK_IN_FLOW", blockMsg);
          ctx.atKey = false;
          const valueProps = resolveProps.resolveProps(sep ?? [], {
            flow: fcName,
            indicator: "map-value-ind",
            next: value,
            offset: keyNode.range[2],
            onError,
            parentIndent: fc.indent,
            startOnNewline: false
          });
          if (valueProps.found) {
            if (!isMap2 && !props.found && ctx.options.strict) {
              if (sep)
                for (const st of sep) {
                  if (st === valueProps.found)
                    break;
                  if (st.type === "newline") {
                    onError(st, "MULTILINE_IMPLICIT_KEY", "Implicit keys of flow sequence pairs need to be on a single line");
                    break;
                  }
                }
              if (props.start < valueProps.found.offset - 1024)
                onError(valueProps.found, "KEY_OVER_1024_CHARS", "The : indicator must be at most 1024 chars after the start of an implicit flow sequence key");
            }
          } else if (value) {
            if ("source" in value && value.source?.[0] === ":")
              onError(value, "MISSING_CHAR", `Missing space after : in ${fcName}`);
            else
              onError(valueProps.start, "MISSING_CHAR", `Missing , or : between ${fcName} items`);
          }
          const valueNode = value ? composeNode(ctx, value, valueProps, onError) : valueProps.found ? composeEmptyNode(ctx, valueProps.end, sep, null, valueProps, onError) : null;
          if (valueNode) {
            if (isBlock(value))
              onError(valueNode.range, "BLOCK_IN_FLOW", blockMsg);
          } else if (valueProps.comment) {
            if (keyNode.comment)
              keyNode.comment += "\n" + valueProps.comment;
            else
              keyNode.comment = valueProps.comment;
          }
          const pair = new Pair.Pair(keyNode, valueNode);
          if (ctx.options.keepSourceTokens)
            pair.srcToken = collItem;
          if (isMap2) {
            const map = coll;
            if (utilMapIncludes.mapIncludes(ctx, map.items, keyNode))
              onError(keyStart, "DUPLICATE_KEY", "Map keys must be unique");
            map.items.push(pair);
          } else {
            const map = new YAMLMap.YAMLMap(ctx.schema);
            map.flow = true;
            map.items.push(pair);
            const endRange = (valueNode ?? keyNode).range;
            map.range = [keyNode.range[0], endRange[1], endRange[2]];
            coll.items.push(map);
          }
          offset = valueNode ? valueNode.range[2] : valueProps.end;
        }
      }
      const expectedEnd = isMap2 ? "}" : "]";
      const [ce, ...ee] = fc.end;
      let cePos = offset;
      if (ce?.source === expectedEnd)
        cePos = ce.offset + ce.source.length;
      else {
        const name = fcName[0].toUpperCase() + fcName.substring(1);
        const msg = atRoot ? `${name} must end with a ${expectedEnd}` : `${name} in block collection must be sufficiently indented and end with a ${expectedEnd}`;
        onError(offset, atRoot ? "MISSING_CHAR" : "BAD_INDENT", msg);
        if (ce && ce.source.length !== 1)
          ee.unshift(ce);
      }
      if (ee.length > 0) {
        const end = resolveEnd.resolveEnd(ee, cePos, ctx.options.strict, onError);
        if (end.comment) {
          if (coll.comment)
            coll.comment += "\n" + end.comment;
          else
            coll.comment = end.comment;
        }
        coll.range = [fc.offset, cePos, end.offset];
      } else {
        coll.range = [fc.offset, cePos, cePos];
      }
      return coll;
    }
    exports.resolveFlowCollection = resolveFlowCollection;
  }
});

// node_modules/yaml/dist/compose/compose-collection.js
var require_compose_collection = __commonJS({
  "node_modules/yaml/dist/compose/compose-collection.js"(exports) {
    "use strict";
    var identity = require_identity();
    var Scalar = require_Scalar();
    var YAMLMap = require_YAMLMap();
    var YAMLSeq = require_YAMLSeq();
    var resolveBlockMap = require_resolve_block_map();
    var resolveBlockSeq = require_resolve_block_seq();
    var resolveFlowCollection = require_resolve_flow_collection();
    function resolveCollection(CN, ctx, token, onError, tagName, tag) {
      const coll = token.type === "block-map" ? resolveBlockMap.resolveBlockMap(CN, ctx, token, onError, tag) : token.type === "block-seq" ? resolveBlockSeq.resolveBlockSeq(CN, ctx, token, onError, tag) : resolveFlowCollection.resolveFlowCollection(CN, ctx, token, onError, tag);
      const Coll = coll.constructor;
      if (tagName === "!" || tagName === Coll.tagName) {
        coll.tag = Coll.tagName;
        return coll;
      }
      if (tagName)
        coll.tag = tagName;
      return coll;
    }
    function composeCollection(CN, ctx, token, props, onError) {
      const tagToken = props.tag;
      const tagName = !tagToken ? null : ctx.directives.tagName(tagToken.source, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg));
      if (token.type === "block-seq") {
        const { anchor, newlineAfterProp: nl } = props;
        const lastProp = anchor && tagToken ? anchor.offset > tagToken.offset ? anchor : tagToken : anchor ?? tagToken;
        if (lastProp && (!nl || nl.offset < lastProp.offset)) {
          const message = "Missing newline after block sequence props";
          onError(lastProp, "MISSING_CHAR", message);
        }
      }
      const expType = token.type === "block-map" ? "map" : token.type === "block-seq" ? "seq" : token.start.source === "{" ? "map" : "seq";
      if (!tagToken || !tagName || tagName === "!" || tagName === YAMLMap.YAMLMap.tagName && expType === "map" || tagName === YAMLSeq.YAMLSeq.tagName && expType === "seq") {
        return resolveCollection(CN, ctx, token, onError, tagName);
      }
      let tag = ctx.schema.tags.find((t) => t.tag === tagName && t.collection === expType);
      if (!tag) {
        const kt = ctx.schema.knownTags[tagName];
        if (kt?.collection === expType) {
          ctx.schema.tags.push(Object.assign({}, kt, { default: false }));
          tag = kt;
        } else {
          if (kt) {
            onError(tagToken, "BAD_COLLECTION_TYPE", `${kt.tag} used for ${expType} collection, but expects ${kt.collection ?? "scalar"}`, true);
          } else {
            onError(tagToken, "TAG_RESOLVE_FAILED", `Unresolved tag: ${tagName}`, true);
          }
          return resolveCollection(CN, ctx, token, onError, tagName);
        }
      }
      const coll = resolveCollection(CN, ctx, token, onError, tagName, tag);
      const res = tag.resolve?.(coll, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg), ctx.options) ?? coll;
      const node = identity.isNode(res) ? res : new Scalar.Scalar(res);
      node.range = coll.range;
      node.tag = tagName;
      if (tag?.format)
        node.format = tag.format;
      return node;
    }
    exports.composeCollection = composeCollection;
  }
});

// node_modules/yaml/dist/compose/resolve-block-scalar.js
var require_resolve_block_scalar = __commonJS({
  "node_modules/yaml/dist/compose/resolve-block-scalar.js"(exports) {
    "use strict";
    var Scalar = require_Scalar();
    function resolveBlockScalar(ctx, scalar, onError) {
      const start = scalar.offset;
      const header = parseBlockScalarHeader(scalar, ctx.options.strict, onError);
      if (!header)
        return { value: "", type: null, comment: "", range: [start, start, start] };
      const type = header.mode === ">" ? Scalar.Scalar.BLOCK_FOLDED : Scalar.Scalar.BLOCK_LITERAL;
      const lines = scalar.source ? splitLines(scalar.source) : [];
      let chompStart = lines.length;
      for (let i = lines.length - 1; i >= 0; --i) {
        const content = lines[i][1];
        if (content === "" || content === "\r")
          chompStart = i;
        else
          break;
      }
      if (chompStart === 0) {
        const value2 = header.chomp === "+" && lines.length > 0 ? "\n".repeat(Math.max(1, lines.length - 1)) : "";
        let end2 = start + header.length;
        if (scalar.source)
          end2 += scalar.source.length;
        return { value: value2, type, comment: header.comment, range: [start, end2, end2] };
      }
      let trimIndent = scalar.indent + header.indent;
      let offset = scalar.offset + header.length;
      let contentStart = 0;
      for (let i = 0; i < chompStart; ++i) {
        const [indent, content] = lines[i];
        if (content === "" || content === "\r") {
          if (header.indent === 0 && indent.length > trimIndent)
            trimIndent = indent.length;
        } else {
          if (indent.length < trimIndent) {
            const message = "Block scalars with more-indented leading empty lines must use an explicit indentation indicator";
            onError(offset + indent.length, "MISSING_CHAR", message);
          }
          if (header.indent === 0)
            trimIndent = indent.length;
          contentStart = i;
          if (trimIndent === 0 && !ctx.atRoot) {
            const message = "Block scalar values in collections must be indented";
            onError(offset, "BAD_INDENT", message);
          }
          break;
        }
        offset += indent.length + content.length + 1;
      }
      for (let i = lines.length - 1; i >= chompStart; --i) {
        if (lines[i][0].length > trimIndent)
          chompStart = i + 1;
      }
      let value = "";
      let sep = "";
      let prevMoreIndented = false;
      for (let i = 0; i < contentStart; ++i)
        value += lines[i][0].slice(trimIndent) + "\n";
      for (let i = contentStart; i < chompStart; ++i) {
        let [indent, content] = lines[i];
        offset += indent.length + content.length + 1;
        const crlf = content[content.length - 1] === "\r";
        if (crlf)
          content = content.slice(0, -1);
        if (content && indent.length < trimIndent) {
          const src = header.indent ? "explicit indentation indicator" : "first line";
          const message = `Block scalar lines must not be less indented than their ${src}`;
          onError(offset - content.length - (crlf ? 2 : 1), "BAD_INDENT", message);
          indent = "";
        }
        if (type === Scalar.Scalar.BLOCK_LITERAL) {
          value += sep + indent.slice(trimIndent) + content;
          sep = "\n";
        } else if (indent.length > trimIndent || content[0] === "	") {
          if (sep === " ")
            sep = "\n";
          else if (!prevMoreIndented && sep === "\n")
            sep = "\n\n";
          value += sep + indent.slice(trimIndent) + content;
          sep = "\n";
          prevMoreIndented = true;
        } else if (content === "") {
          if (sep === "\n")
            value += "\n";
          else
            sep = "\n";
        } else {
          value += sep + content;
          sep = " ";
          prevMoreIndented = false;
        }
      }
      switch (header.chomp) {
        case "-":
          break;
        case "+":
          for (let i = chompStart; i < lines.length; ++i)
            value += "\n" + lines[i][0].slice(trimIndent);
          if (value[value.length - 1] !== "\n")
            value += "\n";
          break;
        default:
          value += "\n";
      }
      const end = start + header.length + scalar.source.length;
      return { value, type, comment: header.comment, range: [start, end, end] };
    }
    function parseBlockScalarHeader({ offset, props }, strict, onError) {
      if (props[0].type !== "block-scalar-header") {
        onError(props[0], "IMPOSSIBLE", "Block scalar header not found");
        return null;
      }
      const { source: source2 } = props[0];
      const mode = source2[0];
      let indent = 0;
      let chomp = "";
      let error = -1;
      for (let i = 1; i < source2.length; ++i) {
        const ch = source2[i];
        if (!chomp && (ch === "-" || ch === "+"))
          chomp = ch;
        else {
          const n = Number(ch);
          if (!indent && n)
            indent = n;
          else if (error === -1)
            error = offset + i;
        }
      }
      if (error !== -1)
        onError(error, "UNEXPECTED_TOKEN", `Block scalar header includes extra characters: ${source2}`);
      let hasSpace = false;
      let comment = "";
      let length = source2.length;
      for (let i = 1; i < props.length; ++i) {
        const token = props[i];
        switch (token.type) {
          case "space":
            hasSpace = true;
          // fallthrough
          case "newline":
            length += token.source.length;
            break;
          case "comment":
            if (strict && !hasSpace) {
              const message = "Comments must be separated from other tokens by white space characters";
              onError(token, "MISSING_CHAR", message);
            }
            length += token.source.length;
            comment = token.source.substring(1);
            break;
          case "error":
            onError(token, "UNEXPECTED_TOKEN", token.message);
            length += token.source.length;
            break;
          /* istanbul ignore next should not happen */
          default: {
            const message = `Unexpected token in block scalar header: ${token.type}`;
            onError(token, "UNEXPECTED_TOKEN", message);
            const ts = token.source;
            if (ts && typeof ts === "string")
              length += ts.length;
          }
        }
      }
      return { mode, indent, chomp, comment, length };
    }
    function splitLines(source2) {
      const split = source2.split(/\n( *)/);
      const first = split[0];
      const m = first.match(/^( *)/);
      const line0 = m?.[1] ? [m[1], first.slice(m[1].length)] : ["", first];
      const lines = [line0];
      for (let i = 1; i < split.length; i += 2)
        lines.push([split[i], split[i + 1]]);
      return lines;
    }
    exports.resolveBlockScalar = resolveBlockScalar;
  }
});

// node_modules/yaml/dist/compose/resolve-flow-scalar.js
var require_resolve_flow_scalar = __commonJS({
  "node_modules/yaml/dist/compose/resolve-flow-scalar.js"(exports) {
    "use strict";
    var Scalar = require_Scalar();
    var resolveEnd = require_resolve_end();
    function resolveFlowScalar(scalar, strict, onError) {
      const { offset, type, source: source2, end } = scalar;
      let _type;
      let value;
      const _onError = (rel, code, msg) => onError(offset + rel, code, msg);
      switch (type) {
        case "scalar":
          _type = Scalar.Scalar.PLAIN;
          value = plainValue(source2, _onError);
          break;
        case "single-quoted-scalar":
          _type = Scalar.Scalar.QUOTE_SINGLE;
          value = singleQuotedValue(source2, _onError);
          break;
        case "double-quoted-scalar":
          _type = Scalar.Scalar.QUOTE_DOUBLE;
          value = doubleQuotedValue(source2, _onError);
          break;
        /* istanbul ignore next should not happen */
        default:
          onError(scalar, "UNEXPECTED_TOKEN", `Expected a flow scalar value, but found: ${type}`);
          return {
            value: "",
            type: null,
            comment: "",
            range: [offset, offset + source2.length, offset + source2.length]
          };
      }
      const valueEnd = offset + source2.length;
      const re = resolveEnd.resolveEnd(end, valueEnd, strict, onError);
      return {
        value,
        type: _type,
        comment: re.comment,
        range: [offset, valueEnd, re.offset]
      };
    }
    function plainValue(source2, onError) {
      let badChar = "";
      switch (source2[0]) {
        /* istanbul ignore next should not happen */
        case "	":
          badChar = "a tab character";
          break;
        case ",":
          badChar = "flow indicator character ,";
          break;
        case "%":
          badChar = "directive indicator character %";
          break;
        case "|":
        case ">": {
          badChar = `block scalar indicator ${source2[0]}`;
          break;
        }
        case "@":
        case "`": {
          badChar = `reserved character ${source2[0]}`;
          break;
        }
      }
      if (badChar)
        onError(0, "BAD_SCALAR_START", `Plain value cannot start with ${badChar}`);
      return foldLines(source2);
    }
    function singleQuotedValue(source2, onError) {
      if (source2[source2.length - 1] !== "'" || source2.length === 1)
        onError(source2.length, "MISSING_CHAR", "Missing closing 'quote");
      return foldLines(source2.slice(1, -1)).replace(/''/g, "'");
    }
    function foldLines(source2) {
      let first, line;
      try {
        first = new RegExp("(.*?)(?<![ 	])[ 	]*\r?\n", "sy");
        line = new RegExp("[ 	]*(.*?)(?:(?<![ 	])[ 	]*)?\r?\n", "sy");
      } catch {
        first = /(.*?)[ \t]*\r?\n/sy;
        line = /[ \t]*(.*?)[ \t]*\r?\n/sy;
      }
      let match = first.exec(source2);
      if (!match)
        return source2;
      let res = match[1];
      let sep = " ";
      let pos = first.lastIndex;
      line.lastIndex = pos;
      while (match = line.exec(source2)) {
        if (match[1] === "") {
          if (sep === "\n")
            res += sep;
          else
            sep = "\n";
        } else {
          res += sep + match[1];
          sep = " ";
        }
        pos = line.lastIndex;
      }
      const last = /[ \t]*(.*)/sy;
      last.lastIndex = pos;
      match = last.exec(source2);
      return res + sep + (match?.[1] ?? "");
    }
    function doubleQuotedValue(source2, onError) {
      let res = "";
      for (let i = 1; i < source2.length - 1; ++i) {
        const ch = source2[i];
        if (ch === "\r" && source2[i + 1] === "\n")
          continue;
        if (ch === "\n") {
          const { fold, offset } = foldNewline(source2, i);
          res += fold;
          i = offset;
        } else if (ch === "\\") {
          let next = source2[++i];
          const cc = escapeCodes[next];
          if (cc)
            res += cc;
          else if (next === "\n") {
            next = source2[i + 1];
            while (next === " " || next === "	")
              next = source2[++i + 1];
          } else if (next === "\r" && source2[i + 1] === "\n") {
            next = source2[++i + 1];
            while (next === " " || next === "	")
              next = source2[++i + 1];
          } else if (next === "x" || next === "u" || next === "U") {
            const length = next === "x" ? 2 : next === "u" ? 4 : 8;
            res += parseCharCode(source2, i + 1, length, onError);
            i += length;
          } else {
            const raw = source2.substr(i - 1, 2);
            onError(i - 1, "BAD_DQ_ESCAPE", `Invalid escape sequence ${raw}`);
            res += raw;
          }
        } else if (ch === " " || ch === "	") {
          const wsStart = i;
          let next = source2[i + 1];
          while (next === " " || next === "	")
            next = source2[++i + 1];
          if (next !== "\n" && !(next === "\r" && source2[i + 2] === "\n"))
            res += i > wsStart ? source2.slice(wsStart, i + 1) : ch;
        } else {
          res += ch;
        }
      }
      if (source2[source2.length - 1] !== '"' || source2.length === 1)
        onError(source2.length, "MISSING_CHAR", 'Missing closing "quote');
      return res;
    }
    function foldNewline(source2, offset) {
      let fold = "";
      let ch = source2[offset + 1];
      while (ch === " " || ch === "	" || ch === "\n" || ch === "\r") {
        if (ch === "\r" && source2[offset + 2] !== "\n")
          break;
        if (ch === "\n")
          fold += "\n";
        offset += 1;
        ch = source2[offset + 1];
      }
      if (!fold)
        fold = " ";
      return { fold, offset };
    }
    var escapeCodes = {
      "0": "\0",
      // null character
      a: "\x07",
      // bell character
      b: "\b",
      // backspace
      e: "\x1B",
      // escape character
      f: "\f",
      // form feed
      n: "\n",
      // line feed
      r: "\r",
      // carriage return
      t: "	",
      // horizontal tab
      v: "\v",
      // vertical tab
      N: "\x85",
      // Unicode next line
      _: "\xA0",
      // Unicode non-breaking space
      L: "\u2028",
      // Unicode line separator
      P: "\u2029",
      // Unicode paragraph separator
      " ": " ",
      '"': '"',
      "/": "/",
      "\\": "\\",
      "	": "	"
    };
    function parseCharCode(source2, offset, length, onError) {
      const cc = source2.substr(offset, length);
      const ok = cc.length === length && /^[0-9a-fA-F]+$/.test(cc);
      const code = ok ? parseInt(cc, 16) : NaN;
      try {
        return String.fromCodePoint(code);
      } catch {
        const raw = source2.substr(offset - 2, length + 2);
        onError(offset - 2, "BAD_DQ_ESCAPE", `Invalid escape sequence ${raw}`);
        return raw;
      }
    }
    exports.resolveFlowScalar = resolveFlowScalar;
  }
});

// node_modules/yaml/dist/compose/compose-scalar.js
var require_compose_scalar = __commonJS({
  "node_modules/yaml/dist/compose/compose-scalar.js"(exports) {
    "use strict";
    var identity = require_identity();
    var Scalar = require_Scalar();
    var resolveBlockScalar = require_resolve_block_scalar();
    var resolveFlowScalar = require_resolve_flow_scalar();
    function composeScalar(ctx, token, tagToken, onError) {
      const { value, type, comment, range } = token.type === "block-scalar" ? resolveBlockScalar.resolveBlockScalar(ctx, token, onError) : resolveFlowScalar.resolveFlowScalar(token, ctx.options.strict, onError);
      const tagName = tagToken ? ctx.directives.tagName(tagToken.source, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg)) : null;
      let tag;
      if (ctx.options.stringKeys && ctx.atKey) {
        tag = ctx.schema[identity.SCALAR];
      } else if (tagName)
        tag = findScalarTagByName(ctx.schema, value, tagName, tagToken, onError);
      else if (token.type === "scalar")
        tag = findScalarTagByTest(ctx, value, token, onError);
      else
        tag = ctx.schema[identity.SCALAR];
      let scalar;
      try {
        const res = tag.resolve(value, (msg) => onError(tagToken ?? token, "TAG_RESOLVE_FAILED", msg), ctx.options);
        scalar = identity.isScalar(res) ? res : new Scalar.Scalar(res);
      } catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        onError(tagToken ?? token, "TAG_RESOLVE_FAILED", msg);
        scalar = new Scalar.Scalar(value);
      }
      scalar.range = range;
      scalar.source = value;
      if (type)
        scalar.type = type;
      if (tagName)
        scalar.tag = tagName;
      if (tag.format)
        scalar.format = tag.format;
      if (comment)
        scalar.comment = comment;
      return scalar;
    }
    function findScalarTagByName(schema2, value, tagName, tagToken, onError) {
      if (tagName === "!")
        return schema2[identity.SCALAR];
      const matchWithTest = [];
      for (const tag of schema2.tags) {
        if (!tag.collection && tag.tag === tagName) {
          if (tag.default && tag.test)
            matchWithTest.push(tag);
          else
            return tag;
        }
      }
      for (const tag of matchWithTest)
        if (tag.test?.test(value))
          return tag;
      const kt = schema2.knownTags[tagName];
      if (kt && !kt.collection) {
        schema2.tags.push(Object.assign({}, kt, { default: false, test: void 0 }));
        return kt;
      }
      onError(tagToken, "TAG_RESOLVE_FAILED", `Unresolved tag: ${tagName}`, tagName !== "tag:yaml.org,2002:str");
      return schema2[identity.SCALAR];
    }
    function findScalarTagByTest({ atKey, directives, schema: schema2 }, value, token, onError) {
      const tag = schema2.tags.find((tag2) => (tag2.default === true || atKey && tag2.default === "key") && tag2.test?.test(value)) || schema2[identity.SCALAR];
      if (schema2.compat) {
        const compat = schema2.compat.find((tag2) => tag2.default && tag2.test?.test(value)) ?? schema2[identity.SCALAR];
        if (tag.tag !== compat.tag) {
          const ts = directives.tagString(tag.tag);
          const cs = directives.tagString(compat.tag);
          const msg = `Value may be parsed as either ${ts} or ${cs}`;
          onError(token, "TAG_RESOLVE_FAILED", msg, true);
        }
      }
      return tag;
    }
    exports.composeScalar = composeScalar;
  }
});

// node_modules/yaml/dist/compose/util-empty-scalar-position.js
var require_util_empty_scalar_position = __commonJS({
  "node_modules/yaml/dist/compose/util-empty-scalar-position.js"(exports) {
    "use strict";
    function emptyScalarPosition(offset, before, pos) {
      if (before) {
        pos ?? (pos = before.length);
        for (let i = pos - 1; i >= 0; --i) {
          let st = before[i];
          switch (st.type) {
            case "space":
            case "comment":
            case "newline":
              offset -= st.source.length;
              continue;
          }
          st = before[++i];
          while (st?.type === "space") {
            offset += st.source.length;
            st = before[++i];
          }
          break;
        }
      }
      return offset;
    }
    exports.emptyScalarPosition = emptyScalarPosition;
  }
});

// node_modules/yaml/dist/compose/compose-node.js
var require_compose_node = __commonJS({
  "node_modules/yaml/dist/compose/compose-node.js"(exports) {
    "use strict";
    var Alias = require_Alias();
    var identity = require_identity();
    var composeCollection = require_compose_collection();
    var composeScalar = require_compose_scalar();
    var resolveEnd = require_resolve_end();
    var utilEmptyScalarPosition = require_util_empty_scalar_position();
    var CN = { composeNode, composeEmptyNode };
    function composeNode(ctx, token, props, onError) {
      const atKey = ctx.atKey;
      const { spaceBefore, comment, anchor, tag } = props;
      let node;
      let isSrcToken = true;
      switch (token.type) {
        case "alias":
          node = composeAlias(ctx, token, onError);
          if (anchor || tag)
            onError(token, "ALIAS_PROPS", "An alias node must not specify any properties");
          break;
        case "scalar":
        case "single-quoted-scalar":
        case "double-quoted-scalar":
        case "block-scalar":
          node = composeScalar.composeScalar(ctx, token, tag, onError);
          if (anchor)
            node.anchor = anchor.source.substring(1);
          break;
        case "block-map":
        case "block-seq":
        case "flow-collection":
          try {
            node = composeCollection.composeCollection(CN, ctx, token, props, onError);
            if (anchor)
              node.anchor = anchor.source.substring(1);
          } catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            onError(token, "RESOURCE_EXHAUSTION", message);
          }
          break;
        default: {
          const message = token.type === "error" ? token.message : `Unsupported token (type: ${token.type})`;
          onError(token, "UNEXPECTED_TOKEN", message);
          isSrcToken = false;
        }
      }
      node ?? (node = composeEmptyNode(ctx, token.offset, void 0, null, props, onError));
      if (anchor && node.anchor === "")
        onError(anchor, "BAD_ALIAS", "Anchor cannot be an empty string");
      if (atKey && ctx.options.stringKeys && (!identity.isScalar(node) || typeof node.value !== "string" || node.tag && node.tag !== "tag:yaml.org,2002:str")) {
        const msg = "With stringKeys, all keys must be strings";
        onError(tag ?? token, "NON_STRING_KEY", msg);
      }
      if (spaceBefore)
        node.spaceBefore = true;
      if (comment) {
        if (token.type === "scalar" && token.source === "")
          node.comment = comment;
        else
          node.commentBefore = comment;
      }
      if (ctx.options.keepSourceTokens && isSrcToken)
        node.srcToken = token;
      return node;
    }
    function composeEmptyNode(ctx, offset, before, pos, { spaceBefore, comment, anchor, tag, end }, onError) {
      const token = {
        type: "scalar",
        offset: utilEmptyScalarPosition.emptyScalarPosition(offset, before, pos),
        indent: -1,
        source: ""
      };
      const node = composeScalar.composeScalar(ctx, token, tag, onError);
      if (anchor) {
        node.anchor = anchor.source.substring(1);
        if (node.anchor === "")
          onError(anchor, "BAD_ALIAS", "Anchor cannot be an empty string");
      }
      if (spaceBefore)
        node.spaceBefore = true;
      if (comment) {
        node.comment = comment;
        node.range[2] = end;
      }
      return node;
    }
    function composeAlias({ options }, { offset, source: source2, end }, onError) {
      const alias = new Alias.Alias(source2.substring(1));
      if (alias.source === "")
        onError(offset, "BAD_ALIAS", "Alias cannot be an empty string");
      if (alias.source.endsWith(":"))
        onError(offset + source2.length - 1, "BAD_ALIAS", "Alias ending in : is ambiguous", true);
      const valueEnd = offset + source2.length;
      const re = resolveEnd.resolveEnd(end, valueEnd, options.strict, onError);
      alias.range = [offset, valueEnd, re.offset];
      if (re.comment)
        alias.comment = re.comment;
      return alias;
    }
    exports.composeEmptyNode = composeEmptyNode;
    exports.composeNode = composeNode;
  }
});

// node_modules/yaml/dist/compose/compose-doc.js
var require_compose_doc = __commonJS({
  "node_modules/yaml/dist/compose/compose-doc.js"(exports) {
    "use strict";
    var Document = require_Document();
    var composeNode = require_compose_node();
    var resolveEnd = require_resolve_end();
    var resolveProps = require_resolve_props();
    function composeDoc(options, directives, { offset, start, value, end }, onError) {
      const opts = Object.assign({ _directives: directives }, options);
      const doc = new Document.Document(void 0, opts);
      const ctx = {
        atKey: false,
        atRoot: true,
        directives: doc.directives,
        options: doc.options,
        schema: doc.schema
      };
      const props = resolveProps.resolveProps(start, {
        indicator: "doc-start",
        next: value ?? end?.[0],
        offset,
        onError,
        parentIndent: 0,
        startOnNewline: true
      });
      if (props.found) {
        doc.directives.docStart = true;
        if (value && (value.type === "block-map" || value.type === "block-seq") && !props.hasNewline)
          onError(props.end, "MISSING_CHAR", "Block collection cannot start on same line with directives-end marker");
      }
      doc.contents = value ? composeNode.composeNode(ctx, value, props, onError) : composeNode.composeEmptyNode(ctx, props.end, start, null, props, onError);
      const contentEnd = doc.contents.range[2];
      const re = resolveEnd.resolveEnd(end, contentEnd, false, onError);
      if (re.comment)
        doc.comment = re.comment;
      doc.range = [offset, contentEnd, re.offset];
      return doc;
    }
    exports.composeDoc = composeDoc;
  }
});

// node_modules/yaml/dist/compose/composer.js
var require_composer = __commonJS({
  "node_modules/yaml/dist/compose/composer.js"(exports) {
    "use strict";
    var node_process = __require("process");
    var directives = require_directives();
    var Document = require_Document();
    var errors = require_errors();
    var identity = require_identity();
    var composeDoc = require_compose_doc();
    var resolveEnd = require_resolve_end();
    function getErrorPos(src) {
      if (typeof src === "number")
        return [src, src + 1];
      if (Array.isArray(src))
        return src.length === 2 ? src : [src[0], src[1]];
      const { offset, source: source2 } = src;
      return [offset, offset + (typeof source2 === "string" ? source2.length : 1)];
    }
    function parsePrelude(prelude) {
      let comment = "";
      let atComment = false;
      let afterEmptyLine = false;
      for (let i = 0; i < prelude.length; ++i) {
        const source2 = prelude[i];
        switch (source2[0]) {
          case "#":
            comment += (comment === "" ? "" : afterEmptyLine ? "\n\n" : "\n") + (source2.substring(1) || " ");
            atComment = true;
            afterEmptyLine = false;
            break;
          case "%":
            if (prelude[i + 1]?.[0] !== "#")
              i += 1;
            atComment = false;
            break;
          default:
            if (!atComment)
              afterEmptyLine = true;
            atComment = false;
        }
      }
      return { comment, afterEmptyLine };
    }
    var Composer = class {
      constructor(options = {}) {
        this.doc = null;
        this.atDirectives = false;
        this.prelude = [];
        this.errors = [];
        this.warnings = [];
        this.onError = (source2, code, message, warning) => {
          const pos = getErrorPos(source2);
          if (warning)
            this.warnings.push(new errors.YAMLWarning(pos, code, message));
          else
            this.errors.push(new errors.YAMLParseError(pos, code, message));
        };
        this.directives = new directives.Directives({ version: options.version || "1.2" });
        this.options = options;
      }
      decorate(doc, afterDoc) {
        const { comment, afterEmptyLine } = parsePrelude(this.prelude);
        if (comment) {
          const dc = doc.contents;
          if (afterDoc) {
            doc.comment = doc.comment ? `${doc.comment}
${comment}` : comment;
          } else if (afterEmptyLine || doc.directives.docStart || !dc) {
            doc.commentBefore = comment;
          } else if (identity.isCollection(dc) && !dc.flow && dc.items.length > 0) {
            let it = dc.items[0];
            if (identity.isPair(it))
              it = it.key;
            const cb = it.commentBefore;
            it.commentBefore = cb ? `${comment}
${cb}` : comment;
          } else {
            const cb = dc.commentBefore;
            dc.commentBefore = cb ? `${comment}
${cb}` : comment;
          }
        }
        if (afterDoc) {
          for (let i = 0; i < this.errors.length; ++i)
            doc.errors.push(this.errors[i]);
          for (let i = 0; i < this.warnings.length; ++i)
            doc.warnings.push(this.warnings[i]);
        } else {
          doc.errors = this.errors;
          doc.warnings = this.warnings;
        }
        this.prelude = [];
        this.errors = [];
        this.warnings = [];
      }
      /**
       * Current stream status information.
       *
       * Mostly useful at the end of input for an empty stream.
       */
      streamInfo() {
        return {
          comment: parsePrelude(this.prelude).comment,
          directives: this.directives,
          errors: this.errors,
          warnings: this.warnings
        };
      }
      /**
       * Compose tokens into documents.
       *
       * @param forceDoc - If the stream contains no document, still emit a final document including any comments and directives that would be applied to a subsequent document.
       * @param endOffset - Should be set if `forceDoc` is also set, to set the document range end and to indicate errors correctly.
       */
      *compose(tokens, forceDoc = false, endOffset = -1) {
        for (const token of tokens)
          yield* this.next(token);
        yield* this.end(forceDoc, endOffset);
      }
      /** Advance the composer by one CST token. */
      *next(token) {
        if (node_process.env.LOG_STREAM)
          console.dir(token, { depth: null });
        switch (token.type) {
          case "directive":
            this.directives.add(token.source, (offset, message, warning) => {
              const pos = getErrorPos(token);
              pos[0] += offset;
              this.onError(pos, "BAD_DIRECTIVE", message, warning);
            });
            this.prelude.push(token.source);
            this.atDirectives = true;
            break;
          case "document": {
            const doc = composeDoc.composeDoc(this.options, this.directives, token, this.onError);
            if (this.atDirectives && !doc.directives.docStart)
              this.onError(token, "MISSING_CHAR", "Missing directives-end/doc-start indicator line");
            this.decorate(doc, false);
            if (this.doc)
              yield this.doc;
            this.doc = doc;
            this.atDirectives = false;
            break;
          }
          case "byte-order-mark":
          case "space":
            break;
          case "comment":
          case "newline":
            this.prelude.push(token.source);
            break;
          case "error": {
            const msg = token.source ? `${token.message}: ${JSON.stringify(token.source)}` : token.message;
            const error = new errors.YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", msg);
            if (this.atDirectives || !this.doc)
              this.errors.push(error);
            else
              this.doc.errors.push(error);
            break;
          }
          case "doc-end": {
            if (!this.doc) {
              const msg = "Unexpected doc-end without preceding document";
              this.errors.push(new errors.YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", msg));
              break;
            }
            this.doc.directives.docEnd = true;
            const end = resolveEnd.resolveEnd(token.end, token.offset + token.source.length, this.doc.options.strict, this.onError);
            this.decorate(this.doc, true);
            if (end.comment) {
              const dc = this.doc.comment;
              this.doc.comment = dc ? `${dc}
${end.comment}` : end.comment;
            }
            this.doc.range[2] = end.offset;
            break;
          }
          default:
            this.errors.push(new errors.YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", `Unsupported token ${token.type}`));
        }
      }
      /**
       * Call at end of input to yield any remaining document.
       *
       * @param forceDoc - If the stream contains no document, still emit a final document including any comments and directives that would be applied to a subsequent document.
       * @param endOffset - Should be set if `forceDoc` is also set, to set the document range end and to indicate errors correctly.
       */
      *end(forceDoc = false, endOffset = -1) {
        if (this.doc) {
          this.decorate(this.doc, true);
          yield this.doc;
          this.doc = null;
        } else if (forceDoc) {
          const opts = Object.assign({ _directives: this.directives }, this.options);
          const doc = new Document.Document(void 0, opts);
          if (this.atDirectives)
            this.onError(endOffset, "MISSING_CHAR", "Missing directives-end indicator line");
          doc.range = [0, endOffset, endOffset];
          this.decorate(doc, false);
          yield doc;
        }
      }
    };
    exports.Composer = Composer;
  }
});

// node_modules/yaml/dist/parse/cst-scalar.js
var require_cst_scalar = __commonJS({
  "node_modules/yaml/dist/parse/cst-scalar.js"(exports) {
    "use strict";
    var resolveBlockScalar = require_resolve_block_scalar();
    var resolveFlowScalar = require_resolve_flow_scalar();
    var errors = require_errors();
    var stringifyString = require_stringifyString();
    function resolveAsScalar(token, strict = true, onError) {
      if (token) {
        const _onError = (pos, code, message) => {
          const offset = typeof pos === "number" ? pos : Array.isArray(pos) ? pos[0] : pos.offset;
          if (onError)
            onError(offset, code, message);
          else
            throw new errors.YAMLParseError([offset, offset + 1], code, message);
        };
        switch (token.type) {
          case "scalar":
          case "single-quoted-scalar":
          case "double-quoted-scalar":
            return resolveFlowScalar.resolveFlowScalar(token, strict, _onError);
          case "block-scalar":
            return resolveBlockScalar.resolveBlockScalar({ options: { strict } }, token, _onError);
        }
      }
      return null;
    }
    function createScalarToken(value, context2) {
      const { implicitKey = false, indent, inFlow = false, offset = -1, type = "PLAIN" } = context2;
      const source2 = stringifyString.stringifyString({ type, value }, {
        implicitKey,
        indent: indent > 0 ? " ".repeat(indent) : "",
        inFlow,
        options: { blockQuote: true, lineWidth: -1 }
      });
      const end = context2.end ?? [
        { type: "newline", offset: -1, indent, source: "\n" }
      ];
      switch (source2[0]) {
        case "|":
        case ">": {
          const he = source2.indexOf("\n");
          const head = source2.substring(0, he);
          const body = source2.substring(he + 1) + "\n";
          const props = [
            { type: "block-scalar-header", offset, indent, source: head }
          ];
          if (!addEndtoBlockProps(props, end))
            props.push({ type: "newline", offset: -1, indent, source: "\n" });
          return { type: "block-scalar", offset, indent, props, source: body };
        }
        case '"':
          return { type: "double-quoted-scalar", offset, indent, source: source2, end };
        case "'":
          return { type: "single-quoted-scalar", offset, indent, source: source2, end };
        default:
          return { type: "scalar", offset, indent, source: source2, end };
      }
    }
    function setScalarValue(token, value, context2 = {}) {
      let { afterKey = false, implicitKey = false, inFlow = false, type } = context2;
      let indent = "indent" in token ? token.indent : null;
      if (afterKey && typeof indent === "number")
        indent += 2;
      if (!type)
        switch (token.type) {
          case "single-quoted-scalar":
            type = "QUOTE_SINGLE";
            break;
          case "double-quoted-scalar":
            type = "QUOTE_DOUBLE";
            break;
          case "block-scalar": {
            const header = token.props[0];
            if (header.type !== "block-scalar-header")
              throw new Error("Invalid block scalar header");
            type = header.source[0] === ">" ? "BLOCK_FOLDED" : "BLOCK_LITERAL";
            break;
          }
          default:
            type = "PLAIN";
        }
      const source2 = stringifyString.stringifyString({ type, value }, {
        implicitKey: implicitKey || indent === null,
        indent: indent !== null && indent > 0 ? " ".repeat(indent) : "",
        inFlow,
        options: { blockQuote: true, lineWidth: -1 }
      });
      switch (source2[0]) {
        case "|":
        case ">":
          setBlockScalarValue(token, source2);
          break;
        case '"':
          setFlowScalarValue(token, source2, "double-quoted-scalar");
          break;
        case "'":
          setFlowScalarValue(token, source2, "single-quoted-scalar");
          break;
        default:
          setFlowScalarValue(token, source2, "scalar");
      }
    }
    function setBlockScalarValue(token, source2) {
      const he = source2.indexOf("\n");
      const head = source2.substring(0, he);
      const body = source2.substring(he + 1) + "\n";
      if (token.type === "block-scalar") {
        const header = token.props[0];
        if (header.type !== "block-scalar-header")
          throw new Error("Invalid block scalar header");
        header.source = head;
        token.source = body;
      } else {
        const { offset } = token;
        const indent = "indent" in token ? token.indent : -1;
        const props = [
          { type: "block-scalar-header", offset, indent, source: head }
        ];
        if (!addEndtoBlockProps(props, "end" in token ? token.end : void 0))
          props.push({ type: "newline", offset: -1, indent, source: "\n" });
        for (const key of Object.keys(token))
          if (key !== "type" && key !== "offset")
            delete token[key];
        Object.assign(token, { type: "block-scalar", indent, props, source: body });
      }
    }
    function addEndtoBlockProps(props, end) {
      if (end)
        for (const st of end)
          switch (st.type) {
            case "space":
            case "comment":
              props.push(st);
              break;
            case "newline":
              props.push(st);
              return true;
          }
      return false;
    }
    function setFlowScalarValue(token, source2, type) {
      switch (token.type) {
        case "scalar":
        case "double-quoted-scalar":
        case "single-quoted-scalar":
          token.type = type;
          token.source = source2;
          break;
        case "block-scalar": {
          const end = token.props.slice(1);
          let oa = source2.length;
          if (token.props[0].type === "block-scalar-header")
            oa -= token.props[0].source.length;
          for (const tok of end)
            tok.offset += oa;
          delete token.props;
          Object.assign(token, { type, source: source2, end });
          break;
        }
        case "block-map":
        case "block-seq": {
          const offset = token.offset + source2.length;
          const nl = { type: "newline", offset, indent: token.indent, source: "\n" };
          delete token.items;
          Object.assign(token, { type, source: source2, end: [nl] });
          break;
        }
        default: {
          const indent = "indent" in token ? token.indent : -1;
          const end = "end" in token && Array.isArray(token.end) ? token.end.filter((st) => st.type === "space" || st.type === "comment" || st.type === "newline") : [];
          for (const key of Object.keys(token))
            if (key !== "type" && key !== "offset")
              delete token[key];
          Object.assign(token, { type, indent, source: source2, end });
        }
      }
    }
    exports.createScalarToken = createScalarToken;
    exports.resolveAsScalar = resolveAsScalar;
    exports.setScalarValue = setScalarValue;
  }
});

// node_modules/yaml/dist/parse/cst-stringify.js
var require_cst_stringify = __commonJS({
  "node_modules/yaml/dist/parse/cst-stringify.js"(exports) {
    "use strict";
    var stringify2 = (cst) => "type" in cst ? stringifyToken(cst) : stringifyItem(cst);
    function stringifyToken(token) {
      switch (token.type) {
        case "block-scalar": {
          let res = "";
          for (const tok of token.props)
            res += stringifyToken(tok);
          return res + token.source;
        }
        case "block-map":
        case "block-seq": {
          let res = "";
          for (const item of token.items)
            res += stringifyItem(item);
          return res;
        }
        case "flow-collection": {
          let res = token.start.source;
          for (const item of token.items)
            res += stringifyItem(item);
          for (const st of token.end)
            res += st.source;
          return res;
        }
        case "document": {
          let res = stringifyItem(token);
          if (token.end)
            for (const st of token.end)
              res += st.source;
          return res;
        }
        default: {
          let res = token.source;
          if ("end" in token && token.end)
            for (const st of token.end)
              res += st.source;
          return res;
        }
      }
    }
    function stringifyItem({ start, key, sep, value }) {
      let res = "";
      for (const st of start)
        res += st.source;
      if (key)
        res += stringifyToken(key);
      if (sep)
        for (const st of sep)
          res += st.source;
      if (value)
        res += stringifyToken(value);
      return res;
    }
    exports.stringify = stringify2;
  }
});

// node_modules/yaml/dist/parse/cst-visit.js
var require_cst_visit = __commonJS({
  "node_modules/yaml/dist/parse/cst-visit.js"(exports) {
    "use strict";
    var BREAK = /* @__PURE__ */ Symbol("break visit");
    var SKIP = /* @__PURE__ */ Symbol("skip children");
    var REMOVE = /* @__PURE__ */ Symbol("remove item");
    function visit(cst, visitor) {
      if ("type" in cst && cst.type === "document")
        cst = { start: cst.start, value: cst.value };
      _visit(Object.freeze([]), cst, visitor);
    }
    visit.BREAK = BREAK;
    visit.SKIP = SKIP;
    visit.REMOVE = REMOVE;
    visit.itemAtPath = (cst, path5) => {
      let item = cst;
      for (const [field, index] of path5) {
        const tok = item?.[field];
        if (tok && "items" in tok) {
          item = tok.items[index];
        } else
          return void 0;
      }
      return item;
    };
    visit.parentCollection = (cst, path5) => {
      const parent = visit.itemAtPath(cst, path5.slice(0, -1));
      const field = path5[path5.length - 1][0];
      const coll = parent?.[field];
      if (coll && "items" in coll)
        return coll;
      throw new Error("Parent collection not found");
    };
    function _visit(path5, item, visitor) {
      let ctrl = visitor(item, path5);
      if (typeof ctrl === "symbol")
        return ctrl;
      for (const field of ["key", "value"]) {
        const token = item[field];
        if (token && "items" in token) {
          for (let i = 0; i < token.items.length; ++i) {
            const ci = _visit(Object.freeze(path5.concat([[field, i]])), token.items[i], visitor);
            if (typeof ci === "number")
              i = ci - 1;
            else if (ci === BREAK)
              return BREAK;
            else if (ci === REMOVE) {
              token.items.splice(i, 1);
              i -= 1;
            }
          }
          if (typeof ctrl === "function" && field === "key")
            ctrl = ctrl(item, path5);
        }
      }
      return typeof ctrl === "function" ? ctrl(item, path5) : ctrl;
    }
    exports.visit = visit;
  }
});

// node_modules/yaml/dist/parse/cst.js
var require_cst = __commonJS({
  "node_modules/yaml/dist/parse/cst.js"(exports) {
    "use strict";
    var cstScalar = require_cst_scalar();
    var cstStringify = require_cst_stringify();
    var cstVisit = require_cst_visit();
    var BOM = "\uFEFF";
    var DOCUMENT = "";
    var FLOW_END = "";
    var SCALAR = "";
    var isCollection = (token) => !!token && "items" in token;
    var isScalar = (token) => !!token && (token.type === "scalar" || token.type === "single-quoted-scalar" || token.type === "double-quoted-scalar" || token.type === "block-scalar");
    function prettyToken(token) {
      switch (token) {
        case BOM:
          return "<BOM>";
        case DOCUMENT:
          return "<DOC>";
        case FLOW_END:
          return "<FLOW_END>";
        case SCALAR:
          return "<SCALAR>";
        default:
          return JSON.stringify(token);
      }
    }
    function tokenType(source2) {
      switch (source2) {
        case BOM:
          return "byte-order-mark";
        case DOCUMENT:
          return "doc-mode";
        case FLOW_END:
          return "flow-error-end";
        case SCALAR:
          return "scalar";
        case "---":
          return "doc-start";
        case "...":
          return "doc-end";
        case "":
        case "\n":
        case "\r\n":
          return "newline";
        case "-":
          return "seq-item-ind";
        case "?":
          return "explicit-key-ind";
        case ":":
          return "map-value-ind";
        case "{":
          return "flow-map-start";
        case "}":
          return "flow-map-end";
        case "[":
          return "flow-seq-start";
        case "]":
          return "flow-seq-end";
        case ",":
          return "comma";
      }
      switch (source2[0]) {
        case " ":
        case "	":
          return "space";
        case "#":
          return "comment";
        case "%":
          return "directive-line";
        case "*":
          return "alias";
        case "&":
          return "anchor";
        case "!":
          return "tag";
        case "'":
          return "single-quoted-scalar";
        case '"':
          return "double-quoted-scalar";
        case "|":
        case ">":
          return "block-scalar-header";
      }
      return null;
    }
    exports.createScalarToken = cstScalar.createScalarToken;
    exports.resolveAsScalar = cstScalar.resolveAsScalar;
    exports.setScalarValue = cstScalar.setScalarValue;
    exports.stringify = cstStringify.stringify;
    exports.visit = cstVisit.visit;
    exports.BOM = BOM;
    exports.DOCUMENT = DOCUMENT;
    exports.FLOW_END = FLOW_END;
    exports.SCALAR = SCALAR;
    exports.isCollection = isCollection;
    exports.isScalar = isScalar;
    exports.prettyToken = prettyToken;
    exports.tokenType = tokenType;
  }
});

// node_modules/yaml/dist/parse/lexer.js
var require_lexer = __commonJS({
  "node_modules/yaml/dist/parse/lexer.js"(exports) {
    "use strict";
    var cst = require_cst();
    function isEmpty(ch) {
      switch (ch) {
        case void 0:
        case " ":
        case "\n":
        case "\r":
        case "	":
          return true;
        default:
          return false;
      }
    }
    var hexDigits = new Set("0123456789ABCDEFabcdef");
    var tagChars = new Set("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-#;/?:@&=+$_.!~*'()");
    var flowIndicatorChars = new Set(",[]{}");
    var invalidAnchorChars = new Set(" ,[]{}\n\r	");
    var isNotAnchorChar = (ch) => !ch || invalidAnchorChars.has(ch);
    var Lexer = class {
      constructor() {
        this.atEnd = false;
        this.blockScalarIndent = -1;
        this.blockScalarKeep = false;
        this.buffer = "";
        this.flowKey = false;
        this.flowLevel = 0;
        this.indentNext = 0;
        this.indentValue = 0;
        this.lineEndPos = null;
        this.next = null;
        this.pos = 0;
      }
      /**
       * Generate YAML tokens from the `source` string. If `incomplete`,
       * a part of the last line may be left as a buffer for the next call.
       *
       * @returns A generator of lexical tokens
       */
      *lex(source2, incomplete = false) {
        if (source2) {
          if (typeof source2 !== "string")
            throw TypeError("source is not a string");
          this.buffer = this.buffer ? this.buffer + source2 : source2;
          this.lineEndPos = null;
        }
        this.atEnd = !incomplete;
        let next = this.next ?? "stream";
        while (next && (incomplete || this.hasChars(1)))
          next = yield* this.parseNext(next);
      }
      atLineEnd() {
        let i = this.pos;
        let ch = this.buffer[i];
        while (ch === " " || ch === "	")
          ch = this.buffer[++i];
        if (!ch || ch === "#" || ch === "\n")
          return true;
        if (ch === "\r")
          return this.buffer[i + 1] === "\n";
        return false;
      }
      charAt(n) {
        return this.buffer[this.pos + n];
      }
      continueScalar(offset) {
        let ch = this.buffer[offset];
        if (this.indentNext > 0) {
          let indent = 0;
          while (ch === " ")
            ch = this.buffer[++indent + offset];
          if (ch === "\r") {
            const next = this.buffer[indent + offset + 1];
            if (next === "\n" || !next && !this.atEnd)
              return offset + indent + 1;
          }
          return ch === "\n" || indent >= this.indentNext || !ch && !this.atEnd ? offset + indent : -1;
        }
        if (ch === "-" || ch === ".") {
          const dt = this.buffer.substr(offset, 3);
          if ((dt === "---" || dt === "...") && isEmpty(this.buffer[offset + 3]))
            return -1;
        }
        return offset;
      }
      getLine() {
        let end = this.lineEndPos;
        if (typeof end !== "number" || end !== -1 && end < this.pos) {
          end = this.buffer.indexOf("\n", this.pos);
          this.lineEndPos = end;
        }
        if (end === -1)
          return this.atEnd ? this.buffer.substring(this.pos) : null;
        if (this.buffer[end - 1] === "\r")
          end -= 1;
        return this.buffer.substring(this.pos, end);
      }
      hasChars(n) {
        return this.pos + n <= this.buffer.length;
      }
      setNext(state) {
        this.buffer = this.buffer.substring(this.pos);
        this.pos = 0;
        this.lineEndPos = null;
        this.next = state;
        return null;
      }
      peek(n) {
        return this.buffer.substr(this.pos, n);
      }
      *parseNext(next) {
        switch (next) {
          case "stream":
            return yield* this.parseStream();
          case "line-start":
            return yield* this.parseLineStart();
          case "block-start":
            return yield* this.parseBlockStart();
          case "doc":
            return yield* this.parseDocument();
          case "flow":
            return yield* this.parseFlowCollection();
          case "quoted-scalar":
            return yield* this.parseQuotedScalar();
          case "block-scalar":
            return yield* this.parseBlockScalar();
          case "plain-scalar":
            return yield* this.parsePlainScalar();
        }
      }
      *parseStream() {
        let line = this.getLine();
        if (line === null)
          return this.setNext("stream");
        if (line[0] === cst.BOM) {
          yield* this.pushCount(1);
          line = line.substring(1);
        }
        if (line[0] === "%") {
          let dirEnd = line.length;
          let cs = line.indexOf("#");
          while (cs !== -1) {
            const ch = line[cs - 1];
            if (ch === " " || ch === "	") {
              dirEnd = cs - 1;
              break;
            } else {
              cs = line.indexOf("#", cs + 1);
            }
          }
          while (true) {
            const ch = line[dirEnd - 1];
            if (ch === " " || ch === "	")
              dirEnd -= 1;
            else
              break;
          }
          const n = (yield* this.pushCount(dirEnd)) + (yield* this.pushSpaces(true));
          yield* this.pushCount(line.length - n);
          this.pushNewline();
          return "stream";
        }
        if (this.atLineEnd()) {
          const sp = yield* this.pushSpaces(true);
          yield* this.pushCount(line.length - sp);
          yield* this.pushNewline();
          return "stream";
        }
        yield cst.DOCUMENT;
        return yield* this.parseLineStart();
      }
      *parseLineStart() {
        const ch = this.charAt(0);
        if (!ch && !this.atEnd)
          return this.setNext("line-start");
        if (ch === "-" || ch === ".") {
          if (!this.atEnd && !this.hasChars(4))
            return this.setNext("line-start");
          const s = this.peek(3);
          if ((s === "---" || s === "...") && isEmpty(this.charAt(3))) {
            yield* this.pushCount(3);
            this.indentValue = 0;
            this.indentNext = 0;
            return s === "---" ? "doc" : "stream";
          }
        }
        this.indentValue = yield* this.pushSpaces(false);
        if (this.indentNext > this.indentValue && !isEmpty(this.charAt(1)))
          this.indentNext = this.indentValue;
        return yield* this.parseBlockStart();
      }
      *parseBlockStart() {
        const [ch0, ch1] = this.peek(2);
        if (!ch1 && !this.atEnd)
          return this.setNext("block-start");
        if ((ch0 === "-" || ch0 === "?" || ch0 === ":") && isEmpty(ch1)) {
          const n = (yield* this.pushCount(1)) + (yield* this.pushSpaces(true));
          this.indentNext = this.indentValue + 1;
          this.indentValue += n;
          return "block-start";
        }
        return "doc";
      }
      *parseDocument() {
        yield* this.pushSpaces(true);
        const line = this.getLine();
        if (line === null)
          return this.setNext("doc");
        let n = yield* this.pushIndicators();
        switch (line[n]) {
          case "#":
            yield* this.pushCount(line.length - n);
          // fallthrough
          case void 0:
            yield* this.pushNewline();
            return yield* this.parseLineStart();
          case "{":
          case "[":
            yield* this.pushCount(1);
            this.flowKey = false;
            this.flowLevel = 1;
            return "flow";
          case "}":
          case "]":
            yield* this.pushCount(1);
            return "doc";
          case "*":
            yield* this.pushUntil(isNotAnchorChar);
            return "doc";
          case '"':
          case "'":
            return yield* this.parseQuotedScalar();
          case "|":
          case ">":
            n += yield* this.parseBlockScalarHeader();
            n += yield* this.pushSpaces(true);
            yield* this.pushCount(line.length - n);
            yield* this.pushNewline();
            return yield* this.parseBlockScalar();
          default:
            return yield* this.parsePlainScalar();
        }
      }
      *parseFlowCollection() {
        let nl, sp;
        let indent = -1;
        do {
          nl = yield* this.pushNewline();
          if (nl > 0) {
            sp = yield* this.pushSpaces(false);
            this.indentValue = indent = sp;
          } else {
            sp = 0;
          }
          sp += yield* this.pushSpaces(true);
        } while (nl + sp > 0);
        const line = this.getLine();
        if (line === null)
          return this.setNext("flow");
        if (indent !== -1 && indent < this.indentNext && line[0] !== "#" || indent === 0 && (line.startsWith("---") || line.startsWith("...")) && isEmpty(line[3])) {
          const atFlowEndMarker = indent === this.indentNext - 1 && this.flowLevel === 1 && (line[0] === "]" || line[0] === "}");
          if (!atFlowEndMarker) {
            this.flowLevel = 0;
            yield cst.FLOW_END;
            return yield* this.parseLineStart();
          }
        }
        let n = 0;
        while (line[n] === ",") {
          n += yield* this.pushCount(1);
          n += yield* this.pushSpaces(true);
          this.flowKey = false;
        }
        n += yield* this.pushIndicators();
        switch (line[n]) {
          case void 0:
            return "flow";
          case "#":
            yield* this.pushCount(line.length - n);
            return "flow";
          case "{":
          case "[":
            yield* this.pushCount(1);
            this.flowKey = false;
            this.flowLevel += 1;
            return "flow";
          case "}":
          case "]":
            yield* this.pushCount(1);
            this.flowKey = true;
            this.flowLevel -= 1;
            return this.flowLevel ? "flow" : "doc";
          case "*":
            yield* this.pushUntil(isNotAnchorChar);
            return "flow";
          case '"':
          case "'":
            this.flowKey = true;
            return yield* this.parseQuotedScalar();
          case ":": {
            const next = this.charAt(1);
            if (this.flowKey || isEmpty(next) || next === ",") {
              this.flowKey = false;
              yield* this.pushCount(1);
              yield* this.pushSpaces(true);
              return "flow";
            }
          }
          // fallthrough
          default:
            this.flowKey = false;
            return yield* this.parsePlainScalar();
        }
      }
      *parseQuotedScalar() {
        const quote = this.charAt(0);
        let end = this.buffer.indexOf(quote, this.pos + 1);
        if (quote === "'") {
          while (end !== -1 && this.buffer[end + 1] === "'")
            end = this.buffer.indexOf("'", end + 2);
        } else {
          while (end !== -1) {
            let n = 0;
            while (this.buffer[end - 1 - n] === "\\")
              n += 1;
            if (n % 2 === 0)
              break;
            end = this.buffer.indexOf('"', end + 1);
          }
        }
        const qb = this.buffer.substring(0, end);
        let nl = qb.indexOf("\n", this.pos);
        if (nl !== -1) {
          while (nl !== -1) {
            const cs = this.continueScalar(nl + 1);
            if (cs === -1)
              break;
            nl = qb.indexOf("\n", cs);
          }
          if (nl !== -1) {
            end = nl - (qb[nl - 1] === "\r" ? 2 : 1);
          }
        }
        if (end === -1) {
          if (!this.atEnd)
            return this.setNext("quoted-scalar");
          end = this.buffer.length;
        }
        yield* this.pushToIndex(end + 1, false);
        return this.flowLevel ? "flow" : "doc";
      }
      *parseBlockScalarHeader() {
        this.blockScalarIndent = -1;
        this.blockScalarKeep = false;
        let i = this.pos;
        while (true) {
          const ch = this.buffer[++i];
          if (ch === "+")
            this.blockScalarKeep = true;
          else if (ch > "0" && ch <= "9")
            this.blockScalarIndent = Number(ch) - 1;
          else if (ch !== "-")
            break;
        }
        return yield* this.pushUntil((ch) => isEmpty(ch) || ch === "#");
      }
      *parseBlockScalar() {
        let nl = this.pos - 1;
        let indent = 0;
        let ch;
        loop: for (let i2 = this.pos; ch = this.buffer[i2]; ++i2) {
          switch (ch) {
            case " ":
              indent += 1;
              break;
            case "\n":
              nl = i2;
              indent = 0;
              break;
            case "\r": {
              const next = this.buffer[i2 + 1];
              if (!next && !this.atEnd)
                return this.setNext("block-scalar");
              if (next === "\n")
                break;
            }
            // fallthrough
            default:
              break loop;
          }
        }
        if (!ch && !this.atEnd)
          return this.setNext("block-scalar");
        if (indent >= this.indentNext) {
          if (this.blockScalarIndent === -1)
            this.indentNext = indent;
          else {
            this.indentNext = this.blockScalarIndent + (this.indentNext === 0 ? 1 : this.indentNext);
          }
          do {
            const cs = this.continueScalar(nl + 1);
            if (cs === -1)
              break;
            nl = this.buffer.indexOf("\n", cs);
          } while (nl !== -1);
          if (nl === -1) {
            if (!this.atEnd)
              return this.setNext("block-scalar");
            nl = this.buffer.length;
          }
        }
        let i = nl + 1;
        ch = this.buffer[i];
        while (ch === " ")
          ch = this.buffer[++i];
        if (ch === "	") {
          while (ch === "	" || ch === " " || ch === "\r" || ch === "\n")
            ch = this.buffer[++i];
          nl = i - 1;
        } else if (!this.blockScalarKeep) {
          do {
            let i2 = nl - 1;
            let ch2 = this.buffer[i2];
            if (ch2 === "\r")
              ch2 = this.buffer[--i2];
            const lastChar = i2;
            while (ch2 === " ")
              ch2 = this.buffer[--i2];
            if (ch2 === "\n" && i2 >= this.pos && i2 + 1 + indent > lastChar)
              nl = i2;
            else
              break;
          } while (true);
        }
        yield cst.SCALAR;
        yield* this.pushToIndex(nl + 1, true);
        return yield* this.parseLineStart();
      }
      *parsePlainScalar() {
        const inFlow = this.flowLevel > 0;
        let end = this.pos - 1;
        let i = this.pos - 1;
        let ch;
        while (ch = this.buffer[++i]) {
          if (ch === ":") {
            const next = this.buffer[i + 1];
            if (isEmpty(next) || inFlow && flowIndicatorChars.has(next))
              break;
            end = i;
          } else if (isEmpty(ch)) {
            let next = this.buffer[i + 1];
            if (ch === "\r") {
              if (next === "\n") {
                i += 1;
                ch = "\n";
                next = this.buffer[i + 1];
              } else
                end = i;
            }
            if (next === "#" || inFlow && flowIndicatorChars.has(next))
              break;
            if (ch === "\n") {
              const cs = this.continueScalar(i + 1);
              if (cs === -1)
                break;
              i = Math.max(i, cs - 2);
            }
          } else {
            if (inFlow && flowIndicatorChars.has(ch))
              break;
            end = i;
          }
        }
        if (!ch && !this.atEnd)
          return this.setNext("plain-scalar");
        yield cst.SCALAR;
        yield* this.pushToIndex(end + 1, true);
        return inFlow ? "flow" : "doc";
      }
      *pushCount(n) {
        if (n > 0) {
          yield this.buffer.substr(this.pos, n);
          this.pos += n;
          return n;
        }
        return 0;
      }
      *pushToIndex(i, allowEmpty) {
        const s = this.buffer.slice(this.pos, i);
        if (s) {
          yield s;
          this.pos += s.length;
          return s.length;
        } else if (allowEmpty)
          yield "";
        return 0;
      }
      *pushIndicators() {
        let n = 0;
        loop: while (true) {
          switch (this.charAt(0)) {
            case "!":
              n += yield* this.pushTag();
              n += yield* this.pushSpaces(true);
              continue loop;
            case "&":
              n += yield* this.pushUntil(isNotAnchorChar);
              n += yield* this.pushSpaces(true);
              continue loop;
            case "-":
            // this is an error
            case "?":
            // this is an error outside flow collections
            case ":": {
              const inFlow = this.flowLevel > 0;
              const ch1 = this.charAt(1);
              if (isEmpty(ch1) || inFlow && flowIndicatorChars.has(ch1)) {
                if (!inFlow)
                  this.indentNext = this.indentValue + 1;
                else if (this.flowKey)
                  this.flowKey = false;
                n += yield* this.pushCount(1);
                n += yield* this.pushSpaces(true);
                continue loop;
              }
            }
          }
          break loop;
        }
        return n;
      }
      *pushTag() {
        if (this.charAt(1) === "<") {
          let i = this.pos + 2;
          let ch = this.buffer[i];
          while (!isEmpty(ch) && ch !== ">")
            ch = this.buffer[++i];
          return yield* this.pushToIndex(ch === ">" ? i + 1 : i, false);
        } else {
          let i = this.pos + 1;
          let ch = this.buffer[i];
          while (ch) {
            if (tagChars.has(ch))
              ch = this.buffer[++i];
            else if (ch === "%" && hexDigits.has(this.buffer[i + 1]) && hexDigits.has(this.buffer[i + 2])) {
              ch = this.buffer[i += 3];
            } else
              break;
          }
          return yield* this.pushToIndex(i, false);
        }
      }
      *pushNewline() {
        const ch = this.buffer[this.pos];
        if (ch === "\n")
          return yield* this.pushCount(1);
        else if (ch === "\r" && this.charAt(1) === "\n")
          return yield* this.pushCount(2);
        else
          return 0;
      }
      *pushSpaces(allowTabs) {
        let i = this.pos - 1;
        let ch;
        do {
          ch = this.buffer[++i];
        } while (ch === " " || allowTabs && ch === "	");
        const n = i - this.pos;
        if (n > 0) {
          yield this.buffer.substr(this.pos, n);
          this.pos = i;
        }
        return n;
      }
      *pushUntil(test) {
        let i = this.pos;
        let ch = this.buffer[i];
        while (!test(ch))
          ch = this.buffer[++i];
        return yield* this.pushToIndex(i, false);
      }
    };
    exports.Lexer = Lexer;
  }
});

// node_modules/yaml/dist/parse/line-counter.js
var require_line_counter = __commonJS({
  "node_modules/yaml/dist/parse/line-counter.js"(exports) {
    "use strict";
    var LineCounter = class {
      constructor() {
        this.lineStarts = [];
        this.addNewLine = (offset) => this.lineStarts.push(offset);
        this.linePos = (offset) => {
          let low = 0;
          let high = this.lineStarts.length;
          while (low < high) {
            const mid = low + high >> 1;
            if (this.lineStarts[mid] < offset)
              low = mid + 1;
            else
              high = mid;
          }
          if (this.lineStarts[low] === offset)
            return { line: low + 1, col: 1 };
          if (low === 0)
            return { line: 0, col: offset };
          const start = this.lineStarts[low - 1];
          return { line: low, col: offset - start + 1 };
        };
      }
    };
    exports.LineCounter = LineCounter;
  }
});

// node_modules/yaml/dist/parse/parser.js
var require_parser = __commonJS({
  "node_modules/yaml/dist/parse/parser.js"(exports) {
    "use strict";
    var node_process = __require("process");
    var cst = require_cst();
    var lexer = require_lexer();
    function includesToken(list, type) {
      for (let i = 0; i < list.length; ++i)
        if (list[i].type === type)
          return true;
      return false;
    }
    function findNonEmptyIndex(list) {
      for (let i = 0; i < list.length; ++i) {
        switch (list[i].type) {
          case "space":
          case "comment":
          case "newline":
            break;
          default:
            return i;
        }
      }
      return -1;
    }
    function isFlowToken(token) {
      switch (token?.type) {
        case "alias":
        case "scalar":
        case "single-quoted-scalar":
        case "double-quoted-scalar":
        case "flow-collection":
          return true;
        default:
          return false;
      }
    }
    function getPrevProps(parent) {
      switch (parent.type) {
        case "document":
          return parent.start;
        case "block-map": {
          const it = parent.items[parent.items.length - 1];
          return it.sep ?? it.start;
        }
        case "block-seq":
          return parent.items[parent.items.length - 1].start;
        /* istanbul ignore next should not happen */
        default:
          return [];
      }
    }
    function getFirstKeyStartProps(prev) {
      if (prev.length === 0)
        return [];
      let i = prev.length;
      loop: while (--i >= 0) {
        switch (prev[i].type) {
          case "doc-start":
          case "explicit-key-ind":
          case "map-value-ind":
          case "seq-item-ind":
          case "newline":
            break loop;
        }
      }
      while (prev[++i]?.type === "space") {
      }
      return prev.splice(i, prev.length);
    }
    function arrayPushArray(target, source2) {
      if (source2.length < 1e5)
        Array.prototype.push.apply(target, source2);
      else
        for (let i = 0; i < source2.length; ++i)
          target.push(source2[i]);
    }
    function fixFlowSeqItems(fc) {
      if (fc.start.type === "flow-seq-start") {
        for (const it of fc.items) {
          if (it.sep && !it.value && !includesToken(it.start, "explicit-key-ind") && !includesToken(it.sep, "map-value-ind")) {
            if (it.key)
              it.value = it.key;
            delete it.key;
            if (isFlowToken(it.value)) {
              if (it.value.end)
                arrayPushArray(it.value.end, it.sep);
              else
                it.value.end = it.sep;
            } else
              arrayPushArray(it.start, it.sep);
            delete it.sep;
          }
        }
      }
    }
    var Parser = class {
      /**
       * @param onNewLine - If defined, called separately with the start position of
       *   each new line (in `parse()`, including the start of input).
       */
      constructor(onNewLine) {
        this.atNewLine = true;
        this.atScalar = false;
        this.indent = 0;
        this.offset = 0;
        this.onKeyLine = false;
        this.stack = [];
        this.source = "";
        this.type = "";
        this.lexer = new lexer.Lexer();
        this.onNewLine = onNewLine;
      }
      /**
       * Parse `source` as a YAML stream.
       * If `incomplete`, a part of the last line may be left as a buffer for the next call.
       *
       * Errors are not thrown, but yielded as `{ type: 'error', message }` tokens.
       *
       * @returns A generator of tokens representing each directive, document, and other structure.
       */
      *parse(source2, incomplete = false) {
        if (this.onNewLine && this.offset === 0)
          this.onNewLine(0);
        for (const lexeme of this.lexer.lex(source2, incomplete))
          yield* this.next(lexeme);
        if (!incomplete)
          yield* this.end();
      }
      /**
       * Advance the parser by the `source` of one lexical token.
       */
      *next(source2) {
        this.source = source2;
        if (node_process.env.LOG_TOKENS)
          console.log("|", cst.prettyToken(source2));
        if (this.atScalar) {
          this.atScalar = false;
          yield* this.step();
          this.offset += source2.length;
          return;
        }
        const type = cst.tokenType(source2);
        if (!type) {
          const message = `Not a YAML token: ${source2}`;
          yield* this.pop({ type: "error", offset: this.offset, message, source: source2 });
          this.offset += source2.length;
        } else if (type === "scalar") {
          this.atNewLine = false;
          this.atScalar = true;
          this.type = "scalar";
        } else {
          this.type = type;
          yield* this.step();
          switch (type) {
            case "newline":
              this.atNewLine = true;
              this.indent = 0;
              if (this.onNewLine)
                this.onNewLine(this.offset + source2.length);
              break;
            case "space":
              if (this.atNewLine && source2[0] === " ")
                this.indent += source2.length;
              break;
            case "explicit-key-ind":
            case "map-value-ind":
            case "seq-item-ind":
              if (this.atNewLine)
                this.indent += source2.length;
              break;
            case "doc-mode":
            case "flow-error-end":
              return;
            default:
              this.atNewLine = false;
          }
          this.offset += source2.length;
        }
      }
      /** Call at end of input to push out any remaining constructions */
      *end() {
        while (this.stack.length > 0)
          yield* this.pop();
      }
      get sourceToken() {
        const st = {
          type: this.type,
          offset: this.offset,
          indent: this.indent,
          source: this.source
        };
        return st;
      }
      *step() {
        const top = this.peek(1);
        if (this.type === "doc-end" && top?.type !== "doc-end") {
          while (this.stack.length > 0)
            yield* this.pop();
          this.stack.push({
            type: "doc-end",
            offset: this.offset,
            source: this.source
          });
          return;
        }
        if (!top)
          return yield* this.stream();
        switch (top.type) {
          case "document":
            return yield* this.document(top);
          case "alias":
          case "scalar":
          case "single-quoted-scalar":
          case "double-quoted-scalar":
            return yield* this.scalar(top);
          case "block-scalar":
            return yield* this.blockScalar(top);
          case "block-map":
            return yield* this.blockMap(top);
          case "block-seq":
            return yield* this.blockSequence(top);
          case "flow-collection":
            return yield* this.flowCollection(top);
          case "doc-end":
            return yield* this.documentEnd(top);
        }
        yield* this.pop();
      }
      peek(n) {
        return this.stack[this.stack.length - n];
      }
      *pop(error) {
        const token = error ?? this.stack.pop();
        if (!token) {
          const message = "Tried to pop an empty stack";
          yield { type: "error", offset: this.offset, source: "", message };
        } else if (this.stack.length === 0) {
          yield token;
        } else {
          const top = this.peek(1);
          if (token.type === "block-scalar") {
            token.indent = "indent" in top ? top.indent : 0;
          } else if (token.type === "flow-collection" && top.type === "document") {
            token.indent = 0;
          }
          if (token.type === "flow-collection")
            fixFlowSeqItems(token);
          switch (top.type) {
            case "document":
              top.value = token;
              break;
            case "block-scalar":
              top.props.push(token);
              break;
            case "block-map": {
              const it = top.items[top.items.length - 1];
              if (it.value) {
                top.items.push({ start: [], key: token, sep: [] });
                this.onKeyLine = true;
                return;
              } else if (it.sep) {
                it.value = token;
              } else {
                Object.assign(it, { key: token, sep: [] });
                this.onKeyLine = !it.explicitKey;
                return;
              }
              break;
            }
            case "block-seq": {
              const it = top.items[top.items.length - 1];
              if (it.value)
                top.items.push({ start: [], value: token });
              else
                it.value = token;
              break;
            }
            case "flow-collection": {
              const it = top.items[top.items.length - 1];
              if (!it || it.value)
                top.items.push({ start: [], key: token, sep: [] });
              else if (it.sep)
                it.value = token;
              else
                Object.assign(it, { key: token, sep: [] });
              return;
            }
            /* istanbul ignore next should not happen */
            default:
              yield* this.pop();
              yield* this.pop(token);
          }
          if ((top.type === "document" || top.type === "block-map" || top.type === "block-seq") && (token.type === "block-map" || token.type === "block-seq")) {
            const last = token.items[token.items.length - 1];
            if (last && !last.sep && !last.value && last.start.length > 0 && findNonEmptyIndex(last.start) === -1 && (token.indent === 0 || last.start.every((st) => st.type !== "comment" || st.indent < token.indent))) {
              if (top.type === "document")
                top.end = last.start;
              else
                top.items.push({ start: last.start });
              token.items.splice(-1, 1);
            }
          }
        }
      }
      *stream() {
        switch (this.type) {
          case "directive-line":
            yield { type: "directive", offset: this.offset, source: this.source };
            return;
          case "byte-order-mark":
          case "space":
          case "comment":
          case "newline":
            yield this.sourceToken;
            return;
          case "doc-mode":
          case "doc-start": {
            const doc = {
              type: "document",
              offset: this.offset,
              start: []
            };
            if (this.type === "doc-start")
              doc.start.push(this.sourceToken);
            this.stack.push(doc);
            return;
          }
        }
        yield {
          type: "error",
          offset: this.offset,
          message: `Unexpected ${this.type} token in YAML stream`,
          source: this.source
        };
      }
      *document(doc) {
        if (doc.value)
          return yield* this.lineEnd(doc);
        switch (this.type) {
          case "doc-start": {
            if (findNonEmptyIndex(doc.start) !== -1) {
              yield* this.pop();
              yield* this.step();
            } else
              doc.start.push(this.sourceToken);
            return;
          }
          case "anchor":
          case "tag":
          case "space":
          case "comment":
          case "newline":
            doc.start.push(this.sourceToken);
            return;
        }
        const bv = this.startBlockValue(doc);
        if (bv)
          this.stack.push(bv);
        else {
          yield {
            type: "error",
            offset: this.offset,
            message: `Unexpected ${this.type} token in YAML document`,
            source: this.source
          };
        }
      }
      *scalar(scalar) {
        if (this.type === "map-value-ind") {
          const prev = getPrevProps(this.peek(2));
          const start = getFirstKeyStartProps(prev);
          let sep;
          if (scalar.end) {
            sep = scalar.end;
            sep.push(this.sourceToken);
            delete scalar.end;
          } else
            sep = [this.sourceToken];
          const map = {
            type: "block-map",
            offset: scalar.offset,
            indent: scalar.indent,
            items: [{ start, key: scalar, sep }]
          };
          this.onKeyLine = true;
          this.stack[this.stack.length - 1] = map;
        } else
          yield* this.lineEnd(scalar);
      }
      *blockScalar(scalar) {
        switch (this.type) {
          case "space":
          case "comment":
          case "newline":
            scalar.props.push(this.sourceToken);
            return;
          case "scalar":
            scalar.source = this.source;
            this.atNewLine = true;
            this.indent = 0;
            if (this.onNewLine) {
              let nl = this.source.indexOf("\n") + 1;
              while (nl !== 0) {
                this.onNewLine(this.offset + nl);
                nl = this.source.indexOf("\n", nl) + 1;
              }
            }
            yield* this.pop();
            break;
          /* istanbul ignore next should not happen */
          default:
            yield* this.pop();
            yield* this.step();
        }
      }
      *blockMap(map) {
        const it = map.items[map.items.length - 1];
        switch (this.type) {
          case "newline":
            this.onKeyLine = false;
            if (it.value) {
              const end = "end" in it.value ? it.value.end : void 0;
              const last = Array.isArray(end) ? end[end.length - 1] : void 0;
              if (last?.type === "comment")
                end?.push(this.sourceToken);
              else
                map.items.push({ start: [this.sourceToken] });
            } else if (it.sep) {
              it.sep.push(this.sourceToken);
            } else {
              it.start.push(this.sourceToken);
            }
            return;
          case "space":
          case "comment":
            if (it.value) {
              map.items.push({ start: [this.sourceToken] });
            } else if (it.sep) {
              it.sep.push(this.sourceToken);
            } else {
              if (this.atIndentedComment(it.start, map.indent)) {
                const prev = map.items[map.items.length - 2];
                const end = prev?.value?.end;
                if (Array.isArray(end)) {
                  arrayPushArray(end, it.start);
                  end.push(this.sourceToken);
                  map.items.pop();
                  return;
                }
              }
              it.start.push(this.sourceToken);
            }
            return;
        }
        if (this.indent >= map.indent) {
          const atMapIndent = !this.onKeyLine && this.indent === map.indent;
          const atNextItem = atMapIndent && (it.sep || it.explicitKey) && this.type !== "seq-item-ind";
          let start = [];
          if (atNextItem && it.sep && !it.value) {
            const nl = [];
            for (let i = 0; i < it.sep.length; ++i) {
              const st = it.sep[i];
              switch (st.type) {
                case "newline":
                  nl.push(i);
                  break;
                case "space":
                  break;
                case "comment":
                  if (st.indent > map.indent)
                    nl.length = 0;
                  break;
                default:
                  nl.length = 0;
              }
            }
            if (nl.length >= 2)
              start = it.sep.splice(nl[1]);
          }
          switch (this.type) {
            case "anchor":
            case "tag":
              if (atNextItem || it.value) {
                start.push(this.sourceToken);
                map.items.push({ start });
                this.onKeyLine = true;
              } else if (it.sep) {
                it.sep.push(this.sourceToken);
              } else {
                it.start.push(this.sourceToken);
              }
              return;
            case "explicit-key-ind":
              if (!it.sep && !it.explicitKey) {
                it.start.push(this.sourceToken);
                it.explicitKey = true;
              } else if (atNextItem || it.value) {
                start.push(this.sourceToken);
                map.items.push({ start, explicitKey: true });
              } else {
                this.stack.push({
                  type: "block-map",
                  offset: this.offset,
                  indent: this.indent,
                  items: [{ start: [this.sourceToken], explicitKey: true }]
                });
              }
              this.onKeyLine = true;
              return;
            case "map-value-ind":
              if (it.explicitKey) {
                if (!it.sep) {
                  if (includesToken(it.start, "newline")) {
                    Object.assign(it, { key: null, sep: [this.sourceToken] });
                  } else {
                    const start2 = getFirstKeyStartProps(it.start);
                    this.stack.push({
                      type: "block-map",
                      offset: this.offset,
                      indent: this.indent,
                      items: [{ start: start2, key: null, sep: [this.sourceToken] }]
                    });
                  }
                } else if (it.value) {
                  map.items.push({ start: [], key: null, sep: [this.sourceToken] });
                } else if (includesToken(it.sep, "map-value-ind")) {
                  this.stack.push({
                    type: "block-map",
                    offset: this.offset,
                    indent: this.indent,
                    items: [{ start, key: null, sep: [this.sourceToken] }]
                  });
                } else if (isFlowToken(it.key) && !includesToken(it.sep, "newline")) {
                  const start2 = getFirstKeyStartProps(it.start);
                  const key = it.key;
                  const sep = it.sep;
                  sep.push(this.sourceToken);
                  delete it.key;
                  delete it.sep;
                  this.stack.push({
                    type: "block-map",
                    offset: this.offset,
                    indent: this.indent,
                    items: [{ start: start2, key, sep }]
                  });
                } else if (start.length > 0) {
                  it.sep = it.sep.concat(start, this.sourceToken);
                } else {
                  it.sep.push(this.sourceToken);
                }
              } else {
                if (!it.sep) {
                  Object.assign(it, { key: null, sep: [this.sourceToken] });
                } else if (it.value || atNextItem) {
                  map.items.push({ start, key: null, sep: [this.sourceToken] });
                } else if (includesToken(it.sep, "map-value-ind")) {
                  this.stack.push({
                    type: "block-map",
                    offset: this.offset,
                    indent: this.indent,
                    items: [{ start: [], key: null, sep: [this.sourceToken] }]
                  });
                } else {
                  it.sep.push(this.sourceToken);
                }
              }
              this.onKeyLine = true;
              return;
            case "alias":
            case "scalar":
            case "single-quoted-scalar":
            case "double-quoted-scalar": {
              const fs4 = this.flowScalar(this.type);
              if (atNextItem || it.value) {
                map.items.push({ start, key: fs4, sep: [] });
                this.onKeyLine = true;
              } else if (it.sep) {
                this.stack.push(fs4);
              } else {
                Object.assign(it, { key: fs4, sep: [] });
                this.onKeyLine = true;
              }
              return;
            }
            default: {
              const bv = this.startBlockValue(map);
              if (bv) {
                if (bv.type === "block-seq") {
                  if (!it.explicitKey && it.sep && !includesToken(it.sep, "newline")) {
                    yield* this.pop({
                      type: "error",
                      offset: this.offset,
                      message: "Unexpected block-seq-ind on same line with key",
                      source: this.source
                    });
                    return;
                  }
                } else if (atMapIndent) {
                  map.items.push({ start });
                }
                this.stack.push(bv);
                return;
              }
            }
          }
        }
        yield* this.pop();
        yield* this.step();
      }
      *blockSequence(seq) {
        const it = seq.items[seq.items.length - 1];
        switch (this.type) {
          case "newline":
            if (it.value) {
              const end = "end" in it.value ? it.value.end : void 0;
              const last = Array.isArray(end) ? end[end.length - 1] : void 0;
              if (last?.type === "comment")
                end?.push(this.sourceToken);
              else
                seq.items.push({ start: [this.sourceToken] });
            } else
              it.start.push(this.sourceToken);
            return;
          case "space":
          case "comment":
            if (it.value)
              seq.items.push({ start: [this.sourceToken] });
            else {
              if (this.atIndentedComment(it.start, seq.indent)) {
                const prev = seq.items[seq.items.length - 2];
                const end = prev?.value?.end;
                if (Array.isArray(end)) {
                  arrayPushArray(end, it.start);
                  end.push(this.sourceToken);
                  seq.items.pop();
                  return;
                }
              }
              it.start.push(this.sourceToken);
            }
            return;
          case "anchor":
          case "tag":
            if (it.value || this.indent <= seq.indent)
              break;
            it.start.push(this.sourceToken);
            return;
          case "seq-item-ind":
            if (this.indent !== seq.indent)
              break;
            if (it.value || includesToken(it.start, "seq-item-ind"))
              seq.items.push({ start: [this.sourceToken] });
            else
              it.start.push(this.sourceToken);
            return;
        }
        if (this.indent > seq.indent) {
          const bv = this.startBlockValue(seq);
          if (bv) {
            this.stack.push(bv);
            return;
          }
        }
        yield* this.pop();
        yield* this.step();
      }
      *flowCollection(fc) {
        const it = fc.items[fc.items.length - 1];
        if (this.type === "flow-error-end") {
          let top;
          do {
            yield* this.pop();
            top = this.peek(1);
          } while (top?.type === "flow-collection");
        } else if (fc.end.length === 0) {
          switch (this.type) {
            case "comma":
            case "explicit-key-ind":
              if (!it || it.sep)
                fc.items.push({ start: [this.sourceToken] });
              else
                it.start.push(this.sourceToken);
              return;
            case "map-value-ind":
              if (!it || it.value)
                fc.items.push({ start: [], key: null, sep: [this.sourceToken] });
              else if (it.sep)
                it.sep.push(this.sourceToken);
              else
                Object.assign(it, { key: null, sep: [this.sourceToken] });
              return;
            case "space":
            case "comment":
            case "newline":
            case "anchor":
            case "tag":
              if (!it || it.value)
                fc.items.push({ start: [this.sourceToken] });
              else if (it.sep)
                it.sep.push(this.sourceToken);
              else
                it.start.push(this.sourceToken);
              return;
            case "alias":
            case "scalar":
            case "single-quoted-scalar":
            case "double-quoted-scalar": {
              const fs4 = this.flowScalar(this.type);
              if (!it || it.value)
                fc.items.push({ start: [], key: fs4, sep: [] });
              else if (it.sep)
                this.stack.push(fs4);
              else
                Object.assign(it, { key: fs4, sep: [] });
              return;
            }
            case "flow-map-end":
            case "flow-seq-end":
              fc.end.push(this.sourceToken);
              return;
          }
          const bv = this.startBlockValue(fc);
          if (bv)
            this.stack.push(bv);
          else {
            yield* this.pop();
            yield* this.step();
          }
        } else {
          const parent = this.peek(2);
          if (parent.type === "block-map" && (this.type === "map-value-ind" && parent.indent === fc.indent || this.type === "newline" && !parent.items[parent.items.length - 1].sep)) {
            yield* this.pop();
            yield* this.step();
          } else if (this.type === "map-value-ind" && parent.type !== "flow-collection") {
            const prev = getPrevProps(parent);
            const start = getFirstKeyStartProps(prev);
            fixFlowSeqItems(fc);
            const sep = fc.end.splice(1, fc.end.length);
            sep.push(this.sourceToken);
            const map = {
              type: "block-map",
              offset: fc.offset,
              indent: fc.indent,
              items: [{ start, key: fc, sep }]
            };
            this.onKeyLine = true;
            this.stack[this.stack.length - 1] = map;
          } else {
            yield* this.lineEnd(fc);
          }
        }
      }
      flowScalar(type) {
        if (this.onNewLine) {
          let nl = this.source.indexOf("\n") + 1;
          while (nl !== 0) {
            this.onNewLine(this.offset + nl);
            nl = this.source.indexOf("\n", nl) + 1;
          }
        }
        return {
          type,
          offset: this.offset,
          indent: this.indent,
          source: this.source
        };
      }
      startBlockValue(parent) {
        switch (this.type) {
          case "alias":
          case "scalar":
          case "single-quoted-scalar":
          case "double-quoted-scalar":
            return this.flowScalar(this.type);
          case "block-scalar-header":
            return {
              type: "block-scalar",
              offset: this.offset,
              indent: this.indent,
              props: [this.sourceToken],
              source: ""
            };
          case "flow-map-start":
          case "flow-seq-start":
            return {
              type: "flow-collection",
              offset: this.offset,
              indent: this.indent,
              start: this.sourceToken,
              items: [],
              end: []
            };
          case "seq-item-ind":
            return {
              type: "block-seq",
              offset: this.offset,
              indent: this.indent,
              items: [{ start: [this.sourceToken] }]
            };
          case "explicit-key-ind": {
            this.onKeyLine = true;
            const prev = getPrevProps(parent);
            const start = getFirstKeyStartProps(prev);
            start.push(this.sourceToken);
            return {
              type: "block-map",
              offset: this.offset,
              indent: this.indent,
              items: [{ start, explicitKey: true }]
            };
          }
          case "map-value-ind": {
            this.onKeyLine = true;
            const prev = getPrevProps(parent);
            const start = getFirstKeyStartProps(prev);
            return {
              type: "block-map",
              offset: this.offset,
              indent: this.indent,
              items: [{ start, key: null, sep: [this.sourceToken] }]
            };
          }
        }
        return null;
      }
      atIndentedComment(start, indent) {
        if (this.type !== "comment")
          return false;
        if (this.indent <= indent)
          return false;
        return start.every((st) => st.type === "newline" || st.type === "space");
      }
      *documentEnd(docEnd) {
        if (this.type !== "doc-mode") {
          if (docEnd.end)
            docEnd.end.push(this.sourceToken);
          else
            docEnd.end = [this.sourceToken];
          if (this.type === "newline")
            yield* this.pop();
        }
      }
      *lineEnd(token) {
        switch (this.type) {
          case "comma":
          case "doc-start":
          case "doc-end":
          case "flow-seq-end":
          case "flow-map-end":
          case "map-value-ind":
            yield* this.pop();
            yield* this.step();
            break;
          case "newline":
            this.onKeyLine = false;
          // fallthrough
          case "space":
          case "comment":
          default:
            if (token.end)
              token.end.push(this.sourceToken);
            else
              token.end = [this.sourceToken];
            if (this.type === "newline")
              yield* this.pop();
        }
      }
    };
    exports.Parser = Parser;
  }
});

// node_modules/yaml/dist/public-api.js
var require_public_api = __commonJS({
  "node_modules/yaml/dist/public-api.js"(exports) {
    "use strict";
    var composer = require_composer();
    var Document = require_Document();
    var errors = require_errors();
    var log = require_log();
    var identity = require_identity();
    var lineCounter = require_line_counter();
    var parser = require_parser();
    function parseOptions(options) {
      const prettyErrors = options.prettyErrors !== false;
      const lineCounter$1 = options.lineCounter || prettyErrors && new lineCounter.LineCounter() || null;
      return { lineCounter: lineCounter$1, prettyErrors };
    }
    function parseAllDocuments(source2, options = {}) {
      const { lineCounter: lineCounter2, prettyErrors } = parseOptions(options);
      const parser$1 = new parser.Parser(lineCounter2?.addNewLine);
      const composer$1 = new composer.Composer(options);
      const docs = Array.from(composer$1.compose(parser$1.parse(source2)));
      if (prettyErrors && lineCounter2)
        for (const doc of docs) {
          doc.errors.forEach(errors.prettifyError(source2, lineCounter2));
          doc.warnings.forEach(errors.prettifyError(source2, lineCounter2));
        }
      if (docs.length > 0)
        return docs;
      return Object.assign([], { empty: true }, composer$1.streamInfo());
    }
    function parseDocument2(source2, options = {}) {
      const { lineCounter: lineCounter2, prettyErrors } = parseOptions(options);
      const parser$1 = new parser.Parser(lineCounter2?.addNewLine);
      const composer$1 = new composer.Composer(options);
      let doc = null;
      for (const _doc of composer$1.compose(parser$1.parse(source2), true, source2.length)) {
        if (!doc)
          doc = _doc;
        else if (doc.options.logLevel !== "silent") {
          doc.errors.push(new errors.YAMLParseError(_doc.range.slice(0, 2), "MULTIPLE_DOCS", "Source contains multiple documents; please use YAML.parseAllDocuments()"));
          break;
        }
      }
      if (prettyErrors && lineCounter2) {
        doc.errors.forEach(errors.prettifyError(source2, lineCounter2));
        doc.warnings.forEach(errors.prettifyError(source2, lineCounter2));
      }
      return doc;
    }
    function parse(src, reviver, options) {
      let _reviver = void 0;
      if (typeof reviver === "function") {
        _reviver = reviver;
      } else if (options === void 0 && reviver && typeof reviver === "object") {
        options = reviver;
      }
      const doc = parseDocument2(src, options);
      if (!doc)
        return null;
      doc.warnings.forEach((warning) => log.warn(doc.options.logLevel, warning));
      if (doc.errors.length > 0) {
        if (doc.options.logLevel !== "silent")
          throw doc.errors[0];
        else
          doc.errors = [];
      }
      return doc.toJS(Object.assign({ reviver: _reviver }, options));
    }
    function stringify2(value, replacer, options) {
      let _replacer = null;
      if (typeof replacer === "function" || Array.isArray(replacer)) {
        _replacer = replacer;
      } else if (options === void 0 && replacer) {
        options = replacer;
      }
      if (typeof options === "string")
        options = options.length;
      if (typeof options === "number") {
        const indent = Math.round(options);
        options = indent < 1 ? void 0 : indent > 8 ? { indent: 8 } : { indent };
      }
      if (value === void 0) {
        const { keepUndefined } = options ?? replacer ?? {};
        if (!keepUndefined)
          return void 0;
      }
      if (identity.isDocument(value) && !_replacer)
        return value.toString(options);
      return new Document.Document(value, _replacer, options).toString(options);
    }
    exports.parse = parse;
    exports.parseAllDocuments = parseAllDocuments;
    exports.parseDocument = parseDocument2;
    exports.stringify = stringify2;
  }
});

// node_modules/yaml/dist/index.js
var require_dist = __commonJS({
  "node_modules/yaml/dist/index.js"(exports) {
    "use strict";
    var composer = require_composer();
    var Document = require_Document();
    var Schema = require_Schema();
    var errors = require_errors();
    var Alias = require_Alias();
    var identity = require_identity();
    var Pair = require_Pair();
    var Scalar = require_Scalar();
    var YAMLMap = require_YAMLMap();
    var YAMLSeq = require_YAMLSeq();
    var cst = require_cst();
    var lexer = require_lexer();
    var lineCounter = require_line_counter();
    var parser = require_parser();
    var publicApi = require_public_api();
    var visit = require_visit();
    exports.Composer = composer.Composer;
    exports.Document = Document.Document;
    exports.Schema = Schema.Schema;
    exports.YAMLError = errors.YAMLError;
    exports.YAMLParseError = errors.YAMLParseError;
    exports.YAMLWarning = errors.YAMLWarning;
    exports.Alias = Alias.Alias;
    exports.isAlias = identity.isAlias;
    exports.isCollection = identity.isCollection;
    exports.isDocument = identity.isDocument;
    exports.isMap = identity.isMap;
    exports.isNode = identity.isNode;
    exports.isPair = identity.isPair;
    exports.isScalar = identity.isScalar;
    exports.isSeq = identity.isSeq;
    exports.Pair = Pair.Pair;
    exports.Scalar = Scalar.Scalar;
    exports.YAMLMap = YAMLMap.YAMLMap;
    exports.YAMLSeq = YAMLSeq.YAMLSeq;
    exports.CST = cst;
    exports.Lexer = lexer.Lexer;
    exports.LineCounter = lineCounter.LineCounter;
    exports.Parser = parser.Parser;
    exports.parse = publicApi.parse;
    exports.parseAllDocuments = publicApi.parseAllDocuments;
    exports.parseDocument = publicApi.parseDocument;
    exports.stringify = publicApi.stringify;
    exports.visit = visit.visit;
    exports.visitAsync = visit.visitAsync;
  }
});

// runtime/core/document.mjs
function parseDocument(source2) {
  requireThat(typeof source2 === "string", "document", "Markdown must be text.");
  const match = /^(\uFEFF?---[ \t]*\r?\n)([\s\S]*?)(^---[ \t]*(?:\r?\n|$))/m.exec(source2);
  if (!match || match.index !== 0) {
    requireThat(!/^\uFEFF?---[ \t]*\r?\n/.test(source2), "frontmatter", "Frontmatter is not closed.");
    return { head: {}, body: source2, source: source2, yaml: null, prefix: "", raw: "", suffix: "", offset: 0 };
  }
  const yaml = (0, import_yaml.parseDocument)(match[2], { keepSourceTokens: true, uniqueKeys: true, version: "1.2" });
  if (yaml.errors.length) throw new WikiError("frontmatter", "YAML: " + yaml.errors.map((e) => e.message).join("; "));
  requireThat(!yaml.contents || (0, import_yaml.isMap)(yaml.contents), "frontmatter", "Frontmatter must be a mapping.");
  let head;
  try {
    head = yaml.toJS({ maxAliasCount: 50 }) ?? {};
  } catch (error) {
    throw new WikiError("frontmatter", "YAML: " + error.message);
  }
  const visibleHead = structuredClone(head), tail = source2.slice(match[0].length), meta = /^\s*<!-- llmwiki:metadata ([^\n]+) -->\r?\n/.exec(tail);
  let metadata = null;
  if (meta) {
    try {
      metadata = JSON.parse(meta[1]);
    } catch {
      throw new WikiError("metadata", "Invalid embedded metadata. Restore it before editing.");
    }
    requireThat(metadata?.format === "llmwiki-metadata/1" && metadata.fields && typeof metadata.fields === "object" && !Array.isArray(metadata.fields), "metadata", "Invalid embedded metadata format.");
    for (const key of technicalKeys) if (Object.hasOwn(metadata.fields, key)) head[key] = metadata.fields[key];
  }
  const metadataPrefix = meta?.[0] ?? "", offset = match[0].length + metadataPrefix.length;
  return {
    head,
    visibleHead,
    metadata,
    metadataPrefix,
    body: source2.slice(offset),
    source: source2,
    yaml,
    prefix: match[1],
    raw: match[2],
    suffix: match[3],
    offset
  };
}
var import_yaml, technicalKeys;
var init_document = __esm({
  "runtime/core/document.mjs"() {
    import_yaml = __toESM(require_dist(), 1);
    init_errors();
    technicalKeys = ["resource", "generated", "sources", "extraction", "source_id"];
  }
});

// runtime/review.mjs
var missing, FolderAccess, environment, reviews, sync, projectSettings;
var init_review = __esm({
  "runtime/review.mjs"() {
    init_reviews();
    init_editorsync();
    init_project();
    init_matching();
    init_document();
    init_errors();
    missing = () => Object.assign(new Error("File or directory not found."), { name: "NotFoundError" });
    FolderAccess = {
      async readBinary(dir, page) {
        const file = await dir.store.read(dir.full(page), { binary: true });
        if (!file) throw missing();
        return file;
      },
      async writeBinary(dir, page, bytes, seen) {
        return dir.store.write(dir.full(page), bytes, { expected: seen?.sha256 ?? null });
      },
      canArchive: (dir) => typeof dir.store.archive === "function",
      async archiveFile(dir, from, to, expected) {
        return dir.store.archive(dir.full(from), dir.full(to), expected);
      },
      async peek(dir, page) {
        return dir.store.read(dir.full(page));
      },
      async readFile(dir, page) {
        const seen = await this.peek(dir, page);
        if (!seen) throw missing();
        return { ...seen, mark: seen.sha256 };
      },
      async writeFile(dir, page, value, seen) {
        try {
          const result = await dir.store.write(dir.full(page), value, { expected: seen?.sha256 ?? seen?.mark ?? null });
          return { ...result, text: value, mark: result.sha256 };
        } catch (e) {
          if (["stale", "busy", "mismatch"].includes(e.code)) return { saved: false, stale: true, reason: e.message };
          throw e;
        }
      },
      async listFolder(dir, _unused, { visible = () => true } = {}) {
        return (await dir.store.list(dir.prefix)).filter((e) => e.kind === "file" && visible(e.path, "file")).map((e) => ({ name: dir.prefix ? e.path.slice(dir.prefix.length + 1) : e.path, size: 0 }));
      }
    };
    environment = {
      FolderAccess,
      crypto,
      matchingBlocks,
      I18n: { message: (key) => key, error: (message) => new Error(message) },
      headField: (text3, key) => parseDocument(text3).head[key],
      parseHead: parseDocument
    };
    reviews = createReviews(environment);
    sync = createSync(environment);
    projectSettings = createProject(environment);
  }
});

// runtime/core/ontology.mjs
var init_ontology = __esm({
  "runtime/core/ontology.mjs"() {
    init_document();
    init_errors();
  }
});

// runtime/core/graph.mjs
var navigationPage;
var init_graph = __esm({
  "runtime/core/graph.mjs"() {
    init_document();
    init_ontology();
    init_errors();
    navigationPage = (path5) => ["WIKI.md", "index.md", "bundle.md", "wiki/index.md", "wiki/bundle.md"].includes(path5);
  }
});

// runtime/links.mjs
var init_links = __esm({
  "runtime/links.mjs"() {
    init_graph();
    init_document();
  }
});

// runtime/derived.mjs
var init_derived = __esm({
  "runtime/derived.mjs"() {
    init_graph();
    init_document();
    init_review();
    init_errors();
    init_links();
    init_links();
  }
});

// runtime/assets/default-register.mjs
var init_default_register = __esm({
  "runtime/assets/default-register.mjs"() {
  }
});

// runtime/core/note-contract.mjs
var init_note_contract = __esm({
  "runtime/core/note-contract.mjs"() {
    init_document();
  }
});

// runtime/content.mjs
var STATUS_VALUES;
var init_content = __esm({
  "runtime/content.mjs"() {
    init_derived();
    init_default_register();
    init_document();
    init_ontology();
    init_graph();
    init_errors();
    init_review();
    init_note_contract();
    STATUS_VALUES = Object.freeze(["draft", "stable", "deprecated"]);
  }
});

// runtime/setup-contract.mjs
var text, flag, texts, location, object, wiki, source, schema;
var init_setup_contract = __esm({
  "runtime/setup-contract.mjs"() {
    init_errors();
    text = { type: "string" };
    flag = { type: "boolean" };
    texts = { type: "array", items: text };
    location = { type: ["string", "null"], description: "Project-relative directory, or null with an existing device binding. Never an absolute OS path." };
    object = (properties) => ({ type: "object", additionalProperties: false, properties });
    wiki = object({ id: text, label: text, path: location, workPath: location, purpose: text, audience: texts, writable: flag, shared: flag, icon: text, default_source: { type: ["string", "null"] } });
    source = object({ id: text, label: text, path: location, wikis: texts, writable: flag, icon: text });
    schema = object({ id: text, label: text, author: text, editor: { type: "string", enum: ["builtin", "obsidian", "both"] }, language: { type: "string", enum: ["de", "en"] }, wikis: { type: "array", items: wiki }, sources: { type: "array", items: source } });
  }
});

// runtime/project.mjs
function validateLocations(root, project, bindings) {
  const clean = (value) => typeof value === "string" ? value.replace(/\\/g, "/").replace(/\/+$/, "") : null;
  const location2 = (f) => f.path === null ? clean(bindings[f.id]?.root) : clean(f.path === "." ? root.root : [root.root, f.path].filter(Boolean).join("/"));
  const overlaps = (a, b) => a !== null && b !== null && (a === b || a === "" || b === "" || a.startsWith(b + "/") || b.startsWith(a + "/"));
  for (const c of project.connections) {
    const folder = (id) => project.folders.find((f) => f.id === id), wiki2 = folder(c.wiki), works = c.works.map(folder);
    for (const work of works) requireThat(!overlaps(location2(wiki2), location2(work)), "binding_overlap", "Wiki storage and working copy must be separate directories.", { wiki: wiki2.id, work: work.id });
    for (const source2 of c.sources.map(folder)) for (const target of [wiki2, ...works]) requireThat(!overlaps(location2(source2), location2(target)), "binding_overlap", "The source binding points inside a wiki/working copy or contains it. Bind the actual original source directory.", { source: source2.id, target: target.id });
  }
}
async function workspaceState(root) {
  const { project } = await load(root), marker = await root.read(INSTANCE), f = await root.read(WORKSPACE_STATE);
  let data = null;
  try {
    data = f ? JSON.parse(f.text) : null;
  } catch {
  }
  return data?.format === "llmwiki-workspace-state/1" && data.project === project.id && data.instance === JSON.parse(marker?.text ?? "null")?.instance && project.connections.some((c) => c.id === data.connection && c.works.includes(data.work)) ? data : null;
}
async function load(root) {
  const file = await root.read(NAME);
  requireThat(file, "setup", "Start guided setup before selecting a task.");
  return { project: projectSettings.validate(JSON.parse(file.text)), file };
}
async function folderStore(root, folder, { bindings = {}, writable = folder.writable } = {}) {
  if (folder.path === null) {
    requireThat(bindings[folder.id], "binding", "Connect this device to the selected folder.", { folder: folder.id });
    return bindings[folder.id].substore("", { writable: writable && folder.kind !== "source" });
  }
  return root.substore(folder.path, { writable: writable && folder.kind !== "source" });
}
function syncIdentity(project, wiki2, work) {
  return JSON.stringify([project.id, wiki2.id, wiki2.path, work.id, work.path]);
}
async function context(root, connection, { bindings = {}, work: workID } = {}) {
  const { project } = await load(root), active = await workspaceState(root);
  connection ??= active?.connection ?? (project.connections.length === 1 ? project.connections[0].id : null);
  const c = project.connections.find((c2) => c2.id === connection);
  requireThat(c, "connection", "Select a connected wiki.");
  const folder = (id) => project.folders.find((f) => f.id === id), wiki2 = folder(c.wiki), work = folder(workID ?? (active?.connection === c.id ? active.work : null) ?? (c.works.length === 1 ? c.works[0] : null));
  validateLocations(root, { ...project, connections: [c] }, bindings);
  requireThat(work && c.works.includes(work.id), "work", "Working folder is not assigned to this wiki.");
  const sources = [];
  for (const id of c.sources) {
    const f = folder(id);
    try {
      sources.push({ ...f, store: await folderStore(root, f, { bindings, writable: false }) });
    } catch (error) {
      sources.push({ ...f, store: null, error: { code: error.code, message: error.message } });
    }
  }
  return { project, connection: c, wiki: wiki2, workFolder: work, work: await folderStore(root, work, { bindings }), remote: await folderStore(root, wiki2, { bindings }), sources, identity: syncIdentity(project, wiki2, work), canPublish: wiki2.writable };
}
var NAME, INSTANCE, WORKSPACE_STATE;
var init_project2 = __esm({
  "runtime/project.mjs"() {
    init_review();
    init_content();
    init_errors();
    init_document();
    init_setup_contract();
    NAME = "llmwiki.project.json";
    INSTANCE = ".llmwiki/project-instance.json";
    WORKSPACE_STATE = ".llmwiki/workspace-state.json";
  }
});

// runtime/adapters/node.mjs
import fs3 from "node:fs/promises";
import { constants } from "node:fs";
import path3 from "node:path";
import { pathToFileURL } from "node:url";
import { createHash as createHash3, randomBytes, randomUUID as randomUUID2 } from "node:crypto";

// runtime/adapters/node-locks.mjs
init_errors();
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { randomUUID, createHash } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
var databases = /* @__PURE__ */ new Map();
var beneath = (root, p) => p === root || p.startsWith(root + path.sep);
function openRegistry(root, target) {
  const shard = createHash("sha256").update(target).digest("hex")[0];
  let entry = databases.get(shard);
  const dir = path.join(os.homedir(), process.platform === "darwin" ? "Library/Caches" : ".cache", "llmwiki", "writers");
  requireThat(!beneath(root, dir), "lock_location", "Writer ownership must be stored outside the project.");
  if (!entry) {
    fs.mkdirSync(dir, { recursive: true, mode: 448 });
    const real = fs.realpathSync(dir);
    requireThat(!fs.lstatSync(dir).isSymbolicLink() && !beneath(root, real), "lock_location", "Writer registry must be a private directory outside the project.");
    fs.chmodSync(dir, 448);
    const registry = path.join(real, "leases-" + shard + ".sqlite");
    let stat;
    try {
      stat = fs.lstatSync(registry);
    } catch (e) {
      if (e.code !== "ENOENT") throw e;
    }
    requireThat(!stat || stat.isFile() && !stat.isSymbolicLink(), "lock_location", "Writer registry must be a regular private file.");
    if (!stat) try {
      fs.closeSync(fs.openSync(registry, "wx", 384));
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
    }
    fs.chmodSync(registry, 384);
    const db = new DatabaseSync(registry, { allowExtension: false });
    try {
      db.exec("PRAGMA busy_timeout=1500; PRAGMA trusted_schema=OFF; PRAGMA journal_mode=DELETE; CREATE TABLE IF NOT EXISTS leases (file TEXT PRIMARY KEY, token TEXT NOT NULL, pid INTEGER NOT NULL, lock TEXT NOT NULL, temporary TEXT NOT NULL);");
      entry = { db, registry };
      databases.set(shard, entry);
    } catch (e) {
      db.close();
      throw e;
    }
  }
  requireThat(!beneath(root, entry.registry), "lock_location", "Writer ownership must remain outside the project.");
  return entry.db;
}
function guarded(db, run) {
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = run();
    db.exec("COMMIT");
    return result;
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}
function busy(clean, reason) {
  return new WikiError("busy", reason === "active" ? "A local writer is saving this file. Wait for it to finish, then retry." : "The retained lock has unknown or conflicting ownership. Close other writers and inspect the lock before any manual recovery.", { path: clean, reason });
}
function readLock(file) {
  let fd;
  try {
    fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
    const stat = fs.fstatSync(fd);
    requireThat(stat.isFile() && stat.size <= 1024, "busy", "The retained lock is not a valid writer record.");
    const raw = fs.readFileSync(fd, "utf8");
    try {
      return { raw, record: JSON.parse(raw) };
    } catch {
      return { raw, record: null };
    }
  } catch (e) {
    if (e.code === "ENOENT") return null;
    throw e;
  } finally {
    if (fd !== void 0) fs.closeSync(fd);
  }
}
function dead(pid) {
  if (!Number.isSafeInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return false;
  } catch (e) {
    return e.code === "ESRCH";
  }
}
function owned(record, token) {
  return record?.format === "llmwiki-lock/2" && record.token === token;
}
function removeTemporary(file) {
  try {
    const stat = fs.lstatSync(file);
    requireThat(stat.isFile() && !stat.isSymbolicLink(), "busy", "A retained temporary path changed type; inspect it before recovery.");
    fs.unlinkSync(file);
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
}
function acquireWriter({ root, target, lockPath, clean }) {
  const db = openRegistry(root, target), token = randomUUID(), temporary = target + ".llmwiki-" + token + ".tmp";
  guarded(db, () => {
    const prior = db.prepare("SELECT * FROM leases WHERE file=?").get(target);
    if (prior) {
      if (!dead(prior.pid)) throw busy(clean, "active");
      const lock = readLock(prior.lock);
      if (lock && !owned(lock.record, prior.token)) throw busy(clean, "unknown");
      if (lock) fs.unlinkSync(prior.lock);
      removeTemporary(prior.temporary);
      db.prepare("DELETE FROM leases WHERE file=? AND token=?").run(target, prior.token);
    }
    if (readLock(lockPath)) throw busy(clean, "unknown");
    db.prepare("INSERT INTO leases VALUES(?,?,?,?,?)").run(target, token, process.pid, lockPath, temporary);
  });
  try {
    const fd = fs.openSync(lockPath, "wx", 384);
    try {
      fs.writeFileSync(fd, JSON.stringify({ format: "llmwiki-lock/2", token }));
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
  } catch (e) {
    guarded(db, () => db.prepare("DELETE FROM leases WHERE file=? AND token=?").run(target, token));
    if (e.code === "EEXIST") throw busy(clean, "unknown");
    throw e;
  }
  return { temporary, release() {
    guarded(db, () => {
      const row = db.prepare("SELECT token FROM leases WHERE file=?").get(target), lock = readLock(lockPath);
      if (row?.token !== token || lock && !owned(lock.record, token)) throw busy(clean, "unknown");
      removeTemporary(temporary);
      if (lock) fs.unlinkSync(lockPath);
      db.prepare("DELETE FROM leases WHERE file=? AND token=?").run(target, token);
    });
  } };
}

// runtime/adapters/node.mjs
init_errors();
var nodeServices = {
  hash: async (value) => createHash3("sha256").update(value).digest("hex"),
  random: (size) => new Uint8Array(randomBytes(size)),
  uuid: () => randomUUID2(),
  now: () => (/* @__PURE__ */ new Date()).toISOString()
};
var NodeStore = class _NodeStore {
  constructor(root, { writable = true, maxBytes = 128 * 1024 * 1024, shadowCacheRoot } = {}) {
    requireThat(typeof root === "string" && path3.isAbsolute(root), "root", "Select an absolute project directory.");
    this.root = path3.resolve(root);
    this.writable = writable;
    this.maxBytes = maxBytes;
    this.shadowCacheRoot = shadowCacheRoot;
    this.services = nodeServices;
    this.capabilities = { binary: true, exclusiveCreate: true, cooperativeLocks: true, externalWriterCAS: false };
  }
  async shadowDatabase(project, options = {}) {
    const { openShadowDatabase: openShadowDatabase2 } = await Promise.resolve().then(() => (init_shadow_node(), shadow_node_exports));
    return openShadowDatabase2(this.root, project, { cacheRoot: this.shadowCacheRoot, ...options, readOnly: this.writable === false || options.readOnly === true });
  }
  async fileURL(relative) {
    return pathToFileURL(await this.location(relative)).href;
  }
  editorLocation() {
    const entry_path = path3.join(this.root, "LLM-Wiki.html");
    return { project_root: this.root, entry_path, entry_uri: pathToFileURL(entry_path).href };
  }
  async location(relative = "", { createParent = false } = {}) {
    const clean = relativePath(relative, { root: true });
    const rootStat = await fs3.lstat(this.root);
    requireThat(rootStat.isDirectory() && !rootStat.isSymbolicLink(), "root", "Root must be a directory, not a symbolic link.");
    const parts = clean ? clean.split("/") : [];
    let current = this.root;
    for (let i = 0; i < parts.length; i++) {
      current = path3.join(current, parts[i]);
      let stat;
      try {
        stat = await fs3.lstat(current);
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
        if (createParent && i < parts.length - 1) {
          try {
            await fs3.mkdir(current);
          } catch (e) {
            if (e.code !== "EEXIST") throw e;
          }
          stat = await fs3.lstat(current);
        } else continue;
      }
      requireThat(!stat.isSymbolicLink(), "symlink", "Symbolic links are not traversed.", { path: clean });
      if (i < parts.length - 1) requireThat(stat.isDirectory(), "path", "Parent path is not a directory.", { path: clean });
    }
    return current;
  }
  async read(relative, { binary = false } = {}) {
    const target = await this.location(relative);
    let handle2;
    try {
      handle2 = await fs3.open(target, constants.O_RDONLY | constants.O_NOFOLLOW);
    } catch (error) {
      if (error.code === "ENOENT") return null;
      throw error;
    }
    try {
      const stat = await handle2.stat();
      requireThat(stat.isFile(), "file", "Select a file.", { path: relative });
      requireThat(stat.size <= this.maxBytes, "size", "File exceeds the reading limit.", { path: relative, size: stat.size });
      const bytes = await handle2.readFile();
      const result = {
        path: relative,
        bytes: new Uint8Array(bytes),
        sha256: await nodeServices.hash(bytes),
        size: bytes.length,
        mode: stat.mode & 511,
        modified_at: stat.mtime.toISOString(),
        created_at: stat.birthtimeMs > 0 ? stat.birthtime.toISOString() : null,
        created_at_basis: stat.birthtimeMs > 0 ? "filesystem_birthtime" : "unknown"
      };
      if (!binary) result.text = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes);
      return result;
    } finally {
      await handle2.close();
    }
  }
  /** Cheap identity for validating a multi-call inventory without rehydrating bytes. */
  async fingerprint(relative) {
    let stat;
    try {
      stat = await fs3.lstat(await this.location(relative));
    } catch (error) {
      if (error.code === "ENOENT") return null;
      throw error;
    }
    requireThat(stat.isFile() && !stat.isSymbolicLink(), "file", "Select a regular file.", { path: relative });
    return [stat.dev, stat.ino, stat.size, stat.mtimeMs, stat.ctimeMs];
  }
  async mkdir(relative) {
    requireThat(this.writable, "read-only", "Source folders are read-only.");
    const target = await this.location(relative + "/.directory-check", { createParent: true });
    return path3.dirname(target);
  }
  async list(relative = "", { recursive = true, hidden = false } = {}) {
    relativePath(relative, { root: true });
    const out = [];
    const visit = async (dir) => {
      const target = await this.location(dir);
      const entries = (await fs3.readdir(target, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name));
      for (const e of entries) {
        if (!hidden && (e.name.startsWith(".") || e.name.startsWith("~$"))) continue;
        const rel = dir ? dir + "/" + e.name : e.name;
        if (e.isSymbolicLink()) {
          out.push({ path: rel, kind: "symlink" });
          continue;
        }
        out.push({ path: rel, kind: e.isDirectory() ? "directory" : "file" });
        if (recursive && e.isDirectory()) await visit(rel);
      }
    };
    await visit(relative);
    return out;
  }
  async write(relative, content, options = {}) {
    requireThat(this.writable, "read-only", "Source folders are read-only.");
    requireThat(Object.hasOwn(options, "expected"), "baseline", "An expected baseline is required before writing.");
    requireThat(options.expected === null || /^[a-f0-9]{64}$/.test(options.expected), "baseline", "Invalid expected baseline.");
    const clean = relativePath(relative), bytes = typeof content === "string" ? new TextEncoder().encode(content) : content;
    requireThat(bytes instanceof Uint8Array && bytes.length <= this.maxBytes, "size", "Invalid or oversized write.");
    const lockRel = ".llmwiki/locks/" + await nodeServices.hash(clean) + ".lock";
    const lockPath = await this.location(lockRel, { createParent: true }), canonical = await fs3.realpath(this.root), target = path3.join(canonical, clean);
    const writer = acquireWriter({ root: canonical, target, lockPath, clean });
    try {
      const current = await this.read(clean, { binary: true });
      requireThat((current?.sha256 ?? null) === options.expected, "stale", "The file changed since the expected baseline.", { path: clean, current: current?.sha256 ?? null });
      await this.location(clean, { createParent: true });
      const temporary = writer.temporary;
      const file = await fs3.open(temporary, "wx", current?.mode ?? options.mode ?? 438);
      try {
        if (current?.mode !== void 0) await file.chmod(current.mode);
        await file.writeFile(bytes);
        await file.sync();
      } finally {
        await file.close();
      }
      const checked = await this.read(clean, { binary: true });
      requireThat((checked?.sha256 ?? null) === options.expected, "stale", "The file changed before replacement.", { path: clean });
      if (options.expected === null) {
        try {
          await fs3.link(temporary, target);
        } catch (error) {
          if (error.code === "EEXIST") throw new WikiError("stale", "The file was created by another writer.", { path: clean });
          throw error;
        }
        await fs3.unlink(temporary);
      } else await fs3.rename(temporary, target);
      const digest2 = await nodeServices.hash(bytes), readback = await this.read(clean, { binary: true });
      requireThat(readback?.sha256 === digest2, "mismatch", "The saved file changed during verification.", { path: clean });
      return { saved: true, path: clean, sha256: digest2 };
    } finally {
      writer.release();
    }
  }
  async archive(from, to, expected) {
    requireThat(this.writable, "read-only", "Sources are read-only.");
    const seen = await this.read(from, { binary: true });
    requireThat(seen?.sha256 === expected, "stale", "The original changed before archiving.");
    const target = await this.location(to, { createParent: true }), source2 = await this.location(from);
    const archived = await this.read(to, { binary: true });
    requireThat(!archived || archived.sha256 === expected, "exists", "Archive destination already exists with different content.");
    if (!archived) await fs3.link(source2, target);
    const verified = await this.read(from, { binary: true });
    requireThat(verified?.sha256 === expected, "stale", "The original changed while archiving; both copies are retained.");
    await fs3.unlink(source2);
    requireThat((await this.read(to, { binary: true }))?.sha256 === expected, "mismatch", "Archive verification failed.");
  }
  async substore(relative, options = {}) {
    const root = await this.location(relative, { createParent: false });
    const store = new _NodeStore(root, { ...options, writable: this.writable && options.writable !== false });
    await store.location("");
    return store;
  }
};

// runtime/node-input.mjs
import path4 from "node:path";
init_errors();
var MAX_REQUEST = 32 * 1024 * 1024;
var flags = /* @__PURE__ */ new Set(["--root", "--input", "--bindings", "--read-only", "--help"]);
function parseArguments(args) {
  const parsed = {};
  for (let i = 0; i < args.length; i++) {
    const flag2 = args[i];
    requireThat(flags.has(flag2), "arguments", "Unknown option: " + flag2 + ". Use --help for supported options.");
    requireThat(!Object.hasOwn(parsed, flag2), "arguments", "Duplicate option: " + flag2);
    if (flag2 === "--read-only" || flag2 === "--help") parsed[flag2] = true;
    else {
      const value = args[++i];
      requireThat(typeof value === "string" && value.length > 0 && !value.startsWith("--"), "arguments", "Missing value for " + flag2);
      parsed[flag2] = value;
    }
  }
  if (!parsed["--help"]) requireThat(parsed["--root"] && parsed["--input"], "arguments", "Use --root ABSOLUTE_PROJECT --input JSON (or a request file, or - for stdin).");
  return parsed;
}
async function fileText(file, maxBytes) {
  const absolute = path4.resolve(file), store = new NodeStore(path4.dirname(absolute), { writable: false, maxBytes });
  const value = await store.read(path4.basename(absolute));
  requireThat(value, "ENOENT", "Input file does not exist.", { path: absolute });
  return value.text;
}
function json(text3, code, message) {
  try {
    return JSON.parse(text3);
  } catch {
    throw new WikiError(code, message);
  }
}
async function readRequest(input, stdin = process.stdin) {
  let text3;
  if (input === "-") {
    const chunks = [];
    let size = 0;
    for await (const chunk of stdin) {
      const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      size += bytes.length;
      requireThat(size <= MAX_REQUEST, "input_size", "Request exceeds 32 MiB.");
      chunks.push(bytes);
    }
    text3 = Buffer.concat(chunks).toString("utf8");
  } else if (/^[\s\uFEFF]*[\[{]/.test(input)) text3 = input;
  else text3 = await fileText(input, MAX_REQUEST);
  requireThat(Buffer.byteLength(text3, "utf8") <= MAX_REQUEST, "input_size", "Request exceeds 32 MiB.");
  const request = json(text3.replace(/^\uFEFF/, ""), "input_json", "Supply valid JSON using --input JSON, --input - or an existing request file inside the granted project.");
  requireThat(request && typeof request === "object" && !Array.isArray(request) && typeof request.action === "string" && request.action.trim(), "input_json", "A JSON object with a nonempty action is required.");
  return request;
}
async function loadBindings(root, { file = null, readOnly = false } = {}) {
  let text3;
  if (file) text3 = await fileText(file, 1024 * 1024);
  else {
    const found = await root.read(".llmwiki/device-bindings.json") ?? await root.read(".llmwiki/bindings.json");
    if (!found) return {};
    text3 = found.text;
  }
  const value = json(text3, "bindings", "Device bindings must contain valid JSON.");
  requireThat(value && typeof value === "object" && !Array.isArray(value), "bindings", "Device bindings must be an object.");
  if (Object.hasOwn(value, "format")) requireThat(value.format === "llmwiki-device-bindings/1", "bindings", "Unknown device binding format.");
  const folders = Object.hasOwn(value, "format") ? value.folders : value;
  requireThat(folders && typeof folders === "object" && !Array.isArray(folders), "bindings", "Device bindings must map folder IDs to absolute host paths.");
  const bindings = {};
  for (const [id, location2] of Object.entries(folders)) {
    requireThat(id && !["__proto__", "constructor", "prototype"].includes(id) && typeof location2 === "string" && path4.isAbsolute(location2), "bindings", "Each device binding needs a folder ID and an absolute host path.", { folder: id });
    bindings[id] = new NodeStore(location2, { writable: !readOnly });
  }
  return bindings;
}

// runtime/answer.mjs
init_errors();
init_project2();

// runtime/passage-links.mjs
init_errors();
var hex = (x) => typeof x === "string" && /^[a-f0-9]{64}$/.test(x);
function validatePassage(p) {
  requireThat(p?.version === 1, "citation_link", "Unsupported passage link.");
  for (const key of ["project", "instance", "connection", "work", "wiki"]) requireThat(typeof p[key] === "string" && p[key].length > 0 && p[key].length <= 256, "citation_link", "Invalid passage scope.");
  requireThat(typeof p.page === "string" && p.page.length <= 2048, "citation_link", "Invalid passage path.");
  relativePath(p.page);
  requireThat(hex(p.revision) && hex(p.quote_hash) && (p.document === null || hex(p.document)) && (p.block === null || hex(p.block)), "citation_link", "Invalid passage identity.");
  requireThat([p.start, p.end, p.offset].every(Number.isSafeInteger) && p.start >= 0 && p.end > p.start && p.end <= 128 * 1024 * 1024 && p.offset >= 0 && p.offset <= p.start, "citation_link", "Invalid passage range.");
  return p;
}
function decodePassage(token) {
  requireThat(typeof token === "string" && token.length > 0 && token.length <= 8192 && /^[A-Za-z0-9_-]+$/.test(token), "citation_link", "Invalid passage link.");
  let a;
  try {
    a = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(atob(token.replaceAll("-", "+").replaceAll("_", "/")), (c) => c.charCodeAt(0))));
  } catch {
    requireThat(false, "citation_link", "Invalid passage encoding.");
  }
  requireThat(Array.isArray(a) && a.length === 14, "citation_link", "Invalid passage fields.");
  const [version, project, instance, connection, work, wiki2, page, document, block, revision, start, end, offset, quote_hash] = a;
  return validatePassage({ version, project, instance, connection, work, wiki: wiki2, page, document, block, revision, start, end, offset, quote_hash });
}

// runtime/citations.mjs
async function editorDestination(root, project) {
  let entry = null, marker = null, entryError = null;
  try {
    entry = await root.read("LLM-Wiki.html");
    marker = await root.read(".llmwiki/project-instance.json");
  } catch (error) {
    entryError = error.code ?? "editor_read_error";
  }
  let instance = null;
  try {
    const data = JSON.parse(marker?.text ?? "null");
    if (data?.project === project.id) instance = data.instance;
  } catch {
  }
  const version = entry?.text.match(/<meta name="llmwiki-editor-version" content="([^"]+)">/)?.[1], parts = version?.split(".").map(Number);
  const compatible = parts?.length === 3 && parts.every(Number.isInteger) && (parts[0] > 0 || parts[1] > 4 || parts[1] === 4 && parts[2] >= 23);
  const bound = instance && entry?.text.includes('<meta name="llmwiki-entry-project" content="' + project.id + '">') && entry?.text.includes('<meta name="llmwiki-entry-instance" content="' + instance + '">');
  let href = null;
  try {
    if (entry && root.fileURL) href = await root.fileURL("LLM-Wiki.html");
  } catch (error) {
    entryError = error.code ?? "editor_link_error";
  }
  return { instance, mode: "inline_editor", available: Boolean(href && bound && compatible), reason: entryError ?? (!entry ? "editor_missing" : !bound ? "editor_instance_mismatch" : !compatible ? "editor_update_required" : !href ? "editor_link_unavailable" : null), minimum_editor: "0.4.23", entry_href: href, use: "Place passage.markdown immediately after the supported claim. Keep editor_href intact; never reconstruct a relative wiki path. A bibliography does not replace inline evidence." };
}

// runtime/shadow.mjs
init_document();
init_errors();
var SHADOW_FORMAT = "llmwiki-shadow/1";
var PARSER_VERSION = "markdown-structure/2";
var hashKey = (services, ...parts) => services.hash(JSON.stringify(parts));
async function parseShadow(source2, services, { maxBytes = 8 * 1024 * 1024 } = {}) {
  requireThat(typeof source2 === "string", "shadow_source", "Supply Markdown text.");
  const bytes = new TextEncoder().encode(source2);
  requireThat(bytes.length <= maxBytes, "shadow_limit", "This document exceeds the structural indexing budget.");
  const parsed = parseDocument(source2), revision = await services.hash(bytes), lines = [];
  let offset = parsed.offset;
  for (const raw of parsed.body.match(/[^\n]*\n|[^\n]+$/g) ?? []) {
    const original = raw.replace(/\r?\n$/, ""), text3 = offset === 0 ? original.replace(/^\uFEFF/, "") : original;
    lines.push({ text: text3, start: offset, end: offset + original.length });
    offset += raw.length;
  }
  const byteAt = new Uint32Array(source2.length + 1), unicodeAt = new Uint32Array(source2.length + 1), lineAt = new Uint32Array(source2.length + 1);
  let b = 0, u = 0, line = 1;
  for (let i = 0; i < source2.length; ) {
    const cp = source2.codePointAt(i), width = cp > 65535 ? 2 : 1;
    byteAt[i] = b;
    unicodeAt[i] = u;
    lineAt[i] = line;
    if (width === 2) {
      byteAt[i + 1] = b;
      unicodeAt[i + 1] = u;
      lineAt[i + 1] = line;
    }
    b += cp <= 127 ? 1 : cp <= 2047 ? 2 : cp <= 65535 ? 3 : 4;
    u++;
    if (cp === 10) line++;
    i += width;
  }
  byteAt[source2.length] = b;
  unicodeAt[source2.length] = u;
  lineAt[source2.length] = line;
  const blocks = [], headings = [];
  const atx = (text3) => /^ {0,3}(#{1,6})[ \t]+(.+?)[ \t]*#*[ \t]*$/.exec(text3);
  const fence = (text3) => /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(text3);
  const list = (text3) => /^\s*(?:[-+*]|\d+[.)])[ \t]+/.test(text3);
  const tableRule = (text3) => /^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(text3);
  const special = (i) => !lines[i]?.text.trim() || atx(lines[i].text) || fence(lines[i].text) || /^\s*<!--/.test(lines[i].text) || list(lines[i].text);
  for (let i = 0; i < lines.length; ) {
    if (!lines[i].text.trim()) {
      i++;
      continue;
    }
    if (/^\s*<!--/.test(lines[i].text)) {
      while (i < lines.length && !lines[i++].text.includes("-->")) {
      }
      continue;
    }
    const first = i, h = atx(lines[i].text), f = fence(lines[i].text), setext = lines[i + 1] && /^ {0,3}(=+|-+)\s*$/.exec(lines[i + 1].text);
    let kind = "paragraph";
    if (h || setext) {
      kind = "heading";
      const depth = h ? h[1].length : setext[1][0] === "=" ? 1 : 2;
      headings.length = depth - 1;
      headings[depth - 1] = h ? h[2] : lines[i].text.trim();
      i += h ? 1 : 2;
    } else if (f) {
      kind = "code";
      i++;
      while (i < lines.length) {
        const end2 = fence(lines[i++].text);
        if (end2 && end2[1][0] === f[1][0] && end2[1].length >= f[1].length && !end2[2].trim()) break;
      }
    } else if (tableRule(lines[i + 1]?.text ?? "")) {
      kind = "table";
      i += 2;
      while (i < lines.length && lines[i].text.trim() && lines[i].text.includes("|")) i++;
    } else if (list(lines[i].text)) {
      kind = "list";
      i++;
      while (i < lines.length && lines[i].text.trim() && !atx(lines[i].text) && !fence(lines[i].text)) i++;
    } else {
      if (/^\s*(?:!\[[^\]]*\]\([^\n]*\)|!\[\[[^\n]+\]\])\s*$/.test(lines[i].text)) kind = "image";
      i++;
      while (i < lines.length && !special(i) && !/^ {0,3}(=+|-+)\s*$/.test(lines[i].text) && !tableRule(lines[i + 1]?.text ?? "")) i++;
    }
    const start = lines[first].start, end = lines[i - 1].end, quote = source2.slice(start, end);
    blocks.push({ kind, start, end, byte_start: byteAt[start], byte_end: byteAt[end], unicode_start: unicodeAt[start], unicode_end: unicodeAt[end], line_start: lineAt[start], line_end: lineAt[end], quote, headings: headings.filter(Boolean), text_hash: await hashKey(services, kind, quote), occurrence: await hashKey(services, PARSER_VERSION, revision, start, end) });
  }
  for (let i = 0; i < blocks.length; i++) {
    blocks[i].previous = blocks[i - 1]?.occurrence ?? null;
    blocks[i].next = blocks[i + 1]?.occurrence ?? null;
  }
  return { format: SHADOW_FORMAT, parser: PARSER_VERSION, revision, bytes: bytes.length, source: source2, blocks };
}

// runtime/shadow-project.mjs
init_errors();

// runtime/shadow-exchange.mjs
init_errors();
var IDENTITY_FRAGMENTS = "llmwiki-shadow-identities/2";
var hex2 = (value) => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
async function assembleIdentities(packages, services) {
  const records = [], groups = /* @__PURE__ */ new Map(), findings = [];
  for (const data of packages) {
    if (data.format === SHADOW_FORMAT) {
      requireThat(Array.isArray(data.documents) && data.documents.length <= 1e3, "shadow_history", "Invalid identity package.");
      records.push(...data.documents);
      continue;
    }
    requireThat(data.format === IDENTITY_FRAGMENTS && Array.isArray(data.fragments) && data.fragments.length > 0 && data.fragments.length <= 1e3, "shadow_history", "Unsupported identity package version. Update both skills and the editor; retain all shared files.");
    for (const part of data.fragments) {
      requireThat(hex2(part.record) && Number.isSafeInteger(part.part) && Number.isSafeInteger(part.total) && part.total > 0 && part.total <= 2e4 && part.part >= 0 && part.part < part.total && Number.isSafeInteger(part.blocks_total) && part.blocks_total > 0 && part.blocks_total <= 2e4 && Array.isArray(part.document?.blocks) && part.document.blocks.length > 0 && part.document.blocks.length <= part.blocks_total, "shadow_history", "Invalid identity fragment.");
      const { blocks, ...meta } = part.document, signature = JSON.stringify([part.total, part.blocks_total, meta]), group = groups.get(part.record) ?? { signature, parts: /* @__PURE__ */ new Map(), meta, total: part.total, blocks_total: part.blocks_total };
      requireThat(group.signature === signature, "shadow_history", "Conflicting identity fragments. Retain the packages for reconciliation.");
      const previous = group.parts.get(part.part);
      requireThat(!previous || JSON.stringify(previous) === JSON.stringify(blocks), "shadow_history", "Conflicting duplicate identity fragment.");
      group.parts.set(part.part, blocks);
      groups.set(part.record, group);
    }
  }
  for (const [hash, group] of groups) {
    if (group.parts.size !== group.total) {
      findings.push({ code: "shadow_exchange_incomplete", page: group.meta.path, revision: group.meta.revision, record: hash, received: group.parts.size, expected: group.total, message: "Identity transfer is incomplete; refresh or finish sync. Preserve every existing package." });
      continue;
    }
    const blocks = [];
    for (let i = 0; i < group.total; i++) blocks.push(...group.parts.get(i));
    const record = { ...group.meta, blocks };
    requireThat(blocks.length === group.blocks_total && await services.hash(JSON.stringify(record)) === hash, "shadow_history", "Reassembled identity checksum is invalid.");
    records.push(record);
  }
  return { records: [...new Map(records.map((r) => [JSON.stringify(r), r])).values()], findings };
}

// runtime/shadow-project.mjs
init_graph();
var CHANGES = ".llmwiki/shadow/changes";
var hex3 = (value) => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
var eligible = (path5) => /\.md$/i.test(path5) && !navigationPage(path5) && !path5.split("/").some((p) => p.startsWith(".") || p.startsWith("~$")) && !/^(schema|meta|notices|vermerke)\//.test(path5);
var missing2 = (e) => e.code === "ENOENT" || e.name === "NotFoundError";
async function files(store, prefix) {
  try {
    return (await store.list(prefix, { hidden: true })).filter((e) => e.kind === "file");
  } catch (e) {
    if (missing2(e)) return [];
    throw e;
  }
}
var issue = (wiki2, error, page) => ({ wiki: wiki2, ...page ? { page } : {}, code: error.code ?? "shadow_read", message: error.message, ...error.details ? { details: error.details } : {} });
function scopes(wikis) {
  requireThat(Array.isArray(wikis) && new Set(wikis.map((w) => w.id)).size === wikis.length, "shadow_scope", "Select unique accessible wikis.");
}
async function history(wiki2, { maxBytes = 32 * 1024 * 1024 } = {}) {
  const entries = await files(wiki2.store, CHANGES);
  requireThat(entries.length <= 8192, "shadow_history_budget", "The identity history exceeds its scan budget.");
  const packages = [];
  let size = 0;
  for (const entry of entries) {
    const name = entry.path.slice(CHANGES.length + 1);
    requireThat(/^[a-f0-9]{64}\.json$/.test(name), "shadow_history", "Invalid identity package name.");
    const file = await wiki2.store.read(entry.path);
    requireThat(file, "shadow_history", "An identity package disappeared.");
    size += file.size ?? new TextEncoder().encode(file.text).length;
    requireThat(size <= maxBytes, "shadow_history_budget", "The identity history exceeds its byte budget.");
    requireThat(await wiki2.store.services.hash(file.text) === name.slice(0, -5), "shadow_history", "An identity package checksum is invalid.");
    const data = JSON.parse(file.text);
    requireThat(data.kind === "identities" && data.wiki === wiki2.id, "shadow_history", "Invalid identity package scope.");
    packages.push(data);
  }
  const result = await assembleIdentities(packages, wiki2.store.services);
  for (const record of result.records) {
    relativePath(record.path);
    requireThat(eligible(record.path) && hex3(record.id) && (record.revision === null || hex3(record.revision)) && Array.isArray(record.blocks) && record.blocks.length <= 2e4, "shadow_history", "Invalid document identity.");
    for (const block of record.blocks) requireThat(hex3(block.id) && hex3(block.text_hash) && hex3(block.occurrence) && Number.isInteger(block.start) && Number.isInteger(block.end) && block.start >= 0 && block.end > block.start, "shadow_history", "Invalid block identity.");
  }
  const current = new Set(result.records.filter((r) => r.parser === PARSER_VERSION).map((r) => JSON.stringify([r.id, r.path, r.revision])));
  result.records = result.records.filter((r) => r.parser === PARSER_VERSION || !current.has(JSON.stringify([r.id, r.path, r.revision])));
  return result;
}
function mapped(parsed, record) {
  const byOccurrence = new Map(record.blocks.map((b) => [b.occurrence, b])), byRange = new Map(record.blocks.map((b) => [JSON.stringify([b.text_hash, b.start, b.end]), b]));
  return { ...parsed, blocks: parsed.blocks.map((b) => {
    const known = record.parser === parsed.parser ? byOccurrence.get(b.occurrence) : byRange.get(JSON.stringify([b.text_hash, b.start, b.end]));
    requireThat(known && known.text_hash === b.text_hash && known.start === b.start && known.end === b.end, "shadow_history", "Stored selectors do not match the current document.");
    return { ...b, id: known.id, mapping: known.mapping, predecessors: known.predecessors ?? [], ...known.candidate_basis ? { candidate_basis: known.candidate_basis } : {} };
  }) };
}
async function currentFiles(wiki2, { maxFiles = 1e4, maxBytes = 64 * 1024 * 1024 } = {}) {
  const entries = (await wiki2.store.list("")).filter((e) => e.kind === "file" && eligible(e.path));
  requireThat(entries.length <= maxFiles, "shadow_budget", "The wiki exceeds the document scan budget.");
  const result = [], findings = [];
  let size = 0;
  for (const e of entries) try {
    const file = await wiki2.store.read(e.path);
    requireThat(file, "shadow_stale", "A listed document disappeared.");
    size += file.size ?? new TextEncoder().encode(file.text).length;
    requireThat(size <= maxBytes, "shadow_budget", "The wiki exceeds the text scan budget.");
    result.push({ ...file, path: e.path });
  } catch (error) {
    findings.push(issue(wiki2.id, error, e.path));
    if (error.code === "shadow_budget") break;
  }
  return { files: result, findings, paths: new Set(entries.map((e) => e.path)) };
}
async function resolvePassage(wikis, token, { project, instance } = {}) {
  scopes(wikis);
  const p = decodePassage(token);
  requireThat(p.project === project && p.instance === instance, "citation_scope", "This passage belongs to another project instance.");
  const wiki2 = wikis.find((w) => w.id === p.wiki && w.connection === p.connection && w.work === p.work);
  requireThat(wiki2, "citation_scope", "The cited working copy is not connected and accessible.");
  const unavailable = (reason) => ({ state: "unavailable", reason, page: p.page, wiki: p.wiki, revision: p.revision, current: null, quote: null, retained: false });
  const checked = async (file2, start2, end2, state) => {
    requireThat(start2 >= 0 && end2 <= file2.text.length && end2 > start2, "citation_stale", "The cited range no longer exists.");
    const quote = file2.text.slice(start2, end2);
    requireThat(await wiki2.store.services.hash(quote) === p.quote_hash, "citation_stale", "The passage no longer matches its quoted wording.");
    requireThat((await wiki2.store.read(file2.path))?.sha256 === file2.sha256, "citation_stale", "The document changed while opening the passage.");
    return { state, page: file2.path, wiki: p.wiki, revision: p.revision, current_revision: file2.sha256, quote, current: { start: start2, end: end2, id: p.block }, retained: false };
  };
  const original = await wiki2.store.read(p.page);
  if (original?.sha256 === p.revision) return checked(original, p.start, p.end, "current");
  if (!p.document || !p.block) return unavailable(original ? "changed" : "missing");
  const records = (await history(wiki2)).records, scan = await currentFiles(wiki2);
  requireThat(!scan.findings.length, "shadow_access", "The wiki cannot be checked completely.");
  const candidates = scan.files.filter((f) => records.some((r) => r.id === p.document && r.path === f.path && r.revision === f.sha256));
  if (candidates.length !== 1) return unavailable(candidates.length ? "ambiguous" : original ? "unindexed" : "missing");
  const file = candidates[0], exact = records.filter((r) => r.path === file.path && r.revision === file.sha256);
  requireThat(new Set(exact.map((r) => JSON.stringify([r.id, r.blocks.map((b) => b.id)]))).size === 1, "shadow_ambiguous", "Conflicting histories cannot resolve this passage.");
  const data = mapped(await parseShadow(file.text, wiki2.store.services), exact[0]), blocks = data.blocks.filter((b) => b.id === p.block);
  if (blocks.length !== 1) return unavailable("changed");
  const block = blocks[0], start = block.start + p.offset, end = start + p.end - p.start;
  if (end > block.end) return unavailable("changed");
  return checked(file, start, end, "unchanged_successor");
}

// runtime/answer.mjs
var check = (ok, message) => requireThat(ok, "answer_input", message);
var escape = (text3) => String(text3).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
function shape(value, keys) {
  check(value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).every((k) => keys.includes(k)), "Use the documented answer fields only.");
}
function text2(value, max = 32768) {
  check(typeof value === "string" && value.trim().length > 0 && value.length <= max, "Answer text is empty or exceeds its limit.");
  return escape(value);
}
function array(value, max) {
  check(Array.isArray(value) && value.length > 0 && value.length <= max, "Answer list is empty or exceeds its limit.");
  return value;
}
async function renderAnswer(root, request, { bindings = {} } = {}) {
  shape(request, ["action", "question", "title", "references", "blocks"]);
  check(request.action === "answer.export", "Use action answer.export in the presentation helper.");
  const question = text2(request.question, 4e3), title = text2(request.title ?? "Antwort mit Quellen", 200), references = array(request.references, 128), blocks = array(request.blocks, 512);
  check(new TextEncoder().encode(JSON.stringify(request)).length <= 2 * 1024 * 1024, "Answer input exceeds 2 MiB.");
  const tokens = references.map((token) => {
    check(typeof token === "string", "Copy passage.reference unchanged.");
    return decodePassage(token);
  });
  const { project } = await load(root), destination = await editorDestination(root, project);
  requireThat(destination.available, "answer_editor", "A compatible canonical project editor is required.", { reason: destination.reason, minimum_editor: destination.minimum_editor });
  const scopes2 = /* @__PURE__ */ new Map(), verified = /* @__PURE__ */ new Map(), evidence = [];
  for (let i = 0; i < tokens.length; i++) {
    const p = tokens[i], token = references[i];
    requireThat(p.project === project.id && p.instance === destination.instance, "citation_scope", "This passage belongs to another project instance.");
    const key = JSON.stringify([p.connection, p.work]);
    if (!scopes2.has(key)) {
      const c = await context(root, p.connection, { bindings, work: p.work });
      scopes2.set(key, { id: c.wiki.id, connection: c.connection.id, work: c.workFolder.id, store: c.work });
    }
    if (!verified.has(token)) {
      const resolved = await resolvePassage([scopes2.get(key)], token, { project: project.id, instance: destination.instance });
      requireThat(resolved.current && typeof resolved.quote === "string", "answer_evidence", "A cited passage is no longer verifiable. Query the current wording before exporting.", { index: i, state: resolved.state, reason: resolved.reason });
      verified.set(token, { ...resolved, number: verified.size + 1, href: destination.entry_href + "#passage=" + token });
    }
    evidence.push(verified.get(token));
  }
  const ref = (index) => {
    check(Number.isSafeInteger(index) && index >= 0 && index < evidence.length, "Reference index is outside the references array.");
    return evidence[index];
  };
  const link = (index) => {
    const e = ref(index);
    return '<a class="citation" href="' + escape(e.href) + '" target="_blank" rel="noopener" title="' + escape(e.page + " \u2014 " + e.quote.slice(0, 400)) + '" aria-label="' + escape("Beleg " + e.number + ": " + e.page) + '">[' + e.number + "]</a>";
  };
  const links = (indices) => " " + [...new Set(array(indices, 128))].map(link).join(" ");
  const claim = (value) => {
    shape(value, ["text", "refs"]);
    return text2(value.text) + links(value.refs);
  };
  const body = blocks.map((block) => {
    check(block && typeof block === "object", "Each answer block needs a type.");
    switch (block.type) {
      case "heading":
        shape(block, ["type", "text"]);
        return "<h2>" + text2(block.text, 200) + "</h2>";
      case "paragraph":
        shape(block, ["type", "text", "refs"]);
        return "<p>" + text2(block.text) + links(block.refs) + "</p>";
      case "list": {
        shape(block, ["type", "ordered", "items"]);
        check(block.ordered === void 0 || typeof block.ordered === "boolean", "ordered must be boolean.");
        const tag = block.ordered ? "ol" : "ul";
        return "<" + tag + ">" + array(block.items, 256).map((item) => "<li>" + claim(item) + "</li>").join("") + "</" + tag + ">";
      }
      case "table": {
        shape(block, ["type", "columns", "rows"]);
        const columns = array(block.columns, 12);
        return '<div class="table"><table><thead><tr>' + columns.map((c) => '<th scope="col">' + text2(c, 200) + "</th>").join("") + '<th scope="col">Beleg</th></tr></thead><tbody>' + array(block.rows, 256).map((row) => {
          shape(row, ["cells", "refs"]);
          check(Array.isArray(row.cells) && row.cells.length === columns.length, "Table rows must match the columns.");
          return "<tr>" + row.cells.map((c) => "<td>" + text2(c) + "</td>").join("") + "<td>" + links(row.refs) + "</td></tr>";
        }).join("") + "</tbody></table></div>";
      }
      case "quote":
        shape(block, ["type", "ref"]);
        return "<blockquote><p>" + escape(ref(block.ref).quote) + "</p><cite>" + escape(ref(block.ref).page) + " " + link(block.ref) + "</cite></blockquote>";
      case "note":
        shape(block, ["type", "text"]);
        return "<aside>" + text2(block.text, 4e3) + "</aside>";
      default:
        check(false, "Unknown answer block type.");
    }
  }).join("\n");
  const brand = true ? "Knowledge Studio" : "Knowledge Studio";
  const html = `<!doctype html>
<html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><title>` + title + " \xB7 " + brand + "</title><style>body{margin:0;background:#f6f7f9;color:#19232f;font:18px/1.6 system-ui,sans-serif}main{max-width:860px;margin:0 auto;padding:40px 28px 80px;background:white;min-height:100vh;box-sizing:border-box}header{border-bottom:1px solid #d7dde4;margin-bottom:32px;padding-bottom:20px}header small{color:#536473}h1{font-size:1.7em;line-height:1.2}h2{font-size:1.2em;margin-top:2em}p,li,td{white-space:pre-wrap;overflow-wrap:anywhere}li{margin:.65em 0}.citation{white-space:nowrap;color:#064fb5;text-decoration:none;font-size:.85em;font-weight:650;padding:.1em .25em;border-radius:4px;background:#eef4ff}.citation:hover,.citation:focus-visible{outline:2px solid #064fb5}blockquote{margin:1.5em 0;padding:.2em 1em;border-left:4px solid #a3bbd8;background:#f5f8fc}cite{font-size:.8em;font-style:normal}aside{padding:12px 16px;border:1px solid #d7dde4;border-radius:8px;color:#425363}.table{overflow:auto}table{border-collapse:collapse;width:100%;font-size:.9em}th,td{padding:10px;text-align:left;vertical-align:top;border-bottom:1px solid #d7dde4}@media print{body,main{background:white}main{padding:0}.citation{color:#064fb5}}</style></head><body><main><header><small>" + brand + "</small><h1>" + title + "</h1><p>" + question + "</p><small>Die nummerierten Belege \xF6ffnen die gepr\xFCfte Textstelle im Projekteditor. Beim ersten \xD6ffnen den Projektordner im Browser freigeben.</small></header>" + body + "</main></body></html>\n";
  return { html, references: verified.size };
}

// runtime/node-budget.mjs
init_errors();
function integer(value, fallback, min, max, name) {
  value ??= fallback;
  requireThat(Number.isInteger(value) && value >= min && value <= max, "runtime_budget", `${name} must be an integer from ${min} to ${max}.`);
  return value;
}
function nodeBudget(request = {}) {
  const budget = integer(request.budget_ms, 2e4, 100, 2e4, "budget_ms"), readTimeout = Math.min(integer(request.read_timeout_ms, 15e3, 25, 15e3, "read_timeout_ms"), Math.max(25, budget - 250));
  const deadline = Date.now() + budget, stores = /* @__PURE__ */ new Map();
  let failure = null, observer = null, mutated = false;
  function check2(details = {}) {
    if (failure) throw failure;
    if (Date.now() >= deadline) throw failure = new WikiError("runtime_budget", "This call reached its time budget; the operation is incomplete.", details);
  }
  async function read(operation, details) {
    check2(details);
    let timer;
    const remaining = deadline - Date.now(), callLimit = remaining <= readTimeout;
    try {
      return await Promise.race([Promise.resolve().then(operation), new Promise((_, reject) => {
        timer = setTimeout(() => {
          failure ??= new WikiError(callLimit ? "runtime_budget" : "runtime_read_timeout", callLimit ? "This call reached its time budget; the operation is incomplete." : "A filesystem read did not finish in time. This operation is incomplete.", details);
          reject(failure);
        }, Math.max(1, Math.min(readTimeout, remaining)));
      })]);
    } finally {
      clearTimeout(timer);
    }
  }
  function wrap(store) {
    const key = store.root + "|" + store.writable;
    if (stores.has(key)) return stores.get(key);
    const proxy = new Proxy(store, { get(target, key2) {
      if (["read", "list", "fingerprint"].includes(key2)) return async (...args) => {
        const details = { operation: key2, path: args[0] ?? "", store: target.root };
        const result = await read(async () => {
          let before = observer && key2 === "read" ? await target.fingerprint(args[0]) : void 0;
          check2(details);
          let value2;
          try {
            value2 = await target[key2](...args);
          } catch (error) {
            if (observer && key2 === "list" && error.code === "ENOENT") await observer({ kind: "list", store: target, path: args[0] ?? "", options: args[1] ?? {}, value: null });
            throw error;
          }
          if (observer && key2 === "read") {
            check2(details);
            let after = await target.fingerprint(args[0]);
            if (JSON.stringify(before) !== JSON.stringify(after)) {
              check2(details);
              before = after;
              value2 = await target.read(...args);
              check2(details);
              after = await target.fingerprint(args[0]);
            }
            requireThat(JSON.stringify(before) === JSON.stringify(after), "sync_changed", "A file changed while being read.", details);
            await observer({ kind: "file", store: target, path: args[0], value: after });
          } else if (observer && key2 === "list") await observer({ kind: "list", store: target, path: args[0] ?? "", options: args[1] ?? {}, value: value2 });
          return value2;
        }, details);
        check2(details);
        return result;
      };
      if (key2 === "substore") return async (...args) => wrap(await read(() => target.substore(...args), { operation: key2, path: args[0], store: target.root }));
      if (["write", "archive", "mkdir"].includes(key2)) return async (...args) => {
        check2({ operation: key2, path: args[0], store: target.root });
        mutated = true;
        const value2 = await target[key2](...args);
        if (observer) await observer({ kind: key2, store: target, args, value: value2 });
        return value2;
      };
      const value = Reflect.get(target, key2);
      return typeof value === "function" ? value.bind(target) : value;
    } });
    stores.set(key, proxy);
    return proxy;
  }
  return { wrap, read, check: check2, get failure() {
    return failure;
  }, get mutated() {
    return mutated;
  }, get remaining() {
    return Math.max(0, deadline - Date.now());
  }, budget, readTimeout, observe(fn) {
    observer = fn;
  } };
}

// runtime/node-process.mjs
import { spawn } from "node:child_process";
var MESSAGE = "llmwiki-runtime-result/1";
var runtimeWorker = () => process.env.LLMWIKI_RUNTIME_WORKER === "1" && typeof process.send === "function";
function sendRuntimeResult(value, code) {
  process.send({ type: MESSAGE, value, code });
}
function superviseRuntime(args, request = null) {
  return new Promise((resolve) => {
    let settled = false, stderr = "", timer, child;
    const finish = (value, code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (child && !child.killed) child.kill("SIGKILL");
      resolve({ value, code });
    };
    const details = { action: request?.action ?? "request", complete: false, partial_changes_possible: !args["--read-only"] && !["inspect", "query", "read", "context", "graph", "source.monitor"].includes(request?.action ?? "request"), next: "Do not repeat with shell suffixes or temporary redirects. Read current state before retrying an interrupted mutation." };
    const fail = (code, message, extra = {}) => finish({ ok: false, error: { code, message, details: { ...details, ...extra } } }, 1);
    try {
      child = spawn(process.execPath, [...process.execArgv, process.argv[1], "--root", args["--root"], ...args["--bindings"] ? ["--bindings", args["--bindings"]] : [], ...args["--read-only"] ? ["--read-only"] : [], "--input", request ? "-" : args["--input"]], {
        env: { ...process.env, LLMWIKI_RUNTIME_WORKER: "1" },
        stdio: ["pipe", "ignore", "pipe", "ipc"]
      });
      timer = setTimeout(() => fail(request?.action === "source.monitor" ? "monitor_timeout" : "runtime_timeout", "The worker could not return a verified result within 35 seconds. The operation remains incomplete."), 35e3);
      child.stderr.on("data", (data) => {
        stderr = (stderr + data.toString()).slice(-4e3);
      });
      child.on("message", (message) => {
        if (message?.type === MESSAGE && typeof message.value?.ok === "boolean" && [0, 1].includes(message.code)) finish(message.value, message.code);
      });
      child.on("error", (error) => fail("runtime_worker", error.message));
      child.on("exit", (code, signal) => {
        if (!settled) fail("runtime_worker", "The runtime worker ended before returning a result.", { exit_code: code, signal, stderr });
      });
      child.stdin.on("error", (error) => {
        if (!settled) fail("runtime_worker", error.message);
      });
      child.stdin.end(request ? JSON.stringify(request) : void 0);
    } catch (error) {
      fail("runtime_worker", error.message);
    }
  });
}

// runtime/answer-cli.mjs
init_errors();
var scope = null;
function respond(value, code = 0) {
  if (runtimeWorker()) sendRuntimeResult(value, code);
  else process.stdout.write(JSON.stringify(value) + "\n", () => process.exit(code));
}
try {
  const args = parseArguments(process.argv.slice(2));
  if (args["--help"]) process.stdout.write(JSON.stringify({ usage: "node answer.mjs --root ABSOLUTE_PROJECT --input JSON_OR_STDIN", action: "answer.export", input: { action: "answer.export", question: "Original question", references: ["passage.reference"], blocks: [{ type: "paragraph", text: "Supported claim.", refs: [0] }, { type: "quote", ref: 0 }] }, blocks: [{ type: "heading", text: "Short heading" }, { type: "paragraph", text: "Supported claim.", refs: [0] }, { type: "list", ordered: false, items: [{ text: "Supported item.", refs: [0] }] }, { type: "table", columns: ["Aspect", "Finding"], rows: [{ cells: ["Aspect", "Finding"], refs: [0] }] }, { type: "quote", ref: 0 }, { type: "note", text: "A limitation, never an uncited factual claim." }], limits: { input_bytes: 2097152, references: 128, blocks: 512, text_chars: 32768, title_heading_column_chars: 200, question_note_chars: 4e3, items_rows: 256, columns: 12 }, references: "Zero-based indexes into the unchanged passage.reference tokens; every paragraph/item/row needs refs. Plain text fields; quotes come from the verified source. Optional title.", output: "One new .llmwiki/answers/<uuid>.html; no knowledge, cache, history or pin writes.", opening: "Call the returned open.tool with open.arguments using the host tool. The absolute file path has no fragment." }) + "\n");
  else if (!runtimeWorker()) {
    const outcome = await superviseRuntime(args);
    respond(outcome.value, outcome.code);
  } else {
    requireThat(!args["--read-only"], "read-only", "The presentation helper creates an answer file; use wiki.mjs for strictly read-only retrieval.");
    const request = await readRequest(args["--input"]);
    scope = nodeBudget();
    const root = scope.wrap(new NodeStore(args["--root"], { writable: false })), rawBindings = await scope.read(() => loadBindings(root, { file: args["--bindings"], readOnly: true }), { operation: "bindings" }), bindings = Object.fromEntries(Object.entries(rawBindings).map(([id, store]) => [id, scope.wrap(store)]));
    const answer = await renderAnswer(root, request, { bindings }), relative = ".llmwiki/answers/" + root.services.uuid() + ".html";
    scope.check();
    const output = scope.wrap(new NodeStore(root.root));
    await output.write(relative, answer.html, { expected: null, mode: 384 });
    const output_path = await root.location(relative);
    respond({ ok: true, result: { output_path, bytes: new TextEncoder().encode(answer.html).length, references: answer.references, open: { tool: "open_on_host", arguments: { path: output_path } } } });
  }
} catch (error) {
  error = scope?.failure ?? error;
  respond({ ok: false, error: { code: error.code ?? "request", message: error.message, details: { ...error.details, ...scope?.failure ? { complete: false, partial_changes_possible: scope.mutated } : {} } } }, 1);
}
