#!/usr/bin/env node
import {createRequire as createHostRequire} from "node:module"; const require = createHostRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x2) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x2, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x2)(function(x2) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x2 + '" is not supported');
});
var __esm = (fn, res, err2) => function __init() {
  if (err2) throw err2[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err2 = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require2() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// runtime/compat/reviews.mjs
function createReviews(environment2) {
  (function(global) {
    "use strict";
    const FORMAT4 = "llmwiki-review/1", ROOT3 = ".llmwiki/reviews", MAX_TEXT = 2e6;
    const idPattern = /^[a-z0-9-]{20,80}$/i;
    const kinds = ["change", "proposal", "reject", "accept", "comment", "external", "resolve", "reopen", "acknowledge", "partial"];
    const F = () => global.FolderAccess;
    const msg = (key, values) => global.I18n.message(key, values);
    function fail(key) {
      throw global.I18n.error(msg(key));
    }
    function author(value) {
      return typeof value === "string" && value.trim() !== "" && value.length <= 120 && !/[\r\n\x00-\x1f]/.test(value);
    }
    function valid(e) {
      return Boolean((!e?.anchor || Number.isInteger(e.anchor.beforeLine) && Number.isInteger(e.anchor.afterLine) && Array.isArray(e.anchor.before) && Array.isArray(e.anchor.after) && e.anchor.before.every((v) => typeof v === "string") && e.anchor.after.every((v) => typeof v === "string")) && e && e.format === FORMAT4 && idPattern.test(e.id) && kinds.includes(e.kind) && (author(e.author) || e.kind === "external" && e.author === "") && typeof e.page === "string" && e.page && !e.page.split("/").some((p) => !p || p === ".." || p === "." || p.startsWith(".")) && !/[\\:\x00-\x1f]/.test(e.page) && (e.parent === null || typeof e.parent === "string" && idPattern.test(e.parent)) && idPattern.test(e.thread) && typeof e.base === "string" && e.base.length <= MAX_TEXT && typeof e.text === "string" && e.text.length <= MAX_TEXT && typeof e.message === "string" && e.message.length <= 1e4 && Array.isArray(e.recipients) && e.recipients.length <= 200 && e.recipients.every(author) && typeof e.at === "string" && /Z$/.test(e.at) && Number.isFinite(Date.parse(e.at)));
    }
    function event(values) {
      const id = global.crypto.randomUUID();
      const e = {
        format: FORMAT4,
        id,
        kind: values.kind,
        page: values.page,
        author: values.author,
        at: (/* @__PURE__ */ new Date()).toISOString(),
        parent: values.parent || null,
        thread: values.thread || id,
        base: values.base,
        text: values.text,
        message: values.message || "",
        recipients: values.recipients || []
      };
      if (!valid(e)) fail("The change record is incomplete or invalid.");
      return e;
    }
    function reply(parent, kind, by, base, text2, message) {
      if (!valid(parent)) fail("The change record is incomplete or invalid.");
      return event({ page: parent.page, kind, author: by, base, text: text2, message, parent: parent.id, thread: kind === "comment" && ["change", "external", "accept"].includes(parent.kind) ? null : parent.thread, recipients: !parent.author || parent.author === by ? parent.recipients : [parent.author] });
    }
    async function hash(text2) {
      const bytes3 = await global.crypto.subtle.digest("SHA-256", new TextEncoder().encode(text2));
      return Array.from(new Uint8Array(bytes3), (v) => v.toString(16).padStart(2, "0")).join("");
    }
    async function pageFolder(page) {
      return ROOT3 + "/" + await hash(page);
    }
    async function eventPath(e) {
      return await pageFolder(e.page) + "/" + e.id + ".json";
    }
    async function append(dir, e) {
      if (!valid(e)) fail("The change record is incomplete or invalid.");
      const done = await F().writeFile(dir, await eventPath(e), JSON.stringify(e, null, 2) + "\n", null);
      if (!done.saved) fail("The response could not be recorded. Nothing was sent.");
      return e;
    }
    async function receipt(dir, e) {
      const path7 = await eventPath(e) + ".applied", text2 = JSON.stringify({ id: e.id, digest: await hash(JSON.stringify(e)) });
      try {
        const existing = await F().readFile(dir, path7);
        return existing.text === text2;
      } catch (error) {
        if (error.name !== "NotFoundError") throw error;
      }
      const result = await F().writeFile(dir, path7, text2, null);
      return Boolean(result.saved);
    }
    async function save2(dir, page, expected, text2, by, parent = null) {
      let current2 = null;
      try {
        current2 = await F().readFile(dir, page);
      } catch (error) {
        if (error.name !== "NotFoundError") throw error;
      }
      if ((current2 ? current2.text : null) !== (expected ? expected.text : null)) return { saved: false, stale: true };
      if (!parent && current2 && current2.text === text2) return { saved: true, recorded: true, text: text2, mark: current2.mark, event: null, unchanged: true };
      const e = parent ? reply(parent, "accept", by, current2 ? current2.text : "", text2, "") : event({ page, kind: "change", author: by, base: current2 ? current2.text : "", text: text2 });
      e.page = page;
      await append(dir, e);
      const done = await F().writeFile(dir, page, text2, current2);
      if (!done.saved) return { ...done, event: e, recorded: false };
      let recorded = false;
      try {
        recorded = await receipt(dir, e);
      } catch (_) {
      }
      return { ...done, event: e, recorded };
    }
    async function accept(dir, e, current2, by) {
      if (!valid(e)) fail("The change record is incomplete or invalid.");
      if (current2.text !== e.text && (["change", "external"].includes(e.kind) || current2.text !== e.base)) {
        const journal = await read(dir, e.page), parts = journal.events.filter((p) => p.kind === "partial" && p.parent === e.id && p.text === current2.text);
        const proven = parts.some((p) => journal.events.some((a) => a.kind === "accept" && a.parent === p.id && a.text === current2.text));
        if (!["proposal", "reject"].includes(e.kind) || !proven) return { saved: false, stale: true };
      }
      return save2(dir, currentPage(await aliases(dir), e.page), current2, e.text, by, e);
    }
    async function directory(dir, path7) {
      for (const part of path7.split("/")) dir = await dir.getDirectoryHandle(part);
      return dir;
    }
    async function readOwn(dir, page = null) {
      let root;
      try {
        root = await directory(dir, page ? await pageFolder(page) : ROOT3);
      } catch (error) {
        if (error.name === "NotFoundError") return { events: [], incomplete: 0, unreadable: 0, pending: [] };
        throw error;
      }
      const found = [], receipts = /* @__PURE__ */ new Map();
      let incomplete = 0, unreadable = 0;
      async function scan(h, depth) {
        for await (const entry of h.values()) {
          if (entry.kind === "directory") {
            if (depth === 0 && page === null && /^[a-f0-9]{64}$/.test(entry.name)) await scan(entry, 1);
            continue;
          }
          if (!/^[a-z0-9-]{20,80}\.json(?:\.applied)?$/i.test(entry.name)) continue;
          try {
            const f = await entry.getFile();
            if (f.size > MAX_TEXT * 12 + 5e4) {
              unreadable++;
              continue;
            }
            const data = JSON.parse(await f.text());
            if (entry.name.endsWith(".applied")) {
              if (data.id + ".json.applied" === entry.name) receipts.set(data.id, data.digest);
              else unreadable++;
            } else if (valid(data) && data.id + ".json" === entry.name && (!page || data.page === page)) found.push(data);
            else unreadable++;
          } catch (_) {
            unreadable++;
          }
        }
      }
      await scan(root, 0);
      const events = [], pending = [];
      for (const e of found) {
        if (["change", "accept"].includes(e.kind) && receipts.get(e.id) !== await hash(JSON.stringify(e))) {
          incomplete++;
          pending.push(e);
          continue;
        }
        events.push(e);
      }
      events.sort((a, b) => a.at.localeCompare(b.at) || a.id.localeCompare(b.id));
      return { events, incomplete, unreadable, pending };
    }
    const aliasCache = /* @__PURE__ */ new WeakMap();
    async function aliases(dir) {
      const cached = aliasCache.get(dir);
      if (cached && Date.now() - cached.at < 500) return cached.map;
      const map = /* @__PURE__ */ new Map();
      let root;
      try {
        root = await directory(dir, ".llmwiki/path-aliases");
      } catch (e) {
        if (e.name === "NotFoundError") return map;
        throw e;
      }
      for await (const entry of root.values()) if (entry.kind === "file" && entry.name.endsWith(".json")) {
        const data = JSON.parse(await (await entry.getFile()).text());
        if (data.kind !== "consolidated" && typeof data.from === "string" && typeof data.to === "string") map.set(data.from, data.to);
      }
      aliasCache.set(dir, { at: Date.now(), map });
      return map;
    }
    function currentPage(map, page) {
      const visited = /* @__PURE__ */ new Set();
      while (map.has(page)) {
        if (visited.has(page)) fail("The synchronization record cannot be read.");
        visited.add(page);
        page = map.get(page);
      }
      return page;
    }
    async function read(dir, page = null) {
      const result = await readOwn(dir, page);
      if (!page) return result;
      const map = await aliases(dir);
      for (const old of map.keys()) if (old !== page && currentPage(map, old) === page) {
        const prior = await readOwn(dir, old);
        result.events.push(...prior.events);
        result.pending.push(...prior.pending);
        result.incomplete += prior.incomplete;
        result.unreadable += prior.unreadable;
      }
      result.events.sort((a, b) => a.at.localeCompare(b.at) || a.id.localeCompare(b.id));
      return result;
    }
    function threadState(events, thread) {
      const byId = new Map(events.map((e) => [e.id, e])), states = events.filter((e) => e.thread === thread && ["resolve", "reopen"].includes(e.kind)), ancestors = /* @__PURE__ */ new Set();
      for (const state2 of states) {
        let parent = state2.parent;
        const visited = /* @__PURE__ */ new Set();
        while (parent && !visited.has(parent)) {
          visited.add(parent);
          ancestors.add(parent);
          parent = byId.get(parent)?.parent;
        }
      }
      const heads = states.filter((e) => !ancestors.has(e.id));
      return heads.length && heads.every((e) => e.kind === "resolve") ? "resolved" : "open";
    }
    function incoming(events, by, seen) {
      const known = new Set(seen || []);
      const parents = new Map(events.map((e) => [e.id, e]));
      const answered = new Set(events.filter((e) => e.author === by && !["acknowledge", "partial", "comment", "resolve", "reopen"].includes(e.kind) || e.kind === "accept" && parents.get(e.parent) && !["change", "external"].includes(parents.get(e.parent).kind)).map((e) => e.parent));
      return events.filter((e) => e.author !== by && !["accept", "external", "resolve", "acknowledge", "partial"].includes(e.kind) && threadState(events, e.thread) !== "resolved" && !known.has(e.id) && !answered.has(e.id) && (e.kind === "change" || !e.recipients.length || e.recipients.includes(by)));
    }
    async function tasks(events, by, checkpoint2, current2, page) {
      const replies = incoming(events, by, checkpoint2?.seen || []).filter((e) => !["change", "external"].includes(e.kind));
      if (!checkpoint2 || checkpoint2.text === current2) return replies;
      let change = events.slice().reverse().find((e) => ["change", "accept"].includes(e.kind) && e.text === current2 && e.base !== e.text);
      if (!change) {
        change = event({ kind: "external", page, author: "", base: checkpoint2.text, text: current2 });
        change.id = "external-" + await hash(JSON.stringify([page, checkpoint2.text, current2]));
        change.thread = change.id;
      }
      return (checkpoint2.seen || []).includes(change.id) ? replies : [change, ...replies];
    }
    function localKey(project, folder, path7, by) {
      return "review/" + [project, folder, String(path7), by || "unnamed"].map(encodeURIComponent).join("/");
    }
    async function checkpoint(key, page, value) {
      if (value) {
        const done = await F().keepDraft(key, page, JSON.stringify(value), "llmwiki-checkpoint/1");
        if (!done) fail("The personal comparison baseline could not be saved.");
        return value;
      }
      const saved = await F().recallDraft(key, page);
      if (!saved) return null;
      try {
        const data = JSON.parse(saved.text);
        return typeof data.text === "string" && Array.isArray(data.seen) ? data : null;
      } catch (_) {
        return null;
      }
    }
    function selectChanges(before, after, selection, revert = false) {
      const hunks = diff(before, after);
      if (!Array.isArray(selection) || !selection.length || new Set(selection).size !== selection.length || selection.some((i2) => !Number.isInteger(i2) || i2 < 0 || i2 >= hunks.length)) fail("Select a valid change.");
      const lines = (revert ? after : before).match(/[^\n]*\n|[^\n]+$/g) || [], next = (revert ? before : after).match(/[^\n]*\n|[^\n]+$/g) || [];
      for (const i2 of [...selection].sort((a, b) => b - a)) {
        const h = hunks[i2], from = revert ? h.afterLine : h.beforeLine, count = revert ? h.after.length : h.before.length, to = revert ? h.beforeLine : h.afterLine, size = revert ? h.before.length : h.after.length;
        lines.splice(from - 1, count, ...next.slice(to - 1, to - 1 + size));
      }
      return lines.join("");
    }
    function diff(before, after) {
      if (before === after) return [];
      const a = before.split(/\r?\n/), b = after.split(/\r?\n/), hunks = [];
      let ai = 0, bi = 0;
      const matches = a.length * b.length <= 4e6 ? global.matchingBlocks(a, b) : [[a.length, b.length, 0]];
      for (const [x2, y, size] of matches) {
        if (x2 > ai || y > bi) hunks.push({ before: a.slice(ai, x2), after: b.slice(bi, y), beforeLine: ai + 1, afterLine: bi + 1 });
        ai = x2 + size;
        bi = y + size;
      }
      return hunks;
    }
    function attribution(before, after, events) {
      const chain = [], used = /* @__PURE__ */ new Set();
      let cursor = after;
      while (cursor !== before) {
        const matches = events.filter((e2) => ["change", "accept"].includes(e2.kind) && e2.base !== e2.text && e2.text === cursor && !used.has(e2.id));
        if (!matches.length) break;
        const e = matches[matches.length - 1];
        used.add(e.id);
        chain.unshift(e);
        cursor = e.base;
      }
      const original = before.split(/\r?\n/), start2 = cursor.split(/\r?\n/), deleted = /* @__PURE__ */ new Map();
      let lines = start2.map(() => ({ author: null, index: null }));
      if (original.length * start2.length <= 4e6) for (const [a, b, size] of global.matchingBlocks(original, start2)) for (let i2 = 0; i2 < size; i2++) lines[b + i2].index = a + i2;
      for (const e of chain) {
        const a = e.base.split(/\r?\n/), b = e.text.split(/\r?\n/), next = b.map(() => ({ author: e, index: null }));
        let old = 0;
        const matches = a.length * b.length <= 4e6 ? global.matchingBlocks(a, b) : [[a.length, b.length, 0]];
        for (const [x2, y, size] of matches) {
          for (let i2 = old; i2 < x2; i2++) if (lines[i2] && lines[i2].index !== null) deleted.set(lines[i2].index, e);
          for (let i2 = 0; i2 < size; i2++) next[y + i2] = lines[x2 + i2];
          old = x2 + size;
        }
        lines = next;
      }
      return diff(before, after).map((h) => {
        const authors = /* @__PURE__ */ new Map();
        let unknown = false;
        for (let i2 = h.afterLine - 1; i2 < h.afterLine - 1 + h.after.length; i2++) {
          const e = lines[i2] && lines[i2].author;
          if (e) authors.set(e.id, e);
          else unknown = true;
        }
        for (let i2 = h.beforeLine - 1; i2 < h.beforeLine - 1 + h.before.length; i2++) {
          const e = deleted.get(i2);
          if (e) authors.set(e.id, e);
          else if (!h.after.length) unknown = true;
        }
        return { authors: Array.from(authors.values()), unknown };
      });
    }
    function parseNotice(text2) {
      if (global.headField(text2, "format") !== "llmwiki-notice/1") return null;
      const sections = {}, body = text2.slice(global.parseHead(text2).offset);
      let heading = null, quote3 = null, width = 0, lines = [];
      for (const line of body.split(/\r?\n/)) {
        const marker = /^ {0,3}(`{3,}|~{3,})/.exec(line);
        if (quote3) {
          if (marker && marker[1][0] === quote3 && marker[1].length >= width) {
            sections[heading] = lines.join("\n");
            quote3 = null;
          } else lines.push(line);
          continue;
        }
        const h = /^##\s+(warum|vorher|nachher)\s*$/.exec(line);
        if (h) heading = h[1];
        if (marker && heading) {
          quote3 = marker[1][0];
          width = marker[1].length;
          lines = [];
        }
      }
      return { author: global.headField(text2, "von") || "", at: global.headField(text2, "wann") || "", base: sections.vorher || "", text: sections.nachher || "", message: sections.warum || "" };
    }
    async function notices(dir, text2) {
      const id = global.headField(text2, "id");
      if (typeof id !== "string" || !/^[a-zA-Z0-9_-]+$/.test(id)) return [];
      const found = [];
      for (const top of ["notices", "vermerke"]) {
        let root;
        try {
          root = await directory(dir, top + "/" + id);
        } catch (error) {
          if (error.name === "NotFoundError") continue;
          throw error;
        }
        for await (const entry of root.values()) if (entry.kind === "file" && entry.name.endsWith(".md")) {
          const file = await entry.getFile();
          if (file.size > MAX_TEXT) continue;
          const n = parseNotice(await file.text());
          if (n) found.push(n);
        }
      }
      return found;
    }
    global.WikiReviews = { selectChanges, revertChanges: (before, after, selection) => selectChanges(before, after, selection, true), threadState, aliases, currentPage, event, valid, reply, save: save2, accept, append, read, incoming, tasks, localKey, checkpoint, diff, attribution, hash, eventPath, receipt, parseNotice, notices };
  })(environment2);
  return environment2.WikiReviews;
}
var init_reviews = __esm({
  "runtime/compat/reviews.mjs"() {
  }
});

// runtime/compat/editorsync.mjs
function createSync(environment2) {
  (function(global) {
    "use strict";
    const F = () => global.FolderAccess, R = () => global.WikiReviews;
    const MAX = 2e6;
    const step = (o, key, fn, result) => o.step ? o.step(JSON.stringify(key), fn, result) : fn();
    const side = (o, dir) => dir === o.work ? "work" : "remote";
    function error(key) {
      return global.I18n.error(global.I18n.message(key));
    }
    function contentClearance(value, page = "") {
      const findings = [], seen = /* @__PURE__ */ new Set(), add3 = (code, field = "") => {
        const key = code + "|" + field;
        if (!seen.has(key)) {
          seen.add(key);
          findings.push({ code, page, ...field ? { field } : {} });
        }
      };
      const secretKey = /^(?:api[_-]?key|access[_-]?token|refresh[_-]?token|token|password|passwort|secret|geheimnis|credential|auth)$/i;
      const deviceKey = /^(?:device[_-]?id|machine[_-]?id|hostname|local[_-]?folder|runner|rechner)$/i;
      const name = (v) => typeof v === "string" && /^[A-Za-z0-9_.-]{1,40}$/.test(v);
      const secret = /-----BEGIN [A-Z ]*PRIVATE KEY-----|\bxox[baprs]-[0-9A-Za-z-]{10,}|\bAKIA[0-9A-Z]{16}\b|\bgh[pousr]_[0-9A-Za-z]{20,}|\bsk-[0-9A-Za-z]{20,}|\bBearer\s+[0-9A-Za-z._~+/-]{20,}/;
      function inspect2(v, field = "", depth = 0) {
        if (depth > 32) {
          add3("clearance_unreadable", field);
          return;
        }
        if (v && typeof v === "object") {
          for (const [key, part] of Object.entries(v)) {
            if (secretKey.test(key) && part !== null && part !== "" && !name(part)) add3("clearance_secret", key);
            if (deviceKey.test(key) && part !== null && part !== "") add3("clearance_device", key);
            inspect2(part, key, depth + 1);
          }
          return;
        }
        if (typeof v !== "string") return;
        if (secret.test(v)) add3("clearance_secret", field);
        const paths = v.replace(/\bhttps?:\/\/[^\s<>"']+/gi, "").replace(/(?<![\p{L}\p{N}_/.~-])[\p{L}\p{N}][\p{L}\p{N}_-]*-\/(?:[\p{L}\p{N}][\p{L}\p{N}_-]*-\/)+[\p{L}\p{N}][\p{L}\p{N}_-]*/gu, "");
        if (/(?:^|[^\w./])\/(?:[\w.-]+\/)+[\w.-]+|(?:^|[^\w])[A-Za-z]:[\\/][\w.\\/-]+|(?:^|[^\w])~\/[\w.-]+/.test(paths)) add3("clearance_device_path", field);
        if (/^\s*[\[{]/.test(v)) try {
          inspect2(JSON.parse(v), field, depth + 1);
          return;
        } catch {
        }
        if (/^---\r?\n/.test(v)) try {
          const parsed = global.WikiCore?.parseDocument(v) ?? global.parseHead?.(v);
          if (parsed?.head) inspect2(parsed.head, field, depth + 1);
        } catch {
          add3("clearance_unreadable", field);
        }
        for (const line of v.split(/\r?\n/)) {
          const pair = /^\s*(?:-\s*)?([A-Za-z_][A-Za-z0-9_.-]*)\s*:\s*(.+?)\s*$/.exec(line);
          if (!pair) continue;
          const part = pair[2].replace(/^['"]|['"]$/g, "");
          if (secretKey.test(pair[1]) && !["null", "~", "[]", "{}"].includes(part) && !name(part)) add3("clearance_secret", pair[1]);
          if (deviceKey.test(pair[1]) && !["null", "~", ""].includes(part)) add3("clearance_device", pair[1]);
        }
      }
      inspect2(value);
      return findings;
    }
    function transferVisible(page, kind) {
      const roots = [".llmwiki/reviews", ".llmwiki/evidence", ".llmwiki/shadow/changes", ".llmwiki/shadow/pins", ".llmwiki/path-aliases", ".llmwiki/transfers", ".llmwiki/retirements"];
      return visible(page, kind) || kind === "directory" && roots.some((r) => r === page || r.startsWith(page + "/") || page.startsWith(r + "/")) || kind === "file" && page.endsWith(".json") && (page === ".llmwiki/identity-aliases.json" || roots.some((r) => page.startsWith(r + "/")));
    }
    async function checkClearance(dir, o = null) {
      const findings = [];
      async function walk(folder, prefix = "") {
        for await (const entry of folder.values()) {
          const page = prefix ? prefix + "/" + entry.name : entry.name;
          if (!transferVisible(page, entry.kind)) continue;
          if (entry.kind === "directory") await walk(entry, page);
          else if (entry.kind === "file") {
            const inspect2 = async () => {
              const file = await peek(dir, page);
              return file ? contentClearance(file.text, page) : [];
            };
            findings.push(...o ? await step(o, ["clearance", side(o, dir), page], inspect2) : await inspect2());
          }
        }
      }
      await walk(dir);
      return findings;
    }
    function requireClearance(findings) {
      if (!findings.length) return;
      const e = error("Sharing paused. Private values were found in a document or its history. Keep the original private and prepare a cleaned copy before sharing.");
      e.code = "clearance";
      e.details = { findings };
      throw e;
    }
    function visible(path7, kind) {
      return !path7.split("/").some((p) => p.startsWith(".") || ["notices", "vermerke"].includes(p)) && (kind === "directory" || path7 === "schema/FIELDS.json" || /\.md$/i.test(path7));
    }
    async function peek(dir, path7) {
      try {
        return await F().readFile(dir, path7);
      } catch (e) {
        if (e.name === "NotFoundError") return null;
        throw e;
      }
    }
    function text2(seen) {
      return seen ? seen.text : null;
    }
    async function guarded2(o, dir, path7, value, seen) {
      if (!o.alive()) throw error("The folder was disconnected.");
      requireClearance(contentClearance(value, path7));
      const done = await F().writeFile(dir, path7, value, seen);
      if (!done.saved) throw error("The file changed during synchronization. It will be checked again.");
      return done;
    }
    async function statePath(o, page) {
      return ".llmwiki/editor-sync/" + await R().hash(o.identity) + "/" + await R().hash(page) + ".json";
    }
    async function baseline(o, page) {
      const path7 = await statePath(o, page), seen = await peek(o.work, path7);
      let data = null;
      if (seen) {
        data = JSON.parse(seen.text);
        if (data.format !== "llmwiki-editor-sync/1" || data.page !== page || data.identity !== o.identity || !(data.text === null || typeof data.text === "string" && data.text.length <= MAX)) throw error("The synchronization record cannot be read.");
      }
      return { path: path7, seen, data };
    }
    async function record(o, b, page, value, resolved = false) {
      return guarded2(o, o.work, b.path, JSON.stringify({ format: "llmwiki-editor-sync/1", identity: o.identity, page, text: value, resolved }), b.seen);
    }
    async function journal(o, from, to, page) {
      const source2 = await R().read(from, page), target = await R().read(to, page);
      const found = new Map([...target.events, ...target.pending].map((e) => [e.id, e]));
      for (const e of source2.events) {
        if (!o.alive()) throw error("The folder was disconnected.");
        requireClearance(contentClearance(e, page));
        const known = found.get(e.id);
        if (known && JSON.stringify(known) !== JSON.stringify(e)) throw error("The synchronization record cannot be read.");
        if (!known) await R().append(to, e);
        if (["change", "accept"].includes(e.kind) && !await R().receipt(to, e)) throw error("The synchronization record cannot be read.");
      }
      return source2;
    }
    async function transferable(dir, page, base, value) {
      const events = (await R().read(dir, page)).events, queue2 = [value], visited = /* @__PURE__ */ new Set();
      while (queue2.length) {
        const cursor = queue2.pop();
        if (cursor === (base ?? "")) return true;
        if (visited.has(cursor)) continue;
        visited.add(cursor);
        for (const e of events) if (["change", "accept"].includes(e.kind) && e.text === cursor && e.text !== e.base) queue2.push(e.base);
      }
      return false;
    }
    async function evidence(o, from, to) {
      let root;
      try {
        root = await from.getDirectoryHandle(".llmwiki");
        root = await root.getDirectoryHandle("evidence");
      } catch (e) {
        if (e.name === "NotFoundError") return;
        throw e;
      }
      async function walk(dir, path7) {
        for await (const entry of dir.values()) {
          const name = path7 + "/" + entry.name;
          if (entry.kind === "directory") {
            await walk(entry, name);
            continue;
          }
          if (!entry.name.endsWith(".json")) continue;
          await step(o, ["evidence", side(o, from), name], async () => {
            const source2 = await peek(from, name), target = await peek(to, name);
            if (target) {
              if (target.text !== source2.text) throw error("The synchronization record cannot be read.");
              return;
            }
            await guarded2(o, to, name, source2.text, null);
          });
        }
      }
      await walk(root, ".llmwiki/evidence");
    }
    async function shadowEvidence(o, from, to) {
      for (const kind of ["changes", "pins"]) {
        let root;
        try {
          root = await from.getDirectoryHandle(".llmwiki");
          root = await root.getDirectoryHandle("shadow");
          root = await root.getDirectoryHandle(kind);
        } catch (e) {
          if (e.name === "NotFoundError") continue;
          throw e;
        }
        for await (const entry of root.values()) {
          await step(o, ["shadow", side(o, from), kind, entry.name], async () => {
            if (entry.kind !== "file" || !/^[a-f0-9]{64}\.json$/.test(entry.name)) throw error("The synchronization record cannot be read.");
            const name = ".llmwiki/shadow/" + kind + "/" + entry.name, source2 = await peek(from, name);
            if (!source2 || source2.text.length > MAX || await R().hash(source2.text) !== entry.name.slice(0, -5)) throw error("The synchronization record cannot be read.");
            const data = JSON.parse(source2.text);
            if (!(data.format === "llmwiki-shadow/1" || kind === "changes" && data.format === "llmwiki-shadow-identities/2") || data.kind !== (kind === "pins" ? "quote" : "identities")) throw error("The synchronization record cannot be read.");
            const target = await peek(to, name);
            if (target) {
              if (target.text !== source2.text) throw error("The synchronization record cannot be read.");
              return;
            }
            await guarded2(o, to, name, source2.text, null);
          });
        }
      }
    }
    async function sharedRecords(o, from, to, kind) {
      let root;
      try {
        root = await from.getDirectoryHandle(".llmwiki");
        root = await root.getDirectoryHandle(kind);
      } catch (e) {
        if (e.name === "NotFoundError") return;
        throw e;
      }
      for await (const entry of root.values()) {
        await step(o, ["records", side(o, from), kind, entry.name], async () => {
          if (entry.kind !== "file" || !/^[a-f0-9]{64}\.json$/.test(entry.name)) throw error("The synchronization record cannot be read.");
          const page = ".llmwiki/" + kind + "/" + entry.name, source2 = await peek(from, page);
          if (!source2 || await R().hash(source2.text) !== entry.name.slice(0, -5)) throw error("The synchronization record cannot be read.");
          const data = JSON.parse(source2.text);
          if (data.format !== (kind === "transfers" ? "llmwiki-transfer/1" : "llmwiki-retirement/1")) throw error("The synchronization record cannot be read.");
          const target = await peek(to, page);
          if (target && target.text !== source2.text) throw error("The synchronization record cannot be read.");
          if (!target) await guarded2(o, to, page, source2.text, null);
        });
      }
    }
    async function retireGroups(o, result) {
      const records = /* @__PURE__ */ new Map(), skip = /* @__PURE__ */ new Set();
      for (const dir of [o.work, o.remote]) {
        let root;
        try {
          root = await dir.getDirectoryHandle(".llmwiki");
          root = await root.getDirectoryHandle("retirements");
        } catch (e) {
          if (e.name === "NotFoundError") continue;
          throw e;
        }
        for await (const e of root.values()) {
          if (e.kind !== "file") continue;
          const f = await peek(dir, ".llmwiki/retirements/" + e.name), r = JSON.parse(f.text);
          if (r.format !== "llmwiki-retirement/1" || typeof r.page !== "string" || r.page.split("/").some((p) => !p || p === "." || p === "..") || /[\\:\x00-\x1f]/.test(r.page) || !/^[a-f0-9]{64}$/.test(r.expected) || !/^[a-f0-9-]{36}$/.test(r.stage)) throw error("The synchronization record cannot be read.");
          records.set(e.name, r);
        }
      }
      for (const r of records.values()) {
        const local2 = await peek(o.work, r.page), remote = await peek(o.remote, r.page), files2 = [local2, remote], hashes = await Promise.all(files2.map((f) => f ? R().hash(f.text) : null));
        if (hashes.every((h) => h !== null && h !== r.expected)) continue;
        if (hashes.some((h) => h !== null && h !== r.expected)) {
          if (hashes.some((h) => h === r.expected)) {
            skip.add(r.page);
            result.conflicts.push({ page: r.page, reason: "retirement_changed", base: null, mine: text2(local2), theirs: text2(remote) });
          }
          continue;
        }
        skip.add(r.page);
        let pending = false;
        for (const [i2, dir] of [o.work, o.remote].entries()) {
          if (!files2[i2]) continue;
          const archive = ".llmwiki/retired/" + r.stage + "/" + r.page;
          if (i2 === 1 && !o.canPublish || !F().archiveFile || F().canArchive && !F().canArchive(dir)) {
            pending = true;
            result.pending++;
            result.pending_details.push({ page: r.page, reason: "host_move_required", archive, expected: r.expected });
            continue;
          }
          await F().archiveFile(dir, r.page, archive, r.expected);
        }
        if (!pending) await record(o, await baseline(o, r.page), r.page, null);
      }
      return skip;
    }
    async function moveAliases(o, result) {
      const all = /* @__PURE__ */ new Map();
      for (const dir of [o.remote, o.work]) {
        let root;
        try {
          root = await dir.getDirectoryHandle(".llmwiki");
          root = await root.getDirectoryHandle("path-aliases");
        } catch (e) {
          if (e.name === "NotFoundError") continue;
          throw e;
        }
        for await (const file of root.values()) if (file.kind === "file" && file.name.endsWith(".json")) {
          const path7 = ".llmwiki/path-aliases/" + file.name, seen = await peek(dir, path7), data = JSON.parse(seen.text);
          if (typeof data.from !== "string" || typeof data.to !== "string" || !data.expected || data.from === data.to) throw error("The synchronization record cannot be read.");
          const known = all.get(data.from);
          if (known && known.seen.text !== seen.text) throw error("The synchronization record cannot be read.");
          all.set(data.from, { data, seen, path: path7 });
        }
      }
      for (const { data, seen, path: path7 } of all.values()) for (const dir of [o.work, ...o.canPublish ? [o.remote] : []]) {
        const prior = await peek(dir, path7);
        if (!prior) await guarded2(o, dir, path7, seen.text, null);
      }
      return all;
    }
    async function identityAliases(o, aliases) {
      const path7 = ".llmwiki/identity-aliases.json", merged = /* @__PURE__ */ new Map();
      function target(p) {
        const seen = /* @__PURE__ */ new Set();
        while (aliases.has(p)) {
          if (seen.has(p)) throw error("The synchronization record cannot be read.");
          seen.add(p);
          p = aliases.get(p).data.to;
        }
        return p;
      }
      for (const dir of [o.remote, o.work]) {
        const file = await peek(dir, path7);
        if (!file) continue;
        const data = JSON.parse(file.text);
        if (data.format !== "llmwiki-identity-aliases/1" || !Array.isArray(data.aliases)) throw error("The synchronization record cannot be read.");
        for (const alias of data.aliases) {
          const value = { ...alias, path: target(alias.path) }, previous = merged.get(alias.id);
          if (previous && JSON.stringify(previous) !== JSON.stringify(value)) throw error("The synchronization record cannot be read.");
          merged.set(alias.id, value);
        }
      }
      if (!merged.size) return;
      const text3 = JSON.stringify({ format: "llmwiki-identity-aliases/1", aliases: [...merged.values()].sort((a, b) => a.id.localeCompare(b.id)) });
      for (const dir of [o.work, ...o.canPublish ? [o.remote] : []]) {
        const seen = await peek(dir, path7);
        if (seen?.text !== text3) await guarded2(o, dir, path7, text3, seen);
      }
    }
    async function retireMoves(o, result, aliases) {
      for (const { data } of aliases.values()) for (const dir of [o.work, ...o.canPublish ? [o.remote] : []]) {
        const old = await peek(dir, data.from);
        if (!old) continue;
        const next = await peek(dir, data.to);
        if (!next || await R().hash(old.text) !== data.expected) {
          result.conflicts.push({ page: data.from, base: null, mine: text2(await peek(o.work, data.from)), theirs: text2(await peek(o.remote, data.from)), move_to: data.to });
          continue;
        }
        if (!F().archiveFile || F().canArchive && !F().canArchive(dir)) {
          result.pending++;
          result.pending_details.push({ page: data.from, reason: "host_move_required", to: data.to, archive: ".llmwiki/moves/" + data.id + "/synced-originals/" + data.from, expected: data.expected });
          continue;
        }
        if (!o.alive()) return;
        await F().archiveFile(dir, data.from, ".llmwiki/moves/" + data.id + "/synced-originals/" + data.from, data.expected);
      }
    }
    const binaryChecks = /* @__PURE__ */ new WeakMap();
    async function binaryAssets(o, result) {
      const visible2 = (path7, kind) => !path7.split("/").some((p) => p.startsWith(".")) && (kind === "directory" || /\.(png|jpe?g|gif|webp|avif|svg|pdf|excalidraw)$/i.test(path7));
      const lists = await Promise.all([F().listFolder(o.work, void 0, { visible: visible2 }), F().listFolder(o.remote, void 0, { visible: visible2 })]);
      let cache = binaryChecks.get(o.work);
      if (!cache) {
        cache = /* @__PURE__ */ new Map();
        binaryChecks.set(o.work, cache);
      }
      const inventory2 = lists.map((items) => new Map(items.map((f) => [f.name, f])));
      const peek2 = async (dir, page) => {
        try {
          return await F().readBinary(dir, page);
        } catch (e) {
          if (e.name === "NotFoundError") return null;
          throw e;
        }
      };
      for (const page of new Set(lists.flat().map((f) => f.name))) {
        await step(o, ["asset", page], async () => {
          if (!o.alive()) return;
          if (!F().readBinary || !F().writeBinary) {
            result.pending++;
            result.pending_details.push({ page, reason: "binary_capability_required" });
            return;
          }
          const info = inventory2.map((items) => items.get(page)), cacheable = info.every((f) => f && Number.isFinite(f.at) && Number.isFinite(f.size)), signature = cacheable ? JSON.stringify(info.map((f) => [f.at, f.size])) : null, key = o.identity + "/" + page, known = cache.get(key);
          if (signature && known?.signature === signature && Date.now() - known.at < 6e4) return;
          cache.delete(key);
          const local2 = await peek2(o.work, page), remote = await peek2(o.remote, page);
          if (local2?.sha256 === remote?.sha256) {
            if (signature) cache.set(key, { signature, at: Date.now() });
            return;
          }
          if (local2 && remote) {
            result.pending++;
            result.pending_details.push({ page, reason: "asset_conflict", local: local2.sha256, remote: remote.sha256 });
            return;
          }
          if (!remote && !o.canPublish) {
            result.pending++;
            result.pending_details.push({ page, reason: "asset_publication_pending" });
            return;
          }
          const source2 = local2 || remote, target = local2 ? o.remote : o.work;
          const done = await F().writeBinary(target, page, source2.bytes, null);
          if (!done.saved) throw error("The file changed during synchronization. It will be checked again.");
          if (local2) result.published++;
          else result.copied++;
        }, result);
      }
    }
    async function run(options) {
      const o = { alive: () => true, ...options }, result = { copied: 0, published: 0, pending: 0, pending_details: [], conflicts: [] };
      if (!o.alive()) return result;
      if (o.work.isSameEntry && await o.work.isSameEntry(o.remote)) throw error("The shared wiki and working folder must be separate.");
      requireClearance([...await checkClearance(o.remote, o), ...o.canPublish ? await checkClearance(o.work, o) : []]);
      await binaryAssets(o, result);
      await evidence(o, o.remote, o.work);
      if (o.canPublish) await evidence(o, o.work, o.remote);
      await shadowEvidence(o, o.remote, o.work);
      if (o.canPublish) await shadowEvidence(o, o.work, o.remote);
      for (const kind of ["transfers", "retirements"]) {
        await sharedRecords(o, o.remote, o.work, kind);
        if (o.canPublish) await sharedRecords(o, o.work, o.remote, kind);
      }
      const retired = await step(o, ["retire_groups"], () => retireGroups(o, result), result);
      const aliases = await moveAliases(o, result);
      await identityAliases(o, aliases);
      const [local2, remote] = await Promise.all([F().listFolder(o.work, void 0, { visible }), F().listFolder(o.remote, void 0, { visible })]);
      const pages = new Map([...local2, ...remote].map((f) => [f.name, f]));
      for (const [page, entry] of pages) {
        if (!o.alive()) break;
        await step(o, ["page", page], async () => {
          if (aliases.has(page) || retired.has(page)) return;
          if (entry.size > MAX) {
            result.pending++;
            result.pending_details.push({ page, reason: "size_limit" });
            return;
          }
          const b = await baseline(o, page), l = await peek(o.work, page), r = await peek(o.remote, page), mine = text2(l), theirs = text2(r);
          if (mine !== null && mine.length > MAX || theirs !== null && theirs.length > MAX) {
            result.pending++;
            result.pending_details.push({ page, reason: "size_limit" });
            return;
          }
          await journal(o, o.remote, o.work, page);
          if (o.canPublish) await journal(o, o.work, o.remote, page);
          if (mine === theirs) {
            if (!b.data || b.data.text !== mine || b.data.resolved) await record(o, b, page, mine);
            return;
          }
          const base = b.data?.text;
          if (!b.data && mine === null && theirs !== null || b.data && mine === base && theirs !== null) {
            if (text2(await peek(o.remote, page)) !== theirs) throw error("The file changed during synchronization. It will be checked again.");
            await guarded2(o, o.work, page, theirs, l);
            await record(o, b, page, theirs);
            result.copied++;
            return;
          }
          const remoteClean = b.data ? theirs === base : theirs === null;
          if (remoteClean && mine !== null) {
            if (!o.canPublish) {
              result.pending++;
              result.pending_details.push({ page, reason: "read_only" });
              return;
            }
            if (!b.data?.resolved || theirs !== base) {
              if (!await transferable(o.work, page, theirs, mine)) {
                result.pending++;
                result.pending_details.push({ page, reason: "author_chain_missing", base: base ?? null, mine, theirs });
                return;
              }
            }
            if (text2(await peek(o.work, page)) !== mine) throw error("The file changed during synchronization. It will be checked again.");
            await guarded2(o, o.remote, page, mine, r);
            await record(o, b, page, mine);
            result.published++;
            return;
          }
          result.conflicts.push({ page, base: base ?? null, mine, theirs });
        }, result);
      }
      await step(o, ["retire_moves"], () => retireMoves(o, result, aliases), result);
      return result;
    }
    async function resolve(options, conflict, value, by, message = "") {
      const o = { alive: () => true, ...options }, l = await peek(o.work, conflict.page), r = await peek(o.remote, conflict.page);
      if (!o.alive()) throw error("The folder was disconnected.");
      if (text2(l) !== conflict.mine || text2(r) !== conflict.theirs) throw error("The file changed again. Reopen the comparison before deciding.");
      if (typeof value !== "string" || value.length > MAX) throw error("Choose a version to keep. No file will be deleted.");
      requireClearance([...contentClearance(value, conflict.page), ...await checkClearance(o.remote)]);
      const b = await baseline(o, conflict.page);
      await journal(o, o.remote, o.work, conflict.page);
      let parent = (await R().read(o.remote, conflict.page)).events.slice().reverse().find((e) => ["change", "accept"].includes(e.kind) && e.text === conflict.theirs);
      if (!parent) {
        parent = R().event({ kind: "external", page: conflict.page, author: "", base: conflict.base ?? "", text: conflict.theirs ?? "" });
        await R().append(o.work, parent);
      }
      const accepted = value === conflict.theirs;
      const response = accepted ? null : R().reply(parent, value === conflict.mine ? "reject" : "proposal", by, conflict.theirs ?? "", value, message);
      const saved = await R().save(o.work, conflict.page, l, value, by, accepted ? parent : null);
      if (!saved.saved || !saved.recorded) throw error("The file changed during synchronization. It will be checked again.");
      if (response) await R().append(o.work, response);
      await record(o, b, conflict.page, conflict.theirs, true);
    }
    global.EditorSync = { run, resolve, visible, contentClearance, checkClearance };
  })(environment2);
  return environment2.EditorSync;
}
var init_editorsync = __esm({
  "runtime/compat/editorsync.mjs"() {
  }
});

// runtime/compat/project.mjs
function createProject(environment2) {
  (function(global) {
    "use strict";
    const msg = (key, values) => global.I18n.message(key, values);
    const NAME2 = "llmwiki.project.json";
    const FORMAT4 = "llmwiki-project/1";
    const ID = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/;
    const ROOT_ICONS = ["folder", "book", "book-open", "user", "users", "briefcase", "library", "archive", "database"];
    function keys(value, required, optional = []) {
      if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((k) => !required.includes(k) && !optional.includes(k)) || required.some((k) => !Object.hasOwn(value, k))) {
        throw global.I18n.error(msg("Unknown or missing project settings."));
      }
    }
    function label2(value) {
      return typeof value === "string" && value.trim().length > 0 && value.length <= 240;
    }
    function validate2(data) {
      keys(data, ["format", "id", "label", "folders", "connections"], ["editor"]);
      if (Object.hasOwn(data, "editor") && !["builtin", "obsidian", "both"].includes(data.editor)) throw global.I18n.error(msg("Choose an editor."));
      if (data.format !== FORMAT4 || typeof data.id !== "string" || !ID.test(data.id) || !label2(data.label)) throw global.I18n.error(msg("Project ID or name is missing."));
      if (!Array.isArray(data.folders) || data.folders.length > 200) throw global.I18n.error(msg("Choose the project folders."));
      const folders = /* @__PURE__ */ new Map();
      for (const f of data.folders) {
        keys(f, ["id", "label", "kind", "path", "writable", "readers", "writers"], ["icon"]);
        if (f.icon !== void 0 && !ROOT_ICONS.includes(f.icon)) throw new Error("Choose a supported root icon.");
        if (typeof f.id !== "string" || !ID.test(f.id) || folders.has(f.id) || !label2(f.label)) throw global.I18n.error(msg("Folder IDs must be unique."));
        if (!["wiki", "work", "source"].includes(f.kind) || typeof f.writable !== "boolean") throw global.I18n.error(msg("Folder type or write permission is missing."));
        if (f.path !== null && (typeof f.path !== "string" || !f.path || /[\\:\x00]/.test(f.path) || f.path !== "." && f.path.split("/").some((p) => !p || p === ".." || p === "."))) throw global.I18n.error(msg("Folder paths must be within the project. External folders are bound on this device."));
        for (const key of ["readers", "writers"]) if (!Array.isArray(f[key]) || f[key].length > 100 || !f[key].every(label2)) throw global.I18n.error(msg("Name the people or groups who may access this folder."));
        if (!f.readers.length || f.writable && !f.writers.length) throw global.I18n.error(msg("Name the readers and, when writing is enabled, the writers."));
        folders.set(f.id, f);
      }
      if (!Array.isArray(data.connections) || data.connections.length > 200) throw global.I18n.error(msg("Create at least one connection."));
      const seen = /* @__PURE__ */ new Set();
      for (const c of data.connections) {
        keys(c, ["id", "label", "wiki", "works", "sources", "mode"], ["default_source"]);
        if (c.default_source != null && !c.sources.includes(c.default_source)) throw new Error("Default source must belong to this wiki.");
        if (typeof c.id !== "string" || !ID.test(c.id) || seen.has(c.id) || !label2(c.label)) throw global.I18n.error(msg("Connections need unique IDs and names."));
        seen.add(c.id);
        if (!["eigen", "gemeinsam"].includes(c.mode)) throw global.I18n.error(msg("Choose whether others write to the wiki."));
        if (!folders.has(c.wiki) || folders.get(c.wiki).kind !== "wiki") throw global.I18n.error(msg("Choose a wiki for this connection."));
        for (const [key, kind] of [["works", "work"], ["sources", "source"]]) {
          if (!Array.isArray(c[key]) || key === "works" && !c[key].length || new Set(c[key]).size !== c[key].length || c[key].some((id) => !folders.has(id) || folders.get(id).kind !== kind)) throw global.I18n.error(msg("Choose the matching working and source folders."));
        }
        const overlaps = (a, b) => a !== null && b !== null && (a === b || a === "." || b === "." || a.startsWith(b + "/") || b.startsWith(a + "/"));
        const wiki2 = folders.get(c.wiki);
        for (const id of c.works) if (c.mode === "gemeinsam" && overlaps(wiki2.path, folders.get(id).path)) throw global.I18n.error(msg("The shared wiki and working folder must be separate."));
        for (const id of c.sources) {
          const source2 = folders.get(id);
          if ([wiki2, ...c.works.map((k) => folders.get(k))].some((f) => overlaps(source2.path, f.path))) throw global.I18n.error(msg("Sources must not be inside a wiki or working folder, or contain either."));
        }
      }
      return data;
    }
    async function read(root) {
      const seen = await global.FolderAccess.peek(root, NAME2);
      if (seen === null) return { data: null, seen: null };
      if (typeof seen.text !== "string") throw global.I18n.error(msg("No read permission for project settings."));
      if (seen.text.length > 1048576) throw global.I18n.error(msg("Project settings are too large."));
      return { data: validate2(JSON.parse(seen.text)), seen };
    }
    async function save2(root, data, seen) {
      validate2(data);
      const done = await global.FolderAccess.writeFile(root, NAME2, JSON.stringify(data, null, 2) + "\n", seen);
      if (!done.saved) throw global.I18n.error(msg("Settings were not saved. Reopen them: someone changed them or write permission is missing."));
      return done;
    }
    async function relative(root, dir) {
      const parts = await root.resolve(dir);
      return parts === null ? null : parts.length ? parts.join("/") : ".";
    }
    function bindingKey(project, folder) {
      return "project/" + encodeURIComponent(project) + "/" + encodeURIComponent(folder);
    }
    async function resolve(root, f, project, recall = global.FolderAccess.recallFolder) {
      if (f.path === null) return recall(bindingKey(project, f.id));
      if (!root) return null;
      let dir = root;
      if (f.path !== ".") for (const part of f.path.split("/")) dir = await dir.getDirectoryHandle(part);
      return dir;
    }
    global.ProjectSettings = { NAME: NAME2, FORMAT: FORMAT4, ROOT_ICONS, validate: validate2, read, save: save2, relative, resolve, bindingKey };
  })(environment2);
  return environment2.ProjectSettings;
}
var init_project = __esm({
  "runtime/compat/project.mjs"() {
  }
});

// runtime/compat/matching.mjs
function placesOf(items) {
  var found = /* @__PURE__ */ new Map();
  for (var index = 0; index < items.length; index += 1) {
    var seen = found.get(items[index]);
    if (seen === void 0) {
      seen = [];
      found.set(items[index], seen);
    }
    seen.push(index);
  }
  return found;
}
function findLongestMatch(a, b, indices, alo, ahi, blo, bhi) {
  var besti = alo;
  var bestj = blo;
  var bestsize = 0;
  var lengths = /* @__PURE__ */ new Map();
  for (var i2 = alo; i2 < ahi; i2 += 1) {
    var next = /* @__PURE__ */ new Map();
    var places = indices.get(a[i2]);
    if (places !== void 0) {
      for (var at = 0; at < places.length; at += 1) {
        var j = places[at];
        if (j < blo) {
          continue;
        }
        if (j >= bhi) {
          break;
        }
        var previous = lengths.get(j - 1);
        var k = (previous === void 0 ? 0 : previous) + 1;
        next.set(j, k);
        if (k > bestsize) {
          besti = i2 - k + 1;
          bestj = j - k + 1;
          bestsize = k;
        }
      }
    }
    lengths = next;
  }
  return [besti, bestj, bestsize];
}
function matchingBlocks(a, b) {
  var indices = placesOf(b);
  var queue2 = [[0, a.length, 0, b.length]];
  var found = [];
  while (queue2.length) {
    var region = queue2.pop();
    var alo = region[0];
    var ahi = region[1];
    var blo = region[2];
    var bhi = region[3];
    var match = findLongestMatch(a, b, indices, alo, ahi, blo, bhi);
    var i2 = match[0];
    var j = match[1];
    var k = match[2];
    if (k) {
      found.push(match);
      if (alo < i2 && blo < j) {
        queue2.push([alo, i2, blo, j]);
      }
      if (i2 + k < ahi && j + k < bhi) {
        queue2.push([i2 + k, ahi, j + k, bhi]);
      }
    }
  }
  found.sort(function(one, other) {
    return one[0] - other[0] || one[1] - other[1] || one[2] - other[2];
  });
  var joined = [];
  var i1 = 0;
  var j1 = 0;
  var k1 = 0;
  for (var index = 0; index < found.length; index += 1) {
    var i22 = found[index][0];
    var j2 = found[index][1];
    var k2 = found[index][2];
    if (i1 + k1 === i22 && j1 + k1 === j2) {
      k1 += k2;
    } else {
      if (k1) {
        joined.push([i1, j1, k1]);
      }
      i1 = i22;
      j1 = j2;
      k1 = k2;
    }
  }
  if (k1) {
    joined.push([i1, j1, k1]);
  }
  joined.push([a.length, b.length, 0]);
  return joined;
}
var init_matching = __esm({
  "runtime/compat/matching.mjs"() {
  }
});

// node_modules/yaml/dist/nodes/identity.js
var require_identity = __commonJS({
  "node_modules/yaml/dist/nodes/identity.js"(exports2) {
    "use strict";
    var ALIAS = /* @__PURE__ */ Symbol.for("yaml.alias");
    var DOC = /* @__PURE__ */ Symbol.for("yaml.document");
    var MAP = /* @__PURE__ */ Symbol.for("yaml.map");
    var PAIR = /* @__PURE__ */ Symbol.for("yaml.pair");
    var SCALAR = /* @__PURE__ */ Symbol.for("yaml.scalar");
    var SEQ = /* @__PURE__ */ Symbol.for("yaml.seq");
    var NODE_TYPE = /* @__PURE__ */ Symbol.for("yaml.node.type");
    var isAlias = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === ALIAS;
    var isDocument = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === DOC;
    var isMap2 = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === MAP;
    var isPair = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === PAIR;
    var isScalar = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === SCALAR;
    var isSeq = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === SEQ;
    function isCollection(node) {
      if (node && typeof node === "object")
        switch (node[NODE_TYPE]) {
          case MAP:
          case SEQ:
            return true;
        }
      return false;
    }
    function isNode(node) {
      if (node && typeof node === "object")
        switch (node[NODE_TYPE]) {
          case ALIAS:
          case MAP:
          case SCALAR:
          case SEQ:
            return true;
        }
      return false;
    }
    var hasAnchor = (node) => (isScalar(node) || isCollection(node)) && !!node.anchor;
    exports2.ALIAS = ALIAS;
    exports2.DOC = DOC;
    exports2.MAP = MAP;
    exports2.NODE_TYPE = NODE_TYPE;
    exports2.PAIR = PAIR;
    exports2.SCALAR = SCALAR;
    exports2.SEQ = SEQ;
    exports2.hasAnchor = hasAnchor;
    exports2.isAlias = isAlias;
    exports2.isCollection = isCollection;
    exports2.isDocument = isDocument;
    exports2.isMap = isMap2;
    exports2.isNode = isNode;
    exports2.isPair = isPair;
    exports2.isScalar = isScalar;
    exports2.isSeq = isSeq;
  }
});

// node_modules/yaml/dist/visit.js
var require_visit = __commonJS({
  "node_modules/yaml/dist/visit.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var BREAK = /* @__PURE__ */ Symbol("break visit");
    var SKIP = /* @__PURE__ */ Symbol("skip children");
    var REMOVE = /* @__PURE__ */ Symbol("remove node");
    function visit(node, visitor) {
      const visitor_ = initVisitor(visitor);
      if (identity2.isDocument(node)) {
        const cd = visit_(null, node.contents, visitor_, Object.freeze([node]));
        if (cd === REMOVE)
          node.contents = null;
      } else
        visit_(null, node, visitor_, Object.freeze([]));
    }
    visit.BREAK = BREAK;
    visit.SKIP = SKIP;
    visit.REMOVE = REMOVE;
    function visit_(key, node, visitor, path7) {
      const ctrl = callVisitor(key, node, visitor, path7);
      if (identity2.isNode(ctrl) || identity2.isPair(ctrl)) {
        replaceNode(key, path7, ctrl);
        return visit_(key, ctrl, visitor, path7);
      }
      if (typeof ctrl !== "symbol") {
        if (identity2.isCollection(node)) {
          path7 = Object.freeze(path7.concat(node));
          for (let i2 = 0; i2 < node.items.length; ++i2) {
            const ci = visit_(i2, node.items[i2], visitor, path7);
            if (typeof ci === "number")
              i2 = ci - 1;
            else if (ci === BREAK)
              return BREAK;
            else if (ci === REMOVE) {
              node.items.splice(i2, 1);
              i2 -= 1;
            }
          }
        } else if (identity2.isPair(node)) {
          path7 = Object.freeze(path7.concat(node));
          const ck = visit_("key", node.key, visitor, path7);
          if (ck === BREAK)
            return BREAK;
          else if (ck === REMOVE)
            node.key = null;
          const cv = visit_("value", node.value, visitor, path7);
          if (cv === BREAK)
            return BREAK;
          else if (cv === REMOVE)
            node.value = null;
        }
      }
      return ctrl;
    }
    async function visitAsync(node, visitor) {
      const visitor_ = initVisitor(visitor);
      if (identity2.isDocument(node)) {
        const cd = await visitAsync_(null, node.contents, visitor_, Object.freeze([node]));
        if (cd === REMOVE)
          node.contents = null;
      } else
        await visitAsync_(null, node, visitor_, Object.freeze([]));
    }
    visitAsync.BREAK = BREAK;
    visitAsync.SKIP = SKIP;
    visitAsync.REMOVE = REMOVE;
    async function visitAsync_(key, node, visitor, path7) {
      const ctrl = await callVisitor(key, node, visitor, path7);
      if (identity2.isNode(ctrl) || identity2.isPair(ctrl)) {
        replaceNode(key, path7, ctrl);
        return visitAsync_(key, ctrl, visitor, path7);
      }
      if (typeof ctrl !== "symbol") {
        if (identity2.isCollection(node)) {
          path7 = Object.freeze(path7.concat(node));
          for (let i2 = 0; i2 < node.items.length; ++i2) {
            const ci = await visitAsync_(i2, node.items[i2], visitor, path7);
            if (typeof ci === "number")
              i2 = ci - 1;
            else if (ci === BREAK)
              return BREAK;
            else if (ci === REMOVE) {
              node.items.splice(i2, 1);
              i2 -= 1;
            }
          }
        } else if (identity2.isPair(node)) {
          path7 = Object.freeze(path7.concat(node));
          const ck = await visitAsync_("key", node.key, visitor, path7);
          if (ck === BREAK)
            return BREAK;
          else if (ck === REMOVE)
            node.key = null;
          const cv = await visitAsync_("value", node.value, visitor, path7);
          if (cv === BREAK)
            return BREAK;
          else if (cv === REMOVE)
            node.value = null;
        }
      }
      return ctrl;
    }
    function initVisitor(visitor) {
      if (typeof visitor === "object" && (visitor.Collection || visitor.Node || visitor.Value)) {
        return Object.assign({
          Alias: visitor.Node,
          Map: visitor.Node,
          Scalar: visitor.Node,
          Seq: visitor.Node
        }, visitor.Value && {
          Map: visitor.Value,
          Scalar: visitor.Value,
          Seq: visitor.Value
        }, visitor.Collection && {
          Map: visitor.Collection,
          Seq: visitor.Collection
        }, visitor);
      }
      return visitor;
    }
    function callVisitor(key, node, visitor, path7) {
      if (typeof visitor === "function")
        return visitor(key, node, path7);
      if (identity2.isMap(node))
        return visitor.Map?.(key, node, path7);
      if (identity2.isSeq(node))
        return visitor.Seq?.(key, node, path7);
      if (identity2.isPair(node))
        return visitor.Pair?.(key, node, path7);
      if (identity2.isScalar(node))
        return visitor.Scalar?.(key, node, path7);
      if (identity2.isAlias(node))
        return visitor.Alias?.(key, node, path7);
      return void 0;
    }
    function replaceNode(key, path7, node) {
      const parent = path7[path7.length - 1];
      if (identity2.isCollection(parent)) {
        parent.items[key] = node;
      } else if (identity2.isPair(parent)) {
        if (key === "key")
          parent.key = node;
        else
          parent.value = node;
      } else if (identity2.isDocument(parent)) {
        parent.contents = node;
      } else {
        const pt = identity2.isAlias(parent) ? "alias" : "scalar";
        throw new Error(`Cannot replace node with ${pt} parent`);
      }
    }
    exports2.visit = visit;
    exports2.visitAsync = visitAsync;
  }
});

// node_modules/yaml/dist/doc/directives.js
var require_directives = __commonJS({
  "node_modules/yaml/dist/doc/directives.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var visit = require_visit();
    var escapeChars = {
      "!": "%21",
      ",": "%2C",
      "[": "%5B",
      "]": "%5D",
      "{": "%7B",
      "}": "%7D"
    };
    var escapeTagName = (tn) => tn.replace(/[!,[\]{}]/g, (ch) => escapeChars[ch]);
    var Directives = class _Directives {
      constructor(yaml, tags) {
        this.docStart = null;
        this.docEnd = false;
        this.yaml = Object.assign({}, _Directives.defaultYaml, yaml);
        this.tags = Object.assign({}, _Directives.defaultTags, tags);
      }
      clone() {
        const copy = new _Directives(this.yaml, this.tags);
        copy.docStart = this.docStart;
        return copy;
      }
      /**
       * During parsing, get a Directives instance for the current document and
       * update the stream state according to the current version's spec.
       */
      atDocument() {
        const res = new _Directives(this.yaml, this.tags);
        switch (this.yaml.version) {
          case "1.1":
            this.atNextDocument = true;
            break;
          case "1.2":
            this.atNextDocument = false;
            this.yaml = {
              explicit: _Directives.defaultYaml.explicit,
              version: "1.2"
            };
            this.tags = Object.assign({}, _Directives.defaultTags);
            break;
        }
        return res;
      }
      /**
       * @param onError - May be called even if the action was successful
       * @returns `true` on success
       */
      add(line, onError) {
        if (this.atNextDocument) {
          this.yaml = { explicit: _Directives.defaultYaml.explicit, version: "1.1" };
          this.tags = Object.assign({}, _Directives.defaultTags);
          this.atNextDocument = false;
        }
        const parts = line.trim().split(/[ \t]+/);
        const name = parts.shift();
        switch (name) {
          case "%TAG": {
            if (parts.length !== 2) {
              onError(0, "%TAG directive should contain exactly two parts");
              if (parts.length < 2)
                return false;
            }
            const [handle2, prefix] = parts;
            this.tags[handle2] = prefix;
            return true;
          }
          case "%YAML": {
            this.yaml.explicit = true;
            if (parts.length !== 1) {
              onError(0, "%YAML directive should contain exactly one part");
              return false;
            }
            const [version2] = parts;
            if (version2 === "1.1" || version2 === "1.2") {
              this.yaml.version = version2;
              return true;
            } else {
              const isValid = /^\d+\.\d+$/.test(version2);
              onError(6, `Unsupported YAML version ${version2}`, isValid);
              return false;
            }
          }
          default:
            onError(0, `Unknown directive ${name}`, true);
            return false;
        }
      }
      /**
       * Resolves a tag, matching handles to those defined in %TAG directives.
       *
       * @returns Resolved tag, which may also be the non-specific tag `'!'` or a
       *   `'!local'` tag, or `null` if unresolvable.
       */
      tagName(source2, onError) {
        if (source2 === "!")
          return "!";
        if (source2[0] !== "!") {
          onError(`Not a valid tag: ${source2}`);
          return null;
        }
        if (source2[1] === "<") {
          const verbatim = source2.slice(2, -1);
          if (verbatim === "!" || verbatim === "!!") {
            onError(`Verbatim tags aren't resolved, so ${source2} is invalid.`);
            return null;
          }
          if (source2[source2.length - 1] !== ">")
            onError("Verbatim tags must end with a >");
          return verbatim;
        }
        const [, handle2, suffix] = source2.match(/^(.*!)([^!]*)$/s);
        if (!suffix)
          onError(`The ${source2} tag has no suffix`);
        const prefix = this.tags[handle2];
        if (prefix) {
          try {
            return prefix + decodeURIComponent(suffix);
          } catch (error) {
            onError(String(error));
            return null;
          }
        }
        if (handle2 === "!")
          return source2;
        onError(`Could not resolve tag: ${source2}`);
        return null;
      }
      /**
       * Given a fully resolved tag, returns its printable string form,
       * taking into account current tag prefixes and defaults.
       */
      tagString(tag) {
        for (const [handle2, prefix] of Object.entries(this.tags)) {
          if (tag.startsWith(prefix))
            return handle2 + escapeTagName(tag.substring(prefix.length));
        }
        return tag[0] === "!" ? tag : `!<${tag}>`;
      }
      toString(doc) {
        const lines = this.yaml.explicit ? [`%YAML ${this.yaml.version || "1.2"}`] : [];
        const tagEntries = Object.entries(this.tags);
        let tagNames;
        if (doc && tagEntries.length > 0 && identity2.isNode(doc.contents)) {
          const tags = {};
          visit.visit(doc.contents, (_key, node) => {
            if (identity2.isNode(node) && node.tag)
              tags[node.tag] = true;
          });
          tagNames = Object.keys(tags);
        } else
          tagNames = [];
        for (const [handle2, prefix] of tagEntries) {
          if (handle2 === "!!" && prefix === "tag:yaml.org,2002:")
            continue;
          if (!doc || tagNames.some((tn) => tn.startsWith(prefix)))
            lines.push(`%TAG ${handle2} ${prefix}`);
        }
        return lines.join("\n");
      }
    };
    Directives.defaultYaml = { explicit: false, version: "1.2" };
    Directives.defaultTags = { "!!": "tag:yaml.org,2002:" };
    exports2.Directives = Directives;
  }
});

// node_modules/yaml/dist/doc/anchors.js
var require_anchors = __commonJS({
  "node_modules/yaml/dist/doc/anchors.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var visit = require_visit();
    function anchorIsValid(anchor) {
      if (/[\x00-\x19\s,[\]{}]/.test(anchor)) {
        const sa = JSON.stringify(anchor);
        const msg = `Anchor must not contain whitespace or control characters: ${sa}`;
        throw new Error(msg);
      }
      return true;
    }
    function anchorNames(root) {
      const anchors = /* @__PURE__ */ new Set();
      visit.visit(root, {
        Value(_key, node) {
          if (node.anchor)
            anchors.add(node.anchor);
        }
      });
      return anchors;
    }
    function findNewAnchor(prefix, exclude) {
      for (let i2 = 1; true; ++i2) {
        const name = `${prefix}${i2}`;
        if (!exclude.has(name))
          return name;
      }
    }
    function createNodeAnchors(doc, prefix) {
      const aliasObjects = [];
      const sourceObjects = /* @__PURE__ */ new Map();
      let prevAnchors = null;
      return {
        onAnchor: (source2) => {
          aliasObjects.push(source2);
          prevAnchors ?? (prevAnchors = anchorNames(doc));
          const anchor = findNewAnchor(prefix, prevAnchors);
          prevAnchors.add(anchor);
          return anchor;
        },
        /**
         * With circular references, the source node is only resolved after all
         * of its child nodes are. This is why anchors are set only after all of
         * the nodes have been created.
         */
        setAnchors: () => {
          for (const source2 of aliasObjects) {
            const ref = sourceObjects.get(source2);
            if (typeof ref === "object" && ref.anchor && (identity2.isScalar(ref.node) || identity2.isCollection(ref.node))) {
              ref.node.anchor = ref.anchor;
            } else {
              const error = new Error("Failed to resolve repeated object (this should not happen)");
              error.source = source2;
              throw error;
            }
          }
        },
        sourceObjects
      };
    }
    exports2.anchorIsValid = anchorIsValid;
    exports2.anchorNames = anchorNames;
    exports2.createNodeAnchors = createNodeAnchors;
    exports2.findNewAnchor = findNewAnchor;
  }
});

// node_modules/yaml/dist/doc/applyReviver.js
var require_applyReviver = __commonJS({
  "node_modules/yaml/dist/doc/applyReviver.js"(exports2) {
    "use strict";
    function applyReviver(reviver, obj, key, val) {
      if (val && typeof val === "object") {
        if (Array.isArray(val)) {
          for (let i2 = 0, len = val.length; i2 < len; ++i2) {
            const v0 = val[i2];
            const v1 = applyReviver(reviver, val, String(i2), v0);
            if (v1 === void 0)
              delete val[i2];
            else if (v1 !== v0)
              val[i2] = v1;
          }
        } else if (val instanceof Map) {
          for (const k of Array.from(val.keys())) {
            const v0 = val.get(k);
            const v1 = applyReviver(reviver, val, k, v0);
            if (v1 === void 0)
              val.delete(k);
            else if (v1 !== v0)
              val.set(k, v1);
          }
        } else if (val instanceof Set) {
          for (const v0 of Array.from(val)) {
            const v1 = applyReviver(reviver, val, v0, v0);
            if (v1 === void 0)
              val.delete(v0);
            else if (v1 !== v0) {
              val.delete(v0);
              val.add(v1);
            }
          }
        } else {
          for (const [k, v0] of Object.entries(val)) {
            const v1 = applyReviver(reviver, val, k, v0);
            if (v1 === void 0)
              delete val[k];
            else if (v1 !== v0)
              val[k] = v1;
          }
        }
      }
      return reviver.call(obj, key, val);
    }
    exports2.applyReviver = applyReviver;
  }
});

// node_modules/yaml/dist/nodes/toJS.js
var require_toJS = __commonJS({
  "node_modules/yaml/dist/nodes/toJS.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    function toJS(value, arg, ctx) {
      if (Array.isArray(value))
        return value.map((v, i2) => toJS(v, String(i2), ctx));
      if (value && typeof value.toJSON === "function") {
        if (!ctx || !identity2.hasAnchor(value))
          return value.toJSON(arg, ctx);
        const data = { aliasCount: 0, count: 1, res: void 0 };
        ctx.anchors.set(value, data);
        ctx.onCreate = (res2) => {
          data.res = res2;
          delete ctx.onCreate;
        };
        const res = value.toJSON(arg, ctx);
        if (ctx.onCreate)
          ctx.onCreate(res);
        return res;
      }
      if (typeof value === "bigint" && !ctx?.keep)
        return Number(value);
      return value;
    }
    exports2.toJS = toJS;
  }
});

// node_modules/yaml/dist/nodes/Node.js
var require_Node = __commonJS({
  "node_modules/yaml/dist/nodes/Node.js"(exports2) {
    "use strict";
    var applyReviver = require_applyReviver();
    var identity2 = require_identity();
    var toJS = require_toJS();
    var NodeBase = class {
      constructor(type) {
        Object.defineProperty(this, identity2.NODE_TYPE, { value: type });
      }
      /** Create a copy of this node.  */
      clone() {
        const copy = Object.create(Object.getPrototypeOf(this), Object.getOwnPropertyDescriptors(this));
        if (this.range)
          copy.range = this.range.slice();
        return copy;
      }
      /** A plain JavaScript representation of this node. */
      toJS(doc, { mapAsMap, maxAliasCount, onAnchor, reviver } = {}) {
        if (!identity2.isDocument(doc))
          throw new TypeError("A document argument is required");
        const ctx = {
          anchors: /* @__PURE__ */ new Map(),
          doc,
          keep: true,
          mapAsMap: mapAsMap === true,
          mapKeyWarned: false,
          maxAliasCount: typeof maxAliasCount === "number" ? maxAliasCount : 100
        };
        const res = toJS.toJS(this, "", ctx);
        if (typeof onAnchor === "function")
          for (const { count, res: res2 } of ctx.anchors.values())
            onAnchor(res2, count);
        return typeof reviver === "function" ? applyReviver.applyReviver(reviver, { "": res }, "", res) : res;
      }
    };
    exports2.NodeBase = NodeBase;
  }
});

// node_modules/yaml/dist/nodes/Alias.js
var require_Alias = __commonJS({
  "node_modules/yaml/dist/nodes/Alias.js"(exports2) {
    "use strict";
    var anchors = require_anchors();
    var visit = require_visit();
    var identity2 = require_identity();
    var Node = require_Node();
    var toJS = require_toJS();
    var Alias = class extends Node.NodeBase {
      constructor(source2) {
        super(identity2.ALIAS);
        this.source = source2;
        Object.defineProperty(this, "tag", {
          set() {
            throw new Error("Alias nodes cannot have tags");
          }
        });
      }
      /**
       * Resolve the value of this alias within `doc`, finding the last
       * instance of the `source` anchor before this node.
       */
      resolve(doc, ctx) {
        if (ctx?.maxAliasCount === 0)
          throw new ReferenceError("Alias resolution is disabled");
        let nodes;
        if (ctx?.aliasResolveCache) {
          nodes = ctx.aliasResolveCache;
        } else {
          nodes = [];
          visit.visit(doc, {
            Node: (_key, node) => {
              if (identity2.isAlias(node) || identity2.hasAnchor(node))
                nodes.push(node);
            }
          });
          if (ctx)
            ctx.aliasResolveCache = nodes;
        }
        let found = void 0;
        for (const node of nodes) {
          if (node === this)
            break;
          if (node.anchor === this.source)
            found = node;
        }
        return found;
      }
      toJSON(_arg, ctx) {
        if (!ctx)
          return { source: this.source };
        const { anchors: anchors2, doc, maxAliasCount } = ctx;
        const source2 = this.resolve(doc, ctx);
        if (!source2) {
          const msg = `Unresolved alias (the anchor must be set before the alias): ${this.source}`;
          throw new ReferenceError(msg);
        }
        let data = anchors2.get(source2);
        if (!data) {
          toJS.toJS(source2, null, ctx);
          data = anchors2.get(source2);
        }
        if (data?.res === void 0) {
          const msg = "This should not happen: Alias anchor was not resolved?";
          throw new ReferenceError(msg);
        }
        if (maxAliasCount >= 0) {
          data.count += 1;
          if (data.aliasCount === 0)
            data.aliasCount = getAliasCount(doc, source2, anchors2);
          if (data.count * data.aliasCount > maxAliasCount) {
            const msg = "Excessive alias count indicates a resource exhaustion attack";
            throw new ReferenceError(msg);
          }
        }
        return data.res;
      }
      toString(ctx, _onComment, _onChompKeep) {
        const src = `*${this.source}`;
        if (ctx) {
          anchors.anchorIsValid(this.source);
          if (ctx.options.verifyAliasOrder && !ctx.anchors.has(this.source)) {
            const msg = `Unresolved alias (the anchor must be set before the alias): ${this.source}`;
            throw new Error(msg);
          }
          if (ctx.implicitKey)
            return `${src} `;
        }
        return src;
      }
    };
    function getAliasCount(doc, node, anchors2) {
      if (identity2.isAlias(node)) {
        const source2 = node.resolve(doc);
        const anchor = anchors2 && source2 && anchors2.get(source2);
        return anchor ? anchor.count * anchor.aliasCount : 0;
      } else if (identity2.isCollection(node)) {
        let count = 0;
        for (const item of node.items) {
          const c = getAliasCount(doc, item, anchors2);
          if (c > count)
            count = c;
        }
        return count;
      } else if (identity2.isPair(node)) {
        const kc = getAliasCount(doc, node.key, anchors2);
        const vc = getAliasCount(doc, node.value, anchors2);
        return Math.max(kc, vc);
      }
      return 1;
    }
    exports2.Alias = Alias;
  }
});

// node_modules/yaml/dist/nodes/Scalar.js
var require_Scalar = __commonJS({
  "node_modules/yaml/dist/nodes/Scalar.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var Node = require_Node();
    var toJS = require_toJS();
    var isScalarValue = (value) => !value || typeof value !== "function" && typeof value !== "object";
    var Scalar = class extends Node.NodeBase {
      constructor(value) {
        super(identity2.SCALAR);
        this.value = value;
      }
      toJSON(arg, ctx) {
        return ctx?.keep ? this.value : toJS.toJS(this.value, arg, ctx);
      }
      toString() {
        return String(this.value);
      }
    };
    Scalar.BLOCK_FOLDED = "BLOCK_FOLDED";
    Scalar.BLOCK_LITERAL = "BLOCK_LITERAL";
    Scalar.PLAIN = "PLAIN";
    Scalar.QUOTE_DOUBLE = "QUOTE_DOUBLE";
    Scalar.QUOTE_SINGLE = "QUOTE_SINGLE";
    exports2.Scalar = Scalar;
    exports2.isScalarValue = isScalarValue;
  }
});

// node_modules/yaml/dist/doc/createNode.js
var require_createNode = __commonJS({
  "node_modules/yaml/dist/doc/createNode.js"(exports2) {
    "use strict";
    var Alias = require_Alias();
    var identity2 = require_identity();
    var Scalar = require_Scalar();
    var defaultTagPrefix = "tag:yaml.org,2002:";
    function findTagObject(value, tagName, tags) {
      if (tagName) {
        const match = tags.filter((t) => t.tag === tagName);
        const tagObj = match.find((t) => !t.format) ?? match[0];
        if (!tagObj)
          throw new Error(`Tag ${tagName} not found`);
        return tagObj;
      }
      return tags.find((t) => t.identify?.(value) && !t.format);
    }
    function createNode(value, tagName, ctx) {
      if (identity2.isDocument(value))
        value = value.contents;
      if (identity2.isNode(value))
        return value;
      if (identity2.isPair(value)) {
        const map = ctx.schema[identity2.MAP].createNode?.(ctx.schema, null, ctx);
        map.items.push(value);
        return map;
      }
      if (value instanceof String || value instanceof Number || value instanceof Boolean || typeof BigInt !== "undefined" && value instanceof BigInt) {
        value = value.valueOf();
      }
      const { aliasDuplicateObjects, onAnchor, onTagObj, schema: schema2, sourceObjects } = ctx;
      let ref = void 0;
      if (aliasDuplicateObjects && value && typeof value === "object") {
        ref = sourceObjects.get(value);
        if (ref) {
          ref.anchor ?? (ref.anchor = onAnchor(value));
          return new Alias.Alias(ref.anchor);
        } else {
          ref = { anchor: null, node: null };
          sourceObjects.set(value, ref);
        }
      }
      if (tagName?.startsWith("!!"))
        tagName = defaultTagPrefix + tagName.slice(2);
      let tagObj = findTagObject(value, tagName, schema2.tags);
      if (!tagObj) {
        if (value && typeof value.toJSON === "function") {
          value = value.toJSON();
        }
        if (!value || typeof value !== "object") {
          const node2 = new Scalar.Scalar(value);
          if (ref)
            ref.node = node2;
          return node2;
        }
        tagObj = value instanceof Map ? schema2[identity2.MAP] : Symbol.iterator in Object(value) ? schema2[identity2.SEQ] : schema2[identity2.MAP];
      }
      if (onTagObj) {
        onTagObj(tagObj);
        delete ctx.onTagObj;
      }
      const node = tagObj?.createNode ? tagObj.createNode(ctx.schema, value, ctx) : typeof tagObj?.nodeClass?.from === "function" ? tagObj.nodeClass.from(ctx.schema, value, ctx) : new Scalar.Scalar(value);
      if (tagName)
        node.tag = tagName;
      else if (!tagObj.default)
        node.tag = tagObj.tag;
      if (ref)
        ref.node = node;
      return node;
    }
    exports2.createNode = createNode;
  }
});

// node_modules/yaml/dist/nodes/Collection.js
var require_Collection = __commonJS({
  "node_modules/yaml/dist/nodes/Collection.js"(exports2) {
    "use strict";
    var createNode = require_createNode();
    var identity2 = require_identity();
    var Node = require_Node();
    function collectionFromPath(schema2, path7, value) {
      let v = value;
      for (let i2 = path7.length - 1; i2 >= 0; --i2) {
        const k = path7[i2];
        if (typeof k === "number" && Number.isInteger(k) && k >= 0) {
          const a = [];
          a[k] = v;
          v = a;
        } else {
          v = /* @__PURE__ */ new Map([[k, v]]);
        }
      }
      return createNode.createNode(v, void 0, {
        aliasDuplicateObjects: false,
        keepUndefined: false,
        onAnchor: () => {
          throw new Error("This should not happen, please report a bug.");
        },
        schema: schema2,
        sourceObjects: /* @__PURE__ */ new Map()
      });
    }
    var isEmptyPath = (path7) => path7 == null || typeof path7 === "object" && !!path7[Symbol.iterator]().next().done;
    var Collection = class extends Node.NodeBase {
      constructor(type, schema2) {
        super(type);
        Object.defineProperty(this, "schema", {
          value: schema2,
          configurable: true,
          enumerable: false,
          writable: true
        });
      }
      /**
       * Create a copy of this collection.
       *
       * @param schema - If defined, overwrites the original's schema
       */
      clone(schema2) {
        const copy = Object.create(Object.getPrototypeOf(this), Object.getOwnPropertyDescriptors(this));
        if (schema2)
          copy.schema = schema2;
        copy.items = copy.items.map((it) => identity2.isNode(it) || identity2.isPair(it) ? it.clone(schema2) : it);
        if (this.range)
          copy.range = this.range.slice();
        return copy;
      }
      /**
       * Adds a value to the collection. For `!!map` and `!!omap` the value must
       * be a Pair instance or a `{ key, value }` object, which may not have a key
       * that already exists in the map.
       */
      addIn(path7, value) {
        if (isEmptyPath(path7))
          this.add(value);
        else {
          const [key, ...rest] = path7;
          const node = this.get(key, true);
          if (identity2.isCollection(node))
            node.addIn(rest, value);
          else if (node === void 0 && this.schema)
            this.set(key, collectionFromPath(this.schema, rest, value));
          else
            throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
        }
      }
      /**
       * Removes a value from the collection.
       * @returns `true` if the item was found and removed.
       */
      deleteIn(path7) {
        const [key, ...rest] = path7;
        if (rest.length === 0)
          return this.delete(key);
        const node = this.get(key, true);
        if (identity2.isCollection(node))
          return node.deleteIn(rest);
        else
          throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
      }
      /**
       * Returns item at `key`, or `undefined` if not found. By default unwraps
       * scalar values from their surrounding node; to disable set `keepScalar` to
       * `true` (collections are always returned intact).
       */
      getIn(path7, keepScalar) {
        const [key, ...rest] = path7;
        const node = this.get(key, true);
        if (rest.length === 0)
          return !keepScalar && identity2.isScalar(node) ? node.value : node;
        else
          return identity2.isCollection(node) ? node.getIn(rest, keepScalar) : void 0;
      }
      hasAllNullValues(allowScalar) {
        return this.items.every((node) => {
          if (!identity2.isPair(node))
            return false;
          const n = node.value;
          return n == null || allowScalar && identity2.isScalar(n) && n.value == null && !n.commentBefore && !n.comment && !n.tag;
        });
      }
      /**
       * Checks if the collection includes a value with the key `key`.
       */
      hasIn(path7) {
        const [key, ...rest] = path7;
        if (rest.length === 0)
          return this.has(key);
        const node = this.get(key, true);
        return identity2.isCollection(node) ? node.hasIn(rest) : false;
      }
      /**
       * Sets a value in this collection. For `!!set`, `value` needs to be a
       * boolean to add/remove the item from the set.
       */
      setIn(path7, value) {
        const [key, ...rest] = path7;
        if (rest.length === 0) {
          this.set(key, value);
        } else {
          const node = this.get(key, true);
          if (identity2.isCollection(node))
            node.setIn(rest, value);
          else if (node === void 0 && this.schema)
            this.set(key, collectionFromPath(this.schema, rest, value));
          else
            throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
        }
      }
    };
    exports2.Collection = Collection;
    exports2.collectionFromPath = collectionFromPath;
    exports2.isEmptyPath = isEmptyPath;
  }
});

// node_modules/yaml/dist/stringify/stringifyComment.js
var require_stringifyComment = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyComment.js"(exports2) {
    "use strict";
    var stringifyComment = (str) => str.replace(/^(?!$)(?: $)?/gm, "#");
    function indentComment(comment, indent) {
      if (/^\n+$/.test(comment))
        return comment.substring(1);
      return indent ? comment.replace(/^(?! *$)/gm, indent) : comment;
    }
    var lineComment = (str, indent, comment) => str.endsWith("\n") ? indentComment(comment, indent) : comment.includes("\n") ? "\n" + indentComment(comment, indent) : (str.endsWith(" ") ? "" : " ") + comment;
    exports2.indentComment = indentComment;
    exports2.lineComment = lineComment;
    exports2.stringifyComment = stringifyComment;
  }
});

// node_modules/yaml/dist/stringify/foldFlowLines.js
var require_foldFlowLines = __commonJS({
  "node_modules/yaml/dist/stringify/foldFlowLines.js"(exports2) {
    "use strict";
    var FOLD_FLOW = "flow";
    var FOLD_BLOCK = "block";
    var FOLD_QUOTED = "quoted";
    function foldFlowLines(text2, indent, mode = "flow", { indentAtStart, lineWidth = 80, minContentWidth = 20, onFold, onOverflow } = {}) {
      if (!lineWidth || lineWidth < 0)
        return text2;
      if (lineWidth < minContentWidth)
        minContentWidth = 0;
      const endStep = Math.max(1 + minContentWidth, 1 + lineWidth - indent.length);
      if (text2.length <= endStep)
        return text2;
      const folds = [];
      const escapedFolds = {};
      let end = lineWidth - indent.length;
      if (typeof indentAtStart === "number") {
        if (indentAtStart > lineWidth - Math.max(2, minContentWidth))
          folds.push(0);
        else
          end = lineWidth - indentAtStart;
      }
      let split = void 0;
      let prev = void 0;
      let overflow = false;
      let i2 = -1;
      let escStart = -1;
      let escEnd = -1;
      if (mode === FOLD_BLOCK) {
        i2 = consumeMoreIndentedLines(text2, i2, indent.length);
        if (i2 !== -1)
          end = i2 + endStep;
      }
      for (let ch; ch = text2[i2 += 1]; ) {
        if (mode === FOLD_QUOTED && ch === "\\") {
          escStart = i2;
          switch (text2[i2 + 1]) {
            case "x":
              i2 += 3;
              break;
            case "u":
              i2 += 5;
              break;
            case "U":
              i2 += 9;
              break;
            default:
              i2 += 1;
          }
          escEnd = i2;
        }
        if (ch === "\n") {
          if (mode === FOLD_BLOCK)
            i2 = consumeMoreIndentedLines(text2, i2, indent.length);
          end = i2 + indent.length + endStep;
          split = void 0;
        } else {
          if (ch === " " && prev && prev !== " " && prev !== "\n" && prev !== "	") {
            const next = text2[i2 + 1];
            if (next && next !== " " && next !== "\n" && next !== "	")
              split = i2;
          }
          if (i2 >= end) {
            if (split) {
              folds.push(split);
              end = split + endStep;
              split = void 0;
            } else if (mode === FOLD_QUOTED) {
              while (prev === " " || prev === "	") {
                prev = ch;
                ch = text2[i2 += 1];
                overflow = true;
              }
              const j = i2 > escEnd + 1 ? i2 - 2 : escStart - 1;
              if (escapedFolds[j])
                return text2;
              folds.push(j);
              escapedFolds[j] = true;
              end = j + endStep;
              split = void 0;
            } else {
              overflow = true;
            }
          }
        }
        prev = ch;
      }
      if (overflow && onOverflow)
        onOverflow();
      if (folds.length === 0)
        return text2;
      if (onFold)
        onFold();
      let res = text2.slice(0, folds[0]);
      for (let i3 = 0; i3 < folds.length; ++i3) {
        const fold = folds[i3];
        const end2 = folds[i3 + 1] || text2.length;
        if (fold === 0)
          res = `
${indent}${text2.slice(0, end2)}`;
        else {
          if (mode === FOLD_QUOTED && escapedFolds[fold])
            res += `${text2[fold]}\\`;
          res += `
${indent}${text2.slice(fold + 1, end2)}`;
        }
      }
      return res;
    }
    function consumeMoreIndentedLines(text2, i2, indent) {
      let end = i2;
      let start2 = i2 + 1;
      let ch = text2[start2];
      while (ch === " " || ch === "	") {
        if (i2 < start2 + indent) {
          ch = text2[++i2];
        } else {
          do {
            ch = text2[++i2];
          } while (ch && ch !== "\n");
          end = i2;
          start2 = i2 + 1;
          ch = text2[start2];
        }
      }
      return end;
    }
    exports2.FOLD_BLOCK = FOLD_BLOCK;
    exports2.FOLD_FLOW = FOLD_FLOW;
    exports2.FOLD_QUOTED = FOLD_QUOTED;
    exports2.foldFlowLines = foldFlowLines;
  }
});

// node_modules/yaml/dist/stringify/stringifyString.js
var require_stringifyString = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyString.js"(exports2) {
    "use strict";
    var Scalar = require_Scalar();
    var foldFlowLines = require_foldFlowLines();
    var getFoldOptions = (ctx, isBlock) => ({
      indentAtStart: isBlock ? ctx.indent.length : ctx.indentAtStart,
      lineWidth: ctx.options.lineWidth,
      minContentWidth: ctx.options.minContentWidth
    });
    var containsDocumentMarker = (str) => /^(%|---|\.\.\.)/m.test(str);
    function lineLengthOverLimit(str, lineWidth, indentLength) {
      if (!lineWidth || lineWidth < 0)
        return false;
      const limit = lineWidth - indentLength;
      const strLen = str.length;
      if (strLen <= limit)
        return false;
      for (let i2 = 0, start2 = 0; i2 < strLen; ++i2) {
        if (str[i2] === "\n") {
          if (i2 - start2 > limit)
            return true;
          start2 = i2 + 1;
          if (strLen - start2 <= limit)
            return false;
        }
      }
      return true;
    }
    function doubleQuotedString(value, ctx) {
      const json3 = JSON.stringify(value);
      if (ctx.options.doubleQuotedAsJSON)
        return json3;
      const { implicitKey } = ctx;
      const minMultiLineLength = ctx.options.doubleQuotedMinMultiLineLength;
      const indent = ctx.indent || (containsDocumentMarker(value) ? "  " : "");
      let str = "";
      let start2 = 0;
      for (let i2 = 0, ch = json3[i2]; ch; ch = json3[++i2]) {
        if (ch === " " && json3[i2 + 1] === "\\" && json3[i2 + 2] === "n") {
          str += json3.slice(start2, i2) + "\\ ";
          i2 += 1;
          start2 = i2;
          ch = "\\";
        }
        if (ch === "\\")
          switch (json3[i2 + 1]) {
            case "u":
              {
                str += json3.slice(start2, i2);
                const code = json3.substr(i2 + 2, 4);
                switch (code) {
                  case "0000":
                    str += "\\0";
                    break;
                  case "0007":
                    str += "\\a";
                    break;
                  case "000b":
                    str += "\\v";
                    break;
                  case "001b":
                    str += "\\e";
                    break;
                  case "0085":
                    str += "\\N";
                    break;
                  case "00a0":
                    str += "\\_";
                    break;
                  case "2028":
                    str += "\\L";
                    break;
                  case "2029":
                    str += "\\P";
                    break;
                  default:
                    if (code.substr(0, 2) === "00")
                      str += "\\x" + code.substr(2);
                    else
                      str += json3.substr(i2, 6);
                }
                i2 += 5;
                start2 = i2 + 1;
              }
              break;
            case "n":
              if (implicitKey || json3[i2 + 2] === '"' || json3.length < minMultiLineLength) {
                i2 += 1;
              } else {
                str += json3.slice(start2, i2) + "\n\n";
                while (json3[i2 + 2] === "\\" && json3[i2 + 3] === "n" && json3[i2 + 4] !== '"') {
                  str += "\n";
                  i2 += 2;
                }
                str += indent;
                if (json3[i2 + 2] === " ")
                  str += "\\";
                i2 += 1;
                start2 = i2 + 1;
              }
              break;
            default:
              i2 += 1;
          }
      }
      str = start2 ? str + json3.slice(start2) : json3;
      return implicitKey ? str : foldFlowLines.foldFlowLines(str, indent, foldFlowLines.FOLD_QUOTED, getFoldOptions(ctx, false));
    }
    function singleQuotedString(value, ctx) {
      if (ctx.options.singleQuote === false || ctx.implicitKey && value.includes("\n") || /[ \t]\n|\n[ \t]/.test(value))
        return doubleQuotedString(value, ctx);
      const indent = ctx.indent || (containsDocumentMarker(value) ? "  " : "");
      const res = "'" + value.replace(/'/g, "''").replace(/\n+/g, `$&
${indent}`) + "'";
      return ctx.implicitKey ? res : foldFlowLines.foldFlowLines(res, indent, foldFlowLines.FOLD_FLOW, getFoldOptions(ctx, false));
    }
    function quotedString(value, ctx) {
      const { singleQuote: singleQuote2 } = ctx.options;
      let qs;
      if (singleQuote2 === false)
        qs = doubleQuotedString;
      else {
        const hasDouble = value.includes('"');
        const hasSingle = value.includes("'");
        if (hasDouble && !hasSingle)
          qs = singleQuotedString;
        else if (hasSingle && !hasDouble)
          qs = doubleQuotedString;
        else
          qs = singleQuote2 ? singleQuotedString : doubleQuotedString;
      }
      return qs(value, ctx);
    }
    var blockEndNewlines;
    try {
      blockEndNewlines = new RegExp("(^|(?<!\n))\n+(?!\n|$)", "g");
    } catch {
      blockEndNewlines = /\n+(?!\n|$)/g;
    }
    function blockString({ comment, type, value }, ctx, onComment, onChompKeep) {
      const { blockQuote, commentString, lineWidth } = ctx.options;
      if (!blockQuote || /\n[\t ]+$/.test(value)) {
        return quotedString(value, ctx);
      }
      const indent = ctx.indent || (ctx.forceBlockIndent || containsDocumentMarker(value) ? "  " : "");
      const literal = blockQuote === "literal" ? true : blockQuote === "folded" || type === Scalar.Scalar.BLOCK_FOLDED ? false : type === Scalar.Scalar.BLOCK_LITERAL ? true : !lineLengthOverLimit(value, lineWidth, indent.length);
      if (!value)
        return literal ? "|\n" : ">\n";
      let chomp;
      let endStart;
      for (endStart = value.length; endStart > 0; --endStart) {
        const ch = value[endStart - 1];
        if (ch !== "\n" && ch !== "	" && ch !== " ")
          break;
      }
      let end = value.substring(endStart);
      const endNlPos = end.indexOf("\n");
      if (endNlPos === -1) {
        chomp = "-";
      } else if (value === end || endNlPos !== end.length - 1) {
        chomp = "+";
        if (onChompKeep)
          onChompKeep();
      } else {
        chomp = "";
      }
      if (end) {
        value = value.slice(0, -end.length);
        if (end[end.length - 1] === "\n")
          end = end.slice(0, -1);
        end = end.replace(blockEndNewlines, `$&${indent}`);
      }
      let startWithSpace = false;
      let startEnd;
      let startNlPos = -1;
      for (startEnd = 0; startEnd < value.length; ++startEnd) {
        const ch = value[startEnd];
        if (ch === " ")
          startWithSpace = true;
        else if (ch === "\n")
          startNlPos = startEnd;
        else
          break;
      }
      let start2 = value.substring(0, startNlPos < startEnd ? startNlPos + 1 : startEnd);
      if (start2) {
        value = value.substring(start2.length);
        start2 = start2.replace(/\n+/g, `$&${indent}`);
      }
      const indentSize = indent ? "2" : "1";
      let header = (startWithSpace ? indentSize : "") + chomp;
      if (comment) {
        header += " " + commentString(comment.replace(/ ?[\r\n]+/g, " "));
        if (onComment)
          onComment();
      }
      if (!literal) {
        const foldedValue = value.replace(/\n+/g, "\n$&").replace(/(?:^|\n)([\t ].*)(?:([\n\t ]*)\n(?![\n\t ]))?/g, "$1$2").replace(/\n+/g, `$&${indent}`);
        let literalFallback = false;
        const foldOptions = getFoldOptions(ctx, true);
        if (blockQuote !== "folded" && type !== Scalar.Scalar.BLOCK_FOLDED) {
          foldOptions.onOverflow = () => {
            literalFallback = true;
          };
        }
        const body = foldFlowLines.foldFlowLines(`${start2}${foldedValue}${end}`, indent, foldFlowLines.FOLD_BLOCK, foldOptions);
        if (!literalFallback)
          return `>${header}
${indent}${body}`;
      }
      value = value.replace(/\n+/g, `$&${indent}`);
      return `|${header}
${indent}${start2}${value}${end}`;
    }
    function plainString(item, ctx, onComment, onChompKeep) {
      const { type, value } = item;
      const { actualString, implicitKey, indent, indentStep, inFlow } = ctx;
      if (implicitKey && value.includes("\n") || inFlow && /[[\]{},]/.test(value)) {
        return quotedString(value, ctx);
      }
      if (/^[\n\t ,[\]{}#&*!|>'"%@`]|^[?-]$|^[?-][ \t]|[\n:][ \t]|[ \t]\n|[\n\t ]#|[\n\t :]$/.test(value)) {
        return implicitKey || inFlow || !value.includes("\n") ? quotedString(value, ctx) : blockString(item, ctx, onComment, onChompKeep);
      }
      if (!implicitKey && !inFlow && type !== Scalar.Scalar.PLAIN && value.includes("\n")) {
        return blockString(item, ctx, onComment, onChompKeep);
      }
      if (containsDocumentMarker(value)) {
        if (indent === "") {
          ctx.forceBlockIndent = true;
          return blockString(item, ctx, onComment, onChompKeep);
        } else if (implicitKey && indent === indentStep) {
          return quotedString(value, ctx);
        }
      }
      const str = value.replace(/\n+/g, `$&
${indent}`);
      if (actualString) {
        const test = (tag) => tag.default && tag.tag !== "tag:yaml.org,2002:str" && tag.test?.test(str);
        const { compat, tags } = ctx.doc.schema;
        if (tags.some(test) || compat?.some(test))
          return quotedString(value, ctx);
      }
      return implicitKey ? str : foldFlowLines.foldFlowLines(str, indent, foldFlowLines.FOLD_FLOW, getFoldOptions(ctx, false));
    }
    function stringifyString(item, ctx, onComment, onChompKeep) {
      const { implicitKey, inFlow } = ctx;
      const ss = typeof item.value === "string" ? item : Object.assign({}, item, { value: String(item.value) });
      let { type } = item;
      if (type !== Scalar.Scalar.QUOTE_DOUBLE) {
        if (/[\x00-\x08\x0b-\x1f\x7f-\x9f\u{D800}-\u{DFFF}]/u.test(ss.value))
          type = Scalar.Scalar.QUOTE_DOUBLE;
      }
      const _stringify = (_type) => {
        switch (_type) {
          case Scalar.Scalar.BLOCK_FOLDED:
          case Scalar.Scalar.BLOCK_LITERAL:
            return implicitKey || inFlow ? quotedString(ss.value, ctx) : blockString(ss, ctx, onComment, onChompKeep);
          case Scalar.Scalar.QUOTE_DOUBLE:
            return doubleQuotedString(ss.value, ctx);
          case Scalar.Scalar.QUOTE_SINGLE:
            return singleQuotedString(ss.value, ctx);
          case Scalar.Scalar.PLAIN:
            return plainString(ss, ctx, onComment, onChompKeep);
          default:
            return null;
        }
      };
      let res = _stringify(type);
      if (res === null) {
        const { defaultKeyType, defaultStringType } = ctx.options;
        const t = implicitKey && defaultKeyType || defaultStringType;
        res = _stringify(t);
        if (res === null)
          throw new Error(`Unsupported default string type ${t}`);
      }
      return res;
    }
    exports2.stringifyString = stringifyString;
  }
});

// node_modules/yaml/dist/stringify/stringify.js
var require_stringify = __commonJS({
  "node_modules/yaml/dist/stringify/stringify.js"(exports2) {
    "use strict";
    var anchors = require_anchors();
    var identity2 = require_identity();
    var stringifyComment = require_stringifyComment();
    var stringifyString = require_stringifyString();
    function createStringifyContext(doc, options) {
      const opt = Object.assign({
        blockQuote: true,
        commentString: stringifyComment.stringifyComment,
        defaultKeyType: null,
        defaultStringType: "PLAIN",
        directives: null,
        doubleQuotedAsJSON: false,
        doubleQuotedMinMultiLineLength: 40,
        falseStr: "false",
        flowCollectionPadding: true,
        indentSeq: true,
        lineWidth: 80,
        minContentWidth: 20,
        nullStr: "null",
        simpleKeys: false,
        singleQuote: null,
        trailingComma: false,
        trueStr: "true",
        verifyAliasOrder: true
      }, doc.schema.toStringOptions, options);
      let inFlow;
      switch (opt.collectionStyle) {
        case "block":
          inFlow = false;
          break;
        case "flow":
          inFlow = true;
          break;
        default:
          inFlow = null;
      }
      return {
        anchors: /* @__PURE__ */ new Set(),
        doc,
        flowCollectionPadding: opt.flowCollectionPadding ? " " : "",
        indent: "",
        indentStep: typeof opt.indent === "number" ? " ".repeat(opt.indent) : "  ",
        inFlow,
        options: opt
      };
    }
    function getTagObject(tags, item) {
      if (item.tag) {
        const match = tags.filter((t) => t.tag === item.tag);
        if (match.length > 0)
          return match.find((t) => t.format === item.format) ?? match[0];
      }
      let tagObj = void 0;
      let obj;
      if (identity2.isScalar(item)) {
        obj = item.value;
        let match = tags.filter((t) => t.identify?.(obj));
        if (match.length > 1) {
          const testMatch = match.filter((t) => t.test);
          if (testMatch.length > 0)
            match = testMatch;
        }
        tagObj = match.find((t) => t.format === item.format) ?? match.find((t) => !t.format);
      } else {
        obj = item;
        tagObj = tags.find((t) => t.nodeClass && obj instanceof t.nodeClass);
      }
      if (!tagObj) {
        const name = obj?.constructor?.name ?? (obj === null ? "null" : typeof obj);
        throw new Error(`Tag not resolved for ${name} value`);
      }
      return tagObj;
    }
    function stringifyProps(node, tagObj, { anchors: anchors$1, doc }) {
      if (!doc.directives)
        return "";
      const props = [];
      const anchor = (identity2.isScalar(node) || identity2.isCollection(node)) && node.anchor;
      if (anchor && anchors.anchorIsValid(anchor)) {
        anchors$1.add(anchor);
        props.push(`&${anchor}`);
      }
      const tag = node.tag ?? (tagObj.default ? null : tagObj.tag);
      if (tag)
        props.push(doc.directives.tagString(tag));
      return props.join(" ");
    }
    function stringify2(item, ctx, onComment, onChompKeep) {
      if (identity2.isPair(item))
        return item.toString(ctx, onComment, onChompKeep);
      if (identity2.isAlias(item)) {
        if (ctx.doc.directives)
          return item.toString(ctx);
        if (ctx.resolvedAliases?.has(item)) {
          throw new TypeError(`Cannot stringify circular structure without alias nodes`);
        } else {
          if (ctx.resolvedAliases)
            ctx.resolvedAliases.add(item);
          else
            ctx.resolvedAliases = /* @__PURE__ */ new Set([item]);
          item = item.resolve(ctx.doc);
        }
      }
      let tagObj = void 0;
      const node = identity2.isNode(item) ? item : ctx.doc.createNode(item, { onTagObj: (o) => tagObj = o });
      tagObj ?? (tagObj = getTagObject(ctx.doc.schema.tags, node));
      const props = stringifyProps(node, tagObj, ctx);
      if (props.length > 0)
        ctx.indentAtStart = (ctx.indentAtStart ?? 0) + props.length + 1;
      const str = typeof tagObj.stringify === "function" ? tagObj.stringify(node, ctx, onComment, onChompKeep) : identity2.isScalar(node) ? stringifyString.stringifyString(node, ctx, onComment, onChompKeep) : node.toString(ctx, onComment, onChompKeep);
      if (!props)
        return str;
      return identity2.isScalar(node) || str[0] === "{" || str[0] === "[" ? `${props} ${str}` : `${props}
${ctx.indent}${str}`;
    }
    exports2.createStringifyContext = createStringifyContext;
    exports2.stringify = stringify2;
  }
});

// node_modules/yaml/dist/stringify/stringifyPair.js
var require_stringifyPair = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyPair.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var Scalar = require_Scalar();
    var stringify2 = require_stringify();
    var stringifyComment = require_stringifyComment();
    function stringifyPair({ key, value }, ctx, onComment, onChompKeep) {
      const { allNullValues, doc, indent, indentStep, options: { commentString, indentSeq, simpleKeys } } = ctx;
      let keyComment = identity2.isNode(key) && key.comment || null;
      if (simpleKeys) {
        if (keyComment) {
          throw new Error("With simple keys, key nodes cannot have comments");
        }
        if (identity2.isCollection(key) || !identity2.isNode(key) && typeof key === "object") {
          const msg = "With simple keys, collection cannot be used as a key value";
          throw new Error(msg);
        }
      }
      let explicitKey = !simpleKeys && (!key || keyComment && value == null && !ctx.inFlow || identity2.isCollection(key) || (identity2.isScalar(key) ? key.type === Scalar.Scalar.BLOCK_FOLDED || key.type === Scalar.Scalar.BLOCK_LITERAL : typeof key === "object"));
      ctx = Object.assign({}, ctx, {
        allNullValues: false,
        implicitKey: !explicitKey && (simpleKeys || !allNullValues),
        indent: indent + indentStep
      });
      let keyCommentDone = false;
      let chompKeep = false;
      let str = stringify2.stringify(key, ctx, () => keyCommentDone = true, () => chompKeep = true);
      if (!explicitKey && !ctx.inFlow && str.length > 1024) {
        if (simpleKeys)
          throw new Error("With simple keys, single line scalar must not span more than 1024 characters");
        explicitKey = true;
      }
      if (ctx.inFlow) {
        if (allNullValues || value == null) {
          if (keyCommentDone && onComment)
            onComment();
          return str === "" ? "?" : explicitKey ? `? ${str}` : str;
        }
      } else if (allNullValues && !simpleKeys || value == null && explicitKey) {
        str = `? ${str}`;
        if (keyComment && !keyCommentDone) {
          str += stringifyComment.lineComment(str, ctx.indent, commentString(keyComment));
        } else if (chompKeep && onChompKeep)
          onChompKeep();
        return str;
      }
      if (keyCommentDone)
        keyComment = null;
      if (explicitKey) {
        if (keyComment)
          str += stringifyComment.lineComment(str, ctx.indent, commentString(keyComment));
        str = `? ${str}
${indent}:`;
      } else {
        str = `${str}:`;
        if (keyComment)
          str += stringifyComment.lineComment(str, ctx.indent, commentString(keyComment));
      }
      let vsb, vcb, valueComment;
      if (identity2.isNode(value)) {
        vsb = !!value.spaceBefore;
        vcb = value.commentBefore;
        valueComment = value.comment;
      } else {
        vsb = false;
        vcb = null;
        valueComment = null;
        if (value && typeof value === "object")
          value = doc.createNode(value);
      }
      ctx.implicitKey = false;
      if (!explicitKey && !keyComment && identity2.isScalar(value))
        ctx.indentAtStart = str.length + 1;
      chompKeep = false;
      if (!indentSeq && indentStep.length >= 2 && !ctx.inFlow && !explicitKey && identity2.isSeq(value) && !value.flow && !value.tag && !value.anchor) {
        ctx.indent = ctx.indent.substring(2);
      }
      let valueCommentDone = false;
      const valueStr = stringify2.stringify(value, ctx, () => valueCommentDone = true, () => chompKeep = true);
      let ws = " ";
      if (keyComment || vsb || vcb) {
        ws = vsb ? "\n" : "";
        if (vcb) {
          const cs = commentString(vcb);
          ws += `
${stringifyComment.indentComment(cs, ctx.indent)}`;
        }
        if (valueStr === "" && !ctx.inFlow) {
          if (ws === "\n" && valueComment)
            ws = "\n\n";
        } else {
          ws += `
${ctx.indent}`;
        }
      } else if (!explicitKey && identity2.isCollection(value)) {
        const vs0 = valueStr[0];
        const nl0 = valueStr.indexOf("\n");
        const hasNewline = nl0 !== -1;
        const flow = ctx.inFlow ?? value.flow ?? value.items.length === 0;
        if (hasNewline || !flow) {
          let hasPropsLine = false;
          if (hasNewline && (vs0 === "&" || vs0 === "!")) {
            let sp0 = valueStr.indexOf(" ");
            if (vs0 === "&" && sp0 !== -1 && sp0 < nl0 && valueStr[sp0 + 1] === "!") {
              sp0 = valueStr.indexOf(" ", sp0 + 1);
            }
            if (sp0 === -1 || nl0 < sp0)
              hasPropsLine = true;
          }
          if (!hasPropsLine)
            ws = `
${ctx.indent}`;
        }
      } else if (valueStr === "" || valueStr[0] === "\n") {
        ws = "";
      }
      str += ws + valueStr;
      if (ctx.inFlow) {
        if (valueCommentDone && onComment)
          onComment();
      } else if (valueComment && !valueCommentDone) {
        str += stringifyComment.lineComment(str, ctx.indent, commentString(valueComment));
      } else if (chompKeep && onChompKeep) {
        onChompKeep();
      }
      return str;
    }
    exports2.stringifyPair = stringifyPair;
  }
});

// node_modules/yaml/dist/log.js
var require_log = __commonJS({
  "node_modules/yaml/dist/log.js"(exports2) {
    "use strict";
    var node_process = __require("process");
    function debug(logLevel, ...messages) {
      if (logLevel === "debug")
        console.log(...messages);
    }
    function warn(logLevel, warning) {
      if (logLevel === "debug" || logLevel === "warn") {
        if (typeof node_process.emitWarning === "function")
          node_process.emitWarning(warning);
        else
          console.warn(warning);
      }
    }
    exports2.debug = debug;
    exports2.warn = warn;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/merge.js
var require_merge = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/merge.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var Scalar = require_Scalar();
    var MERGE_KEY = "<<";
    var merge = {
      identify: (value) => value === MERGE_KEY || typeof value === "symbol" && value.description === MERGE_KEY,
      default: "key",
      tag: "tag:yaml.org,2002:merge",
      test: /^<<$/,
      resolve: () => Object.assign(new Scalar.Scalar(Symbol(MERGE_KEY)), {
        addToJSMap: addMergeToJSMap
      }),
      stringify: () => MERGE_KEY
    };
    var isMergeKey = (ctx, key) => (merge.identify(key) || identity2.isScalar(key) && (!key.type || key.type === Scalar.Scalar.PLAIN) && merge.identify(key.value)) && ctx?.doc.schema.tags.some((tag) => tag.tag === merge.tag && tag.default);
    function addMergeToJSMap(ctx, map, value) {
      const source2 = resolveAliasValue(ctx, value);
      if (identity2.isSeq(source2))
        for (const it of source2.items)
          mergeValue(ctx, map, it);
      else if (Array.isArray(source2))
        for (const it of source2)
          mergeValue(ctx, map, it);
      else
        mergeValue(ctx, map, source2);
    }
    function mergeValue(ctx, map, value) {
      const source2 = resolveAliasValue(ctx, value);
      if (!identity2.isMap(source2))
        throw new Error("Merge sources must be maps or map aliases");
      const srcMap = source2.toJSON(null, ctx, Map);
      for (const [key, value2] of srcMap) {
        if (map instanceof Map) {
          if (!map.has(key))
            map.set(key, value2);
        } else if (map instanceof Set) {
          map.add(key);
        } else if (!Object.prototype.hasOwnProperty.call(map, key)) {
          Object.defineProperty(map, key, {
            value: value2,
            writable: true,
            enumerable: true,
            configurable: true
          });
        }
      }
      return map;
    }
    function resolveAliasValue(ctx, value) {
      return ctx && identity2.isAlias(value) ? value.resolve(ctx.doc, ctx) : value;
    }
    exports2.addMergeToJSMap = addMergeToJSMap;
    exports2.isMergeKey = isMergeKey;
    exports2.merge = merge;
  }
});

// node_modules/yaml/dist/nodes/addPairToJSMap.js
var require_addPairToJSMap = __commonJS({
  "node_modules/yaml/dist/nodes/addPairToJSMap.js"(exports2) {
    "use strict";
    var log = require_log();
    var merge = require_merge();
    var stringify2 = require_stringify();
    var identity2 = require_identity();
    var toJS = require_toJS();
    function addPairToJSMap(ctx, map, { key, value }) {
      if (identity2.isNode(key) && key.addToJSMap)
        key.addToJSMap(ctx, map, value);
      else if (merge.isMergeKey(ctx, key))
        merge.addMergeToJSMap(ctx, map, value);
      else {
        const jsKey = toJS.toJS(key, "", ctx);
        if (map instanceof Map) {
          map.set(jsKey, toJS.toJS(value, jsKey, ctx));
        } else if (map instanceof Set) {
          map.add(jsKey);
        } else {
          const stringKey = stringifyKey(key, jsKey, ctx);
          const jsValue = toJS.toJS(value, stringKey, ctx);
          if (stringKey in map)
            Object.defineProperty(map, stringKey, {
              value: jsValue,
              writable: true,
              enumerable: true,
              configurable: true
            });
          else
            map[stringKey] = jsValue;
        }
      }
      return map;
    }
    function stringifyKey(key, jsKey, ctx) {
      if (jsKey === null)
        return "";
      if (typeof jsKey !== "object")
        return String(jsKey);
      if (identity2.isNode(key) && ctx?.doc) {
        const strCtx = stringify2.createStringifyContext(ctx.doc, {});
        strCtx.anchors = /* @__PURE__ */ new Set();
        for (const node of ctx.anchors.keys())
          strCtx.anchors.add(node.anchor);
        strCtx.inFlow = true;
        strCtx.inStringifyKey = true;
        const strKey = key.toString(strCtx);
        if (!ctx.mapKeyWarned) {
          let jsonStr = JSON.stringify(strKey);
          if (jsonStr.length > 40)
            jsonStr = jsonStr.substring(0, 36) + '..."';
          log.warn(ctx.doc.options.logLevel, `Keys with collection values will be stringified due to JS Object restrictions: ${jsonStr}. Set mapAsMap: true to use object keys.`);
          ctx.mapKeyWarned = true;
        }
        return strKey;
      }
      return JSON.stringify(jsKey);
    }
    exports2.addPairToJSMap = addPairToJSMap;
  }
});

// node_modules/yaml/dist/nodes/Pair.js
var require_Pair = __commonJS({
  "node_modules/yaml/dist/nodes/Pair.js"(exports2) {
    "use strict";
    var createNode = require_createNode();
    var stringifyPair = require_stringifyPair();
    var addPairToJSMap = require_addPairToJSMap();
    var identity2 = require_identity();
    function createPair(key, value, ctx) {
      const k = createNode.createNode(key, void 0, ctx);
      const v = createNode.createNode(value, void 0, ctx);
      return new Pair(k, v);
    }
    var Pair = class _Pair {
      constructor(key, value = null) {
        Object.defineProperty(this, identity2.NODE_TYPE, { value: identity2.PAIR });
        this.key = key;
        this.value = value;
      }
      clone(schema2) {
        let { key, value } = this;
        if (identity2.isNode(key))
          key = key.clone(schema2);
        if (identity2.isNode(value))
          value = value.clone(schema2);
        return new _Pair(key, value);
      }
      toJSON(_, ctx) {
        const pair = ctx?.mapAsMap ? /* @__PURE__ */ new Map() : {};
        return addPairToJSMap.addPairToJSMap(ctx, pair, this);
      }
      toString(ctx, onComment, onChompKeep) {
        return ctx?.doc ? stringifyPair.stringifyPair(this, ctx, onComment, onChompKeep) : JSON.stringify(this);
      }
    };
    exports2.Pair = Pair;
    exports2.createPair = createPair;
  }
});

// node_modules/yaml/dist/stringify/stringifyCollection.js
var require_stringifyCollection = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyCollection.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var stringify2 = require_stringify();
    var stringifyComment = require_stringifyComment();
    function stringifyCollection(collection, ctx, options) {
      const flow = ctx.inFlow ?? collection.flow;
      const stringify3 = flow ? stringifyFlowCollection : stringifyBlockCollection;
      return stringify3(collection, ctx, options);
    }
    function stringifyBlockCollection({ comment, items }, ctx, { blockItemPrefix, flowChars, itemIndent, onChompKeep, onComment }) {
      const { indent, options: { commentString } } = ctx;
      const itemCtx = Object.assign({}, ctx, { indent: itemIndent, type: null });
      let chompKeep = false;
      const lines = [];
      for (let i2 = 0; i2 < items.length; ++i2) {
        const item = items[i2];
        let comment2 = null;
        if (identity2.isNode(item)) {
          if (!chompKeep && item.spaceBefore)
            lines.push("");
          addCommentBefore(ctx, lines, item.commentBefore, chompKeep);
          if (item.comment)
            comment2 = item.comment;
        } else if (identity2.isPair(item)) {
          const ik = identity2.isNode(item.key) ? item.key : null;
          if (ik) {
            if (!chompKeep && ik.spaceBefore)
              lines.push("");
            addCommentBefore(ctx, lines, ik.commentBefore, chompKeep);
          }
        }
        chompKeep = false;
        let str2 = stringify2.stringify(item, itemCtx, () => comment2 = null, () => chompKeep = true);
        if (comment2)
          str2 += stringifyComment.lineComment(str2, itemIndent, commentString(comment2));
        if (chompKeep && comment2)
          chompKeep = false;
        lines.push(blockItemPrefix + str2);
      }
      let str;
      if (lines.length === 0) {
        str = flowChars.start + flowChars.end;
      } else {
        str = lines[0];
        for (let i2 = 1; i2 < lines.length; ++i2) {
          const line = lines[i2];
          str += line ? `
${indent}${line}` : "\n";
        }
      }
      if (comment) {
        str += "\n" + stringifyComment.indentComment(commentString(comment), indent);
        if (onComment)
          onComment();
      } else if (chompKeep && onChompKeep)
        onChompKeep();
      return str;
    }
    function stringifyFlowCollection({ items }, ctx, { flowChars, itemIndent }) {
      const { indent, indentStep, flowCollectionPadding: fcPadding, options: { commentString } } = ctx;
      itemIndent += indentStep;
      const itemCtx = Object.assign({}, ctx, {
        indent: itemIndent,
        inFlow: true,
        type: null
      });
      let reqNewline = false;
      let linesAtValue = 0;
      const lines = [];
      for (let i2 = 0; i2 < items.length; ++i2) {
        const item = items[i2];
        let comment = null;
        if (identity2.isNode(item)) {
          if (item.spaceBefore)
            lines.push("");
          addCommentBefore(ctx, lines, item.commentBefore, false);
          if (item.comment)
            comment = item.comment;
        } else if (identity2.isPair(item)) {
          const ik = identity2.isNode(item.key) ? item.key : null;
          if (ik) {
            if (ik.spaceBefore)
              lines.push("");
            addCommentBefore(ctx, lines, ik.commentBefore, false);
            if (ik.comment)
              reqNewline = true;
          }
          const iv = identity2.isNode(item.value) ? item.value : null;
          if (iv) {
            if (iv.comment)
              comment = iv.comment;
            if (iv.commentBefore)
              reqNewline = true;
          } else if (item.value == null && ik?.comment) {
            comment = ik.comment;
          }
        }
        if (comment)
          reqNewline = true;
        let str = stringify2.stringify(item, itemCtx, () => comment = null);
        reqNewline || (reqNewline = lines.length > linesAtValue || str.includes("\n"));
        if (i2 < items.length - 1) {
          str += ",";
        } else if (ctx.options.trailingComma) {
          if (ctx.options.lineWidth > 0) {
            reqNewline || (reqNewline = lines.reduce((sum, line) => sum + line.length + 2, 2) + (str.length + 2) > ctx.options.lineWidth);
          }
          if (reqNewline) {
            str += ",";
          }
        }
        if (comment)
          str += stringifyComment.lineComment(str, itemIndent, commentString(comment));
        lines.push(str);
        linesAtValue = lines.length;
      }
      const { start: start2, end } = flowChars;
      if (lines.length === 0) {
        return start2 + end;
      } else {
        if (!reqNewline) {
          const len = lines.reduce((sum, line) => sum + line.length + 2, 2);
          reqNewline = ctx.options.lineWidth > 0 && len > ctx.options.lineWidth;
        }
        if (reqNewline) {
          let str = start2;
          for (const line of lines)
            str += line ? `
${indentStep}${indent}${line}` : "\n";
          return `${str}
${indent}${end}`;
        } else {
          return `${start2}${fcPadding}${lines.join(" ")}${fcPadding}${end}`;
        }
      }
    }
    function addCommentBefore({ indent, options: { commentString } }, lines, comment, chompKeep) {
      if (comment && chompKeep)
        comment = comment.replace(/^\n+/, "");
      if (comment) {
        const ic = stringifyComment.indentComment(commentString(comment), indent);
        lines.push(ic.trimStart());
      }
    }
    exports2.stringifyCollection = stringifyCollection;
  }
});

// node_modules/yaml/dist/nodes/YAMLMap.js
var require_YAMLMap = __commonJS({
  "node_modules/yaml/dist/nodes/YAMLMap.js"(exports2) {
    "use strict";
    var stringifyCollection = require_stringifyCollection();
    var addPairToJSMap = require_addPairToJSMap();
    var Collection = require_Collection();
    var identity2 = require_identity();
    var Pair = require_Pair();
    var Scalar = require_Scalar();
    function findPair(items, key) {
      const k = identity2.isScalar(key) ? key.value : key;
      for (const it of items) {
        if (identity2.isPair(it)) {
          if (it.key === key || it.key === k)
            return it;
          if (identity2.isScalar(it.key) && it.key.value === k)
            return it;
        }
      }
      return void 0;
    }
    var YAMLMap = class extends Collection.Collection {
      static get tagName() {
        return "tag:yaml.org,2002:map";
      }
      constructor(schema2) {
        super(identity2.MAP, schema2);
        this.items = [];
      }
      /**
       * A generic collection parsing method that can be extended
       * to other node classes that inherit from YAMLMap
       */
      static from(schema2, obj, ctx) {
        const { keepUndefined, replacer } = ctx;
        const map = new this(schema2);
        const add3 = (key, value) => {
          if (typeof replacer === "function")
            value = replacer.call(obj, key, value);
          else if (Array.isArray(replacer) && !replacer.includes(key))
            return;
          if (value !== void 0 || keepUndefined)
            map.items.push(Pair.createPair(key, value, ctx));
        };
        if (obj instanceof Map) {
          for (const [key, value] of obj)
            add3(key, value);
        } else if (obj && typeof obj === "object") {
          for (const key of Object.keys(obj))
            add3(key, obj[key]);
        }
        if (typeof schema2.sortMapEntries === "function") {
          map.items.sort(schema2.sortMapEntries);
        }
        return map;
      }
      /**
       * Adds a value to the collection.
       *
       * @param overwrite - If not set `true`, using a key that is already in the
       *   collection will throw. Otherwise, overwrites the previous value.
       */
      add(pair, overwrite) {
        let _pair;
        if (identity2.isPair(pair))
          _pair = pair;
        else if (!pair || typeof pair !== "object" || !("key" in pair)) {
          _pair = new Pair.Pair(pair, pair?.value);
        } else
          _pair = new Pair.Pair(pair.key, pair.value);
        const prev = findPair(this.items, _pair.key);
        const sortEntries = this.schema?.sortMapEntries;
        if (prev) {
          if (!overwrite)
            throw new Error(`Key ${_pair.key} already set`);
          if (identity2.isScalar(prev.value) && Scalar.isScalarValue(_pair.value))
            prev.value.value = _pair.value;
          else
            prev.value = _pair.value;
        } else if (sortEntries) {
          const i2 = this.items.findIndex((item) => sortEntries(_pair, item) < 0);
          if (i2 === -1)
            this.items.push(_pair);
          else
            this.items.splice(i2, 0, _pair);
        } else {
          this.items.push(_pair);
        }
      }
      delete(key) {
        const it = findPair(this.items, key);
        if (!it)
          return false;
        const del = this.items.splice(this.items.indexOf(it), 1);
        return del.length > 0;
      }
      get(key, keepScalar) {
        const it = findPair(this.items, key);
        const node = it?.value;
        return (!keepScalar && identity2.isScalar(node) ? node.value : node) ?? void 0;
      }
      has(key) {
        return !!findPair(this.items, key);
      }
      set(key, value) {
        this.add(new Pair.Pair(key, value), true);
      }
      /**
       * @param ctx - Conversion context, originally set in Document#toJS()
       * @param {Class} Type - If set, forces the returned collection type
       * @returns Instance of Type, Map, or Object
       */
      toJSON(_, ctx, Type) {
        const map = Type ? new Type() : ctx?.mapAsMap ? /* @__PURE__ */ new Map() : {};
        if (ctx?.onCreate)
          ctx.onCreate(map);
        for (const item of this.items)
          addPairToJSMap.addPairToJSMap(ctx, map, item);
        return map;
      }
      toString(ctx, onComment, onChompKeep) {
        if (!ctx)
          return JSON.stringify(this);
        for (const item of this.items) {
          if (!identity2.isPair(item))
            throw new Error(`Map items must all be pairs; found ${JSON.stringify(item)} instead`);
        }
        if (!ctx.allNullValues && this.hasAllNullValues(false))
          ctx = Object.assign({}, ctx, { allNullValues: true });
        return stringifyCollection.stringifyCollection(this, ctx, {
          blockItemPrefix: "",
          flowChars: { start: "{", end: "}" },
          itemIndent: ctx.indent || "",
          onChompKeep,
          onComment
        });
      }
    };
    exports2.YAMLMap = YAMLMap;
    exports2.findPair = findPair;
  }
});

// node_modules/yaml/dist/schema/common/map.js
var require_map = __commonJS({
  "node_modules/yaml/dist/schema/common/map.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var YAMLMap = require_YAMLMap();
    var map = {
      collection: "map",
      default: true,
      nodeClass: YAMLMap.YAMLMap,
      tag: "tag:yaml.org,2002:map",
      resolve(map2, onError) {
        if (!identity2.isMap(map2))
          onError("Expected a mapping for this tag");
        return map2;
      },
      createNode: (schema2, obj, ctx) => YAMLMap.YAMLMap.from(schema2, obj, ctx)
    };
    exports2.map = map;
  }
});

// node_modules/yaml/dist/nodes/YAMLSeq.js
var require_YAMLSeq = __commonJS({
  "node_modules/yaml/dist/nodes/YAMLSeq.js"(exports2) {
    "use strict";
    var createNode = require_createNode();
    var stringifyCollection = require_stringifyCollection();
    var Collection = require_Collection();
    var identity2 = require_identity();
    var Scalar = require_Scalar();
    var toJS = require_toJS();
    var YAMLSeq = class extends Collection.Collection {
      static get tagName() {
        return "tag:yaml.org,2002:seq";
      }
      constructor(schema2) {
        super(identity2.SEQ, schema2);
        this.items = [];
      }
      add(value) {
        this.items.push(value);
      }
      /**
       * Removes a value from the collection.
       *
       * `key` must contain a representation of an integer for this to succeed.
       * It may be wrapped in a `Scalar`.
       *
       * @returns `true` if the item was found and removed.
       */
      delete(key) {
        const idx = asItemIndex(key);
        if (typeof idx !== "number")
          return false;
        const del = this.items.splice(idx, 1);
        return del.length > 0;
      }
      get(key, keepScalar) {
        const idx = asItemIndex(key);
        if (typeof idx !== "number")
          return void 0;
        const it = this.items[idx];
        return !keepScalar && identity2.isScalar(it) ? it.value : it;
      }
      /**
       * Checks if the collection includes a value with the key `key`.
       *
       * `key` must contain a representation of an integer for this to succeed.
       * It may be wrapped in a `Scalar`.
       */
      has(key) {
        const idx = asItemIndex(key);
        return typeof idx === "number" && idx < this.items.length;
      }
      /**
       * Sets a value in this collection. For `!!set`, `value` needs to be a
       * boolean to add/remove the item from the set.
       *
       * If `key` does not contain a representation of an integer, this will throw.
       * It may be wrapped in a `Scalar`.
       */
      set(key, value) {
        const idx = asItemIndex(key);
        if (typeof idx !== "number")
          throw new Error(`Expected a valid index, not ${key}.`);
        const prev = this.items[idx];
        if (identity2.isScalar(prev) && Scalar.isScalarValue(value))
          prev.value = value;
        else
          this.items[idx] = value;
      }
      toJSON(_, ctx) {
        const seq = [];
        if (ctx?.onCreate)
          ctx.onCreate(seq);
        let i2 = 0;
        for (const item of this.items)
          seq.push(toJS.toJS(item, String(i2++), ctx));
        return seq;
      }
      toString(ctx, onComment, onChompKeep) {
        if (!ctx)
          return JSON.stringify(this);
        return stringifyCollection.stringifyCollection(this, ctx, {
          blockItemPrefix: "- ",
          flowChars: { start: "[", end: "]" },
          itemIndent: (ctx.indent || "") + "  ",
          onChompKeep,
          onComment
        });
      }
      static from(schema2, obj, ctx) {
        const { replacer } = ctx;
        const seq = new this(schema2);
        if (obj && Symbol.iterator in Object(obj)) {
          let i2 = 0;
          for (let it of obj) {
            if (typeof replacer === "function") {
              const key = obj instanceof Set ? it : String(i2++);
              it = replacer.call(obj, key, it);
            }
            seq.items.push(createNode.createNode(it, void 0, ctx));
          }
        }
        return seq;
      }
    };
    function asItemIndex(key) {
      let idx = identity2.isScalar(key) ? key.value : key;
      if (idx && typeof idx === "string")
        idx = Number(idx);
      return typeof idx === "number" && Number.isInteger(idx) && idx >= 0 ? idx : null;
    }
    exports2.YAMLSeq = YAMLSeq;
  }
});

// node_modules/yaml/dist/schema/common/seq.js
var require_seq = __commonJS({
  "node_modules/yaml/dist/schema/common/seq.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var YAMLSeq = require_YAMLSeq();
    var seq = {
      collection: "seq",
      default: true,
      nodeClass: YAMLSeq.YAMLSeq,
      tag: "tag:yaml.org,2002:seq",
      resolve(seq2, onError) {
        if (!identity2.isSeq(seq2))
          onError("Expected a sequence for this tag");
        return seq2;
      },
      createNode: (schema2, obj, ctx) => YAMLSeq.YAMLSeq.from(schema2, obj, ctx)
    };
    exports2.seq = seq;
  }
});

// node_modules/yaml/dist/schema/common/string.js
var require_string = __commonJS({
  "node_modules/yaml/dist/schema/common/string.js"(exports2) {
    "use strict";
    var stringifyString = require_stringifyString();
    var string = {
      identify: (value) => typeof value === "string",
      default: true,
      tag: "tag:yaml.org,2002:str",
      resolve: (str) => str,
      stringify(item, ctx, onComment, onChompKeep) {
        ctx = Object.assign({ actualString: true }, ctx);
        return stringifyString.stringifyString(item, ctx, onComment, onChompKeep);
      }
    };
    exports2.string = string;
  }
});

// node_modules/yaml/dist/schema/common/null.js
var require_null = __commonJS({
  "node_modules/yaml/dist/schema/common/null.js"(exports2) {
    "use strict";
    var Scalar = require_Scalar();
    var nullTag = {
      identify: (value) => value == null,
      createNode: () => new Scalar.Scalar(null),
      default: true,
      tag: "tag:yaml.org,2002:null",
      test: /^(?:~|[Nn]ull|NULL)?$/,
      resolve: () => new Scalar.Scalar(null),
      stringify: ({ source: source2 }, ctx) => typeof source2 === "string" && nullTag.test.test(source2) ? source2 : ctx.options.nullStr
    };
    exports2.nullTag = nullTag;
  }
});

// node_modules/yaml/dist/schema/core/bool.js
var require_bool = __commonJS({
  "node_modules/yaml/dist/schema/core/bool.js"(exports2) {
    "use strict";
    var Scalar = require_Scalar();
    var boolTag = {
      identify: (value) => typeof value === "boolean",
      default: true,
      tag: "tag:yaml.org,2002:bool",
      test: /^(?:[Tt]rue|TRUE|[Ff]alse|FALSE)$/,
      resolve: (str) => new Scalar.Scalar(str[0] === "t" || str[0] === "T"),
      stringify({ source: source2, value }, ctx) {
        if (source2 && boolTag.test.test(source2)) {
          const sv = source2[0] === "t" || source2[0] === "T";
          if (value === sv)
            return source2;
        }
        return value ? ctx.options.trueStr : ctx.options.falseStr;
      }
    };
    exports2.boolTag = boolTag;
  }
});

// node_modules/yaml/dist/stringify/stringifyNumber.js
var require_stringifyNumber = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyNumber.js"(exports2) {
    "use strict";
    function stringifyNumber({ format, minFractionDigits, tag, value }) {
      if (typeof value === "bigint")
        return String(value);
      const num = typeof value === "number" ? value : Number(value);
      if (!isFinite(num))
        return isNaN(num) ? ".nan" : num < 0 ? "-.inf" : ".inf";
      let n = Object.is(value, -0) ? "-0" : JSON.stringify(value);
      if (!format && minFractionDigits && (!tag || tag === "tag:yaml.org,2002:float") && /^-?\d/.test(n) && !n.includes("e")) {
        let i2 = n.indexOf(".");
        if (i2 < 0) {
          i2 = n.length;
          n += ".";
        }
        let d = minFractionDigits - (n.length - i2 - 1);
        while (d-- > 0)
          n += "0";
      }
      return n;
    }
    exports2.stringifyNumber = stringifyNumber;
  }
});

// node_modules/yaml/dist/schema/core/float.js
var require_float = __commonJS({
  "node_modules/yaml/dist/schema/core/float.js"(exports2) {
    "use strict";
    var Scalar = require_Scalar();
    var stringifyNumber = require_stringifyNumber();
    var floatNaN = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      test: /^(?:[-+]?\.(?:inf|Inf|INF)|\.nan|\.NaN|\.NAN)$/,
      resolve: (str) => str.slice(-3).toLowerCase() === "nan" ? NaN : str[0] === "-" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY,
      stringify: stringifyNumber.stringifyNumber
    };
    var floatExp = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      format: "EXP",
      test: /^[-+]?(?:\.[0-9]+|[0-9]+(?:\.[0-9]*)?)[eE][-+]?[0-9]+$/,
      resolve: (str) => parseFloat(str),
      stringify(node) {
        const num = Number(node.value);
        return isFinite(num) ? num.toExponential() : stringifyNumber.stringifyNumber(node);
      }
    };
    var float = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      test: /^[-+]?(?:\.[0-9]+|[0-9]+\.[0-9]*)$/,
      resolve(str) {
        const node = new Scalar.Scalar(parseFloat(str));
        const dot = str.indexOf(".");
        if (dot !== -1 && str[str.length - 1] === "0")
          node.minFractionDigits = str.length - dot - 1;
        return node;
      },
      stringify: stringifyNumber.stringifyNumber
    };
    exports2.float = float;
    exports2.floatExp = floatExp;
    exports2.floatNaN = floatNaN;
  }
});

// node_modules/yaml/dist/schema/core/int.js
var require_int = __commonJS({
  "node_modules/yaml/dist/schema/core/int.js"(exports2) {
    "use strict";
    var stringifyNumber = require_stringifyNumber();
    var intIdentify = (value) => typeof value === "bigint" || Number.isInteger(value);
    var intResolve = (str, offset, radix, { intAsBigInt }) => intAsBigInt ? BigInt(str) : parseInt(str.substring(offset), radix);
    function intStringify(node, radix, prefix) {
      const { value } = node;
      if (intIdentify(value) && value >= 0)
        return prefix + value.toString(radix);
      return stringifyNumber.stringifyNumber(node);
    }
    var intOct = {
      identify: (value) => intIdentify(value) && value >= 0,
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "OCT",
      test: /^0o[0-7]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 2, 8, opt),
      stringify: (node) => intStringify(node, 8, "0o")
    };
    var int = {
      identify: intIdentify,
      default: true,
      tag: "tag:yaml.org,2002:int",
      test: /^[-+]?[0-9]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 0, 10, opt),
      stringify: stringifyNumber.stringifyNumber
    };
    var intHex = {
      identify: (value) => intIdentify(value) && value >= 0,
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "HEX",
      test: /^0x[0-9a-fA-F]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 2, 16, opt),
      stringify: (node) => intStringify(node, 16, "0x")
    };
    exports2.int = int;
    exports2.intHex = intHex;
    exports2.intOct = intOct;
  }
});

// node_modules/yaml/dist/schema/core/schema.js
var require_schema = __commonJS({
  "node_modules/yaml/dist/schema/core/schema.js"(exports2) {
    "use strict";
    var map = require_map();
    var _null = require_null();
    var seq = require_seq();
    var string = require_string();
    var bool = require_bool();
    var float = require_float();
    var int = require_int();
    var schema2 = [
      map.map,
      seq.seq,
      string.string,
      _null.nullTag,
      bool.boolTag,
      int.intOct,
      int.int,
      int.intHex,
      float.floatNaN,
      float.floatExp,
      float.float
    ];
    exports2.schema = schema2;
  }
});

// node_modules/yaml/dist/schema/json/schema.js
var require_schema2 = __commonJS({
  "node_modules/yaml/dist/schema/json/schema.js"(exports2) {
    "use strict";
    var Scalar = require_Scalar();
    var map = require_map();
    var seq = require_seq();
    function intIdentify(value) {
      return typeof value === "bigint" || Number.isInteger(value);
    }
    var stringifyJSON = ({ value }) => JSON.stringify(value);
    var jsonScalars = [
      {
        identify: (value) => typeof value === "string",
        default: true,
        tag: "tag:yaml.org,2002:str",
        resolve: (str) => str,
        stringify: stringifyJSON
      },
      {
        identify: (value) => value == null,
        createNode: () => new Scalar.Scalar(null),
        default: true,
        tag: "tag:yaml.org,2002:null",
        test: /^null$/,
        resolve: () => null,
        stringify: stringifyJSON
      },
      {
        identify: (value) => typeof value === "boolean",
        default: true,
        tag: "tag:yaml.org,2002:bool",
        test: /^true$|^false$/,
        resolve: (str) => str === "true",
        stringify: stringifyJSON
      },
      {
        identify: intIdentify,
        default: true,
        tag: "tag:yaml.org,2002:int",
        test: /^-?(?:0|[1-9][0-9]*)$/,
        resolve: (str, _onError, { intAsBigInt }) => intAsBigInt ? BigInt(str) : parseInt(str, 10),
        stringify: ({ value }) => intIdentify(value) ? value.toString() : JSON.stringify(value)
      },
      {
        identify: (value) => typeof value === "number",
        default: true,
        tag: "tag:yaml.org,2002:float",
        test: /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]*)?(?:[eE][-+]?[0-9]+)?$/,
        resolve: (str) => parseFloat(str),
        stringify: stringifyJSON
      }
    ];
    var jsonError = {
      default: true,
      tag: "",
      test: /^/,
      resolve(str, onError) {
        onError(`Unresolved plain scalar ${JSON.stringify(str)}`);
        return str;
      }
    };
    var schema2 = [map.map, seq.seq].concat(jsonScalars, jsonError);
    exports2.schema = schema2;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/binary.js
var require_binary = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/binary.js"(exports2) {
    "use strict";
    var node_buffer = __require("buffer");
    var Scalar = require_Scalar();
    var stringifyString = require_stringifyString();
    var binary = {
      identify: (value) => value instanceof Uint8Array,
      // Buffer inherits from Uint8Array
      default: false,
      tag: "tag:yaml.org,2002:binary",
      /**
       * Returns a Buffer in node and an Uint8Array in browsers
       *
       * To use the resulting buffer as an image, you'll want to do something like:
       *
       *   const blob = new Blob([buffer], { type: 'image/jpeg' })
       *   document.querySelector('#photo').src = URL.createObjectURL(blob)
       */
      resolve(src, onError) {
        if (typeof node_buffer.Buffer === "function") {
          return node_buffer.Buffer.from(src, "base64");
        } else if (typeof atob === "function") {
          const str = atob(src.replace(/[\n\r]/g, ""));
          const buffer = new Uint8Array(str.length);
          for (let i2 = 0; i2 < str.length; ++i2)
            buffer[i2] = str.charCodeAt(i2);
          return buffer;
        } else {
          onError("This environment does not support reading binary tags; either Buffer or atob is required");
          return src;
        }
      },
      stringify({ comment, type, value }, ctx, onComment, onChompKeep) {
        if (!value)
          return "";
        const buf = value;
        let str;
        if (typeof node_buffer.Buffer === "function") {
          str = buf instanceof node_buffer.Buffer ? buf.toString("base64") : node_buffer.Buffer.from(buf.buffer).toString("base64");
        } else if (typeof btoa === "function") {
          let s = "";
          for (let i2 = 0; i2 < buf.length; ++i2)
            s += String.fromCharCode(buf[i2]);
          str = btoa(s);
        } else {
          throw new Error("This environment does not support writing binary tags; either Buffer or btoa is required");
        }
        type ?? (type = Scalar.Scalar.BLOCK_LITERAL);
        if (type !== Scalar.Scalar.QUOTE_DOUBLE) {
          const lineWidth = Math.max(ctx.options.lineWidth - ctx.indent.length, ctx.options.minContentWidth);
          const n = Math.ceil(str.length / lineWidth);
          const lines = new Array(n);
          for (let i2 = 0, o = 0; i2 < n; ++i2, o += lineWidth) {
            lines[i2] = str.substr(o, lineWidth);
          }
          str = lines.join(type === Scalar.Scalar.BLOCK_LITERAL ? "\n" : " ");
        }
        return stringifyString.stringifyString({ comment, type, value: str }, ctx, onComment, onChompKeep);
      }
    };
    exports2.binary = binary;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/pairs.js
var require_pairs = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/pairs.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var Pair = require_Pair();
    var Scalar = require_Scalar();
    var YAMLSeq = require_YAMLSeq();
    function resolvePairs(seq, onError) {
      if (identity2.isSeq(seq)) {
        for (let i2 = 0; i2 < seq.items.length; ++i2) {
          let item = seq.items[i2];
          if (identity2.isPair(item))
            continue;
          else if (identity2.isMap(item)) {
            if (item.items.length > 1)
              onError("Each pair must have its own sequence indicator");
            const pair = item.items[0] || new Pair.Pair(new Scalar.Scalar(null));
            if (item.commentBefore)
              pair.key.commentBefore = pair.key.commentBefore ? `${item.commentBefore}
${pair.key.commentBefore}` : item.commentBefore;
            if (item.comment) {
              const cn = pair.value ?? pair.key;
              cn.comment = cn.comment ? `${item.comment}
${cn.comment}` : item.comment;
            }
            item = pair;
          }
          seq.items[i2] = identity2.isPair(item) ? item : new Pair.Pair(item);
        }
      } else
        onError("Expected a sequence for this tag");
      return seq;
    }
    function createPairs(schema2, iterable, ctx) {
      const { replacer } = ctx;
      const pairs2 = new YAMLSeq.YAMLSeq(schema2);
      pairs2.tag = "tag:yaml.org,2002:pairs";
      let i2 = 0;
      if (iterable && Symbol.iterator in Object(iterable))
        for (let it of iterable) {
          if (typeof replacer === "function")
            it = replacer.call(iterable, String(i2++), it);
          let key, value;
          if (Array.isArray(it)) {
            if (it.length === 2) {
              key = it[0];
              value = it[1];
            } else
              throw new TypeError(`Expected [key, value] tuple: ${it}`);
          } else if (it && it instanceof Object) {
            const keys = Object.keys(it);
            if (keys.length === 1) {
              key = keys[0];
              value = it[key];
            } else {
              throw new TypeError(`Expected tuple with one key, not ${keys.length} keys`);
            }
          } else {
            key = it;
          }
          pairs2.items.push(Pair.createPair(key, value, ctx));
        }
      return pairs2;
    }
    var pairs = {
      collection: "seq",
      default: false,
      tag: "tag:yaml.org,2002:pairs",
      resolve: resolvePairs,
      createNode: createPairs
    };
    exports2.createPairs = createPairs;
    exports2.pairs = pairs;
    exports2.resolvePairs = resolvePairs;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/omap.js
var require_omap = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/omap.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var toJS = require_toJS();
    var YAMLMap = require_YAMLMap();
    var YAMLSeq = require_YAMLSeq();
    var pairs = require_pairs();
    var YAMLOMap = class _YAMLOMap extends YAMLSeq.YAMLSeq {
      constructor() {
        super();
        this.add = YAMLMap.YAMLMap.prototype.add.bind(this);
        this.delete = YAMLMap.YAMLMap.prototype.delete.bind(this);
        this.get = YAMLMap.YAMLMap.prototype.get.bind(this);
        this.has = YAMLMap.YAMLMap.prototype.has.bind(this);
        this.set = YAMLMap.YAMLMap.prototype.set.bind(this);
        this.tag = _YAMLOMap.tag;
      }
      /**
       * If `ctx` is given, the return type is actually `Map<unknown, unknown>`,
       * but TypeScript won't allow widening the signature of a child method.
       */
      toJSON(_, ctx) {
        if (!ctx)
          return super.toJSON(_);
        const map = /* @__PURE__ */ new Map();
        if (ctx?.onCreate)
          ctx.onCreate(map);
        for (const pair of this.items) {
          let key, value;
          if (identity2.isPair(pair)) {
            key = toJS.toJS(pair.key, "", ctx);
            value = toJS.toJS(pair.value, key, ctx);
          } else {
            key = toJS.toJS(pair, "", ctx);
          }
          if (map.has(key))
            throw new Error("Ordered maps must not include duplicate keys");
          map.set(key, value);
        }
        return map;
      }
      static from(schema2, iterable, ctx) {
        const pairs$1 = pairs.createPairs(schema2, iterable, ctx);
        const omap2 = new this();
        omap2.items = pairs$1.items;
        return omap2;
      }
    };
    YAMLOMap.tag = "tag:yaml.org,2002:omap";
    var omap = {
      collection: "seq",
      identify: (value) => value instanceof Map,
      nodeClass: YAMLOMap,
      default: false,
      tag: "tag:yaml.org,2002:omap",
      resolve(seq, onError) {
        const pairs$1 = pairs.resolvePairs(seq, onError);
        const seenKeys = [];
        for (const { key } of pairs$1.items) {
          if (identity2.isScalar(key)) {
            if (seenKeys.includes(key.value)) {
              onError(`Ordered maps must not include duplicate keys: ${key.value}`);
            } else {
              seenKeys.push(key.value);
            }
          }
        }
        return Object.assign(new YAMLOMap(), pairs$1);
      },
      createNode: (schema2, iterable, ctx) => YAMLOMap.from(schema2, iterable, ctx)
    };
    exports2.YAMLOMap = YAMLOMap;
    exports2.omap = omap;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/bool.js
var require_bool2 = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/bool.js"(exports2) {
    "use strict";
    var Scalar = require_Scalar();
    function boolStringify({ value, source: source2 }, ctx) {
      const boolObj = value ? trueTag : falseTag;
      if (source2 && boolObj.test.test(source2))
        return source2;
      return value ? ctx.options.trueStr : ctx.options.falseStr;
    }
    var trueTag = {
      identify: (value) => value === true,
      default: true,
      tag: "tag:yaml.org,2002:bool",
      test: /^(?:Y|y|[Yy]es|YES|[Tt]rue|TRUE|[Oo]n|ON)$/,
      resolve: () => new Scalar.Scalar(true),
      stringify: boolStringify
    };
    var falseTag = {
      identify: (value) => value === false,
      default: true,
      tag: "tag:yaml.org,2002:bool",
      test: /^(?:N|n|[Nn]o|NO|[Ff]alse|FALSE|[Oo]ff|OFF)$/,
      resolve: () => new Scalar.Scalar(false),
      stringify: boolStringify
    };
    exports2.falseTag = falseTag;
    exports2.trueTag = trueTag;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/float.js
var require_float2 = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/float.js"(exports2) {
    "use strict";
    var Scalar = require_Scalar();
    var stringifyNumber = require_stringifyNumber();
    var floatNaN = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      test: /^(?:[-+]?\.(?:inf|Inf|INF)|\.nan|\.NaN|\.NAN)$/,
      resolve: (str) => str.slice(-3).toLowerCase() === "nan" ? NaN : str[0] === "-" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY,
      stringify: stringifyNumber.stringifyNumber
    };
    var floatExp = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      format: "EXP",
      test: /^[-+]?(?:[0-9][0-9_]*)?(?:\.[0-9_]*)?[eE][-+]?[0-9]+$/,
      resolve: (str) => parseFloat(str.replace(/_/g, "")),
      stringify(node) {
        const num = Number(node.value);
        return isFinite(num) ? num.toExponential() : stringifyNumber.stringifyNumber(node);
      }
    };
    var float = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      test: /^[-+]?(?:[0-9][0-9_]*)?\.[0-9_]*$/,
      resolve(str) {
        const node = new Scalar.Scalar(parseFloat(str.replace(/_/g, "")));
        const dot = str.indexOf(".");
        if (dot !== -1) {
          const f = str.substring(dot + 1).replace(/_/g, "");
          if (f[f.length - 1] === "0")
            node.minFractionDigits = f.length;
        }
        return node;
      },
      stringify: stringifyNumber.stringifyNumber
    };
    exports2.float = float;
    exports2.floatExp = floatExp;
    exports2.floatNaN = floatNaN;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/int.js
var require_int2 = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/int.js"(exports2) {
    "use strict";
    var stringifyNumber = require_stringifyNumber();
    var intIdentify = (value) => typeof value === "bigint" || Number.isInteger(value);
    function intResolve(str, offset, radix, { intAsBigInt }) {
      const sign = str[0];
      if (sign === "-" || sign === "+")
        offset += 1;
      str = str.substring(offset).replace(/_/g, "");
      if (intAsBigInt) {
        switch (radix) {
          case 2:
            str = `0b${str}`;
            break;
          case 8:
            str = `0o${str}`;
            break;
          case 16:
            str = `0x${str}`;
            break;
        }
        const n2 = BigInt(str);
        return sign === "-" ? BigInt(-1) * n2 : n2;
      }
      const n = parseInt(str, radix);
      return sign === "-" ? -1 * n : n;
    }
    function intStringify(node, radix, prefix) {
      const { value } = node;
      if (intIdentify(value)) {
        const str = value.toString(radix);
        return value < 0 ? "-" + prefix + str.substr(1) : prefix + str;
      }
      return stringifyNumber.stringifyNumber(node);
    }
    var intBin = {
      identify: intIdentify,
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "BIN",
      test: /^[-+]?0b[0-1_]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 2, 2, opt),
      stringify: (node) => intStringify(node, 2, "0b")
    };
    var intOct = {
      identify: intIdentify,
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "OCT",
      test: /^[-+]?0[0-7_]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 1, 8, opt),
      stringify: (node) => intStringify(node, 8, "0")
    };
    var int = {
      identify: intIdentify,
      default: true,
      tag: "tag:yaml.org,2002:int",
      test: /^[-+]?[0-9][0-9_]*$/,
      resolve: (str, _onError, opt) => intResolve(str, 0, 10, opt),
      stringify: stringifyNumber.stringifyNumber
    };
    var intHex = {
      identify: intIdentify,
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "HEX",
      test: /^[-+]?0x[0-9a-fA-F_]+$/,
      resolve: (str, _onError, opt) => intResolve(str, 2, 16, opt),
      stringify: (node) => intStringify(node, 16, "0x")
    };
    exports2.int = int;
    exports2.intBin = intBin;
    exports2.intHex = intHex;
    exports2.intOct = intOct;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/set.js
var require_set = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/set.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var Pair = require_Pair();
    var YAMLMap = require_YAMLMap();
    var YAMLSet = class _YAMLSet extends YAMLMap.YAMLMap {
      constructor(schema2) {
        super(schema2);
        this.tag = _YAMLSet.tag;
      }
      add(key) {
        let pair;
        if (identity2.isPair(key))
          pair = key;
        else if (key && typeof key === "object" && "key" in key && "value" in key && key.value === null)
          pair = new Pair.Pair(key.key, null);
        else
          pair = new Pair.Pair(key, null);
        const prev = YAMLMap.findPair(this.items, pair.key);
        if (!prev)
          this.items.push(pair);
      }
      /**
       * If `keepPair` is `true`, returns the Pair matching `key`.
       * Otherwise, returns the value of that Pair's key.
       */
      get(key, keepPair) {
        const pair = YAMLMap.findPair(this.items, key);
        return !keepPair && identity2.isPair(pair) ? identity2.isScalar(pair.key) ? pair.key.value : pair.key : pair;
      }
      set(key, value) {
        if (typeof value !== "boolean")
          throw new Error(`Expected boolean value for set(key, value) in a YAML set, not ${typeof value}`);
        const prev = YAMLMap.findPair(this.items, key);
        if (prev && !value) {
          this.items.splice(this.items.indexOf(prev), 1);
        } else if (!prev && value) {
          this.items.push(new Pair.Pair(key));
        }
      }
      toJSON(_, ctx) {
        return super.toJSON(_, ctx, Set);
      }
      toString(ctx, onComment, onChompKeep) {
        if (!ctx)
          return JSON.stringify(this);
        if (this.hasAllNullValues(true))
          return super.toString(Object.assign({}, ctx, { allNullValues: true }), onComment, onChompKeep);
        else
          throw new Error("Set items must all have null values");
      }
      static from(schema2, iterable, ctx) {
        const { replacer } = ctx;
        const set2 = new this(schema2);
        if (iterable && Symbol.iterator in Object(iterable))
          for (let value of iterable) {
            if (typeof replacer === "function")
              value = replacer.call(iterable, value, value);
            set2.items.push(Pair.createPair(value, null, ctx));
          }
        return set2;
      }
    };
    YAMLSet.tag = "tag:yaml.org,2002:set";
    var set = {
      collection: "map",
      identify: (value) => value instanceof Set,
      nodeClass: YAMLSet,
      default: false,
      tag: "tag:yaml.org,2002:set",
      createNode: (schema2, iterable, ctx) => YAMLSet.from(schema2, iterable, ctx),
      resolve(map, onError) {
        if (identity2.isMap(map)) {
          if (map.hasAllNullValues(true))
            return Object.assign(new YAMLSet(), map);
          else
            onError("Set items must all have null values");
        } else
          onError("Expected a mapping for this tag");
        return map;
      }
    };
    exports2.YAMLSet = YAMLSet;
    exports2.set = set;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/timestamp.js
var require_timestamp = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/timestamp.js"(exports2) {
    "use strict";
    var stringifyNumber = require_stringifyNumber();
    function parseSexagesimal(str, asBigInt) {
      const sign = str[0];
      const parts = sign === "-" || sign === "+" ? str.substring(1) : str;
      const num = (n) => asBigInt ? BigInt(n) : Number(n);
      const res = parts.replace(/_/g, "").split(":").reduce((res2, p) => res2 * num(60) + num(p), num(0));
      return sign === "-" ? num(-1) * res : res;
    }
    function stringifySexagesimal(node) {
      let { value } = node;
      let num = (n) => n;
      if (typeof value === "bigint")
        num = (n) => BigInt(n);
      else if (isNaN(value) || !isFinite(value))
        return stringifyNumber.stringifyNumber(node);
      let sign = "";
      if (value < 0) {
        sign = "-";
        value *= num(-1);
      }
      const _60 = num(60);
      const parts = [value % _60];
      if (value < 60) {
        parts.unshift(0);
      } else {
        value = (value - parts[0]) / _60;
        parts.unshift(value % _60);
        if (value >= 60) {
          value = (value - parts[0]) / _60;
          parts.unshift(value);
        }
      }
      return sign + parts.map((n) => String(n).padStart(2, "0")).join(":").replace(/000000\d*$/, "");
    }
    var intTime = {
      identify: (value) => typeof value === "bigint" || Number.isInteger(value),
      default: true,
      tag: "tag:yaml.org,2002:int",
      format: "TIME",
      test: /^[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+$/,
      resolve: (str, _onError, { intAsBigInt }) => parseSexagesimal(str, intAsBigInt),
      stringify: stringifySexagesimal
    };
    var floatTime = {
      identify: (value) => typeof value === "number",
      default: true,
      tag: "tag:yaml.org,2002:float",
      format: "TIME",
      test: /^[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\.[0-9_]*$/,
      resolve: (str) => parseSexagesimal(str, false),
      stringify: stringifySexagesimal
    };
    var timestamp = {
      identify: (value) => value instanceof Date,
      default: true,
      tag: "tag:yaml.org,2002:timestamp",
      // If the time zone is omitted, the timestamp is assumed to be specified in UTC. The time part
      // may be omitted altogether, resulting in a date format. In such a case, the time part is
      // assumed to be 00:00:00Z (start of day, UTC).
      test: RegExp("^([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})(?:(?:t|T|[ \\t]+)([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2}(\\.[0-9]+)?)(?:[ \\t]*(Z|[-+][012]?[0-9](?::[0-9]{2})?))?)?$"),
      resolve(str) {
        const match = str.match(timestamp.test);
        if (!match)
          throw new Error("!!timestamp expects a date, starting with yyyy-mm-dd");
        const [, year, month, day, hour, minute, second] = match.map(Number);
        const millisec = match[7] ? Number((match[7] + "00").substr(1, 3)) : 0;
        let date2 = Date.UTC(year, month - 1, day, hour || 0, minute || 0, second || 0, millisec);
        const tz = match[8];
        if (tz && tz !== "Z") {
          let d = parseSexagesimal(tz, false);
          if (Math.abs(d) < 30)
            d *= 60;
          date2 -= 6e4 * d;
        }
        return new Date(date2);
      },
      stringify: ({ value }) => value?.toISOString().replace(/(T00:00:00)?\.000Z$/, "") ?? ""
    };
    exports2.floatTime = floatTime;
    exports2.intTime = intTime;
    exports2.timestamp = timestamp;
  }
});

// node_modules/yaml/dist/schema/yaml-1.1/schema.js
var require_schema3 = __commonJS({
  "node_modules/yaml/dist/schema/yaml-1.1/schema.js"(exports2) {
    "use strict";
    var map = require_map();
    var _null = require_null();
    var seq = require_seq();
    var string = require_string();
    var binary = require_binary();
    var bool = require_bool2();
    var float = require_float2();
    var int = require_int2();
    var merge = require_merge();
    var omap = require_omap();
    var pairs = require_pairs();
    var set = require_set();
    var timestamp = require_timestamp();
    var schema2 = [
      map.map,
      seq.seq,
      string.string,
      _null.nullTag,
      bool.trueTag,
      bool.falseTag,
      int.intBin,
      int.intOct,
      int.int,
      int.intHex,
      float.floatNaN,
      float.floatExp,
      float.float,
      binary.binary,
      merge.merge,
      omap.omap,
      pairs.pairs,
      set.set,
      timestamp.intTime,
      timestamp.floatTime,
      timestamp.timestamp
    ];
    exports2.schema = schema2;
  }
});

// node_modules/yaml/dist/schema/tags.js
var require_tags = __commonJS({
  "node_modules/yaml/dist/schema/tags.js"(exports2) {
    "use strict";
    var map = require_map();
    var _null = require_null();
    var seq = require_seq();
    var string = require_string();
    var bool = require_bool();
    var float = require_float();
    var int = require_int();
    var schema2 = require_schema();
    var schema$1 = require_schema2();
    var binary = require_binary();
    var merge = require_merge();
    var omap = require_omap();
    var pairs = require_pairs();
    var schema$2 = require_schema3();
    var set = require_set();
    var timestamp = require_timestamp();
    var schemas = /* @__PURE__ */ new Map([
      ["core", schema2.schema],
      ["failsafe", [map.map, seq.seq, string.string]],
      ["json", schema$1.schema],
      ["yaml11", schema$2.schema],
      ["yaml-1.1", schema$2.schema]
    ]);
    var tagsByName = {
      binary: binary.binary,
      bool: bool.boolTag,
      float: float.float,
      floatExp: float.floatExp,
      floatNaN: float.floatNaN,
      floatTime: timestamp.floatTime,
      int: int.int,
      intHex: int.intHex,
      intOct: int.intOct,
      intTime: timestamp.intTime,
      map: map.map,
      merge: merge.merge,
      null: _null.nullTag,
      omap: omap.omap,
      pairs: pairs.pairs,
      seq: seq.seq,
      set: set.set,
      timestamp: timestamp.timestamp
    };
    var coreKnownTags = {
      "tag:yaml.org,2002:binary": binary.binary,
      "tag:yaml.org,2002:merge": merge.merge,
      "tag:yaml.org,2002:omap": omap.omap,
      "tag:yaml.org,2002:pairs": pairs.pairs,
      "tag:yaml.org,2002:set": set.set,
      "tag:yaml.org,2002:timestamp": timestamp.timestamp
    };
    function getTags(customTags, schemaName, addMergeTag) {
      const schemaTags = schemas.get(schemaName);
      if (schemaTags && !customTags) {
        return addMergeTag && !schemaTags.includes(merge.merge) ? schemaTags.concat(merge.merge) : schemaTags.slice();
      }
      let tags = schemaTags;
      if (!tags) {
        if (Array.isArray(customTags))
          tags = [];
        else {
          const keys = Array.from(schemas.keys()).filter((key) => key !== "yaml11").map((key) => JSON.stringify(key)).join(", ");
          throw new Error(`Unknown schema "${schemaName}"; use one of ${keys} or define customTags array`);
        }
      }
      if (Array.isArray(customTags)) {
        for (const tag of customTags)
          tags = tags.concat(tag);
      } else if (typeof customTags === "function") {
        tags = customTags(tags.slice());
      }
      if (addMergeTag)
        tags = tags.concat(merge.merge);
      return tags.reduce((tags2, tag) => {
        const tagObj = typeof tag === "string" ? tagsByName[tag] : tag;
        if (!tagObj) {
          const tagName = JSON.stringify(tag);
          const keys = Object.keys(tagsByName).map((key) => JSON.stringify(key)).join(", ");
          throw new Error(`Unknown custom tag ${tagName}; use one of ${keys}`);
        }
        if (!tags2.includes(tagObj))
          tags2.push(tagObj);
        return tags2;
      }, []);
    }
    exports2.coreKnownTags = coreKnownTags;
    exports2.getTags = getTags;
  }
});

// node_modules/yaml/dist/schema/Schema.js
var require_Schema = __commonJS({
  "node_modules/yaml/dist/schema/Schema.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var map = require_map();
    var seq = require_seq();
    var string = require_string();
    var tags = require_tags();
    var sortMapEntriesByKey = (a, b) => a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
    var Schema = class _Schema {
      constructor({ compat, customTags, merge, resolveKnownTags, schema: schema2, sortMapEntries, toStringDefaults }) {
        this.compat = Array.isArray(compat) ? tags.getTags(compat, "compat") : compat ? tags.getTags(null, compat) : null;
        this.name = typeof schema2 === "string" && schema2 || "core";
        this.knownTags = resolveKnownTags ? tags.coreKnownTags : {};
        this.tags = tags.getTags(customTags, this.name, merge);
        this.toStringOptions = toStringDefaults ?? null;
        Object.defineProperty(this, identity2.MAP, { value: map.map });
        Object.defineProperty(this, identity2.SCALAR, { value: string.string });
        Object.defineProperty(this, identity2.SEQ, { value: seq.seq });
        this.sortMapEntries = typeof sortMapEntries === "function" ? sortMapEntries : sortMapEntries === true ? sortMapEntriesByKey : null;
      }
      clone() {
        const copy = Object.create(_Schema.prototype, Object.getOwnPropertyDescriptors(this));
        copy.tags = this.tags.slice();
        return copy;
      }
    };
    exports2.Schema = Schema;
  }
});

// node_modules/yaml/dist/stringify/stringifyDocument.js
var require_stringifyDocument = __commonJS({
  "node_modules/yaml/dist/stringify/stringifyDocument.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var stringify2 = require_stringify();
    var stringifyComment = require_stringifyComment();
    function stringifyDocument(doc, options) {
      const lines = [];
      let hasDirectives = options.directives === true;
      if (options.directives !== false && doc.directives) {
        const dir = doc.directives.toString(doc);
        if (dir) {
          lines.push(dir);
          hasDirectives = true;
        } else if (doc.directives.docStart)
          hasDirectives = true;
      }
      if (hasDirectives)
        lines.push("---");
      const ctx = stringify2.createStringifyContext(doc, options);
      const { commentString } = ctx.options;
      if (doc.commentBefore) {
        if (lines.length !== 1)
          lines.unshift("");
        const cs = commentString(doc.commentBefore);
        lines.unshift(stringifyComment.indentComment(cs, ""));
      }
      let chompKeep = false;
      let contentComment = null;
      if (doc.contents) {
        if (identity2.isNode(doc.contents)) {
          if (doc.contents.spaceBefore && hasDirectives)
            lines.push("");
          if (doc.contents.commentBefore) {
            const cs = commentString(doc.contents.commentBefore);
            lines.push(stringifyComment.indentComment(cs, ""));
          }
          ctx.forceBlockIndent = !!doc.comment;
          contentComment = doc.contents.comment;
        }
        const onChompKeep = contentComment ? void 0 : () => chompKeep = true;
        let body = stringify2.stringify(doc.contents, ctx, () => contentComment = null, onChompKeep);
        if (contentComment)
          body += stringifyComment.lineComment(body, "", commentString(contentComment));
        if ((body[0] === "|" || body[0] === ">") && lines[lines.length - 1] === "---") {
          lines[lines.length - 1] = `--- ${body}`;
        } else
          lines.push(body);
      } else {
        lines.push(stringify2.stringify(doc.contents, ctx));
      }
      if (doc.directives?.docEnd) {
        if (doc.comment) {
          const cs = commentString(doc.comment);
          if (cs.includes("\n")) {
            lines.push("...");
            lines.push(stringifyComment.indentComment(cs, ""));
          } else {
            lines.push(`... ${cs}`);
          }
        } else {
          lines.push("...");
        }
      } else {
        let dc = doc.comment;
        if (dc && chompKeep)
          dc = dc.replace(/^\n+/, "");
        if (dc) {
          if ((!chompKeep || contentComment) && lines[lines.length - 1] !== "")
            lines.push("");
          lines.push(stringifyComment.indentComment(commentString(dc), ""));
        }
      }
      return lines.join("\n") + "\n";
    }
    exports2.stringifyDocument = stringifyDocument;
  }
});

// node_modules/yaml/dist/doc/Document.js
var require_Document = __commonJS({
  "node_modules/yaml/dist/doc/Document.js"(exports2) {
    "use strict";
    var Alias = require_Alias();
    var Collection = require_Collection();
    var identity2 = require_identity();
    var Pair = require_Pair();
    var toJS = require_toJS();
    var Schema = require_Schema();
    var stringifyDocument = require_stringifyDocument();
    var anchors = require_anchors();
    var applyReviver = require_applyReviver();
    var createNode = require_createNode();
    var directives = require_directives();
    var Document = class _Document {
      constructor(value, replacer, options) {
        this.commentBefore = null;
        this.comment = null;
        this.errors = [];
        this.warnings = [];
        Object.defineProperty(this, identity2.NODE_TYPE, { value: identity2.DOC });
        let _replacer = null;
        if (typeof replacer === "function" || Array.isArray(replacer)) {
          _replacer = replacer;
        } else if (options === void 0 && replacer) {
          options = replacer;
          replacer = void 0;
        }
        const opt = Object.assign({
          intAsBigInt: false,
          keepSourceTokens: false,
          logLevel: "warn",
          prettyErrors: true,
          strict: true,
          stringKeys: false,
          uniqueKeys: true,
          version: "1.2"
        }, options);
        this.options = opt;
        let { version: version2 } = opt;
        if (options?._directives) {
          this.directives = options._directives.atDocument();
          if (this.directives.yaml.explicit)
            version2 = this.directives.yaml.version;
        } else
          this.directives = new directives.Directives({ version: version2 });
        this.setSchema(version2, options);
        this.contents = value === void 0 ? null : this.createNode(value, _replacer, options);
      }
      /**
       * Create a deep copy of this Document and its contents.
       *
       * Custom Node values that inherit from `Object` still refer to their original instances.
       */
      clone() {
        const copy = Object.create(_Document.prototype, {
          [identity2.NODE_TYPE]: { value: identity2.DOC }
        });
        copy.commentBefore = this.commentBefore;
        copy.comment = this.comment;
        copy.errors = this.errors.slice();
        copy.warnings = this.warnings.slice();
        copy.options = Object.assign({}, this.options);
        if (this.directives)
          copy.directives = this.directives.clone();
        copy.schema = this.schema.clone();
        copy.contents = identity2.isNode(this.contents) ? this.contents.clone(copy.schema) : this.contents;
        if (this.range)
          copy.range = this.range.slice();
        return copy;
      }
      /** Adds a value to the document. */
      add(value) {
        if (assertCollection(this.contents))
          this.contents.add(value);
      }
      /** Adds a value to the document. */
      addIn(path7, value) {
        if (assertCollection(this.contents))
          this.contents.addIn(path7, value);
      }
      /**
       * Create a new `Alias` node, ensuring that the target `node` has the required anchor.
       *
       * If `node` already has an anchor, `name` is ignored.
       * Otherwise, the `node.anchor` value will be set to `name`,
       * or if an anchor with that name is already present in the document,
       * `name` will be used as a prefix for a new unique anchor.
       * If `name` is undefined, the generated anchor will use 'a' as a prefix.
       */
      createAlias(node, name) {
        if (!node.anchor) {
          const prev = anchors.anchorNames(this);
          node.anchor = // eslint-disable-next-line @typescript-eslint/prefer-nullish-coalescing
          !name || prev.has(name) ? anchors.findNewAnchor(name || "a", prev) : name;
        }
        return new Alias.Alias(node.anchor);
      }
      createNode(value, replacer, options) {
        let _replacer = void 0;
        if (typeof replacer === "function") {
          value = replacer.call({ "": value }, "", value);
          _replacer = replacer;
        } else if (Array.isArray(replacer)) {
          const keyToStr = (v) => typeof v === "number" || v instanceof String || v instanceof Number;
          const asStr = replacer.filter(keyToStr).map(String);
          if (asStr.length > 0)
            replacer = replacer.concat(asStr);
          _replacer = replacer;
        } else if (options === void 0 && replacer) {
          options = replacer;
          replacer = void 0;
        }
        const { aliasDuplicateObjects, anchorPrefix, flow, keepUndefined, onTagObj, tag } = options ?? {};
        const { onAnchor, setAnchors, sourceObjects } = anchors.createNodeAnchors(
          this,
          // eslint-disable-next-line @typescript-eslint/prefer-nullish-coalescing
          anchorPrefix || "a"
        );
        const ctx = {
          aliasDuplicateObjects: aliasDuplicateObjects ?? true,
          keepUndefined: keepUndefined ?? false,
          onAnchor,
          onTagObj,
          replacer: _replacer,
          schema: this.schema,
          sourceObjects
        };
        const node = createNode.createNode(value, tag, ctx);
        if (flow && identity2.isCollection(node))
          node.flow = true;
        setAnchors();
        return node;
      }
      /**
       * Convert a key and a value into a `Pair` using the current schema,
       * recursively wrapping all values as `Scalar` or `Collection` nodes.
       */
      createPair(key, value, options = {}) {
        const k = this.createNode(key, null, options);
        const v = this.createNode(value, null, options);
        return new Pair.Pair(k, v);
      }
      /**
       * Removes a value from the document.
       * @returns `true` if the item was found and removed.
       */
      delete(key) {
        return assertCollection(this.contents) ? this.contents.delete(key) : false;
      }
      /**
       * Removes a value from the document.
       * @returns `true` if the item was found and removed.
       */
      deleteIn(path7) {
        if (Collection.isEmptyPath(path7)) {
          if (this.contents == null)
            return false;
          this.contents = null;
          return true;
        }
        return assertCollection(this.contents) ? this.contents.deleteIn(path7) : false;
      }
      /**
       * Returns item at `key`, or `undefined` if not found. By default unwraps
       * scalar values from their surrounding node; to disable set `keepScalar` to
       * `true` (collections are always returned intact).
       */
      get(key, keepScalar) {
        return identity2.isCollection(this.contents) ? this.contents.get(key, keepScalar) : void 0;
      }
      /**
       * Returns item at `path`, or `undefined` if not found. By default unwraps
       * scalar values from their surrounding node; to disable set `keepScalar` to
       * `true` (collections are always returned intact).
       */
      getIn(path7, keepScalar) {
        if (Collection.isEmptyPath(path7))
          return !keepScalar && identity2.isScalar(this.contents) ? this.contents.value : this.contents;
        return identity2.isCollection(this.contents) ? this.contents.getIn(path7, keepScalar) : void 0;
      }
      /**
       * Checks if the document includes a value with the key `key`.
       */
      has(key) {
        return identity2.isCollection(this.contents) ? this.contents.has(key) : false;
      }
      /**
       * Checks if the document includes a value at `path`.
       */
      hasIn(path7) {
        if (Collection.isEmptyPath(path7))
          return this.contents !== void 0;
        return identity2.isCollection(this.contents) ? this.contents.hasIn(path7) : false;
      }
      /**
       * Sets a value in this document. For `!!set`, `value` needs to be a
       * boolean to add/remove the item from the set.
       */
      set(key, value) {
        if (this.contents == null) {
          this.contents = Collection.collectionFromPath(this.schema, [key], value);
        } else if (assertCollection(this.contents)) {
          this.contents.set(key, value);
        }
      }
      /**
       * Sets a value in this document. For `!!set`, `value` needs to be a
       * boolean to add/remove the item from the set.
       */
      setIn(path7, value) {
        if (Collection.isEmptyPath(path7)) {
          this.contents = value;
        } else if (this.contents == null) {
          this.contents = Collection.collectionFromPath(this.schema, Array.from(path7), value);
        } else if (assertCollection(this.contents)) {
          this.contents.setIn(path7, value);
        }
      }
      /**
       * Change the YAML version and schema used by the document.
       * A `null` version disables support for directives, explicit tags, anchors, and aliases.
       * It also requires the `schema` option to be given as a `Schema` instance value.
       *
       * Overrides all previously set schema options.
       */
      setSchema(version2, options = {}) {
        if (typeof version2 === "number")
          version2 = String(version2);
        let opt;
        switch (version2) {
          case "1.1":
            if (this.directives)
              this.directives.yaml.version = "1.1";
            else
              this.directives = new directives.Directives({ version: "1.1" });
            opt = { resolveKnownTags: false, schema: "yaml-1.1" };
            break;
          case "1.2":
          case "next":
            if (this.directives)
              this.directives.yaml.version = version2;
            else
              this.directives = new directives.Directives({ version: version2 });
            opt = { resolveKnownTags: true, schema: "core" };
            break;
          case null:
            if (this.directives)
              delete this.directives;
            opt = null;
            break;
          default: {
            const sv = JSON.stringify(version2);
            throw new Error(`Expected '1.1', '1.2' or null as first argument, but found: ${sv}`);
          }
        }
        if (options.schema instanceof Object)
          this.schema = options.schema;
        else if (opt)
          this.schema = new Schema.Schema(Object.assign(opt, options));
        else
          throw new Error(`With a null YAML version, the { schema: Schema } option is required`);
      }
      // json & jsonArg are only used from toJSON()
      toJS({ json: json3, jsonArg, mapAsMap, maxAliasCount, onAnchor, reviver } = {}) {
        const ctx = {
          anchors: /* @__PURE__ */ new Map(),
          doc: this,
          keep: !json3,
          mapAsMap: mapAsMap === true,
          mapKeyWarned: false,
          maxAliasCount: typeof maxAliasCount === "number" ? maxAliasCount : 100
        };
        const res = toJS.toJS(this.contents, jsonArg ?? "", ctx);
        if (typeof onAnchor === "function")
          for (const { count, res: res2 } of ctx.anchors.values())
            onAnchor(res2, count);
        return typeof reviver === "function" ? applyReviver.applyReviver(reviver, { "": res }, "", res) : res;
      }
      /**
       * A JSON representation of the document `contents`.
       *
       * @param jsonArg Used by `JSON.stringify` to indicate the array index or
       *   property name.
       */
      toJSON(jsonArg, onAnchor) {
        return this.toJS({ json: true, jsonArg, mapAsMap: false, onAnchor });
      }
      /** A YAML representation of the document. */
      toString(options = {}) {
        if (this.errors.length > 0)
          throw new Error("Document with errors cannot be stringified");
        if ("indent" in options && (!Number.isInteger(options.indent) || Number(options.indent) <= 0)) {
          const s = JSON.stringify(options.indent);
          throw new Error(`"indent" option must be a positive integer, not ${s}`);
        }
        return stringifyDocument.stringifyDocument(this, options);
      }
    };
    function assertCollection(contents) {
      if (identity2.isCollection(contents))
        return true;
      throw new Error("Expected a YAML collection as document contents");
    }
    exports2.Document = Document;
  }
});

// node_modules/yaml/dist/errors.js
var require_errors = __commonJS({
  "node_modules/yaml/dist/errors.js"(exports2) {
    "use strict";
    var YAMLError = class extends Error {
      constructor(name, pos, code, message) {
        super();
        this.name = name;
        this.code = code;
        this.message = message;
        this.pos = pos;
      }
    };
    var YAMLParseError = class extends YAMLError {
      constructor(pos, code, message) {
        super("YAMLParseError", pos, code, message);
      }
    };
    var YAMLWarning = class extends YAMLError {
      constructor(pos, code, message) {
        super("YAMLWarning", pos, code, message);
      }
    };
    var prettifyError = (src, lc) => (error) => {
      if (error.pos[0] === -1)
        return;
      error.linePos = error.pos.map((pos) => lc.linePos(pos));
      const { line, col } = error.linePos[0];
      error.message += ` at line ${line}, column ${col}`;
      let ci = col - 1;
      let lineStr = src.substring(lc.lineStarts[line - 1], lc.lineStarts[line]).replace(/[\n\r]+$/, "");
      if (ci >= 60 && lineStr.length > 80) {
        const trimStart = Math.min(ci - 39, lineStr.length - 79);
        lineStr = "\u2026" + lineStr.substring(trimStart);
        ci -= trimStart - 1;
      }
      if (lineStr.length > 80)
        lineStr = lineStr.substring(0, 79) + "\u2026";
      if (line > 1 && /^ *$/.test(lineStr.substring(0, ci))) {
        let prev = src.substring(lc.lineStarts[line - 2], lc.lineStarts[line - 1]);
        if (prev.length > 80)
          prev = prev.substring(0, 79) + "\u2026\n";
        lineStr = prev + lineStr;
      }
      if (/[^ ]/.test(lineStr)) {
        let count = 1;
        const end = error.linePos[1];
        if (end?.line === line && end.col > col) {
          count = Math.max(1, Math.min(end.col - col, 80 - ci));
        }
        const pointer = " ".repeat(ci) + "^".repeat(count);
        error.message += `:

${lineStr}
${pointer}
`;
      }
    };
    exports2.YAMLError = YAMLError;
    exports2.YAMLParseError = YAMLParseError;
    exports2.YAMLWarning = YAMLWarning;
    exports2.prettifyError = prettifyError;
  }
});

// node_modules/yaml/dist/compose/resolve-props.js
var require_resolve_props = __commonJS({
  "node_modules/yaml/dist/compose/resolve-props.js"(exports2) {
    "use strict";
    function resolveProps(tokens, { flow, indicator, next, offset, onError, parentIndent, startOnNewline }) {
      let spaceBefore = false;
      let atNewline = startOnNewline;
      let hasSpace = startOnNewline;
      let comment = "";
      let commentSep = "";
      let hasNewline = false;
      let reqSpace = false;
      let tab = null;
      let anchor = null;
      let tag = null;
      let newlineAfterProp = null;
      let comma = null;
      let found = null;
      let start2 = null;
      for (const token of tokens) {
        if (reqSpace) {
          if (token.type !== "space" && token.type !== "newline" && token.type !== "comma")
            onError(token.offset, "MISSING_CHAR", "Tags and anchors must be separated from the next token by white space");
          reqSpace = false;
        }
        if (tab) {
          if (atNewline && token.type !== "comment" && token.type !== "newline") {
            onError(tab, "TAB_AS_INDENT", "Tabs are not allowed as indentation");
          }
          tab = null;
        }
        switch (token.type) {
          case "space":
            if (!flow && (indicator !== "doc-start" || next?.type !== "flow-collection") && token.source.includes("	")) {
              tab = token;
            }
            hasSpace = true;
            break;
          case "comment": {
            if (!hasSpace)
              onError(token, "MISSING_CHAR", "Comments must be separated from other tokens by white space characters");
            const cb = token.source.substring(1) || " ";
            if (!comment)
              comment = cb;
            else
              comment += commentSep + cb;
            commentSep = "";
            atNewline = false;
            break;
          }
          case "newline":
            if (atNewline) {
              if (comment)
                comment += token.source;
              else if (!found || indicator !== "seq-item-ind")
                spaceBefore = true;
            } else
              commentSep += token.source;
            atNewline = true;
            hasNewline = true;
            if (anchor || tag)
              newlineAfterProp = token;
            hasSpace = true;
            break;
          case "anchor":
            if (anchor)
              onError(token, "MULTIPLE_ANCHORS", "A node can have at most one anchor");
            if (token.source.endsWith(":"))
              onError(token.offset + token.source.length - 1, "BAD_ALIAS", "Anchor ending in : is ambiguous", true);
            anchor = token;
            start2 ?? (start2 = token.offset);
            atNewline = false;
            hasSpace = false;
            reqSpace = true;
            break;
          case "tag": {
            if (tag)
              onError(token, "MULTIPLE_TAGS", "A node can have at most one tag");
            tag = token;
            start2 ?? (start2 = token.offset);
            atNewline = false;
            hasSpace = false;
            reqSpace = true;
            break;
          }
          case indicator:
            if (anchor || tag)
              onError(token, "BAD_PROP_ORDER", `Anchors and tags must be after the ${token.source} indicator`);
            if (found)
              onError(token, "UNEXPECTED_TOKEN", `Unexpected ${token.source} in ${flow ?? "collection"}`);
            found = token;
            atNewline = indicator === "seq-item-ind" || indicator === "explicit-key-ind";
            hasSpace = false;
            break;
          case "comma":
            if (flow) {
              if (comma)
                onError(token, "UNEXPECTED_TOKEN", `Unexpected , in ${flow}`);
              comma = token;
              atNewline = false;
              hasSpace = false;
              break;
            }
          // else fallthrough
          default:
            onError(token, "UNEXPECTED_TOKEN", `Unexpected ${token.type} token`);
            atNewline = false;
            hasSpace = false;
        }
      }
      const last = tokens[tokens.length - 1];
      const end = last ? last.offset + last.source.length : offset;
      if (reqSpace && next && next.type !== "space" && next.type !== "newline" && next.type !== "comma" && (next.type !== "scalar" || next.source !== "")) {
        onError(next.offset, "MISSING_CHAR", "Tags and anchors must be separated from the next token by white space");
      }
      if (tab && (atNewline && tab.indent <= parentIndent || next?.type === "block-map" || next?.type === "block-seq"))
        onError(tab, "TAB_AS_INDENT", "Tabs are not allowed as indentation");
      return {
        comma,
        found,
        spaceBefore,
        comment,
        hasNewline,
        anchor,
        tag,
        newlineAfterProp,
        end,
        start: start2 ?? end
      };
    }
    exports2.resolveProps = resolveProps;
  }
});

// node_modules/yaml/dist/compose/util-contains-newline.js
var require_util_contains_newline = __commonJS({
  "node_modules/yaml/dist/compose/util-contains-newline.js"(exports2) {
    "use strict";
    function containsNewline(key) {
      if (!key)
        return null;
      switch (key.type) {
        case "alias":
        case "scalar":
        case "double-quoted-scalar":
        case "single-quoted-scalar":
          if (key.source.includes("\n"))
            return true;
          if (key.end) {
            for (const st of key.end)
              if (st.type === "newline")
                return true;
          }
          return false;
        case "flow-collection":
          for (const it of key.items) {
            for (const st of it.start)
              if (st.type === "newline")
                return true;
            if (it.sep) {
              for (const st of it.sep)
                if (st.type === "newline")
                  return true;
            }
            if (containsNewline(it.key) || containsNewline(it.value))
              return true;
          }
          return false;
        default:
          return true;
      }
    }
    exports2.containsNewline = containsNewline;
  }
});

// node_modules/yaml/dist/compose/util-flow-indent-check.js
var require_util_flow_indent_check = __commonJS({
  "node_modules/yaml/dist/compose/util-flow-indent-check.js"(exports2) {
    "use strict";
    var utilContainsNewline = require_util_contains_newline();
    function flowIndentCheck(indent, fc, onError) {
      if (fc?.type === "flow-collection") {
        const end = fc.end[0];
        if (end.indent === indent && (end.source === "]" || end.source === "}") && utilContainsNewline.containsNewline(fc)) {
          const msg = "Flow end indicator should be more indented than parent";
          onError(end, "BAD_INDENT", msg, true);
        }
      }
    }
    exports2.flowIndentCheck = flowIndentCheck;
  }
});

// node_modules/yaml/dist/compose/util-map-includes.js
var require_util_map_includes = __commonJS({
  "node_modules/yaml/dist/compose/util-map-includes.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    function mapIncludes(ctx, items, search) {
      const { uniqueKeys } = ctx.options;
      if (uniqueKeys === false)
        return false;
      const isEqual = typeof uniqueKeys === "function" ? uniqueKeys : (a, b) => a === b || identity2.isScalar(a) && identity2.isScalar(b) && a.value === b.value;
      return items.some((pair) => isEqual(pair.key, search));
    }
    exports2.mapIncludes = mapIncludes;
  }
});

// node_modules/yaml/dist/compose/resolve-block-map.js
var require_resolve_block_map = __commonJS({
  "node_modules/yaml/dist/compose/resolve-block-map.js"(exports2) {
    "use strict";
    var Pair = require_Pair();
    var YAMLMap = require_YAMLMap();
    var resolveProps = require_resolve_props();
    var utilContainsNewline = require_util_contains_newline();
    var utilFlowIndentCheck = require_util_flow_indent_check();
    var utilMapIncludes = require_util_map_includes();
    var startColMsg = "All mapping items must start at the same column";
    function resolveBlockMap({ composeNode, composeEmptyNode }, ctx, bm, onError, tag) {
      const NodeClass = tag?.nodeClass ?? YAMLMap.YAMLMap;
      const map = new NodeClass(ctx.schema);
      if (ctx.atRoot)
        ctx.atRoot = false;
      let offset = bm.offset;
      let commentEnd = null;
      for (const collItem of bm.items) {
        const { start: start2, key, sep: sep2, value } = collItem;
        const keyProps = resolveProps.resolveProps(start2, {
          indicator: "explicit-key-ind",
          next: key ?? sep2?.[0],
          offset,
          onError,
          parentIndent: bm.indent,
          startOnNewline: true
        });
        const implicitKey = !keyProps.found;
        if (implicitKey) {
          if (key) {
            if (key.type === "block-seq")
              onError(offset, "BLOCK_AS_IMPLICIT_KEY", "A block sequence may not be used as an implicit map key");
            else if ("indent" in key && key.indent !== bm.indent)
              onError(offset, "BAD_INDENT", startColMsg);
          }
          if (!keyProps.anchor && !keyProps.tag && !sep2) {
            commentEnd = keyProps.end;
            if (keyProps.comment) {
              if (map.comment)
                map.comment += "\n" + keyProps.comment;
              else
                map.comment = keyProps.comment;
            }
            continue;
          }
          if (keyProps.newlineAfterProp || utilContainsNewline.containsNewline(key)) {
            onError(key ?? start2[start2.length - 1], "MULTILINE_IMPLICIT_KEY", "Implicit keys need to be on a single line");
          }
        } else if (keyProps.found?.indent !== bm.indent) {
          onError(offset, "BAD_INDENT", startColMsg);
        }
        ctx.atKey = true;
        const keyStart = keyProps.end;
        const keyNode = key ? composeNode(ctx, key, keyProps, onError) : composeEmptyNode(ctx, keyStart, start2, null, keyProps, onError);
        if (ctx.schema.compat)
          utilFlowIndentCheck.flowIndentCheck(bm.indent, key, onError);
        ctx.atKey = false;
        if (utilMapIncludes.mapIncludes(ctx, map.items, keyNode))
          onError(keyStart, "DUPLICATE_KEY", "Map keys must be unique");
        const valueProps = resolveProps.resolveProps(sep2 ?? [], {
          indicator: "map-value-ind",
          next: value,
          offset: keyNode.range[2],
          onError,
          parentIndent: bm.indent,
          startOnNewline: !key || key.type === "block-scalar"
        });
        offset = valueProps.end;
        if (valueProps.found) {
          if (implicitKey) {
            if (value?.type === "block-map" && !valueProps.hasNewline)
              onError(offset, "BLOCK_AS_IMPLICIT_KEY", "Nested mappings are not allowed in compact mappings");
            if (ctx.options.strict && keyProps.start < valueProps.found.offset - 1024)
              onError(keyNode.range, "KEY_OVER_1024_CHARS", "The : indicator must be at most 1024 chars after the start of an implicit block mapping key");
          }
          const valueNode = value ? composeNode(ctx, value, valueProps, onError) : composeEmptyNode(ctx, offset, sep2, null, valueProps, onError);
          if (ctx.schema.compat)
            utilFlowIndentCheck.flowIndentCheck(bm.indent, value, onError);
          offset = valueNode.range[2];
          const pair = new Pair.Pair(keyNode, valueNode);
          if (ctx.options.keepSourceTokens)
            pair.srcToken = collItem;
          map.items.push(pair);
        } else {
          if (implicitKey)
            onError(keyNode.range, "MISSING_CHAR", "Implicit map keys need to be followed by map values");
          if (valueProps.comment) {
            if (keyNode.comment)
              keyNode.comment += "\n" + valueProps.comment;
            else
              keyNode.comment = valueProps.comment;
          }
          const pair = new Pair.Pair(keyNode);
          if (ctx.options.keepSourceTokens)
            pair.srcToken = collItem;
          map.items.push(pair);
        }
      }
      if (commentEnd && commentEnd < offset)
        onError(commentEnd, "IMPOSSIBLE", "Map comment with trailing content");
      map.range = [bm.offset, offset, commentEnd ?? offset];
      return map;
    }
    exports2.resolveBlockMap = resolveBlockMap;
  }
});

// node_modules/yaml/dist/compose/resolve-block-seq.js
var require_resolve_block_seq = __commonJS({
  "node_modules/yaml/dist/compose/resolve-block-seq.js"(exports2) {
    "use strict";
    var YAMLSeq = require_YAMLSeq();
    var resolveProps = require_resolve_props();
    var utilFlowIndentCheck = require_util_flow_indent_check();
    function resolveBlockSeq({ composeNode, composeEmptyNode }, ctx, bs, onError, tag) {
      const NodeClass = tag?.nodeClass ?? YAMLSeq.YAMLSeq;
      const seq = new NodeClass(ctx.schema);
      if (ctx.atRoot)
        ctx.atRoot = false;
      if (ctx.atKey)
        ctx.atKey = false;
      let offset = bs.offset;
      let commentEnd = null;
      for (const { start: start2, value } of bs.items) {
        const props = resolveProps.resolveProps(start2, {
          indicator: "seq-item-ind",
          next: value,
          offset,
          onError,
          parentIndent: bs.indent,
          startOnNewline: true
        });
        if (!props.found) {
          if (props.anchor || props.tag || value) {
            if (value?.type === "block-seq")
              onError(props.end, "BAD_INDENT", "All sequence items must start at the same column");
            else
              onError(offset, "MISSING_CHAR", "Sequence item without - indicator");
          } else {
            commentEnd = props.end;
            if (props.comment)
              seq.comment = props.comment;
            continue;
          }
        }
        const node = value ? composeNode(ctx, value, props, onError) : composeEmptyNode(ctx, props.end, start2, null, props, onError);
        if (ctx.schema.compat)
          utilFlowIndentCheck.flowIndentCheck(bs.indent, value, onError);
        offset = node.range[2];
        seq.items.push(node);
      }
      seq.range = [bs.offset, offset, commentEnd ?? offset];
      return seq;
    }
    exports2.resolveBlockSeq = resolveBlockSeq;
  }
});

// node_modules/yaml/dist/compose/resolve-end.js
var require_resolve_end = __commonJS({
  "node_modules/yaml/dist/compose/resolve-end.js"(exports2) {
    "use strict";
    function resolveEnd(end, offset, reqSpace, onError) {
      let comment = "";
      if (end) {
        let hasSpace = false;
        let sep2 = "";
        for (const token of end) {
          const { source: source2, type } = token;
          switch (type) {
            case "space":
              hasSpace = true;
              break;
            case "comment": {
              if (reqSpace && !hasSpace)
                onError(token, "MISSING_CHAR", "Comments must be separated from other tokens by white space characters");
              const cb = source2.substring(1) || " ";
              if (!comment)
                comment = cb;
              else
                comment += sep2 + cb;
              sep2 = "";
              break;
            }
            case "newline":
              if (comment)
                sep2 += source2;
              hasSpace = true;
              break;
            default:
              onError(token, "UNEXPECTED_TOKEN", `Unexpected ${type} at node end`);
          }
          offset += source2.length;
        }
      }
      return { comment, offset };
    }
    exports2.resolveEnd = resolveEnd;
  }
});

// node_modules/yaml/dist/compose/resolve-flow-collection.js
var require_resolve_flow_collection = __commonJS({
  "node_modules/yaml/dist/compose/resolve-flow-collection.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var Pair = require_Pair();
    var YAMLMap = require_YAMLMap();
    var YAMLSeq = require_YAMLSeq();
    var resolveEnd = require_resolve_end();
    var resolveProps = require_resolve_props();
    var utilContainsNewline = require_util_contains_newline();
    var utilMapIncludes = require_util_map_includes();
    var blockMsg = "Block collections are not allowed within flow collections";
    var isBlock = (token) => token && (token.type === "block-map" || token.type === "block-seq");
    function resolveFlowCollection({ composeNode, composeEmptyNode }, ctx, fc, onError, tag) {
      const isMap2 = fc.start.source === "{";
      const fcName = isMap2 ? "flow map" : "flow sequence";
      const NodeClass = tag?.nodeClass ?? (isMap2 ? YAMLMap.YAMLMap : YAMLSeq.YAMLSeq);
      const coll = new NodeClass(ctx.schema);
      coll.flow = true;
      const atRoot = ctx.atRoot;
      if (atRoot)
        ctx.atRoot = false;
      if (ctx.atKey)
        ctx.atKey = false;
      let offset = fc.offset + fc.start.source.length;
      for (let i2 = 0; i2 < fc.items.length; ++i2) {
        const collItem = fc.items[i2];
        const { start: start2, key, sep: sep2, value } = collItem;
        const props = resolveProps.resolveProps(start2, {
          flow: fcName,
          indicator: "explicit-key-ind",
          next: key ?? sep2?.[0],
          offset,
          onError,
          parentIndent: fc.indent,
          startOnNewline: false
        });
        if (!props.found) {
          if (!props.anchor && !props.tag && !sep2 && !value) {
            if (i2 === 0 && props.comma)
              onError(props.comma, "UNEXPECTED_TOKEN", `Unexpected , in ${fcName}`);
            else if (i2 < fc.items.length - 1)
              onError(props.start, "UNEXPECTED_TOKEN", `Unexpected empty item in ${fcName}`);
            if (props.comment) {
              if (coll.comment)
                coll.comment += "\n" + props.comment;
              else
                coll.comment = props.comment;
            }
            offset = props.end;
            continue;
          }
          if (!isMap2 && ctx.options.strict && utilContainsNewline.containsNewline(key))
            onError(
              key,
              // checked by containsNewline()
              "MULTILINE_IMPLICIT_KEY",
              "Implicit keys of flow sequence pairs need to be on a single line"
            );
        }
        if (i2 === 0) {
          if (props.comma)
            onError(props.comma, "UNEXPECTED_TOKEN", `Unexpected , in ${fcName}`);
        } else {
          if (!props.comma)
            onError(props.start, "MISSING_CHAR", `Missing , between ${fcName} items`);
          if (props.comment) {
            let prevItemComment = "";
            loop: for (const st of start2) {
              switch (st.type) {
                case "comma":
                case "space":
                  break;
                case "comment":
                  prevItemComment = st.source.substring(1);
                  break loop;
                default:
                  break loop;
              }
            }
            if (prevItemComment) {
              let prev = coll.items[coll.items.length - 1];
              if (identity2.isPair(prev))
                prev = prev.value ?? prev.key;
              if (prev.comment)
                prev.comment += "\n" + prevItemComment;
              else
                prev.comment = prevItemComment;
              props.comment = props.comment.substring(prevItemComment.length + 1);
            }
          }
        }
        if (!isMap2 && !sep2 && !props.found) {
          const valueNode = value ? composeNode(ctx, value, props, onError) : composeEmptyNode(ctx, props.end, sep2, null, props, onError);
          coll.items.push(valueNode);
          offset = valueNode.range[2];
          if (isBlock(value))
            onError(valueNode.range, "BLOCK_IN_FLOW", blockMsg);
        } else {
          ctx.atKey = true;
          const keyStart = props.end;
          const keyNode = key ? composeNode(ctx, key, props, onError) : composeEmptyNode(ctx, keyStart, start2, null, props, onError);
          if (isBlock(key))
            onError(keyNode.range, "BLOCK_IN_FLOW", blockMsg);
          ctx.atKey = false;
          const valueProps = resolveProps.resolveProps(sep2 ?? [], {
            flow: fcName,
            indicator: "map-value-ind",
            next: value,
            offset: keyNode.range[2],
            onError,
            parentIndent: fc.indent,
            startOnNewline: false
          });
          if (valueProps.found) {
            if (!isMap2 && !props.found && ctx.options.strict) {
              if (sep2)
                for (const st of sep2) {
                  if (st === valueProps.found)
                    break;
                  if (st.type === "newline") {
                    onError(st, "MULTILINE_IMPLICIT_KEY", "Implicit keys of flow sequence pairs need to be on a single line");
                    break;
                  }
                }
              if (props.start < valueProps.found.offset - 1024)
                onError(valueProps.found, "KEY_OVER_1024_CHARS", "The : indicator must be at most 1024 chars after the start of an implicit flow sequence key");
            }
          } else if (value) {
            if ("source" in value && value.source?.[0] === ":")
              onError(value, "MISSING_CHAR", `Missing space after : in ${fcName}`);
            else
              onError(valueProps.start, "MISSING_CHAR", `Missing , or : between ${fcName} items`);
          }
          const valueNode = value ? composeNode(ctx, value, valueProps, onError) : valueProps.found ? composeEmptyNode(ctx, valueProps.end, sep2, null, valueProps, onError) : null;
          if (valueNode) {
            if (isBlock(value))
              onError(valueNode.range, "BLOCK_IN_FLOW", blockMsg);
          } else if (valueProps.comment) {
            if (keyNode.comment)
              keyNode.comment += "\n" + valueProps.comment;
            else
              keyNode.comment = valueProps.comment;
          }
          const pair = new Pair.Pair(keyNode, valueNode);
          if (ctx.options.keepSourceTokens)
            pair.srcToken = collItem;
          if (isMap2) {
            const map = coll;
            if (utilMapIncludes.mapIncludes(ctx, map.items, keyNode))
              onError(keyStart, "DUPLICATE_KEY", "Map keys must be unique");
            map.items.push(pair);
          } else {
            const map = new YAMLMap.YAMLMap(ctx.schema);
            map.flow = true;
            map.items.push(pair);
            const endRange = (valueNode ?? keyNode).range;
            map.range = [keyNode.range[0], endRange[1], endRange[2]];
            coll.items.push(map);
          }
          offset = valueNode ? valueNode.range[2] : valueProps.end;
        }
      }
      const expectedEnd = isMap2 ? "}" : "]";
      const [ce, ...ee] = fc.end;
      let cePos = offset;
      if (ce?.source === expectedEnd)
        cePos = ce.offset + ce.source.length;
      else {
        const name = fcName[0].toUpperCase() + fcName.substring(1);
        const msg = atRoot ? `${name} must end with a ${expectedEnd}` : `${name} in block collection must be sufficiently indented and end with a ${expectedEnd}`;
        onError(offset, atRoot ? "MISSING_CHAR" : "BAD_INDENT", msg);
        if (ce && ce.source.length !== 1)
          ee.unshift(ce);
      }
      if (ee.length > 0) {
        const end = resolveEnd.resolveEnd(ee, cePos, ctx.options.strict, onError);
        if (end.comment) {
          if (coll.comment)
            coll.comment += "\n" + end.comment;
          else
            coll.comment = end.comment;
        }
        coll.range = [fc.offset, cePos, end.offset];
      } else {
        coll.range = [fc.offset, cePos, cePos];
      }
      return coll;
    }
    exports2.resolveFlowCollection = resolveFlowCollection;
  }
});

// node_modules/yaml/dist/compose/compose-collection.js
var require_compose_collection = __commonJS({
  "node_modules/yaml/dist/compose/compose-collection.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var Scalar = require_Scalar();
    var YAMLMap = require_YAMLMap();
    var YAMLSeq = require_YAMLSeq();
    var resolveBlockMap = require_resolve_block_map();
    var resolveBlockSeq = require_resolve_block_seq();
    var resolveFlowCollection = require_resolve_flow_collection();
    function resolveCollection(CN, ctx, token, onError, tagName, tag) {
      const coll = token.type === "block-map" ? resolveBlockMap.resolveBlockMap(CN, ctx, token, onError, tag) : token.type === "block-seq" ? resolveBlockSeq.resolveBlockSeq(CN, ctx, token, onError, tag) : resolveFlowCollection.resolveFlowCollection(CN, ctx, token, onError, tag);
      const Coll = coll.constructor;
      if (tagName === "!" || tagName === Coll.tagName) {
        coll.tag = Coll.tagName;
        return coll;
      }
      if (tagName)
        coll.tag = tagName;
      return coll;
    }
    function composeCollection(CN, ctx, token, props, onError) {
      const tagToken = props.tag;
      const tagName = !tagToken ? null : ctx.directives.tagName(tagToken.source, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg));
      if (token.type === "block-seq") {
        const { anchor, newlineAfterProp: nl } = props;
        const lastProp = anchor && tagToken ? anchor.offset > tagToken.offset ? anchor : tagToken : anchor ?? tagToken;
        if (lastProp && (!nl || nl.offset < lastProp.offset)) {
          const message = "Missing newline after block sequence props";
          onError(lastProp, "MISSING_CHAR", message);
        }
      }
      const expType = token.type === "block-map" ? "map" : token.type === "block-seq" ? "seq" : token.start.source === "{" ? "map" : "seq";
      if (!tagToken || !tagName || tagName === "!" || tagName === YAMLMap.YAMLMap.tagName && expType === "map" || tagName === YAMLSeq.YAMLSeq.tagName && expType === "seq") {
        return resolveCollection(CN, ctx, token, onError, tagName);
      }
      let tag = ctx.schema.tags.find((t) => t.tag === tagName && t.collection === expType);
      if (!tag) {
        const kt = ctx.schema.knownTags[tagName];
        if (kt?.collection === expType) {
          ctx.schema.tags.push(Object.assign({}, kt, { default: false }));
          tag = kt;
        } else {
          if (kt) {
            onError(tagToken, "BAD_COLLECTION_TYPE", `${kt.tag} used for ${expType} collection, but expects ${kt.collection ?? "scalar"}`, true);
          } else {
            onError(tagToken, "TAG_RESOLVE_FAILED", `Unresolved tag: ${tagName}`, true);
          }
          return resolveCollection(CN, ctx, token, onError, tagName);
        }
      }
      const coll = resolveCollection(CN, ctx, token, onError, tagName, tag);
      const res = tag.resolve?.(coll, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg), ctx.options) ?? coll;
      const node = identity2.isNode(res) ? res : new Scalar.Scalar(res);
      node.range = coll.range;
      node.tag = tagName;
      if (tag?.format)
        node.format = tag.format;
      return node;
    }
    exports2.composeCollection = composeCollection;
  }
});

// node_modules/yaml/dist/compose/resolve-block-scalar.js
var require_resolve_block_scalar = __commonJS({
  "node_modules/yaml/dist/compose/resolve-block-scalar.js"(exports2) {
    "use strict";
    var Scalar = require_Scalar();
    function resolveBlockScalar(ctx, scalar, onError) {
      const start2 = scalar.offset;
      const header = parseBlockScalarHeader(scalar, ctx.options.strict, onError);
      if (!header)
        return { value: "", type: null, comment: "", range: [start2, start2, start2] };
      const type = header.mode === ">" ? Scalar.Scalar.BLOCK_FOLDED : Scalar.Scalar.BLOCK_LITERAL;
      const lines = scalar.source ? splitLines(scalar.source) : [];
      let chompStart = lines.length;
      for (let i2 = lines.length - 1; i2 >= 0; --i2) {
        const content = lines[i2][1];
        if (content === "" || content === "\r")
          chompStart = i2;
        else
          break;
      }
      if (chompStart === 0) {
        const value2 = header.chomp === "+" && lines.length > 0 ? "\n".repeat(Math.max(1, lines.length - 1)) : "";
        let end2 = start2 + header.length;
        if (scalar.source)
          end2 += scalar.source.length;
        return { value: value2, type, comment: header.comment, range: [start2, end2, end2] };
      }
      let trimIndent = scalar.indent + header.indent;
      let offset = scalar.offset + header.length;
      let contentStart = 0;
      for (let i2 = 0; i2 < chompStart; ++i2) {
        const [indent, content] = lines[i2];
        if (content === "" || content === "\r") {
          if (header.indent === 0 && indent.length > trimIndent)
            trimIndent = indent.length;
        } else {
          if (indent.length < trimIndent) {
            const message = "Block scalars with more-indented leading empty lines must use an explicit indentation indicator";
            onError(offset + indent.length, "MISSING_CHAR", message);
          }
          if (header.indent === 0)
            trimIndent = indent.length;
          contentStart = i2;
          if (trimIndent === 0 && !ctx.atRoot) {
            const message = "Block scalar values in collections must be indented";
            onError(offset, "BAD_INDENT", message);
          }
          break;
        }
        offset += indent.length + content.length + 1;
      }
      for (let i2 = lines.length - 1; i2 >= chompStart; --i2) {
        if (lines[i2][0].length > trimIndent)
          chompStart = i2 + 1;
      }
      let value = "";
      let sep2 = "";
      let prevMoreIndented = false;
      for (let i2 = 0; i2 < contentStart; ++i2)
        value += lines[i2][0].slice(trimIndent) + "\n";
      for (let i2 = contentStart; i2 < chompStart; ++i2) {
        let [indent, content] = lines[i2];
        offset += indent.length + content.length + 1;
        const crlf = content[content.length - 1] === "\r";
        if (crlf)
          content = content.slice(0, -1);
        if (content && indent.length < trimIndent) {
          const src = header.indent ? "explicit indentation indicator" : "first line";
          const message = `Block scalar lines must not be less indented than their ${src}`;
          onError(offset - content.length - (crlf ? 2 : 1), "BAD_INDENT", message);
          indent = "";
        }
        if (type === Scalar.Scalar.BLOCK_LITERAL) {
          value += sep2 + indent.slice(trimIndent) + content;
          sep2 = "\n";
        } else if (indent.length > trimIndent || content[0] === "	") {
          if (sep2 === " ")
            sep2 = "\n";
          else if (!prevMoreIndented && sep2 === "\n")
            sep2 = "\n\n";
          value += sep2 + indent.slice(trimIndent) + content;
          sep2 = "\n";
          prevMoreIndented = true;
        } else if (content === "") {
          if (sep2 === "\n")
            value += "\n";
          else
            sep2 = "\n";
        } else {
          value += sep2 + content;
          sep2 = " ";
          prevMoreIndented = false;
        }
      }
      switch (header.chomp) {
        case "-":
          break;
        case "+":
          for (let i2 = chompStart; i2 < lines.length; ++i2)
            value += "\n" + lines[i2][0].slice(trimIndent);
          if (value[value.length - 1] !== "\n")
            value += "\n";
          break;
        default:
          value += "\n";
      }
      const end = start2 + header.length + scalar.source.length;
      return { value, type, comment: header.comment, range: [start2, end, end] };
    }
    function parseBlockScalarHeader({ offset, props }, strict, onError) {
      if (props[0].type !== "block-scalar-header") {
        onError(props[0], "IMPOSSIBLE", "Block scalar header not found");
        return null;
      }
      const { source: source2 } = props[0];
      const mode = source2[0];
      let indent = 0;
      let chomp = "";
      let error = -1;
      for (let i2 = 1; i2 < source2.length; ++i2) {
        const ch = source2[i2];
        if (!chomp && (ch === "-" || ch === "+"))
          chomp = ch;
        else {
          const n = Number(ch);
          if (!indent && n)
            indent = n;
          else if (error === -1)
            error = offset + i2;
        }
      }
      if (error !== -1)
        onError(error, "UNEXPECTED_TOKEN", `Block scalar header includes extra characters: ${source2}`);
      let hasSpace = false;
      let comment = "";
      let length = source2.length;
      for (let i2 = 1; i2 < props.length; ++i2) {
        const token = props[i2];
        switch (token.type) {
          case "space":
            hasSpace = true;
          // fallthrough
          case "newline":
            length += token.source.length;
            break;
          case "comment":
            if (strict && !hasSpace) {
              const message = "Comments must be separated from other tokens by white space characters";
              onError(token, "MISSING_CHAR", message);
            }
            length += token.source.length;
            comment = token.source.substring(1);
            break;
          case "error":
            onError(token, "UNEXPECTED_TOKEN", token.message);
            length += token.source.length;
            break;
          /* istanbul ignore next should not happen */
          default: {
            const message = `Unexpected token in block scalar header: ${token.type}`;
            onError(token, "UNEXPECTED_TOKEN", message);
            const ts = token.source;
            if (ts && typeof ts === "string")
              length += ts.length;
          }
        }
      }
      return { mode, indent, chomp, comment, length };
    }
    function splitLines(source2) {
      const split = source2.split(/\n( *)/);
      const first = split[0];
      const m = first.match(/^( *)/);
      const line0 = m?.[1] ? [m[1], first.slice(m[1].length)] : ["", first];
      const lines = [line0];
      for (let i2 = 1; i2 < split.length; i2 += 2)
        lines.push([split[i2], split[i2 + 1]]);
      return lines;
    }
    exports2.resolveBlockScalar = resolveBlockScalar;
  }
});

// node_modules/yaml/dist/compose/resolve-flow-scalar.js
var require_resolve_flow_scalar = __commonJS({
  "node_modules/yaml/dist/compose/resolve-flow-scalar.js"(exports2) {
    "use strict";
    var Scalar = require_Scalar();
    var resolveEnd = require_resolve_end();
    function resolveFlowScalar(scalar, strict, onError) {
      const { offset, type, source: source2, end } = scalar;
      let _type;
      let value;
      const _onError = (rel, code, msg) => onError(offset + rel, code, msg);
      switch (type) {
        case "scalar":
          _type = Scalar.Scalar.PLAIN;
          value = plainValue(source2, _onError);
          break;
        case "single-quoted-scalar":
          _type = Scalar.Scalar.QUOTE_SINGLE;
          value = singleQuotedValue(source2, _onError);
          break;
        case "double-quoted-scalar":
          _type = Scalar.Scalar.QUOTE_DOUBLE;
          value = doubleQuotedValue(source2, _onError);
          break;
        /* istanbul ignore next should not happen */
        default:
          onError(scalar, "UNEXPECTED_TOKEN", `Expected a flow scalar value, but found: ${type}`);
          return {
            value: "",
            type: null,
            comment: "",
            range: [offset, offset + source2.length, offset + source2.length]
          };
      }
      const valueEnd = offset + source2.length;
      const re = resolveEnd.resolveEnd(end, valueEnd, strict, onError);
      return {
        value,
        type: _type,
        comment: re.comment,
        range: [offset, valueEnd, re.offset]
      };
    }
    function plainValue(source2, onError) {
      let badChar = "";
      switch (source2[0]) {
        /* istanbul ignore next should not happen */
        case "	":
          badChar = "a tab character";
          break;
        case ",":
          badChar = "flow indicator character ,";
          break;
        case "%":
          badChar = "directive indicator character %";
          break;
        case "|":
        case ">": {
          badChar = `block scalar indicator ${source2[0]}`;
          break;
        }
        case "@":
        case "`": {
          badChar = `reserved character ${source2[0]}`;
          break;
        }
      }
      if (badChar)
        onError(0, "BAD_SCALAR_START", `Plain value cannot start with ${badChar}`);
      return foldLines(source2);
    }
    function singleQuotedValue(source2, onError) {
      if (source2[source2.length - 1] !== "'" || source2.length === 1)
        onError(source2.length, "MISSING_CHAR", "Missing closing 'quote");
      return foldLines(source2.slice(1, -1)).replace(/''/g, "'");
    }
    function foldLines(source2) {
      let first, line;
      try {
        first = new RegExp("(.*?)(?<![ 	])[ 	]*\r?\n", "sy");
        line = new RegExp("[ 	]*(.*?)(?:(?<![ 	])[ 	]*)?\r?\n", "sy");
      } catch {
        first = /(.*?)[ \t]*\r?\n/sy;
        line = /[ \t]*(.*?)[ \t]*\r?\n/sy;
      }
      let match = first.exec(source2);
      if (!match)
        return source2;
      let res = match[1];
      let sep2 = " ";
      let pos = first.lastIndex;
      line.lastIndex = pos;
      while (match = line.exec(source2)) {
        if (match[1] === "") {
          if (sep2 === "\n")
            res += sep2;
          else
            sep2 = "\n";
        } else {
          res += sep2 + match[1];
          sep2 = " ";
        }
        pos = line.lastIndex;
      }
      const last = /[ \t]*(.*)/sy;
      last.lastIndex = pos;
      match = last.exec(source2);
      return res + sep2 + (match?.[1] ?? "");
    }
    function doubleQuotedValue(source2, onError) {
      let res = "";
      for (let i2 = 1; i2 < source2.length - 1; ++i2) {
        const ch = source2[i2];
        if (ch === "\r" && source2[i2 + 1] === "\n")
          continue;
        if (ch === "\n") {
          const { fold, offset } = foldNewline(source2, i2);
          res += fold;
          i2 = offset;
        } else if (ch === "\\") {
          let next = source2[++i2];
          const cc = escapeCodes[next];
          if (cc)
            res += cc;
          else if (next === "\n") {
            next = source2[i2 + 1];
            while (next === " " || next === "	")
              next = source2[++i2 + 1];
          } else if (next === "\r" && source2[i2 + 1] === "\n") {
            next = source2[++i2 + 1];
            while (next === " " || next === "	")
              next = source2[++i2 + 1];
          } else if (next === "x" || next === "u" || next === "U") {
            const length = next === "x" ? 2 : next === "u" ? 4 : 8;
            res += parseCharCode(source2, i2 + 1, length, onError);
            i2 += length;
          } else {
            const raw = source2.substr(i2 - 1, 2);
            onError(i2 - 1, "BAD_DQ_ESCAPE", `Invalid escape sequence ${raw}`);
            res += raw;
          }
        } else if (ch === " " || ch === "	") {
          const wsStart = i2;
          let next = source2[i2 + 1];
          while (next === " " || next === "	")
            next = source2[++i2 + 1];
          if (next !== "\n" && !(next === "\r" && source2[i2 + 2] === "\n"))
            res += i2 > wsStart ? source2.slice(wsStart, i2 + 1) : ch;
        } else {
          res += ch;
        }
      }
      if (source2[source2.length - 1] !== '"' || source2.length === 1)
        onError(source2.length, "MISSING_CHAR", 'Missing closing "quote');
      return res;
    }
    function foldNewline(source2, offset) {
      let fold = "";
      let ch = source2[offset + 1];
      while (ch === " " || ch === "	" || ch === "\n" || ch === "\r") {
        if (ch === "\r" && source2[offset + 2] !== "\n")
          break;
        if (ch === "\n")
          fold += "\n";
        offset += 1;
        ch = source2[offset + 1];
      }
      if (!fold)
        fold = " ";
      return { fold, offset };
    }
    var escapeCodes = {
      "0": "\0",
      // null character
      a: "\x07",
      // bell character
      b: "\b",
      // backspace
      e: "\x1B",
      // escape character
      f: "\f",
      // form feed
      n: "\n",
      // line feed
      r: "\r",
      // carriage return
      t: "	",
      // horizontal tab
      v: "\v",
      // vertical tab
      N: "\x85",
      // Unicode next line
      _: "\xA0",
      // Unicode non-breaking space
      L: "\u2028",
      // Unicode line separator
      P: "\u2029",
      // Unicode paragraph separator
      " ": " ",
      '"': '"',
      "/": "/",
      "\\": "\\",
      "	": "	"
    };
    function parseCharCode(source2, offset, length, onError) {
      const cc = source2.substr(offset, length);
      const ok = cc.length === length && /^[0-9a-fA-F]+$/.test(cc);
      const code = ok ? parseInt(cc, 16) : NaN;
      try {
        return String.fromCodePoint(code);
      } catch {
        const raw = source2.substr(offset - 2, length + 2);
        onError(offset - 2, "BAD_DQ_ESCAPE", `Invalid escape sequence ${raw}`);
        return raw;
      }
    }
    exports2.resolveFlowScalar = resolveFlowScalar;
  }
});

// node_modules/yaml/dist/compose/compose-scalar.js
var require_compose_scalar = __commonJS({
  "node_modules/yaml/dist/compose/compose-scalar.js"(exports2) {
    "use strict";
    var identity2 = require_identity();
    var Scalar = require_Scalar();
    var resolveBlockScalar = require_resolve_block_scalar();
    var resolveFlowScalar = require_resolve_flow_scalar();
    function composeScalar(ctx, token, tagToken, onError) {
      const { value, type, comment, range } = token.type === "block-scalar" ? resolveBlockScalar.resolveBlockScalar(ctx, token, onError) : resolveFlowScalar.resolveFlowScalar(token, ctx.options.strict, onError);
      const tagName = tagToken ? ctx.directives.tagName(tagToken.source, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg)) : null;
      let tag;
      if (ctx.options.stringKeys && ctx.atKey) {
        tag = ctx.schema[identity2.SCALAR];
      } else if (tagName)
        tag = findScalarTagByName(ctx.schema, value, tagName, tagToken, onError);
      else if (token.type === "scalar")
        tag = findScalarTagByTest(ctx, value, token, onError);
      else
        tag = ctx.schema[identity2.SCALAR];
      let scalar;
      try {
        const res = tag.resolve(value, (msg) => onError(tagToken ?? token, "TAG_RESOLVE_FAILED", msg), ctx.options);
        scalar = identity2.isScalar(res) ? res : new Scalar.Scalar(res);
      } catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        onError(tagToken ?? token, "TAG_RESOLVE_FAILED", msg);
        scalar = new Scalar.Scalar(value);
      }
      scalar.range = range;
      scalar.source = value;
      if (type)
        scalar.type = type;
      if (tagName)
        scalar.tag = tagName;
      if (tag.format)
        scalar.format = tag.format;
      if (comment)
        scalar.comment = comment;
      return scalar;
    }
    function findScalarTagByName(schema2, value, tagName, tagToken, onError) {
      if (tagName === "!")
        return schema2[identity2.SCALAR];
      const matchWithTest = [];
      for (const tag of schema2.tags) {
        if (!tag.collection && tag.tag === tagName) {
          if (tag.default && tag.test)
            matchWithTest.push(tag);
          else
            return tag;
        }
      }
      for (const tag of matchWithTest)
        if (tag.test?.test(value))
          return tag;
      const kt = schema2.knownTags[tagName];
      if (kt && !kt.collection) {
        schema2.tags.push(Object.assign({}, kt, { default: false, test: void 0 }));
        return kt;
      }
      onError(tagToken, "TAG_RESOLVE_FAILED", `Unresolved tag: ${tagName}`, tagName !== "tag:yaml.org,2002:str");
      return schema2[identity2.SCALAR];
    }
    function findScalarTagByTest({ atKey, directives, schema: schema2 }, value, token, onError) {
      const tag = schema2.tags.find((tag2) => (tag2.default === true || atKey && tag2.default === "key") && tag2.test?.test(value)) || schema2[identity2.SCALAR];
      if (schema2.compat) {
        const compat = schema2.compat.find((tag2) => tag2.default && tag2.test?.test(value)) ?? schema2[identity2.SCALAR];
        if (tag.tag !== compat.tag) {
          const ts = directives.tagString(tag.tag);
          const cs = directives.tagString(compat.tag);
          const msg = `Value may be parsed as either ${ts} or ${cs}`;
          onError(token, "TAG_RESOLVE_FAILED", msg, true);
        }
      }
      return tag;
    }
    exports2.composeScalar = composeScalar;
  }
});

// node_modules/yaml/dist/compose/util-empty-scalar-position.js
var require_util_empty_scalar_position = __commonJS({
  "node_modules/yaml/dist/compose/util-empty-scalar-position.js"(exports2) {
    "use strict";
    function emptyScalarPosition(offset, before, pos) {
      if (before) {
        pos ?? (pos = before.length);
        for (let i2 = pos - 1; i2 >= 0; --i2) {
          let st = before[i2];
          switch (st.type) {
            case "space":
            case "comment":
            case "newline":
              offset -= st.source.length;
              continue;
          }
          st = before[++i2];
          while (st?.type === "space") {
            offset += st.source.length;
            st = before[++i2];
          }
          break;
        }
      }
      return offset;
    }
    exports2.emptyScalarPosition = emptyScalarPosition;
  }
});

// node_modules/yaml/dist/compose/compose-node.js
var require_compose_node = __commonJS({
  "node_modules/yaml/dist/compose/compose-node.js"(exports2) {
    "use strict";
    var Alias = require_Alias();
    var identity2 = require_identity();
    var composeCollection = require_compose_collection();
    var composeScalar = require_compose_scalar();
    var resolveEnd = require_resolve_end();
    var utilEmptyScalarPosition = require_util_empty_scalar_position();
    var CN = { composeNode, composeEmptyNode };
    function composeNode(ctx, token, props, onError) {
      const atKey = ctx.atKey;
      const { spaceBefore, comment, anchor, tag } = props;
      let node;
      let isSrcToken = true;
      switch (token.type) {
        case "alias":
          node = composeAlias(ctx, token, onError);
          if (anchor || tag)
            onError(token, "ALIAS_PROPS", "An alias node must not specify any properties");
          break;
        case "scalar":
        case "single-quoted-scalar":
        case "double-quoted-scalar":
        case "block-scalar":
          node = composeScalar.composeScalar(ctx, token, tag, onError);
          if (anchor)
            node.anchor = anchor.source.substring(1);
          break;
        case "block-map":
        case "block-seq":
        case "flow-collection":
          try {
            node = composeCollection.composeCollection(CN, ctx, token, props, onError);
            if (anchor)
              node.anchor = anchor.source.substring(1);
          } catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            onError(token, "RESOURCE_EXHAUSTION", message);
          }
          break;
        default: {
          const message = token.type === "error" ? token.message : `Unsupported token (type: ${token.type})`;
          onError(token, "UNEXPECTED_TOKEN", message);
          isSrcToken = false;
        }
      }
      node ?? (node = composeEmptyNode(ctx, token.offset, void 0, null, props, onError));
      if (anchor && node.anchor === "")
        onError(anchor, "BAD_ALIAS", "Anchor cannot be an empty string");
      if (atKey && ctx.options.stringKeys && (!identity2.isScalar(node) || typeof node.value !== "string" || node.tag && node.tag !== "tag:yaml.org,2002:str")) {
        const msg = "With stringKeys, all keys must be strings";
        onError(tag ?? token, "NON_STRING_KEY", msg);
      }
      if (spaceBefore)
        node.spaceBefore = true;
      if (comment) {
        if (token.type === "scalar" && token.source === "")
          node.comment = comment;
        else
          node.commentBefore = comment;
      }
      if (ctx.options.keepSourceTokens && isSrcToken)
        node.srcToken = token;
      return node;
    }
    function composeEmptyNode(ctx, offset, before, pos, { spaceBefore, comment, anchor, tag, end }, onError) {
      const token = {
        type: "scalar",
        offset: utilEmptyScalarPosition.emptyScalarPosition(offset, before, pos),
        indent: -1,
        source: ""
      };
      const node = composeScalar.composeScalar(ctx, token, tag, onError);
      if (anchor) {
        node.anchor = anchor.source.substring(1);
        if (node.anchor === "")
          onError(anchor, "BAD_ALIAS", "Anchor cannot be an empty string");
      }
      if (spaceBefore)
        node.spaceBefore = true;
      if (comment) {
        node.comment = comment;
        node.range[2] = end;
      }
      return node;
    }
    function composeAlias({ options }, { offset, source: source2, end }, onError) {
      const alias = new Alias.Alias(source2.substring(1));
      if (alias.source === "")
        onError(offset, "BAD_ALIAS", "Alias cannot be an empty string");
      if (alias.source.endsWith(":"))
        onError(offset + source2.length - 1, "BAD_ALIAS", "Alias ending in : is ambiguous", true);
      const valueEnd = offset + source2.length;
      const re = resolveEnd.resolveEnd(end, valueEnd, options.strict, onError);
      alias.range = [offset, valueEnd, re.offset];
      if (re.comment)
        alias.comment = re.comment;
      return alias;
    }
    exports2.composeEmptyNode = composeEmptyNode;
    exports2.composeNode = composeNode;
  }
});

// node_modules/yaml/dist/compose/compose-doc.js
var require_compose_doc = __commonJS({
  "node_modules/yaml/dist/compose/compose-doc.js"(exports2) {
    "use strict";
    var Document = require_Document();
    var composeNode = require_compose_node();
    var resolveEnd = require_resolve_end();
    var resolveProps = require_resolve_props();
    function composeDoc(options, directives, { offset, start: start2, value, end }, onError) {
      const opts = Object.assign({ _directives: directives }, options);
      const doc = new Document.Document(void 0, opts);
      const ctx = {
        atKey: false,
        atRoot: true,
        directives: doc.directives,
        options: doc.options,
        schema: doc.schema
      };
      const props = resolveProps.resolveProps(start2, {
        indicator: "doc-start",
        next: value ?? end?.[0],
        offset,
        onError,
        parentIndent: 0,
        startOnNewline: true
      });
      if (props.found) {
        doc.directives.docStart = true;
        if (value && (value.type === "block-map" || value.type === "block-seq") && !props.hasNewline)
          onError(props.end, "MISSING_CHAR", "Block collection cannot start on same line with directives-end marker");
      }
      doc.contents = value ? composeNode.composeNode(ctx, value, props, onError) : composeNode.composeEmptyNode(ctx, props.end, start2, null, props, onError);
      const contentEnd = doc.contents.range[2];
      const re = resolveEnd.resolveEnd(end, contentEnd, false, onError);
      if (re.comment)
        doc.comment = re.comment;
      doc.range = [offset, contentEnd, re.offset];
      return doc;
    }
    exports2.composeDoc = composeDoc;
  }
});

// node_modules/yaml/dist/compose/composer.js
var require_composer = __commonJS({
  "node_modules/yaml/dist/compose/composer.js"(exports2) {
    "use strict";
    var node_process = __require("process");
    var directives = require_directives();
    var Document = require_Document();
    var errors = require_errors();
    var identity2 = require_identity();
    var composeDoc = require_compose_doc();
    var resolveEnd = require_resolve_end();
    function getErrorPos(src) {
      if (typeof src === "number")
        return [src, src + 1];
      if (Array.isArray(src))
        return src.length === 2 ? src : [src[0], src[1]];
      const { offset, source: source2 } = src;
      return [offset, offset + (typeof source2 === "string" ? source2.length : 1)];
    }
    function parsePrelude(prelude) {
      let comment = "";
      let atComment = false;
      let afterEmptyLine = false;
      for (let i2 = 0; i2 < prelude.length; ++i2) {
        const source2 = prelude[i2];
        switch (source2[0]) {
          case "#":
            comment += (comment === "" ? "" : afterEmptyLine ? "\n\n" : "\n") + (source2.substring(1) || " ");
            atComment = true;
            afterEmptyLine = false;
            break;
          case "%":
            if (prelude[i2 + 1]?.[0] !== "#")
              i2 += 1;
            atComment = false;
            break;
          default:
            if (!atComment)
              afterEmptyLine = true;
            atComment = false;
        }
      }
      return { comment, afterEmptyLine };
    }
    var Composer = class {
      constructor(options = {}) {
        this.doc = null;
        this.atDirectives = false;
        this.prelude = [];
        this.errors = [];
        this.warnings = [];
        this.onError = (source2, code, message, warning) => {
          const pos = getErrorPos(source2);
          if (warning)
            this.warnings.push(new errors.YAMLWarning(pos, code, message));
          else
            this.errors.push(new errors.YAMLParseError(pos, code, message));
        };
        this.directives = new directives.Directives({ version: options.version || "1.2" });
        this.options = options;
      }
      decorate(doc, afterDoc) {
        const { comment, afterEmptyLine } = parsePrelude(this.prelude);
        if (comment) {
          const dc = doc.contents;
          if (afterDoc) {
            doc.comment = doc.comment ? `${doc.comment}
${comment}` : comment;
          } else if (afterEmptyLine || doc.directives.docStart || !dc) {
            doc.commentBefore = comment;
          } else if (identity2.isCollection(dc) && !dc.flow && dc.items.length > 0) {
            let it = dc.items[0];
            if (identity2.isPair(it))
              it = it.key;
            const cb = it.commentBefore;
            it.commentBefore = cb ? `${comment}
${cb}` : comment;
          } else {
            const cb = dc.commentBefore;
            dc.commentBefore = cb ? `${comment}
${cb}` : comment;
          }
        }
        if (afterDoc) {
          for (let i2 = 0; i2 < this.errors.length; ++i2)
            doc.errors.push(this.errors[i2]);
          for (let i2 = 0; i2 < this.warnings.length; ++i2)
            doc.warnings.push(this.warnings[i2]);
        } else {
          doc.errors = this.errors;
          doc.warnings = this.warnings;
        }
        this.prelude = [];
        this.errors = [];
        this.warnings = [];
      }
      /**
       * Current stream status information.
       *
       * Mostly useful at the end of input for an empty stream.
       */
      streamInfo() {
        return {
          comment: parsePrelude(this.prelude).comment,
          directives: this.directives,
          errors: this.errors,
          warnings: this.warnings
        };
      }
      /**
       * Compose tokens into documents.
       *
       * @param forceDoc - If the stream contains no document, still emit a final document including any comments and directives that would be applied to a subsequent document.
       * @param endOffset - Should be set if `forceDoc` is also set, to set the document range end and to indicate errors correctly.
       */
      *compose(tokens, forceDoc = false, endOffset = -1) {
        for (const token of tokens)
          yield* this.next(token);
        yield* this.end(forceDoc, endOffset);
      }
      /** Advance the composer by one CST token. */
      *next(token) {
        if (node_process.env.LOG_STREAM)
          console.dir(token, { depth: null });
        switch (token.type) {
          case "directive":
            this.directives.add(token.source, (offset, message, warning) => {
              const pos = getErrorPos(token);
              pos[0] += offset;
              this.onError(pos, "BAD_DIRECTIVE", message, warning);
            });
            this.prelude.push(token.source);
            this.atDirectives = true;
            break;
          case "document": {
            const doc = composeDoc.composeDoc(this.options, this.directives, token, this.onError);
            if (this.atDirectives && !doc.directives.docStart)
              this.onError(token, "MISSING_CHAR", "Missing directives-end/doc-start indicator line");
            this.decorate(doc, false);
            if (this.doc)
              yield this.doc;
            this.doc = doc;
            this.atDirectives = false;
            break;
          }
          case "byte-order-mark":
          case "space":
            break;
          case "comment":
          case "newline":
            this.prelude.push(token.source);
            break;
          case "error": {
            const msg = token.source ? `${token.message}: ${JSON.stringify(token.source)}` : token.message;
            const error = new errors.YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", msg);
            if (this.atDirectives || !this.doc)
              this.errors.push(error);
            else
              this.doc.errors.push(error);
            break;
          }
          case "doc-end": {
            if (!this.doc) {
              const msg = "Unexpected doc-end without preceding document";
              this.errors.push(new errors.YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", msg));
              break;
            }
            this.doc.directives.docEnd = true;
            const end = resolveEnd.resolveEnd(token.end, token.offset + token.source.length, this.doc.options.strict, this.onError);
            this.decorate(this.doc, true);
            if (end.comment) {
              const dc = this.doc.comment;
              this.doc.comment = dc ? `${dc}
${end.comment}` : end.comment;
            }
            this.doc.range[2] = end.offset;
            break;
          }
          default:
            this.errors.push(new errors.YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", `Unsupported token ${token.type}`));
        }
      }
      /**
       * Call at end of input to yield any remaining document.
       *
       * @param forceDoc - If the stream contains no document, still emit a final document including any comments and directives that would be applied to a subsequent document.
       * @param endOffset - Should be set if `forceDoc` is also set, to set the document range end and to indicate errors correctly.
       */
      *end(forceDoc = false, endOffset = -1) {
        if (this.doc) {
          this.decorate(this.doc, true);
          yield this.doc;
          this.doc = null;
        } else if (forceDoc) {
          const opts = Object.assign({ _directives: this.directives }, this.options);
          const doc = new Document.Document(void 0, opts);
          if (this.atDirectives)
            this.onError(endOffset, "MISSING_CHAR", "Missing directives-end indicator line");
          doc.range = [0, endOffset, endOffset];
          this.decorate(doc, false);
          yield doc;
        }
      }
    };
    exports2.Composer = Composer;
  }
});

// node_modules/yaml/dist/parse/cst-scalar.js
var require_cst_scalar = __commonJS({
  "node_modules/yaml/dist/parse/cst-scalar.js"(exports2) {
    "use strict";
    var resolveBlockScalar = require_resolve_block_scalar();
    var resolveFlowScalar = require_resolve_flow_scalar();
    var errors = require_errors();
    var stringifyString = require_stringifyString();
    function resolveAsScalar(token, strict = true, onError) {
      if (token) {
        const _onError = (pos, code, message) => {
          const offset = typeof pos === "number" ? pos : Array.isArray(pos) ? pos[0] : pos.offset;
          if (onError)
            onError(offset, code, message);
          else
            throw new errors.YAMLParseError([offset, offset + 1], code, message);
        };
        switch (token.type) {
          case "scalar":
          case "single-quoted-scalar":
          case "double-quoted-scalar":
            return resolveFlowScalar.resolveFlowScalar(token, strict, _onError);
          case "block-scalar":
            return resolveBlockScalar.resolveBlockScalar({ options: { strict } }, token, _onError);
        }
      }
      return null;
    }
    function createScalarToken(value, context2) {
      const { implicitKey = false, indent, inFlow = false, offset = -1, type = "PLAIN" } = context2;
      const source2 = stringifyString.stringifyString({ type, value }, {
        implicitKey,
        indent: indent > 0 ? " ".repeat(indent) : "",
        inFlow,
        options: { blockQuote: true, lineWidth: -1 }
      });
      const end = context2.end ?? [
        { type: "newline", offset: -1, indent, source: "\n" }
      ];
      switch (source2[0]) {
        case "|":
        case ">": {
          const he = source2.indexOf("\n");
          const head = source2.substring(0, he);
          const body = source2.substring(he + 1) + "\n";
          const props = [
            { type: "block-scalar-header", offset, indent, source: head }
          ];
          if (!addEndtoBlockProps(props, end))
            props.push({ type: "newline", offset: -1, indent, source: "\n" });
          return { type: "block-scalar", offset, indent, props, source: body };
        }
        case '"':
          return { type: "double-quoted-scalar", offset, indent, source: source2, end };
        case "'":
          return { type: "single-quoted-scalar", offset, indent, source: source2, end };
        default:
          return { type: "scalar", offset, indent, source: source2, end };
      }
    }
    function setScalarValue(token, value, context2 = {}) {
      let { afterKey = false, implicitKey = false, inFlow = false, type } = context2;
      let indent = "indent" in token ? token.indent : null;
      if (afterKey && typeof indent === "number")
        indent += 2;
      if (!type)
        switch (token.type) {
          case "single-quoted-scalar":
            type = "QUOTE_SINGLE";
            break;
          case "double-quoted-scalar":
            type = "QUOTE_DOUBLE";
            break;
          case "block-scalar": {
            const header = token.props[0];
            if (header.type !== "block-scalar-header")
              throw new Error("Invalid block scalar header");
            type = header.source[0] === ">" ? "BLOCK_FOLDED" : "BLOCK_LITERAL";
            break;
          }
          default:
            type = "PLAIN";
        }
      const source2 = stringifyString.stringifyString({ type, value }, {
        implicitKey: implicitKey || indent === null,
        indent: indent !== null && indent > 0 ? " ".repeat(indent) : "",
        inFlow,
        options: { blockQuote: true, lineWidth: -1 }
      });
      switch (source2[0]) {
        case "|":
        case ">":
          setBlockScalarValue(token, source2);
          break;
        case '"':
          setFlowScalarValue(token, source2, "double-quoted-scalar");
          break;
        case "'":
          setFlowScalarValue(token, source2, "single-quoted-scalar");
          break;
        default:
          setFlowScalarValue(token, source2, "scalar");
      }
    }
    function setBlockScalarValue(token, source2) {
      const he = source2.indexOf("\n");
      const head = source2.substring(0, he);
      const body = source2.substring(he + 1) + "\n";
      if (token.type === "block-scalar") {
        const header = token.props[0];
        if (header.type !== "block-scalar-header")
          throw new Error("Invalid block scalar header");
        header.source = head;
        token.source = body;
      } else {
        const { offset } = token;
        const indent = "indent" in token ? token.indent : -1;
        const props = [
          { type: "block-scalar-header", offset, indent, source: head }
        ];
        if (!addEndtoBlockProps(props, "end" in token ? token.end : void 0))
          props.push({ type: "newline", offset: -1, indent, source: "\n" });
        for (const key of Object.keys(token))
          if (key !== "type" && key !== "offset")
            delete token[key];
        Object.assign(token, { type: "block-scalar", indent, props, source: body });
      }
    }
    function addEndtoBlockProps(props, end) {
      if (end)
        for (const st of end)
          switch (st.type) {
            case "space":
            case "comment":
              props.push(st);
              break;
            case "newline":
              props.push(st);
              return true;
          }
      return false;
    }
    function setFlowScalarValue(token, source2, type) {
      switch (token.type) {
        case "scalar":
        case "double-quoted-scalar":
        case "single-quoted-scalar":
          token.type = type;
          token.source = source2;
          break;
        case "block-scalar": {
          const end = token.props.slice(1);
          let oa = source2.length;
          if (token.props[0].type === "block-scalar-header")
            oa -= token.props[0].source.length;
          for (const tok of end)
            tok.offset += oa;
          delete token.props;
          Object.assign(token, { type, source: source2, end });
          break;
        }
        case "block-map":
        case "block-seq": {
          const offset = token.offset + source2.length;
          const nl = { type: "newline", offset, indent: token.indent, source: "\n" };
          delete token.items;
          Object.assign(token, { type, source: source2, end: [nl] });
          break;
        }
        default: {
          const indent = "indent" in token ? token.indent : -1;
          const end = "end" in token && Array.isArray(token.end) ? token.end.filter((st) => st.type === "space" || st.type === "comment" || st.type === "newline") : [];
          for (const key of Object.keys(token))
            if (key !== "type" && key !== "offset")
              delete token[key];
          Object.assign(token, { type, indent, source: source2, end });
        }
      }
    }
    exports2.createScalarToken = createScalarToken;
    exports2.resolveAsScalar = resolveAsScalar;
    exports2.setScalarValue = setScalarValue;
  }
});

// node_modules/yaml/dist/parse/cst-stringify.js
var require_cst_stringify = __commonJS({
  "node_modules/yaml/dist/parse/cst-stringify.js"(exports2) {
    "use strict";
    var stringify2 = (cst) => "type" in cst ? stringifyToken(cst) : stringifyItem(cst);
    function stringifyToken(token) {
      switch (token.type) {
        case "block-scalar": {
          let res = "";
          for (const tok of token.props)
            res += stringifyToken(tok);
          return res + token.source;
        }
        case "block-map":
        case "block-seq": {
          let res = "";
          for (const item of token.items)
            res += stringifyItem(item);
          return res;
        }
        case "flow-collection": {
          let res = token.start.source;
          for (const item of token.items)
            res += stringifyItem(item);
          for (const st of token.end)
            res += st.source;
          return res;
        }
        case "document": {
          let res = stringifyItem(token);
          if (token.end)
            for (const st of token.end)
              res += st.source;
          return res;
        }
        default: {
          let res = token.source;
          if ("end" in token && token.end)
            for (const st of token.end)
              res += st.source;
          return res;
        }
      }
    }
    function stringifyItem({ start: start2, key, sep: sep2, value }) {
      let res = "";
      for (const st of start2)
        res += st.source;
      if (key)
        res += stringifyToken(key);
      if (sep2)
        for (const st of sep2)
          res += st.source;
      if (value)
        res += stringifyToken(value);
      return res;
    }
    exports2.stringify = stringify2;
  }
});

// node_modules/yaml/dist/parse/cst-visit.js
var require_cst_visit = __commonJS({
  "node_modules/yaml/dist/parse/cst-visit.js"(exports2) {
    "use strict";
    var BREAK = /* @__PURE__ */ Symbol("break visit");
    var SKIP = /* @__PURE__ */ Symbol("skip children");
    var REMOVE = /* @__PURE__ */ Symbol("remove item");
    function visit(cst, visitor) {
      if ("type" in cst && cst.type === "document")
        cst = { start: cst.start, value: cst.value };
      _visit(Object.freeze([]), cst, visitor);
    }
    visit.BREAK = BREAK;
    visit.SKIP = SKIP;
    visit.REMOVE = REMOVE;
    visit.itemAtPath = (cst, path7) => {
      let item = cst;
      for (const [field, index] of path7) {
        const tok = item?.[field];
        if (tok && "items" in tok) {
          item = tok.items[index];
        } else
          return void 0;
      }
      return item;
    };
    visit.parentCollection = (cst, path7) => {
      const parent = visit.itemAtPath(cst, path7.slice(0, -1));
      const field = path7[path7.length - 1][0];
      const coll = parent?.[field];
      if (coll && "items" in coll)
        return coll;
      throw new Error("Parent collection not found");
    };
    function _visit(path7, item, visitor) {
      let ctrl = visitor(item, path7);
      if (typeof ctrl === "symbol")
        return ctrl;
      for (const field of ["key", "value"]) {
        const token = item[field];
        if (token && "items" in token) {
          for (let i2 = 0; i2 < token.items.length; ++i2) {
            const ci = _visit(Object.freeze(path7.concat([[field, i2]])), token.items[i2], visitor);
            if (typeof ci === "number")
              i2 = ci - 1;
            else if (ci === BREAK)
              return BREAK;
            else if (ci === REMOVE) {
              token.items.splice(i2, 1);
              i2 -= 1;
            }
          }
          if (typeof ctrl === "function" && field === "key")
            ctrl = ctrl(item, path7);
        }
      }
      return typeof ctrl === "function" ? ctrl(item, path7) : ctrl;
    }
    exports2.visit = visit;
  }
});

// node_modules/yaml/dist/parse/cst.js
var require_cst = __commonJS({
  "node_modules/yaml/dist/parse/cst.js"(exports2) {
    "use strict";
    var cstScalar = require_cst_scalar();
    var cstStringify = require_cst_stringify();
    var cstVisit = require_cst_visit();
    var BOM = "\uFEFF";
    var DOCUMENT = "";
    var FLOW_END = "";
    var SCALAR = "";
    var isCollection = (token) => !!token && "items" in token;
    var isScalar = (token) => !!token && (token.type === "scalar" || token.type === "single-quoted-scalar" || token.type === "double-quoted-scalar" || token.type === "block-scalar");
    function prettyToken(token) {
      switch (token) {
        case BOM:
          return "<BOM>";
        case DOCUMENT:
          return "<DOC>";
        case FLOW_END:
          return "<FLOW_END>";
        case SCALAR:
          return "<SCALAR>";
        default:
          return JSON.stringify(token);
      }
    }
    function tokenType(source2) {
      switch (source2) {
        case BOM:
          return "byte-order-mark";
        case DOCUMENT:
          return "doc-mode";
        case FLOW_END:
          return "flow-error-end";
        case SCALAR:
          return "scalar";
        case "---":
          return "doc-start";
        case "...":
          return "doc-end";
        case "":
        case "\n":
        case "\r\n":
          return "newline";
        case "-":
          return "seq-item-ind";
        case "?":
          return "explicit-key-ind";
        case ":":
          return "map-value-ind";
        case "{":
          return "flow-map-start";
        case "}":
          return "flow-map-end";
        case "[":
          return "flow-seq-start";
        case "]":
          return "flow-seq-end";
        case ",":
          return "comma";
      }
      switch (source2[0]) {
        case " ":
        case "	":
          return "space";
        case "#":
          return "comment";
        case "%":
          return "directive-line";
        case "*":
          return "alias";
        case "&":
          return "anchor";
        case "!":
          return "tag";
        case "'":
          return "single-quoted-scalar";
        case '"':
          return "double-quoted-scalar";
        case "|":
        case ">":
          return "block-scalar-header";
      }
      return null;
    }
    exports2.createScalarToken = cstScalar.createScalarToken;
    exports2.resolveAsScalar = cstScalar.resolveAsScalar;
    exports2.setScalarValue = cstScalar.setScalarValue;
    exports2.stringify = cstStringify.stringify;
    exports2.visit = cstVisit.visit;
    exports2.BOM = BOM;
    exports2.DOCUMENT = DOCUMENT;
    exports2.FLOW_END = FLOW_END;
    exports2.SCALAR = SCALAR;
    exports2.isCollection = isCollection;
    exports2.isScalar = isScalar;
    exports2.prettyToken = prettyToken;
    exports2.tokenType = tokenType;
  }
});

// node_modules/yaml/dist/parse/lexer.js
var require_lexer = __commonJS({
  "node_modules/yaml/dist/parse/lexer.js"(exports2) {
    "use strict";
    var cst = require_cst();
    function isEmpty(ch) {
      switch (ch) {
        case void 0:
        case " ":
        case "\n":
        case "\r":
        case "	":
          return true;
        default:
          return false;
      }
    }
    var hexDigits = new Set("0123456789ABCDEFabcdef");
    var tagChars = new Set("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-#;/?:@&=+$_.!~*'()");
    var flowIndicatorChars = new Set(",[]{}");
    var invalidAnchorChars = new Set(" ,[]{}\n\r	");
    var isNotAnchorChar = (ch) => !ch || invalidAnchorChars.has(ch);
    var Lexer = class {
      constructor() {
        this.atEnd = false;
        this.blockScalarIndent = -1;
        this.blockScalarKeep = false;
        this.buffer = "";
        this.flowKey = false;
        this.flowLevel = 0;
        this.indentNext = 0;
        this.indentValue = 0;
        this.lineEndPos = null;
        this.next = null;
        this.pos = 0;
      }
      /**
       * Generate YAML tokens from the `source` string. If `incomplete`,
       * a part of the last line may be left as a buffer for the next call.
       *
       * @returns A generator of lexical tokens
       */
      *lex(source2, incomplete = false) {
        if (source2) {
          if (typeof source2 !== "string")
            throw TypeError("source is not a string");
          this.buffer = this.buffer ? this.buffer + source2 : source2;
          this.lineEndPos = null;
        }
        this.atEnd = !incomplete;
        let next = this.next ?? "stream";
        while (next && (incomplete || this.hasChars(1)))
          next = yield* this.parseNext(next);
      }
      atLineEnd() {
        let i2 = this.pos;
        let ch = this.buffer[i2];
        while (ch === " " || ch === "	")
          ch = this.buffer[++i2];
        if (!ch || ch === "#" || ch === "\n")
          return true;
        if (ch === "\r")
          return this.buffer[i2 + 1] === "\n";
        return false;
      }
      charAt(n) {
        return this.buffer[this.pos + n];
      }
      continueScalar(offset) {
        let ch = this.buffer[offset];
        if (this.indentNext > 0) {
          let indent = 0;
          while (ch === " ")
            ch = this.buffer[++indent + offset];
          if (ch === "\r") {
            const next = this.buffer[indent + offset + 1];
            if (next === "\n" || !next && !this.atEnd)
              return offset + indent + 1;
          }
          return ch === "\n" || indent >= this.indentNext || !ch && !this.atEnd ? offset + indent : -1;
        }
        if (ch === "-" || ch === ".") {
          const dt = this.buffer.substr(offset, 3);
          if ((dt === "---" || dt === "...") && isEmpty(this.buffer[offset + 3]))
            return -1;
        }
        return offset;
      }
      getLine() {
        let end = this.lineEndPos;
        if (typeof end !== "number" || end !== -1 && end < this.pos) {
          end = this.buffer.indexOf("\n", this.pos);
          this.lineEndPos = end;
        }
        if (end === -1)
          return this.atEnd ? this.buffer.substring(this.pos) : null;
        if (this.buffer[end - 1] === "\r")
          end -= 1;
        return this.buffer.substring(this.pos, end);
      }
      hasChars(n) {
        return this.pos + n <= this.buffer.length;
      }
      setNext(state2) {
        this.buffer = this.buffer.substring(this.pos);
        this.pos = 0;
        this.lineEndPos = null;
        this.next = state2;
        return null;
      }
      peek(n) {
        return this.buffer.substr(this.pos, n);
      }
      *parseNext(next) {
        switch (next) {
          case "stream":
            return yield* this.parseStream();
          case "line-start":
            return yield* this.parseLineStart();
          case "block-start":
            return yield* this.parseBlockStart();
          case "doc":
            return yield* this.parseDocument();
          case "flow":
            return yield* this.parseFlowCollection();
          case "quoted-scalar":
            return yield* this.parseQuotedScalar();
          case "block-scalar":
            return yield* this.parseBlockScalar();
          case "plain-scalar":
            return yield* this.parsePlainScalar();
        }
      }
      *parseStream() {
        let line = this.getLine();
        if (line === null)
          return this.setNext("stream");
        if (line[0] === cst.BOM) {
          yield* this.pushCount(1);
          line = line.substring(1);
        }
        if (line[0] === "%") {
          let dirEnd = line.length;
          let cs = line.indexOf("#");
          while (cs !== -1) {
            const ch = line[cs - 1];
            if (ch === " " || ch === "	") {
              dirEnd = cs - 1;
              break;
            } else {
              cs = line.indexOf("#", cs + 1);
            }
          }
          while (true) {
            const ch = line[dirEnd - 1];
            if (ch === " " || ch === "	")
              dirEnd -= 1;
            else
              break;
          }
          const n = (yield* this.pushCount(dirEnd)) + (yield* this.pushSpaces(true));
          yield* this.pushCount(line.length - n);
          this.pushNewline();
          return "stream";
        }
        if (this.atLineEnd()) {
          const sp = yield* this.pushSpaces(true);
          yield* this.pushCount(line.length - sp);
          yield* this.pushNewline();
          return "stream";
        }
        yield cst.DOCUMENT;
        return yield* this.parseLineStart();
      }
      *parseLineStart() {
        const ch = this.charAt(0);
        if (!ch && !this.atEnd)
          return this.setNext("line-start");
        if (ch === "-" || ch === ".") {
          if (!this.atEnd && !this.hasChars(4))
            return this.setNext("line-start");
          const s = this.peek(3);
          if ((s === "---" || s === "...") && isEmpty(this.charAt(3))) {
            yield* this.pushCount(3);
            this.indentValue = 0;
            this.indentNext = 0;
            return s === "---" ? "doc" : "stream";
          }
        }
        this.indentValue = yield* this.pushSpaces(false);
        if (this.indentNext > this.indentValue && !isEmpty(this.charAt(1)))
          this.indentNext = this.indentValue;
        return yield* this.parseBlockStart();
      }
      *parseBlockStart() {
        const [ch0, ch1] = this.peek(2);
        if (!ch1 && !this.atEnd)
          return this.setNext("block-start");
        if ((ch0 === "-" || ch0 === "?" || ch0 === ":") && isEmpty(ch1)) {
          const n = (yield* this.pushCount(1)) + (yield* this.pushSpaces(true));
          this.indentNext = this.indentValue + 1;
          this.indentValue += n;
          return "block-start";
        }
        return "doc";
      }
      *parseDocument() {
        yield* this.pushSpaces(true);
        const line = this.getLine();
        if (line === null)
          return this.setNext("doc");
        let n = yield* this.pushIndicators();
        switch (line[n]) {
          case "#":
            yield* this.pushCount(line.length - n);
          // fallthrough
          case void 0:
            yield* this.pushNewline();
            return yield* this.parseLineStart();
          case "{":
          case "[":
            yield* this.pushCount(1);
            this.flowKey = false;
            this.flowLevel = 1;
            return "flow";
          case "}":
          case "]":
            yield* this.pushCount(1);
            return "doc";
          case "*":
            yield* this.pushUntil(isNotAnchorChar);
            return "doc";
          case '"':
          case "'":
            return yield* this.parseQuotedScalar();
          case "|":
          case ">":
            n += yield* this.parseBlockScalarHeader();
            n += yield* this.pushSpaces(true);
            yield* this.pushCount(line.length - n);
            yield* this.pushNewline();
            return yield* this.parseBlockScalar();
          default:
            return yield* this.parsePlainScalar();
        }
      }
      *parseFlowCollection() {
        let nl, sp;
        let indent = -1;
        do {
          nl = yield* this.pushNewline();
          if (nl > 0) {
            sp = yield* this.pushSpaces(false);
            this.indentValue = indent = sp;
          } else {
            sp = 0;
          }
          sp += yield* this.pushSpaces(true);
        } while (nl + sp > 0);
        const line = this.getLine();
        if (line === null)
          return this.setNext("flow");
        if (indent !== -1 && indent < this.indentNext && line[0] !== "#" || indent === 0 && (line.startsWith("---") || line.startsWith("...")) && isEmpty(line[3])) {
          const atFlowEndMarker = indent === this.indentNext - 1 && this.flowLevel === 1 && (line[0] === "]" || line[0] === "}");
          if (!atFlowEndMarker) {
            this.flowLevel = 0;
            yield cst.FLOW_END;
            return yield* this.parseLineStart();
          }
        }
        let n = 0;
        while (line[n] === ",") {
          n += yield* this.pushCount(1);
          n += yield* this.pushSpaces(true);
          this.flowKey = false;
        }
        n += yield* this.pushIndicators();
        switch (line[n]) {
          case void 0:
            return "flow";
          case "#":
            yield* this.pushCount(line.length - n);
            return "flow";
          case "{":
          case "[":
            yield* this.pushCount(1);
            this.flowKey = false;
            this.flowLevel += 1;
            return "flow";
          case "}":
          case "]":
            yield* this.pushCount(1);
            this.flowKey = true;
            this.flowLevel -= 1;
            return this.flowLevel ? "flow" : "doc";
          case "*":
            yield* this.pushUntil(isNotAnchorChar);
            return "flow";
          case '"':
          case "'":
            this.flowKey = true;
            return yield* this.parseQuotedScalar();
          case ":": {
            const next = this.charAt(1);
            if (this.flowKey || isEmpty(next) || next === ",") {
              this.flowKey = false;
              yield* this.pushCount(1);
              yield* this.pushSpaces(true);
              return "flow";
            }
          }
          // fallthrough
          default:
            this.flowKey = false;
            return yield* this.parsePlainScalar();
        }
      }
      *parseQuotedScalar() {
        const quote3 = this.charAt(0);
        let end = this.buffer.indexOf(quote3, this.pos + 1);
        if (quote3 === "'") {
          while (end !== -1 && this.buffer[end + 1] === "'")
            end = this.buffer.indexOf("'", end + 2);
        } else {
          while (end !== -1) {
            let n = 0;
            while (this.buffer[end - 1 - n] === "\\")
              n += 1;
            if (n % 2 === 0)
              break;
            end = this.buffer.indexOf('"', end + 1);
          }
        }
        const qb = this.buffer.substring(0, end);
        let nl = qb.indexOf("\n", this.pos);
        if (nl !== -1) {
          while (nl !== -1) {
            const cs = this.continueScalar(nl + 1);
            if (cs === -1)
              break;
            nl = qb.indexOf("\n", cs);
          }
          if (nl !== -1) {
            end = nl - (qb[nl - 1] === "\r" ? 2 : 1);
          }
        }
        if (end === -1) {
          if (!this.atEnd)
            return this.setNext("quoted-scalar");
          end = this.buffer.length;
        }
        yield* this.pushToIndex(end + 1, false);
        return this.flowLevel ? "flow" : "doc";
      }
      *parseBlockScalarHeader() {
        this.blockScalarIndent = -1;
        this.blockScalarKeep = false;
        let i2 = this.pos;
        while (true) {
          const ch = this.buffer[++i2];
          if (ch === "+")
            this.blockScalarKeep = true;
          else if (ch > "0" && ch <= "9")
            this.blockScalarIndent = Number(ch) - 1;
          else if (ch !== "-")
            break;
        }
        return yield* this.pushUntil((ch) => isEmpty(ch) || ch === "#");
      }
      *parseBlockScalar() {
        let nl = this.pos - 1;
        let indent = 0;
        let ch;
        loop: for (let i3 = this.pos; ch = this.buffer[i3]; ++i3) {
          switch (ch) {
            case " ":
              indent += 1;
              break;
            case "\n":
              nl = i3;
              indent = 0;
              break;
            case "\r": {
              const next = this.buffer[i3 + 1];
              if (!next && !this.atEnd)
                return this.setNext("block-scalar");
              if (next === "\n")
                break;
            }
            // fallthrough
            default:
              break loop;
          }
        }
        if (!ch && !this.atEnd)
          return this.setNext("block-scalar");
        if (indent >= this.indentNext) {
          if (this.blockScalarIndent === -1)
            this.indentNext = indent;
          else {
            this.indentNext = this.blockScalarIndent + (this.indentNext === 0 ? 1 : this.indentNext);
          }
          do {
            const cs = this.continueScalar(nl + 1);
            if (cs === -1)
              break;
            nl = this.buffer.indexOf("\n", cs);
          } while (nl !== -1);
          if (nl === -1) {
            if (!this.atEnd)
              return this.setNext("block-scalar");
            nl = this.buffer.length;
          }
        }
        let i2 = nl + 1;
        ch = this.buffer[i2];
        while (ch === " ")
          ch = this.buffer[++i2];
        if (ch === "	") {
          while (ch === "	" || ch === " " || ch === "\r" || ch === "\n")
            ch = this.buffer[++i2];
          nl = i2 - 1;
        } else if (!this.blockScalarKeep) {
          do {
            let i3 = nl - 1;
            let ch2 = this.buffer[i3];
            if (ch2 === "\r")
              ch2 = this.buffer[--i3];
            const lastChar = i3;
            while (ch2 === " ")
              ch2 = this.buffer[--i3];
            if (ch2 === "\n" && i3 >= this.pos && i3 + 1 + indent > lastChar)
              nl = i3;
            else
              break;
          } while (true);
        }
        yield cst.SCALAR;
        yield* this.pushToIndex(nl + 1, true);
        return yield* this.parseLineStart();
      }
      *parsePlainScalar() {
        const inFlow = this.flowLevel > 0;
        let end = this.pos - 1;
        let i2 = this.pos - 1;
        let ch;
        while (ch = this.buffer[++i2]) {
          if (ch === ":") {
            const next = this.buffer[i2 + 1];
            if (isEmpty(next) || inFlow && flowIndicatorChars.has(next))
              break;
            end = i2;
          } else if (isEmpty(ch)) {
            let next = this.buffer[i2 + 1];
            if (ch === "\r") {
              if (next === "\n") {
                i2 += 1;
                ch = "\n";
                next = this.buffer[i2 + 1];
              } else
                end = i2;
            }
            if (next === "#" || inFlow && flowIndicatorChars.has(next))
              break;
            if (ch === "\n") {
              const cs = this.continueScalar(i2 + 1);
              if (cs === -1)
                break;
              i2 = Math.max(i2, cs - 2);
            }
          } else {
            if (inFlow && flowIndicatorChars.has(ch))
              break;
            end = i2;
          }
        }
        if (!ch && !this.atEnd)
          return this.setNext("plain-scalar");
        yield cst.SCALAR;
        yield* this.pushToIndex(end + 1, true);
        return inFlow ? "flow" : "doc";
      }
      *pushCount(n) {
        if (n > 0) {
          yield this.buffer.substr(this.pos, n);
          this.pos += n;
          return n;
        }
        return 0;
      }
      *pushToIndex(i2, allowEmpty) {
        const s = this.buffer.slice(this.pos, i2);
        if (s) {
          yield s;
          this.pos += s.length;
          return s.length;
        } else if (allowEmpty)
          yield "";
        return 0;
      }
      *pushIndicators() {
        let n = 0;
        loop: while (true) {
          switch (this.charAt(0)) {
            case "!":
              n += yield* this.pushTag();
              n += yield* this.pushSpaces(true);
              continue loop;
            case "&":
              n += yield* this.pushUntil(isNotAnchorChar);
              n += yield* this.pushSpaces(true);
              continue loop;
            case "-":
            // this is an error
            case "?":
            // this is an error outside flow collections
            case ":": {
              const inFlow = this.flowLevel > 0;
              const ch1 = this.charAt(1);
              if (isEmpty(ch1) || inFlow && flowIndicatorChars.has(ch1)) {
                if (!inFlow)
                  this.indentNext = this.indentValue + 1;
                else if (this.flowKey)
                  this.flowKey = false;
                n += yield* this.pushCount(1);
                n += yield* this.pushSpaces(true);
                continue loop;
              }
            }
          }
          break loop;
        }
        return n;
      }
      *pushTag() {
        if (this.charAt(1) === "<") {
          let i2 = this.pos + 2;
          let ch = this.buffer[i2];
          while (!isEmpty(ch) && ch !== ">")
            ch = this.buffer[++i2];
          return yield* this.pushToIndex(ch === ">" ? i2 + 1 : i2, false);
        } else {
          let i2 = this.pos + 1;
          let ch = this.buffer[i2];
          while (ch) {
            if (tagChars.has(ch))
              ch = this.buffer[++i2];
            else if (ch === "%" && hexDigits.has(this.buffer[i2 + 1]) && hexDigits.has(this.buffer[i2 + 2])) {
              ch = this.buffer[i2 += 3];
            } else
              break;
          }
          return yield* this.pushToIndex(i2, false);
        }
      }
      *pushNewline() {
        const ch = this.buffer[this.pos];
        if (ch === "\n")
          return yield* this.pushCount(1);
        else if (ch === "\r" && this.charAt(1) === "\n")
          return yield* this.pushCount(2);
        else
          return 0;
      }
      *pushSpaces(allowTabs) {
        let i2 = this.pos - 1;
        let ch;
        do {
          ch = this.buffer[++i2];
        } while (ch === " " || allowTabs && ch === "	");
        const n = i2 - this.pos;
        if (n > 0) {
          yield this.buffer.substr(this.pos, n);
          this.pos = i2;
        }
        return n;
      }
      *pushUntil(test) {
        let i2 = this.pos;
        let ch = this.buffer[i2];
        while (!test(ch))
          ch = this.buffer[++i2];
        return yield* this.pushToIndex(i2, false);
      }
    };
    exports2.Lexer = Lexer;
  }
});

// node_modules/yaml/dist/parse/line-counter.js
var require_line_counter = __commonJS({
  "node_modules/yaml/dist/parse/line-counter.js"(exports2) {
    "use strict";
    var LineCounter = class {
      constructor() {
        this.lineStarts = [];
        this.addNewLine = (offset) => this.lineStarts.push(offset);
        this.linePos = (offset) => {
          let low = 0;
          let high = this.lineStarts.length;
          while (low < high) {
            const mid = low + high >> 1;
            if (this.lineStarts[mid] < offset)
              low = mid + 1;
            else
              high = mid;
          }
          if (this.lineStarts[low] === offset)
            return { line: low + 1, col: 1 };
          if (low === 0)
            return { line: 0, col: offset };
          const start2 = this.lineStarts[low - 1];
          return { line: low, col: offset - start2 + 1 };
        };
      }
    };
    exports2.LineCounter = LineCounter;
  }
});

// node_modules/yaml/dist/parse/parser.js
var require_parser = __commonJS({
  "node_modules/yaml/dist/parse/parser.js"(exports2) {
    "use strict";
    var node_process = __require("process");
    var cst = require_cst();
    var lexer = require_lexer();
    function includesToken(list, type) {
      for (let i2 = 0; i2 < list.length; ++i2)
        if (list[i2].type === type)
          return true;
      return false;
    }
    function findNonEmptyIndex(list) {
      for (let i2 = 0; i2 < list.length; ++i2) {
        switch (list[i2].type) {
          case "space":
          case "comment":
          case "newline":
            break;
          default:
            return i2;
        }
      }
      return -1;
    }
    function isFlowToken(token) {
      switch (token?.type) {
        case "alias":
        case "scalar":
        case "single-quoted-scalar":
        case "double-quoted-scalar":
        case "flow-collection":
          return true;
        default:
          return false;
      }
    }
    function getPrevProps(parent) {
      switch (parent.type) {
        case "document":
          return parent.start;
        case "block-map": {
          const it = parent.items[parent.items.length - 1];
          return it.sep ?? it.start;
        }
        case "block-seq":
          return parent.items[parent.items.length - 1].start;
        /* istanbul ignore next should not happen */
        default:
          return [];
      }
    }
    function getFirstKeyStartProps(prev) {
      if (prev.length === 0)
        return [];
      let i2 = prev.length;
      loop: while (--i2 >= 0) {
        switch (prev[i2].type) {
          case "doc-start":
          case "explicit-key-ind":
          case "map-value-ind":
          case "seq-item-ind":
          case "newline":
            break loop;
        }
      }
      while (prev[++i2]?.type === "space") {
      }
      return prev.splice(i2, prev.length);
    }
    function arrayPushArray(target, source2) {
      if (source2.length < 1e5)
        Array.prototype.push.apply(target, source2);
      else
        for (let i2 = 0; i2 < source2.length; ++i2)
          target.push(source2[i2]);
    }
    function fixFlowSeqItems(fc) {
      if (fc.start.type === "flow-seq-start") {
        for (const it of fc.items) {
          if (it.sep && !it.value && !includesToken(it.start, "explicit-key-ind") && !includesToken(it.sep, "map-value-ind")) {
            if (it.key)
              it.value = it.key;
            delete it.key;
            if (isFlowToken(it.value)) {
              if (it.value.end)
                arrayPushArray(it.value.end, it.sep);
              else
                it.value.end = it.sep;
            } else
              arrayPushArray(it.start, it.sep);
            delete it.sep;
          }
        }
      }
    }
    var Parser = class {
      /**
       * @param onNewLine - If defined, called separately with the start position of
       *   each new line (in `parse()`, including the start of input).
       */
      constructor(onNewLine) {
        this.atNewLine = true;
        this.atScalar = false;
        this.indent = 0;
        this.offset = 0;
        this.onKeyLine = false;
        this.stack = [];
        this.source = "";
        this.type = "";
        this.lexer = new lexer.Lexer();
        this.onNewLine = onNewLine;
      }
      /**
       * Parse `source` as a YAML stream.
       * If `incomplete`, a part of the last line may be left as a buffer for the next call.
       *
       * Errors are not thrown, but yielded as `{ type: 'error', message }` tokens.
       *
       * @returns A generator of tokens representing each directive, document, and other structure.
       */
      *parse(source2, incomplete = false) {
        if (this.onNewLine && this.offset === 0)
          this.onNewLine(0);
        for (const lexeme of this.lexer.lex(source2, incomplete))
          yield* this.next(lexeme);
        if (!incomplete)
          yield* this.end();
      }
      /**
       * Advance the parser by the `source` of one lexical token.
       */
      *next(source2) {
        this.source = source2;
        if (node_process.env.LOG_TOKENS)
          console.log("|", cst.prettyToken(source2));
        if (this.atScalar) {
          this.atScalar = false;
          yield* this.step();
          this.offset += source2.length;
          return;
        }
        const type = cst.tokenType(source2);
        if (!type) {
          const message = `Not a YAML token: ${source2}`;
          yield* this.pop({ type: "error", offset: this.offset, message, source: source2 });
          this.offset += source2.length;
        } else if (type === "scalar") {
          this.atNewLine = false;
          this.atScalar = true;
          this.type = "scalar";
        } else {
          this.type = type;
          yield* this.step();
          switch (type) {
            case "newline":
              this.atNewLine = true;
              this.indent = 0;
              if (this.onNewLine)
                this.onNewLine(this.offset + source2.length);
              break;
            case "space":
              if (this.atNewLine && source2[0] === " ")
                this.indent += source2.length;
              break;
            case "explicit-key-ind":
            case "map-value-ind":
            case "seq-item-ind":
              if (this.atNewLine)
                this.indent += source2.length;
              break;
            case "doc-mode":
            case "flow-error-end":
              return;
            default:
              this.atNewLine = false;
          }
          this.offset += source2.length;
        }
      }
      /** Call at end of input to push out any remaining constructions */
      *end() {
        while (this.stack.length > 0)
          yield* this.pop();
      }
      get sourceToken() {
        const st = {
          type: this.type,
          offset: this.offset,
          indent: this.indent,
          source: this.source
        };
        return st;
      }
      *step() {
        const top = this.peek(1);
        if (this.type === "doc-end" && top?.type !== "doc-end") {
          while (this.stack.length > 0)
            yield* this.pop();
          this.stack.push({
            type: "doc-end",
            offset: this.offset,
            source: this.source
          });
          return;
        }
        if (!top)
          return yield* this.stream();
        switch (top.type) {
          case "document":
            return yield* this.document(top);
          case "alias":
          case "scalar":
          case "single-quoted-scalar":
          case "double-quoted-scalar":
            return yield* this.scalar(top);
          case "block-scalar":
            return yield* this.blockScalar(top);
          case "block-map":
            return yield* this.blockMap(top);
          case "block-seq":
            return yield* this.blockSequence(top);
          case "flow-collection":
            return yield* this.flowCollection(top);
          case "doc-end":
            return yield* this.documentEnd(top);
        }
        yield* this.pop();
      }
      peek(n) {
        return this.stack[this.stack.length - n];
      }
      *pop(error) {
        const token = error ?? this.stack.pop();
        if (!token) {
          const message = "Tried to pop an empty stack";
          yield { type: "error", offset: this.offset, source: "", message };
        } else if (this.stack.length === 0) {
          yield token;
        } else {
          const top = this.peek(1);
          if (token.type === "block-scalar") {
            token.indent = "indent" in top ? top.indent : 0;
          } else if (token.type === "flow-collection" && top.type === "document") {
            token.indent = 0;
          }
          if (token.type === "flow-collection")
            fixFlowSeqItems(token);
          switch (top.type) {
            case "document":
              top.value = token;
              break;
            case "block-scalar":
              top.props.push(token);
              break;
            case "block-map": {
              const it = top.items[top.items.length - 1];
              if (it.value) {
                top.items.push({ start: [], key: token, sep: [] });
                this.onKeyLine = true;
                return;
              } else if (it.sep) {
                it.value = token;
              } else {
                Object.assign(it, { key: token, sep: [] });
                this.onKeyLine = !it.explicitKey;
                return;
              }
              break;
            }
            case "block-seq": {
              const it = top.items[top.items.length - 1];
              if (it.value)
                top.items.push({ start: [], value: token });
              else
                it.value = token;
              break;
            }
            case "flow-collection": {
              const it = top.items[top.items.length - 1];
              if (!it || it.value)
                top.items.push({ start: [], key: token, sep: [] });
              else if (it.sep)
                it.value = token;
              else
                Object.assign(it, { key: token, sep: [] });
              return;
            }
            /* istanbul ignore next should not happen */
            default:
              yield* this.pop();
              yield* this.pop(token);
          }
          if ((top.type === "document" || top.type === "block-map" || top.type === "block-seq") && (token.type === "block-map" || token.type === "block-seq")) {
            const last = token.items[token.items.length - 1];
            if (last && !last.sep && !last.value && last.start.length > 0 && findNonEmptyIndex(last.start) === -1 && (token.indent === 0 || last.start.every((st) => st.type !== "comment" || st.indent < token.indent))) {
              if (top.type === "document")
                top.end = last.start;
              else
                top.items.push({ start: last.start });
              token.items.splice(-1, 1);
            }
          }
        }
      }
      *stream() {
        switch (this.type) {
          case "directive-line":
            yield { type: "directive", offset: this.offset, source: this.source };
            return;
          case "byte-order-mark":
          case "space":
          case "comment":
          case "newline":
            yield this.sourceToken;
            return;
          case "doc-mode":
          case "doc-start": {
            const doc = {
              type: "document",
              offset: this.offset,
              start: []
            };
            if (this.type === "doc-start")
              doc.start.push(this.sourceToken);
            this.stack.push(doc);
            return;
          }
        }
        yield {
          type: "error",
          offset: this.offset,
          message: `Unexpected ${this.type} token in YAML stream`,
          source: this.source
        };
      }
      *document(doc) {
        if (doc.value)
          return yield* this.lineEnd(doc);
        switch (this.type) {
          case "doc-start": {
            if (findNonEmptyIndex(doc.start) !== -1) {
              yield* this.pop();
              yield* this.step();
            } else
              doc.start.push(this.sourceToken);
            return;
          }
          case "anchor":
          case "tag":
          case "space":
          case "comment":
          case "newline":
            doc.start.push(this.sourceToken);
            return;
        }
        const bv = this.startBlockValue(doc);
        if (bv)
          this.stack.push(bv);
        else {
          yield {
            type: "error",
            offset: this.offset,
            message: `Unexpected ${this.type} token in YAML document`,
            source: this.source
          };
        }
      }
      *scalar(scalar) {
        if (this.type === "map-value-ind") {
          const prev = getPrevProps(this.peek(2));
          const start2 = getFirstKeyStartProps(prev);
          let sep2;
          if (scalar.end) {
            sep2 = scalar.end;
            sep2.push(this.sourceToken);
            delete scalar.end;
          } else
            sep2 = [this.sourceToken];
          const map = {
            type: "block-map",
            offset: scalar.offset,
            indent: scalar.indent,
            items: [{ start: start2, key: scalar, sep: sep2 }]
          };
          this.onKeyLine = true;
          this.stack[this.stack.length - 1] = map;
        } else
          yield* this.lineEnd(scalar);
      }
      *blockScalar(scalar) {
        switch (this.type) {
          case "space":
          case "comment":
          case "newline":
            scalar.props.push(this.sourceToken);
            return;
          case "scalar":
            scalar.source = this.source;
            this.atNewLine = true;
            this.indent = 0;
            if (this.onNewLine) {
              let nl = this.source.indexOf("\n") + 1;
              while (nl !== 0) {
                this.onNewLine(this.offset + nl);
                nl = this.source.indexOf("\n", nl) + 1;
              }
            }
            yield* this.pop();
            break;
          /* istanbul ignore next should not happen */
          default:
            yield* this.pop();
            yield* this.step();
        }
      }
      *blockMap(map) {
        const it = map.items[map.items.length - 1];
        switch (this.type) {
          case "newline":
            this.onKeyLine = false;
            if (it.value) {
              const end = "end" in it.value ? it.value.end : void 0;
              const last = Array.isArray(end) ? end[end.length - 1] : void 0;
              if (last?.type === "comment")
                end?.push(this.sourceToken);
              else
                map.items.push({ start: [this.sourceToken] });
            } else if (it.sep) {
              it.sep.push(this.sourceToken);
            } else {
              it.start.push(this.sourceToken);
            }
            return;
          case "space":
          case "comment":
            if (it.value) {
              map.items.push({ start: [this.sourceToken] });
            } else if (it.sep) {
              it.sep.push(this.sourceToken);
            } else {
              if (this.atIndentedComment(it.start, map.indent)) {
                const prev = map.items[map.items.length - 2];
                const end = prev?.value?.end;
                if (Array.isArray(end)) {
                  arrayPushArray(end, it.start);
                  end.push(this.sourceToken);
                  map.items.pop();
                  return;
                }
              }
              it.start.push(this.sourceToken);
            }
            return;
        }
        if (this.indent >= map.indent) {
          const atMapIndent = !this.onKeyLine && this.indent === map.indent;
          const atNextItem = atMapIndent && (it.sep || it.explicitKey) && this.type !== "seq-item-ind";
          let start2 = [];
          if (atNextItem && it.sep && !it.value) {
            const nl = [];
            for (let i2 = 0; i2 < it.sep.length; ++i2) {
              const st = it.sep[i2];
              switch (st.type) {
                case "newline":
                  nl.push(i2);
                  break;
                case "space":
                  break;
                case "comment":
                  if (st.indent > map.indent)
                    nl.length = 0;
                  break;
                default:
                  nl.length = 0;
              }
            }
            if (nl.length >= 2)
              start2 = it.sep.splice(nl[1]);
          }
          switch (this.type) {
            case "anchor":
            case "tag":
              if (atNextItem || it.value) {
                start2.push(this.sourceToken);
                map.items.push({ start: start2 });
                this.onKeyLine = true;
              } else if (it.sep) {
                it.sep.push(this.sourceToken);
              } else {
                it.start.push(this.sourceToken);
              }
              return;
            case "explicit-key-ind":
              if (!it.sep && !it.explicitKey) {
                it.start.push(this.sourceToken);
                it.explicitKey = true;
              } else if (atNextItem || it.value) {
                start2.push(this.sourceToken);
                map.items.push({ start: start2, explicitKey: true });
              } else {
                this.stack.push({
                  type: "block-map",
                  offset: this.offset,
                  indent: this.indent,
                  items: [{ start: [this.sourceToken], explicitKey: true }]
                });
              }
              this.onKeyLine = true;
              return;
            case "map-value-ind":
              if (it.explicitKey) {
                if (!it.sep) {
                  if (includesToken(it.start, "newline")) {
                    Object.assign(it, { key: null, sep: [this.sourceToken] });
                  } else {
                    const start3 = getFirstKeyStartProps(it.start);
                    this.stack.push({
                      type: "block-map",
                      offset: this.offset,
                      indent: this.indent,
                      items: [{ start: start3, key: null, sep: [this.sourceToken] }]
                    });
                  }
                } else if (it.value) {
                  map.items.push({ start: [], key: null, sep: [this.sourceToken] });
                } else if (includesToken(it.sep, "map-value-ind")) {
                  this.stack.push({
                    type: "block-map",
                    offset: this.offset,
                    indent: this.indent,
                    items: [{ start: start2, key: null, sep: [this.sourceToken] }]
                  });
                } else if (isFlowToken(it.key) && !includesToken(it.sep, "newline")) {
                  const start3 = getFirstKeyStartProps(it.start);
                  const key = it.key;
                  const sep2 = it.sep;
                  sep2.push(this.sourceToken);
                  delete it.key;
                  delete it.sep;
                  this.stack.push({
                    type: "block-map",
                    offset: this.offset,
                    indent: this.indent,
                    items: [{ start: start3, key, sep: sep2 }]
                  });
                } else if (start2.length > 0) {
                  it.sep = it.sep.concat(start2, this.sourceToken);
                } else {
                  it.sep.push(this.sourceToken);
                }
              } else {
                if (!it.sep) {
                  Object.assign(it, { key: null, sep: [this.sourceToken] });
                } else if (it.value || atNextItem) {
                  map.items.push({ start: start2, key: null, sep: [this.sourceToken] });
                } else if (includesToken(it.sep, "map-value-ind")) {
                  this.stack.push({
                    type: "block-map",
                    offset: this.offset,
                    indent: this.indent,
                    items: [{ start: [], key: null, sep: [this.sourceToken] }]
                  });
                } else {
                  it.sep.push(this.sourceToken);
                }
              }
              this.onKeyLine = true;
              return;
            case "alias":
            case "scalar":
            case "single-quoted-scalar":
            case "double-quoted-scalar": {
              const fs7 = this.flowScalar(this.type);
              if (atNextItem || it.value) {
                map.items.push({ start: start2, key: fs7, sep: [] });
                this.onKeyLine = true;
              } else if (it.sep) {
                this.stack.push(fs7);
              } else {
                Object.assign(it, { key: fs7, sep: [] });
                this.onKeyLine = true;
              }
              return;
            }
            default: {
              const bv = this.startBlockValue(map);
              if (bv) {
                if (bv.type === "block-seq") {
                  if (!it.explicitKey && it.sep && !includesToken(it.sep, "newline")) {
                    yield* this.pop({
                      type: "error",
                      offset: this.offset,
                      message: "Unexpected block-seq-ind on same line with key",
                      source: this.source
                    });
                    return;
                  }
                } else if (atMapIndent) {
                  map.items.push({ start: start2 });
                }
                this.stack.push(bv);
                return;
              }
            }
          }
        }
        yield* this.pop();
        yield* this.step();
      }
      *blockSequence(seq) {
        const it = seq.items[seq.items.length - 1];
        switch (this.type) {
          case "newline":
            if (it.value) {
              const end = "end" in it.value ? it.value.end : void 0;
              const last = Array.isArray(end) ? end[end.length - 1] : void 0;
              if (last?.type === "comment")
                end?.push(this.sourceToken);
              else
                seq.items.push({ start: [this.sourceToken] });
            } else
              it.start.push(this.sourceToken);
            return;
          case "space":
          case "comment":
            if (it.value)
              seq.items.push({ start: [this.sourceToken] });
            else {
              if (this.atIndentedComment(it.start, seq.indent)) {
                const prev = seq.items[seq.items.length - 2];
                const end = prev?.value?.end;
                if (Array.isArray(end)) {
                  arrayPushArray(end, it.start);
                  end.push(this.sourceToken);
                  seq.items.pop();
                  return;
                }
              }
              it.start.push(this.sourceToken);
            }
            return;
          case "anchor":
          case "tag":
            if (it.value || this.indent <= seq.indent)
              break;
            it.start.push(this.sourceToken);
            return;
          case "seq-item-ind":
            if (this.indent !== seq.indent)
              break;
            if (it.value || includesToken(it.start, "seq-item-ind"))
              seq.items.push({ start: [this.sourceToken] });
            else
              it.start.push(this.sourceToken);
            return;
        }
        if (this.indent > seq.indent) {
          const bv = this.startBlockValue(seq);
          if (bv) {
            this.stack.push(bv);
            return;
          }
        }
        yield* this.pop();
        yield* this.step();
      }
      *flowCollection(fc) {
        const it = fc.items[fc.items.length - 1];
        if (this.type === "flow-error-end") {
          let top;
          do {
            yield* this.pop();
            top = this.peek(1);
          } while (top?.type === "flow-collection");
        } else if (fc.end.length === 0) {
          switch (this.type) {
            case "comma":
            case "explicit-key-ind":
              if (!it || it.sep)
                fc.items.push({ start: [this.sourceToken] });
              else
                it.start.push(this.sourceToken);
              return;
            case "map-value-ind":
              if (!it || it.value)
                fc.items.push({ start: [], key: null, sep: [this.sourceToken] });
              else if (it.sep)
                it.sep.push(this.sourceToken);
              else
                Object.assign(it, { key: null, sep: [this.sourceToken] });
              return;
            case "space":
            case "comment":
            case "newline":
            case "anchor":
            case "tag":
              if (!it || it.value)
                fc.items.push({ start: [this.sourceToken] });
              else if (it.sep)
                it.sep.push(this.sourceToken);
              else
                it.start.push(this.sourceToken);
              return;
            case "alias":
            case "scalar":
            case "single-quoted-scalar":
            case "double-quoted-scalar": {
              const fs7 = this.flowScalar(this.type);
              if (!it || it.value)
                fc.items.push({ start: [], key: fs7, sep: [] });
              else if (it.sep)
                this.stack.push(fs7);
              else
                Object.assign(it, { key: fs7, sep: [] });
              return;
            }
            case "flow-map-end":
            case "flow-seq-end":
              fc.end.push(this.sourceToken);
              return;
          }
          const bv = this.startBlockValue(fc);
          if (bv)
            this.stack.push(bv);
          else {
            yield* this.pop();
            yield* this.step();
          }
        } else {
          const parent = this.peek(2);
          if (parent.type === "block-map" && (this.type === "map-value-ind" && parent.indent === fc.indent || this.type === "newline" && !parent.items[parent.items.length - 1].sep)) {
            yield* this.pop();
            yield* this.step();
          } else if (this.type === "map-value-ind" && parent.type !== "flow-collection") {
            const prev = getPrevProps(parent);
            const start2 = getFirstKeyStartProps(prev);
            fixFlowSeqItems(fc);
            const sep2 = fc.end.splice(1, fc.end.length);
            sep2.push(this.sourceToken);
            const map = {
              type: "block-map",
              offset: fc.offset,
              indent: fc.indent,
              items: [{ start: start2, key: fc, sep: sep2 }]
            };
            this.onKeyLine = true;
            this.stack[this.stack.length - 1] = map;
          } else {
            yield* this.lineEnd(fc);
          }
        }
      }
      flowScalar(type) {
        if (this.onNewLine) {
          let nl = this.source.indexOf("\n") + 1;
          while (nl !== 0) {
            this.onNewLine(this.offset + nl);
            nl = this.source.indexOf("\n", nl) + 1;
          }
        }
        return {
          type,
          offset: this.offset,
          indent: this.indent,
          source: this.source
        };
      }
      startBlockValue(parent) {
        switch (this.type) {
          case "alias":
          case "scalar":
          case "single-quoted-scalar":
          case "double-quoted-scalar":
            return this.flowScalar(this.type);
          case "block-scalar-header":
            return {
              type: "block-scalar",
              offset: this.offset,
              indent: this.indent,
              props: [this.sourceToken],
              source: ""
            };
          case "flow-map-start":
          case "flow-seq-start":
            return {
              type: "flow-collection",
              offset: this.offset,
              indent: this.indent,
              start: this.sourceToken,
              items: [],
              end: []
            };
          case "seq-item-ind":
            return {
              type: "block-seq",
              offset: this.offset,
              indent: this.indent,
              items: [{ start: [this.sourceToken] }]
            };
          case "explicit-key-ind": {
            this.onKeyLine = true;
            const prev = getPrevProps(parent);
            const start2 = getFirstKeyStartProps(prev);
            start2.push(this.sourceToken);
            return {
              type: "block-map",
              offset: this.offset,
              indent: this.indent,
              items: [{ start: start2, explicitKey: true }]
            };
          }
          case "map-value-ind": {
            this.onKeyLine = true;
            const prev = getPrevProps(parent);
            const start2 = getFirstKeyStartProps(prev);
            return {
              type: "block-map",
              offset: this.offset,
              indent: this.indent,
              items: [{ start: start2, key: null, sep: [this.sourceToken] }]
            };
          }
        }
        return null;
      }
      atIndentedComment(start2, indent) {
        if (this.type !== "comment")
          return false;
        if (this.indent <= indent)
          return false;
        return start2.every((st) => st.type === "newline" || st.type === "space");
      }
      *documentEnd(docEnd) {
        if (this.type !== "doc-mode") {
          if (docEnd.end)
            docEnd.end.push(this.sourceToken);
          else
            docEnd.end = [this.sourceToken];
          if (this.type === "newline")
            yield* this.pop();
        }
      }
      *lineEnd(token) {
        switch (this.type) {
          case "comma":
          case "doc-start":
          case "doc-end":
          case "flow-seq-end":
          case "flow-map-end":
          case "map-value-ind":
            yield* this.pop();
            yield* this.step();
            break;
          case "newline":
            this.onKeyLine = false;
          // fallthrough
          case "space":
          case "comment":
          default:
            if (token.end)
              token.end.push(this.sourceToken);
            else
              token.end = [this.sourceToken];
            if (this.type === "newline")
              yield* this.pop();
        }
      }
    };
    exports2.Parser = Parser;
  }
});

// node_modules/yaml/dist/public-api.js
var require_public_api = __commonJS({
  "node_modules/yaml/dist/public-api.js"(exports2) {
    "use strict";
    var composer = require_composer();
    var Document = require_Document();
    var errors = require_errors();
    var log = require_log();
    var identity2 = require_identity();
    var lineCounter = require_line_counter();
    var parser = require_parser();
    function parseOptions(options) {
      const prettyErrors = options.prettyErrors !== false;
      const lineCounter$1 = options.lineCounter || prettyErrors && new lineCounter.LineCounter() || null;
      return { lineCounter: lineCounter$1, prettyErrors };
    }
    function parseAllDocuments(source2, options = {}) {
      const { lineCounter: lineCounter2, prettyErrors } = parseOptions(options);
      const parser$1 = new parser.Parser(lineCounter2?.addNewLine);
      const composer$1 = new composer.Composer(options);
      const docs = Array.from(composer$1.compose(parser$1.parse(source2)));
      if (prettyErrors && lineCounter2)
        for (const doc of docs) {
          doc.errors.forEach(errors.prettifyError(source2, lineCounter2));
          doc.warnings.forEach(errors.prettifyError(source2, lineCounter2));
        }
      if (docs.length > 0)
        return docs;
      return Object.assign([], { empty: true }, composer$1.streamInfo());
    }
    function parseDocument2(source2, options = {}) {
      const { lineCounter: lineCounter2, prettyErrors } = parseOptions(options);
      const parser$1 = new parser.Parser(lineCounter2?.addNewLine);
      const composer$1 = new composer.Composer(options);
      let doc = null;
      for (const _doc of composer$1.compose(parser$1.parse(source2), true, source2.length)) {
        if (!doc)
          doc = _doc;
        else if (doc.options.logLevel !== "silent") {
          doc.errors.push(new errors.YAMLParseError(_doc.range.slice(0, 2), "MULTIPLE_DOCS", "Source contains multiple documents; please use YAML.parseAllDocuments()"));
          break;
        }
      }
      if (prettyErrors && lineCounter2) {
        doc.errors.forEach(errors.prettifyError(source2, lineCounter2));
        doc.warnings.forEach(errors.prettifyError(source2, lineCounter2));
      }
      return doc;
    }
    function parse(src, reviver, options) {
      let _reviver = void 0;
      if (typeof reviver === "function") {
        _reviver = reviver;
      } else if (options === void 0 && reviver && typeof reviver === "object") {
        options = reviver;
      }
      const doc = parseDocument2(src, options);
      if (!doc)
        return null;
      doc.warnings.forEach((warning) => log.warn(doc.options.logLevel, warning));
      if (doc.errors.length > 0) {
        if (doc.options.logLevel !== "silent")
          throw doc.errors[0];
        else
          doc.errors = [];
      }
      return doc.toJS(Object.assign({ reviver: _reviver }, options));
    }
    function stringify2(value, replacer, options) {
      let _replacer = null;
      if (typeof replacer === "function" || Array.isArray(replacer)) {
        _replacer = replacer;
      } else if (options === void 0 && replacer) {
        options = replacer;
      }
      if (typeof options === "string")
        options = options.length;
      if (typeof options === "number") {
        const indent = Math.round(options);
        options = indent < 1 ? void 0 : indent > 8 ? { indent: 8 } : { indent };
      }
      if (value === void 0) {
        const { keepUndefined } = options ?? replacer ?? {};
        if (!keepUndefined)
          return void 0;
      }
      if (identity2.isDocument(value) && !_replacer)
        return value.toString(options);
      return new Document.Document(value, _replacer, options).toString(options);
    }
    exports2.parse = parse;
    exports2.parseAllDocuments = parseAllDocuments;
    exports2.parseDocument = parseDocument2;
    exports2.stringify = stringify2;
  }
});

// node_modules/yaml/dist/index.js
var require_dist = __commonJS({
  "node_modules/yaml/dist/index.js"(exports2) {
    "use strict";
    var composer = require_composer();
    var Document = require_Document();
    var Schema = require_Schema();
    var errors = require_errors();
    var Alias = require_Alias();
    var identity2 = require_identity();
    var Pair = require_Pair();
    var Scalar = require_Scalar();
    var YAMLMap = require_YAMLMap();
    var YAMLSeq = require_YAMLSeq();
    var cst = require_cst();
    var lexer = require_lexer();
    var lineCounter = require_line_counter();
    var parser = require_parser();
    var publicApi = require_public_api();
    var visit = require_visit();
    exports2.Composer = composer.Composer;
    exports2.Document = Document.Document;
    exports2.Schema = Schema.Schema;
    exports2.YAMLError = errors.YAMLError;
    exports2.YAMLParseError = errors.YAMLParseError;
    exports2.YAMLWarning = errors.YAMLWarning;
    exports2.Alias = Alias.Alias;
    exports2.isAlias = identity2.isAlias;
    exports2.isCollection = identity2.isCollection;
    exports2.isDocument = identity2.isDocument;
    exports2.isMap = identity2.isMap;
    exports2.isNode = identity2.isNode;
    exports2.isPair = identity2.isPair;
    exports2.isScalar = identity2.isScalar;
    exports2.isSeq = identity2.isSeq;
    exports2.Pair = Pair.Pair;
    exports2.Scalar = Scalar.Scalar;
    exports2.YAMLMap = YAMLMap.YAMLMap;
    exports2.YAMLSeq = YAMLSeq.YAMLSeq;
    exports2.CST = cst;
    exports2.Lexer = lexer.Lexer;
    exports2.LineCounter = lineCounter.LineCounter;
    exports2.Parser = parser.Parser;
    exports2.parse = publicApi.parse;
    exports2.parseAllDocuments = publicApi.parseAllDocuments;
    exports2.parseDocument = publicApi.parseDocument;
    exports2.stringify = publicApi.stringify;
    exports2.visit = visit.visit;
    exports2.visitAsync = visit.visitAsync;
  }
});

// runtime/core/errors.mjs
function requireThat(condition, code, message, details) {
  if (!condition) throw new WikiError(code, message, details);
}
function relativePath(value, { root = false } = {}) {
  requireThat(typeof value === "string", "path", "A relative path is required.");
  if (root && (value === "" || value === ".")) return "";
  requireThat(
    value.length > 0 && value.length <= 4096 && !/[\\:\x00-\x1f]/.test(value) && !value.split("/").some((p) => !p || p === "." || p === ".."),
    "path",
    "Invalid relative path or traversal.",
    { path: value }
  );
  return value;
}
function nonempty(value, label2, max2 = 1e4) {
  requireThat(
    typeof value === "string" && value.trim() && value.length <= max2,
    "input",
    `Supply ${label2}.`
  );
  return value.trim();
}
var WikiError;
var init_errors = __esm({
  "runtime/core/errors.mjs"() {
    WikiError = class extends Error {
      constructor(code, message, details = {}) {
        super(message);
        this.name = "WikiError";
        this.code = code;
        this.details = details;
      }
    };
  }
});

// runtime/core/document.mjs
function metadataComment(data) {
  return "\n<!-- llmwiki:metadata " + JSON.stringify(data).replace(/[<>&]/g, (c) => "\\u" + c.charCodeAt(0).toString(16).padStart(4, "0")) + " -->\n";
}
function parseDocument(source2) {
  requireThat(typeof source2 === "string", "document", "Markdown must be text.");
  const match = /^(\uFEFF?---[ \t]*\r?\n)([\s\S]*?)(^---[ \t]*(?:\r?\n|$))/m.exec(source2);
  if (!match || match.index !== 0) {
    requireThat(!/^\uFEFF?---[ \t]*\r?\n/.test(source2), "frontmatter", "Frontmatter is not closed.");
    return { head: {}, body: source2, source: source2, yaml: null, prefix: "", raw: "", suffix: "", offset: 0 };
  }
  const yaml = (0, import_yaml.parseDocument)(match[2], { keepSourceTokens: true, uniqueKeys: true, version: "1.2" });
  if (yaml.errors.length) throw new WikiError("frontmatter", "YAML: " + yaml.errors.map((e) => e.message).join("; "));
  requireThat(!yaml.contents || (0, import_yaml.isMap)(yaml.contents), "frontmatter", "Frontmatter must be a mapping.");
  let head;
  try {
    head = yaml.toJS({ maxAliasCount: 50 }) ?? {};
  } catch (error) {
    throw new WikiError("frontmatter", "YAML: " + error.message);
  }
  const visibleHead = structuredClone(head), tail = source2.slice(match[0].length), meta = /^\s*<!-- llmwiki:metadata ([^\n]+) -->\r?\n/.exec(tail);
  let metadata2 = null;
  if (meta) {
    try {
      metadata2 = JSON.parse(meta[1]);
    } catch {
      throw new WikiError("metadata", "Invalid embedded metadata. Restore it before editing.");
    }
    requireThat(metadata2?.format === "llmwiki-metadata/1" && metadata2.fields && typeof metadata2.fields === "object" && !Array.isArray(metadata2.fields), "metadata", "Invalid embedded metadata format.");
    for (const key of technicalKeys) if (Object.hasOwn(metadata2.fields, key)) head[key] = metadata2.fields[key];
  }
  const metadataPrefix = meta?.[0] ?? "", offset = match[0].length + metadataPrefix.length;
  return {
    head,
    visibleHead,
    metadata: metadata2,
    metadataPrefix,
    body: source2.slice(offset),
    source: source2,
    yaml,
    prefix: match[1],
    raw: match[2],
    suffix: match[3],
    offset
  };
}
function patchHead(source2, updates) {
  const parsed = parseDocument(source2);
  if (parsed.metadata) {
    const fields = { ...parsed.metadata.fields }, visible = {};
    for (const [key, value] of Object.entries(updates)) {
      if (technicalKeys.includes(key)) fields[key] = value;
      else visible[key] = value;
    }
    const withFields = parsed.prefix + parsed.raw + parsed.suffix + metadataComment({ ...parsed.metadata, fields }) + parsed.body;
    return projectMetadata(patchVisibleHead(withFields, visible), parsed.metadata.visible);
  }
  return patchVisibleHead(source2, updates);
}
function patchVisibleHead(source2, updates) {
  requireThat(updates && typeof updates === "object" && !Array.isArray(updates), "head", "Head changes must be a mapping.");
  const parsed = parseDocument(source2);
  if (!parsed.yaml) return "---\n" + (0, import_yaml.stringify)(updates, { lineWidth: 0 }) + "---\n" + source2;
  const replacements = [], additions = [];
  const items = parsed.yaml.contents?.items ?? [];
  for (const [key, value] of Object.entries(updates)) {
    requireThat(!Object.hasOwn(Object.prototype, key) && key !== "prototype", "head", "Reserved head field.");
    const i2 = items.findIndex((pair2) => pair2.key?.value === key);
    const written = (0, import_yaml.stringify)({ [key]: value }, { lineWidth: 0 });
    if (i2 < 0) {
      additions.push(written);
      continue;
    }
    const pair = items[i2];
    requireThat(!pair.value?.anchor, "head", "An anchored field needs an explicit document edit.");
    const start2 = pair.key.range[0];
    let end = pair.value?.range?.[2] ?? pair.key.range[2];
    if (!pair.value) {
      const eol = parsed.raw.indexOf("\n", end);
      end = eol < 0 ? parsed.raw.length : eol + 1;
    }
    const comment = pair.value?.comment;
    const replacement = comment ? written.trimEnd() + " #" + comment + "\n" : written;
    replacements.push({ start: start2, end, text: replacement });
  }
  let raw = parsed.raw;
  for (const edit of replacements.sort((a, b) => b.start - a.start)) raw = raw.slice(0, edit.start) + edit.text + raw.slice(edit.end);
  if (additions.length) raw = raw.replace(/\s*$/, "\n") + additions.join("");
  const result = parsed.prefix + raw + parsed.suffix + (parsed.metadataPrefix ?? "") + parsed.body;
  parseDocument(result);
  return result;
}
function newDocument(head, body) {
  return "---\n" + (0, import_yaml.stringify)(head, { lineWidth: 0 }) + "---\n\n" + body;
}
function projectMetadata(source2, visible) {
  const p = parseDocument(source2);
  if (!p.yaml) return source2;
  const fields = { ...p.metadata?.fields };
  for (const key of technicalKeys) if (Object.hasOwn(p.head, key)) fields[key] = p.head[key];
  if (!Object.keys(fields).length) return source2;
  visible = (visible ?? p.metadata?.visible ?? ["resource"]).filter((k) => presentationKeys.includes(k));
  const projection = { resource: !Object.hasOwn(fields, "resource") ? void 0 : Array.isArray(fields.resource) ? fields.resource : typeof fields.resource === "object" && fields.resource !== null ? fields.resource.link ? [fields.resource.link] : [] : Array.isArray(fields.resource) ? fields.resource : fields.resource ? [fields.resource] : [], source_created_at: fields.resource?.created_at, source_modified_at: fields.resource?.modified_at, generated_at: fields.generated?.at };
  let text2 = p.prefix + p.raw + p.suffix + p.body;
  text2 = removeHeadFields(text2, [...technicalKeys, ...presentationKeys]);
  text2 = patchVisibleHead(text2, Object.fromEntries(visible.filter((k) => projection[k] !== void 0).map((k) => [k, projection[k]])));
  const next = parseDocument(text2);
  return next.prefix + next.raw + next.suffix + metadataComment({ format: "llmwiki-metadata/1", fields, visible }) + next.body;
}
function mapAuthored(text2, transform) {
  const protectedParts = /<!-- llmwiki:source:start -->[\s\S]*?<!-- llmwiki:source:end -->|^ {0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?^ {0,3}\1[^\n]*(?:\n|$)/gm;
  let result = "", at = 0;
  for (const m of text2.matchAll(protectedParts)) {
    result += transform(text2.slice(at, m.index)) + m[0];
    at = m.index + m[0].length;
  }
  return result + transform(text2.slice(at));
}
function stripNavigation(text2, { members = true, legacy = false } = {}) {
  return mapAuthored(text2, (part) => {
    part = part.replace(/<!-- llmwiki:provenance:start -->[\s\S]*?<!-- llmwiki:provenance:end -->\n?/g, "");
    part = part.replace(/<!-- vault-operator:incoming-links -->[\s\S]*?<!-- \/vault-operator:incoming-links -->\n?/g, "");
    if (members) part = part.replace(/<!-- llmwiki:members:start -->[\s\S]*?<!-- llmwiki:members:end -->\n?/g, "");
    if (legacy) part = part.replace(/<!-- derived incoming -->[\s\S]*?<!-- \/derived -->\n?/g, "");
    return part;
  });
}
function statementText(source2) {
  source2 = stripNavigation(source2);
  const kept = [], hidden = [];
  let fence = null, inside = false;
  for (const original of source2.match(/[^\n]*\n|[^\n]+$/g) ?? []) {
    let line = original;
    const marker = /^ {0,3}(`{3,}|~{3,})/.exec(line);
    if (marker) {
      if (!fence) fence = marker[1];
      else if (marker[1][0] === fence[0] && marker[1].length >= fence.length) fence = null;
    }
    if (inside) {
      hidden.push(line);
      if (!fence && /^ {0,3}<!--\s*\/derived\s*-->\s*$/.test(line)) {
        inside = false;
        hidden.length = 0;
        if (kept.length && !kept.at(-1).trim()) kept.pop();
      }
      continue;
    }
    if (!fence && !marker && /^ {0,3}<!--\s*derived\b[^>]*-->\s*$/.test(line)) {
      inside = true;
      hidden.push(line);
      continue;
    }
    if (!fence && !marker) line = line.replace(/ \^[a-zA-Z0-9-]+(?=\r?\n?$)/, "");
    if (!fence && /^\|\s*in\s*\|/.test(line)) continue;
    kept.push(line);
  }
  return kept.concat(hidden).join("");
}
function mirroredContent(body) {
  const start2 = "<!-- llmwiki:source:start -->", end = "<!-- llmwiki:source:end -->", a = body.indexOf(start2), b = body.indexOf(end);
  if (a < 0 || b < a) return null;
  return body.slice(a + start2.length, b).replace(/^\n## Source content\n\n/, "").replace(/\n$/, "");
}
function sectionText(body, names) {
  const lines = body.split(/\r?\n/), out = [];
  let inside = false;
  for (const line of lines) {
    const heading = /^##[ \t]+(.+?)\s*$/.exec(line);
    if (heading) {
      if (inside) break;
      inside = names.includes(heading[1]);
      continue;
    }
    if (inside) out.push(line);
  }
  return out.join("\n").trim();
}
function bodyLinks(body) {
  const visible = body.replace(/<!--[^]*?-->/g, "").replace(/^ {0,3}(`{3,}|~{3,})[^]*?^ {0,3}\1[^\n]*(?:\n|$)/gm, "").replace(/(`+)[^]*?\1/g, "");
  return [...visible.matchAll(/\[\[([^\]]+)\]\]|\[[^\]]*\]\(<?([^\s)>]+)>?(?:\s+"[^"]*")?\)/g)].map((m) => ({ written: (m[1] ?? m[2]).split("|")[0], offset: m.index, embedded: visible[m.index - 1] === "!" }));
}
function relationRows(body) {
  const lines = body.replace(/<!--[^]*?-->/g, "").split(/\r?\n/), rows = [];
  let fence = null;
  for (let i2 = 0; i2 < lines.length; i2++) {
    const line = lines[i2], marker = /^ {0,3}(`{3,}|~{3,})/.exec(line);
    if (marker) {
      if (!fence) fence = marker[1];
      else if (marker[1][0] === fence[0] && marker[1].length >= fence.length) fence = null;
      continue;
    }
    if (fence || !line.trimStart().startsWith("|")) continue;
    const cells = line.trim().split(/(?<!\\)\|/).slice(1, -1).map((c) => c.trim().replace(/\\\|/g, "|"));
    if (!["out", "in"].includes(cells[0])) continue;
    rows.push({
      direction: cells[0],
      type: cells[1] ?? "",
      written: bodyLinks(cells[2] ?? "")[0]?.written ?? cells[2] ?? "",
      reason: cells[3] ?? "",
      line: i2 + 1,
      valid: cells.length === 4
    });
  }
  return rows;
}
function listValue(value) {
  if (value === void 0 || value === null) return [];
  return Array.isArray(value) ? value : [value];
}
function removeHeadFields(source2, keys) {
  const p = parseDocument(source2);
  if (!p.yaml) return source2;
  const edits = [];
  for (const pair of p.yaml.contents?.items ?? []) if (keys.includes(pair.key?.value)) {
    const start2 = pair.key.range[0], end = pair.value?.range?.[2] ?? pair.key.range[2];
    edits.push({ start: start2, end });
  }
  let raw = p.raw;
  for (const e of edits.sort((a, b) => b.start - a.start)) raw = raw.slice(0, e.start) + raw.slice(e.end);
  const metadata2 = p.metadata ? { ...p.metadata, fields: Object.fromEntries(Object.entries(p.metadata.fields).filter(([key]) => !keys.includes(key))) } : null;
  const result = p.prefix + raw + p.suffix + (metadata2 ? metadataComment(metadata2) : "") + p.body;
  parseDocument(result);
  return result;
}
var import_yaml, technicalKeys, presentationKeys;
var init_document = __esm({
  "runtime/core/document.mjs"() {
    import_yaml = __toESM(require_dist(), 1);
    init_errors();
    technicalKeys = ["resource", "generated", "sources", "extraction", "source_id"];
    presentationKeys = ["resource", "source_created_at", "source_modified_at", "generated_at"];
  }
});

// runtime/review.mjs
function handle(store, prefix = "") {
  const full = (p) => prefix ? p ? prefix + "/" + p : prefix : p;
  return {
    store,
    prefix,
    kind: "directory",
    name: prefix.split("/").at(-1),
    async isSameEntry(other) {
      return store === other.store && prefix === other.prefix || store.root && store.root === other.store.root && prefix === other.prefix;
    },
    async getDirectoryHandle(part) {
      relativePath(part);
      const p = full(part);
      try {
        await store.list(p, { recursive: false, hidden: true });
      } catch (e) {
        if (e.code === "ENOENT") throw missing();
        throw e;
      }
      return handle(store, p);
    },
    async *values() {
      for (const entry of await store.list(prefix, { recursive: false, hidden: true })) {
        const name = entry.path.split("/").at(-1);
        if (entry.kind === "directory") yield { ...handle(store, entry.path), name };
        else if (entry.kind === "file") yield { kind: "file", name, async getFile() {
          const seen = await store.read(entry.path);
          if (!seen) throw missing();
          return { size: seen.size, text: async () => seen.text };
        } };
      }
    },
    full
  };
}
async function save(store, page, text2, author, expected) {
  const current2 = await store.read(page);
  if ((current2?.sha256 ?? null) !== expected) throw Object.assign(new Error("The document changed."), { code: "stale" });
  const result = await reviews.save(handle(store), page, current2, text2, author);
  if (!result.saved || !result.recorded) throw Object.assign(new Error("The save has no completed review receipt."), { code: "incomplete_save", result });
  return result;
}
var missing, FolderAccess, environment, reviews, sync, projectSettings;
var init_review = __esm({
  "runtime/review.mjs"() {
    init_reviews();
    init_editorsync();
    init_project();
    init_matching();
    init_document();
    init_errors();
    missing = () => Object.assign(new Error("File or directory not found."), { name: "NotFoundError" });
    FolderAccess = {
      async readBinary(dir, page) {
        const file = await dir.store.read(dir.full(page), { binary: true });
        if (!file) throw missing();
        return file;
      },
      async writeBinary(dir, page, bytes3, seen) {
        return dir.store.write(dir.full(page), bytes3, { expected: seen?.sha256 ?? null });
      },
      canArchive: (dir) => typeof dir.store.archive === "function",
      async archiveFile(dir, from, to, expected) {
        return dir.store.archive(dir.full(from), dir.full(to), expected);
      },
      async peek(dir, page) {
        return dir.store.read(dir.full(page));
      },
      async readFile(dir, page) {
        const seen = await this.peek(dir, page);
        if (!seen) throw missing();
        return { ...seen, mark: seen.sha256 };
      },
      async writeFile(dir, page, value, seen) {
        try {
          const result = await dir.store.write(dir.full(page), value, { expected: seen?.sha256 ?? seen?.mark ?? null });
          return { ...result, text: value, mark: result.sha256 };
        } catch (e) {
          if (["stale", "busy", "mismatch"].includes(e.code)) return { saved: false, stale: true, reason: e.message };
          throw e;
        }
      },
      async listFolder(dir, _unused, { visible = () => true } = {}) {
        return (await dir.store.list(dir.prefix)).filter((e) => e.kind === "file" && visible(e.path, "file")).map((e) => ({ name: dir.prefix ? e.path.slice(dir.prefix.length + 1) : e.path, size: 0 }));
      }
    };
    environment = {
      FolderAccess,
      crypto,
      matchingBlocks,
      I18n: { message: (key) => key, error: (message) => new Error(message) },
      headField: (text2, key) => parseDocument(text2).head[key],
      parseHead: parseDocument
    };
    reviews = createReviews(environment);
    sync = createSync(environment);
    projectSettings = createProject(environment);
  }
});

// runtime/core/ontology.mjs
function readRegister(text2) {
  const parsed = parseDocument(text2);
  requireThat(parsed.head.register_version === 1 && Object.keys(parsed.head).length === 1, "ontology", "Unknown or missing register version.");
  const sections = /* @__PURE__ */ new Set(), genera = /* @__PURE__ */ new Map(), edges = /* @__PURE__ */ new Map();
  let section = null, entry = null;
  for (const [index, raw] of parsed.body.split(/\r?\n/).entries()) {
    const line = raw.trim(), heading = /^(#+)\s+(.+)$/.exec(line);
    if (heading) {
      const [, level, title] = heading;
      entry = null;
      if (level.length === 1) {
        section = null;
        continue;
      }
      if (level.length === 2) {
        requireThat(["Genera", "Edges"].includes(title) && !sections.has(title), "ontology", "Unknown or duplicate ontology section.", { line: index + 1 });
        sections.add(title);
        section = title;
        continue;
      }
      requireThat(level.length === 3 && section && identifier.test(title), "ontology", "Invalid ontology entry.", { line: index + 1 });
      const rows = section === "Genera" ? genera : edges;
      requireThat(!rows.has(title), "ontology", "Duplicate ontology entry.", { type: title });
      entry = { name: title, line: index + 1, fields: /* @__PURE__ */ Object.create(null) };
      rows.set(title, entry);
      continue;
    }
    if (!entry || !line) continue;
    const match = /^-\s+([^:]+):\s?(.*)$/.exec(line);
    requireThat(match, "ontology", "Unexpected text in an ontology entry.", { line: index + 1 });
    const [, key, value] = match;
    requireThat(
      (section === "Genera" ? GENUS_KEYS : EDGE_KEYS).includes(key) && !Object.hasOwn(entry.fields, key),
      "ontology",
      "Unknown or duplicate ontology field.",
      { field: key, line: index + 1 }
    );
    entry.fields[key] = value.trim();
  }
  requireThat(sections.size === 2 && genera.size > 0 && edges.size > 0, "ontology", "Register must define genera and edges.");
  const orders = /* @__PURE__ */ new Set();
  for (const genus of genera.values()) {
    const f = genus.fields;
    requireThat(GENUS_KEYS.every((k) => Object.hasOwn(f, k)), "ontology", "Genus is missing required fields.", { type: genus.name });
    requireThat(["core", "inherited"].includes(f.Origin), "ontology", "Unknown genus origin.");
    requireThat(f.Origin === "inherited" || Boolean(f.Label && f.Question), "ontology", "Core genus needs a label and question.");
    requireThat(/^[1-9]\d*$/.test(f.Order) && !orders.has(Number(f.Order)), "ontology", "Genus order must be positive and unique.");
    orders.add(Number(f.Order));
    requireThat(["true", "false"].includes(f["Related required"]), "ontology", "Related required must be true or false.");
    requireThat(f["Stale interval"] === "null" || /^[1-9]\d*$/.test(f["Stale interval"]), "ontology", "Invalid stale interval.");
    for (const key of ["Classes", "Required from stable", "Edges out"]) {
      const items = bars(f[key]);
      requireThat(items.every((v) => identifier.test(v)) && new Set(items).size === items.length, "ontology", "Invalid ontology value list.", { field: key });
    }
    requireThat(bars(f["Sections"]).every(Boolean), "ontology", "Empty required section.");
    Object.assign(genus, {
      label: f.Label,
      question: f.Question,
      order: Number(f.Order),
      classes: bars(f.Classes),
      required: bars(f["Required from stable"]),
      sections: bars(f.Sections),
      edgesOut: bars(f["Edges out"]),
      relatedRequired: f["Related required"] === "true",
      staleInterval: f["Stale interval"] === "null" ? null : Number(f["Stale interval"])
    });
    requireThat(genus.edgesOut.every((k) => edges.has(k)), "ontology", "Genus names an unregistered edge.", { type: genus.name });
  }
  for (const edge of edges.values()) {
    const f = edge.fields;
    requireThat(f.Domain && f.Range, "ontology", "Edge needs domain and range.");
    if (Object.hasOwn(f, "Transitive")) requireThat(["true", "false"].includes(f.Transitive), "ontology", "Transitive must be true or false.");
    for (const [key, tokens] of [["Domain", ["any"]], ["Range", ["any", "same"]]]) {
      const values = bars(f[key]);
      requireThat(
        values.length === 1 && tokens.includes(values[0]) || values.length > 0 && values.every((v) => genera.has(v)) && new Set(values).size === values.length,
        "ontology",
        "Unknown genus in edge " + key.toLowerCase() + ".",
        { edge: edge.name }
      );
    }
    Object.assign(edge, { domain: bars(f.Domain), range: bars(f.Range), transitive: f.Transitive === "true", definition: f.Definition ?? "", example: f.Example ?? "" });
  }
  return { version: 1, genera, edges };
}
function edgeAllowed(register, type, source2, target) {
  const edge = register.edges.get(type), genus = register.genera.get(source2);
  if (!edge || !genus || !register.genera.has(target)) throw new WikiError("ontology", "Unknown or unregistered relationship or document type.", { type, source: source2, target });
  return genus.edgesOut.includes(type) && (edge.domain.includes("any") || edge.domain.includes(source2)) && (edge.range.includes("any") || edge.range.includes("same") && source2 === target || edge.range.includes(target));
}
var GENUS_KEYS, EDGE_KEYS, identifier, bars;
var init_ontology = __esm({
  "runtime/core/ontology.mjs"() {
    init_document();
    init_errors();
    GENUS_KEYS = ["Label", "Question", "Order", "Classes", "Required from stable", "Sections", "Edges out", "Related required", "Stale interval", "Origin"];
    EDGE_KEYS = ["Domain", "Range", "Transitive", "Definition", "Example"];
    identifier = /^[a-z][a-z0-9_-]*$/;
    bars = (value) => value === "" ? [] : value.split("|").map((s) => s.trim());
  }
});

// runtime/core/graph.mjs
var graph_exports = {};
__export(graph_exports, {
  buildGraph: () => buildGraph,
  graphProjection: () => graphProjection,
  navigationPage: () => navigationPage,
  pageKey: () => pageKey,
  resolveEvidence: () => resolveEvidence,
  resolvePage: () => resolvePage
});
function graphProjection(graph) {
  const pages = [...graph.pages.values()].filter((p) => !navigationPage(p.path)), keys = new Set(pages.map((p) => p.key));
  return { pages, edges: graph.edges.filter((e) => keys.has(e.source) && keys.has(e.target)) };
}
function normalize(parts) {
  const result = [];
  for (const part of parts) {
    if (part === "..") {
      if (!result.length) return null;
      result.pop();
    } else if (part && part !== ".") result.push(part);
  }
  return result.join("/");
}
function resolvePage(graph, from, written) {
  let text2;
  try {
    text2 = decodeURIComponent(String(written).trim()).split("|")[0].split("#")[0];
  } catch {
    return { code: "invalid_link" };
  }
  if (!text2 || /^(?:[a-z][a-z0-9+.-]*:|\/)/i.test(text2) || /[\\\x00-\x1f]/.test(text2)) return { code: "external_link" };
  if (/^(schema|meta|notices|vermerke)\//.test(text2)) return { code: "technical_link" };
  const origin = typeof from === "string" ? graph.pages.get(from) : from;
  const scope = graph.scopes.get(origin.wiki);
  const choose = (keys) => keys.length === 1 ? { key: keys[0] } : { code: keys.length ? "ambiguous_link" : "unresolved_link" };
  const local2 = (s, value) => {
    const path7 = value.endsWith(".md") ? value : value + ".md";
    if (s.paths.has(path7)) return { key: s.paths.get(path7) };
    if (s.ids.has(value)) return choose(s.ids.get(value));
    return !value.includes("/") ? choose(s.names.get(value.replace(/\.md$/, "")) ?? []) : { code: "unresolved_link" };
  };
  if (text2.startsWith("./") || text2.startsWith("../")) {
    const relative = normalize([...origin.path.split("/").slice(0, -1), ...text2.split("/")]);
    if (relative !== null) {
      if (technical(relative)) return { code: "technical_link" };
      const result = local2(scope, relative);
      if (result.key || result.code === "ambiguous_link") return result;
    }
    if (scope.path !== null && scope.path !== void 0) {
      const full = normalize([...scope.path.split("/"), ...origin.path.split("/").slice(0, -1), ...text2.split("/")]);
      if (full !== null) return choose(graph.projectPaths.get(full.endsWith(".md") ? full : full + ".md") ?? []);
    }
    return { code: "unresolved_link" };
  }
  const direct = local2(scope, text2);
  if (direct.key || direct.code === "ambiguous_link") return direct;
  if (text2.includes("/")) {
    const split = text2.indexOf("/"), prefix = text2.slice(0, split), rest = text2.slice(split + 1);
    const exact = graph.scopes.get(prefix);
    const matches = exact ? [exact] : [...graph.scopes.values()].filter((s) => s.label === prefix || s.path === prefix);
    if (matches.length === 1) return local2(matches[0], rest);
    if (matches.length > 1) return { code: "ambiguous_link" };
    return choose(graph.projectPaths.get(text2.endsWith(".md") ? text2 : text2 + ".md") ?? []);
  }
  return choose(graph.names.get(text2.replace(/\.md$/, "")) ?? []);
}
async function buildGraph(wikis, { allowMissingRegister = false } = {}) {
  requireThat(Array.isArray(wikis) && wikis.length > 0 && new Set(wikis.map((w) => w.id)).size === wikis.length, "scope", "Select unique accessible wikis.");
  const graph = { pages: /* @__PURE__ */ new Map(), scopes: /* @__PURE__ */ new Map(), names: /* @__PURE__ */ new Map(), projectPaths: /* @__PURE__ */ new Map(), evidence: /* @__PURE__ */ new Map(), edges: [], findings: [], failures: [], redirects: [] };
  for (const wiki2 of wikis) {
    const scope = { ...wiki2, paths: /* @__PURE__ */ new Map(), names: /* @__PURE__ */ new Map(), ids: /* @__PURE__ */ new Map(), register: null };
    graph.scopes.set(wiki2.id, scope);
    try {
      const register = await wiki2.store.read("schema/TYPES.md");
      if (!register && allowMissingRegister) graph.failures.push({ wiki: wiki2.id, code: "ontology", message: "Wiki has no type register; typed relations cannot be validated." });
      else {
        requireThat(register, "ontology", "Wiki has no type register.");
        scope.register = readRegister(register.text);
      }
      for (const entry of await wiki2.store.list("")) {
        if (entry.kind !== "file" || !entry.path.endsWith(".md") || technical(entry.path)) continue;
        try {
          const file = await wiki2.store.read(entry.path), parsed = parseDocument(file.text);
          if (parsed.head.llmwiki_redirect) {
            graph.redirects.push({ wiki: wiki2.id, path: entry.path, target: parsed.head.llmwiki_redirect });
            continue;
          }
          const key = pageKey(wiki2.id, entry.path), page = { ...parsed, key, wiki: wiki2.id, path: entry.path, sha256: file.sha256 };
          graph.pages.set(key, page);
          scope.paths.set(entry.path, key);
          const name = entry.path.split("/").pop().slice(0, -3);
          add(scope.names, name, key);
          add(graph.names, name, key);
          const id = String(page.head.id ?? "").trim();
          if (id) add(scope.ids, id, key);
          const evidence = String(page.head.source_id ?? page.head.id ?? "").trim();
          if (evidence) add(graph.evidence, evidence, key);
          if (wiki2.path !== null && wiki2.path !== void 0) {
            const p = normalize([...wiki2.path.split("/"), ...entry.path.split("/")]);
            if (p !== null) add(graph.projectPaths, p, key);
          }
        } catch (error) {
          graph.failures.push({ wiki: wiki2.id, page: entry.path, code: error.code ?? "read", message: error.message });
        }
      }
    } catch (error) {
      graph.failures.push({ wiki: wiki2.id, code: error.code ?? "read", message: error.message });
    }
  }
  for (const scope of graph.scopes.values()) {
    const record = await scope.store.read(".llmwiki/identity-aliases.json");
    if (!record) continue;
    try {
      const data = JSON.parse(record.text);
      requireThat(data.format === "llmwiki-identity-aliases/1" && Array.isArray(data.aliases), "identity", "Invalid identity aliases.");
      for (const alias of data.aliases) {
        const key = scope.paths.get(alias.path);
        requireThat(key && typeof alias.id === "string" && alias.id.trim(), "identity", "Alias target is missing.");
        if (!scope.ids.has(alias.id)) {
          add(scope.ids, alias.id, key);
          add(graph.evidence, alias.id, key);
        }
      }
    } catch (error) {
      graph.findings.push({ wiki: scope.id, code: "identity_alias_invalid", message: error.message });
    }
  }
  for (const r of graph.redirects) {
    const target = graph.scopes.get(r.target.wiki), keys = target?.ids.get(r.target.id) ?? [], key = keys.length === 1 ? keys[0] : null, page = graph.pages.get(key);
    if (!page) continue;
    const origin = graph.scopes.get(r.wiki);
    origin.paths.set(r.path, key);
    if (!origin.ids.has(r.target.id)) origin.ids.set(r.target.id, [key]);
    const name = r.path.split("/").at(-1).replace(/\.md$/, "");
    if (!origin.names.has(name)) origin.names.set(name, [key]);
    if (origin.path != null) add(graph.projectPaths, origin.path + "/" + r.path, key);
  }
  for (const [id, keys] of graph.evidence) if (keys.length > 1) graph.findings.push({ code: "duplicate_id", id, pages: keys });
  const seen = /* @__PURE__ */ new Set();
  for (const page of graph.pages.values()) {
    if (navigationPage(page.path)) continue;
    const authored2 = stripNavigation(page.head.resource ? page.body.replace(/<!-- llmwiki:source:start -->[\s\S]*?<!-- llmwiki:source:end -->/g, "") : page.body);
    const rows = relationRows(authored2), typed = new Set(rows.filter((r) => r.direction === "out").map((r) => r.written.split("#")[0]));
    const candidates = [
      ...rows.filter((r) => r.direction === "out").map((r) => ({ ...r, origin: "table" })),
      ...listValue(page.head.related).filter((v) => typeof v === "string").map((v) => ({ written: bodyLinks(v)[0]?.written ?? v, type: "", reason: "", origin: "head" })),
      ...bodyLinks(authored2.replace(/^\|\s*in\s*\|[^\n]*(?:\n|$)/gm, "")).map((v) => ({ ...v, type: "", reason: "", origin: "text" }))
    ];
    for (const written of listValue(page.head.superseded_by).filter((v) => typeof v === "string")) candidates.push({ written: bodyLinks(written)[0]?.written ?? written, type: "superseded_by", reason: "superseded_by", origin: "head" });
    for (const edge of candidates) {
      if (edge.embedded && /\.(?:png|jpe?g|gif|webp|avif|pdf|excalidraw)(?:#.*)?$/i.test(edge.written)) continue;
      if (edge.origin !== "table" && !edge.type && typed.has(edge.written.split("#")[0])) continue;
      const resolved = resolvePage(graph, page, edge.written);
      if (!resolved.key) {
        if (!["external_link", "technical_link"].includes(resolved.code)) graph.findings.push({ code: resolved.code, wiki: page.wiki, page: page.path, written: edge.written });
        continue;
      }
      const target = graph.pages.get(resolved.key);
      if (navigationPage(target.path)) continue;
      let valid = true;
      if (edge.type) {
        try {
          valid = edge.valid !== false && Boolean(edge.reason.trim()) && edgeAllowed(graph.scopes.get(page.wiki).register, edge.type, page.head.type, target.head.type);
        } catch {
          valid = false;
        }
        if (!valid) graph.findings.push({ code: "invalid_relation", wiki: page.wiki, page: page.path, type: edge.type, target: target.path, line: edge.line });
      }
      if (page.key === target.key) {
        graph.findings.push({ code: "self_link", wiki: page.wiki, page: page.path });
        continue;
      }
      const identity2 = JSON.stringify([page.key, target.key, edge.type, edge.reason]);
      if (seen.has(identity2)) continue;
      seen.add(identity2);
      graph.edges.push({ ...edge, source: page.key, target: target.key, valid });
    }
  }
  const pair = (e) => JSON.stringify([e.source, e.target].sort());
  const typedPairs = new Set(graph.edges.filter((e) => e.valid && e.type).map(pair));
  graph.edges = graph.edges.filter((e) => e.type || !typedPairs.has(pair(e)));
  graph.outgoing = /* @__PURE__ */ new Map();
  graph.incoming = /* @__PURE__ */ new Map();
  for (const edge of graph.edges) {
    add(graph.outgoing, edge.source, edge);
    add(graph.incoming, edge.target, edge);
  }
  const transitive = graph.edges.filter((e) => e.valid && e.type && graph.scopes.get(graph.pages.get(e.source).wiki).register.edges.get(e.type)?.transitive);
  for (const edge of transitive) {
    const visited = /* @__PURE__ */ new Set(), queue2 = [edge.target];
    let cycle = false;
    while (queue2.length) {
      const key = queue2.pop();
      if (key === edge.source) {
        cycle = true;
        break;
      }
      if (visited.has(key)) continue;
      visited.add(key);
      for (const next of graph.outgoing.get(key) ?? []) if (next.valid && next.type === edge.type) queue2.push(next.target);
    }
    if (cycle) graph.findings.push({ code: "relation_cycle", type: edge.type, source: edge.source, target: edge.target });
  }
  return graph;
}
function resolveEvidence(graph, identifier2, wiki2) {
  const raw = String(identifier2), split = raw.search(/[@#]/), id = split < 0 ? raw : raw.slice(0, split), anchor = split < 0 ? "" : raw.slice(split + 1).replace(/^\^/, "");
  let keys = graph.evidence.get(id) ?? [];
  if (keys.length !== 1) return null;
  const page = graph.pages.get(keys[0]);
  if (anchor) {
    const escaped = anchor.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    if (!new RegExp("(?:\\^" + escaped + "(?:\\s|$)|^#{1,6}\\s+" + escaped + "\\s*$)", "m").test(page.body)) return null;
  }
  return { id, wiki: page.wiki, page: page.path, title: page.head.title ?? "", anchor, text: page.body, key: page.key };
}
var navigationPage, pageKey, technical, add;
var init_graph = __esm({
  "runtime/core/graph.mjs"() {
    init_document();
    init_ontology();
    init_errors();
    navigationPage = (path7) => ["WIKI.md", "index.md", "bundle.md", "wiki/index.md", "wiki/bundle.md"].includes(path7);
    pageKey = (wiki2, page) => JSON.stringify([wiki2, page]);
    technical = (path7) => path7.split("/").some((p) => p.startsWith(".") || p.startsWith("~$")) || /^(schema|meta|notices|vermerke)\//.test(path7);
    add = (map, key, value) => {
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(value);
    };
  }
});

// runtime/links.mjs
function markdownLink(from, to, label2) {
  const a = from.split("/").slice(0, -1), b = to.split("/");
  while (a.length && b.length && a[0] === b[0]) {
    a.shift();
    b.shift();
  }
  const target = (a.length ? "../".repeat(a.length) : "./") + b.map((p) => encodeURIComponent(p).replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16))).join("/");
  return "[" + String(label2 ?? to).replace(/[\[\]\\|\r\n]/g, " ") + "](" + target + ")";
}
function rewriteDocument(source2, from, to, mapping, graph) {
  const page = { wiki: "wiki", path: from }, parsed = parseDocument(source2);
  const rewrite = (whole, written, label2) => {
    const resolved = resolvePage(graph, page, written), target = graph.pages.get(resolved.key);
    if (!target) return whole;
    const hash = written.indexOf("#"), anchor = hash < 0 ? "" : written.slice(hash);
    return markdownLink(to, mapping[target.path] ?? target.path, label2 || target.head.title).replace(/\)$/, (anchor || "") + ")");
  };
  const convert = (text2) => text2.replace(/<!-- llmwiki:source:start -->[\s\S]*?<!-- llmwiki:source:end -->|^ {0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?^ {0,3}\1[^\n]*(?:\n|$)|(`+)[^\n]*?\2|(!?)\[\[([^\]]+)\]\]|(!?)\[([^\]]*)\]\(<?([^\s)>]+)>?\)/gm, (whole, fence, inline, embed, wiki2, image, label2, url) => {
    if (fence || inline || whole.startsWith("<!--")) return whole;
    if (wiki2) {
      const [written, title] = wiki2.split("|");
      return (embed || "") + rewrite(whole.replace(/^!/, ""), written, title);
    }
    return (image || "") + rewrite(whole.replace(/^!/, ""), url, label2);
  });
  const changes = {};
  for (const key of ["related", "superseded_by"]) if (parsed.head[key]) changes[key] = (Array.isArray(parsed.head[key]) ? parsed.head[key] : [parsed.head[key]]).map((value) => {
    const raw = String(value);
    return raw.includes("[") ? convert(raw) : rewrite(raw, raw);
  });
  const patched = Object.keys(changes).length ? patchHead(source2, changes) : source2, p = parseDocument(patched);
  return patched.slice(0, p.offset) + convert(p.body);
}
var init_links = __esm({
  "runtime/links.mjs"() {
    init_graph();
    init_document();
  }
});

// runtime/derived.mjs
function replaceDerived(text2, kind, body) {
  const start2 = "<!-- llmwiki:" + kind + ":start -->", end = "<!-- llmwiki:" + kind + ":end -->", a = text2.indexOf(start2), b = text2.indexOf(end);
  requireThat(a < 0 && b < 0 || a >= 0 && b > a && text2.indexOf(start2, a + 1) < 0 && text2.indexOf(end, b + 1) < 0, "derived", "Malformed generated section: " + kind);
  const block = start2 + "\n" + body + "\n" + end;
  return a < 0 ? text2.trimEnd() + "\n\n" + block + "\n" : text2.slice(0, a) + block + text2.slice(b + end.length);
}
async function materializeRelations(store) {
  const graph = await buildGraph([{ id: "wiki", store }]);
  let updated = 0;
  const bundle = await store.read("wiki/bundle.md"), english = bundle && parseDocument(bundle.text).head.language === "en";
  const authored2 = (text2) => text2.replace(/<!-- llmwiki:source:start -->[\s\S]*?<!-- llmwiki:source:end -->|^ {0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?^ {0,3}\1[^\n]*(?:\n|$)|^\|\s*in\s*\|[^\r\n]*(?:\r?\n|$)/gm, (part) => /^\|\s*in\s*\|/.test(part) ? "" : part);
  for (const p of graph.pages.values()) {
    const tracking = ".llmwiki/derived-relations/" + encodeURIComponent(p.head.id || p.path) + ".json", oldTracking = ".llmwiki/derived-relations/" + encodeURIComponent(p.sha256) + ".json";
    const prior = await store.read(tracking) ?? (!p.head.id ? await store.read(oldTracking) : null), managed = prior ? JSON.parse(prior.text) : [];
    const own = /* @__PURE__ */ new Set();
    for (const v of listValue(p.head.related).filter((v2) => !managed.includes(v2))) {
      const r = resolvePage(graph, p, bodyLinks(String(v))[0]?.written ?? v), target = graph.pages.get(r.key);
      own.add(target ? markdownLink(p.path, target.path, target.head.title) : v);
    }
    const authoredBody = authored2(stripNavigation(p.head.resource ? p.body.replace(/<!-- llmwiki:source:start -->[\s\S]*?<!-- llmwiki:source:end -->/g, "") : p.body));
    const bodyTargets = new Set(bodyLinks(authoredBody).filter((l) => !l.embedded).map((l) => resolvePage(graph, p, l.written).key));
    const added = /* @__PURE__ */ new Set();
    for (const e of graph.outgoing.get(p.key) || []) if (e.valid && (e.origin === "table" || bodyTargets.has(e.target))) {
      const target = graph.pages.get(e.target), link = markdownLink(p.path, target.path, target.head.title);
      if (!own.has(link)) added.add(link);
    }
    const related = [.../* @__PURE__ */ new Set([...own, ...added])].sort();
    let text2 = JSON.stringify(related) === JSON.stringify(p.head.related ?? []) ? p.source : patchHead(p.source, { related });
    text2 = rewriteDocument(text2, p.path, p.path, {}, graph);
    const parsed = parseDocument(text2);
    let body = authored2(stripNavigation(parsed.body, { legacy: true }));
    const incoming = (graph.incoming.get(p.key) || []).filter((e) => e.valid), bySource = /* @__PURE__ */ new Map();
    for (const e of incoming) {
      if (!bySource.has(e.source)) bySource.set(e.source, []);
      bySource.get(e.source).push(e);
    }
    if (bySource.size) {
      const rows = [...bySource].map(([key]) => {
        const source2 = graph.pages.get(key);
        return "> | " + markdownLink(p.path, source2.path, source2.head.title) + " |";
      }).sort().join("\n");
      const heading = english ? "Relations" : "Beziehungen";
      const title = english ? bySource.size + " notes link here" : bySource.size + " Notizen verweisen hierher";
      body = body.trimEnd() + "\n\n<!-- vault-operator:incoming-links -->\n" + (new RegExp("^## " + heading + "\\s*$", "m").test(body) ? "" : "## " + heading + "\n\n") + "> [!relation-in]- " + title + "\n> | " + (english ? "Note" : "Notiz") + " |\n> | --- |\n" + rows + "\n<!-- /vault-operator:incoming-links -->\n";
    }
    if (p.head.type === "topic" && !["wiki/index.md", "WIKI.md"].includes(p.path)) {
      const members = [...new Set(incoming.filter((e) => e.type === "part_of").map((e) => e.source))].map((key) => graph.pages.get(key));
      body = replaceDerived(body, "members", members.map((s) => "- " + markdownLink(p.path, s.path, s.head.title) + " \u2014 " + s.head.description).sort().join("\n") || (english ? "No assigned pages yet." : "Noch keine zugeordneten Seiten."));
    }
    const evidenceLinks = /* @__PURE__ */ new Set();
    if (typeof p.head.resource?.link === "string") evidenceLinks.add(p.head.resource.link);
    for (const id of listValue(p.head.sources)) {
      const key = (graph.evidence.get(String(id).split(/[@#]/)[0]) || [])[0], evidence = graph.pages.get(key);
      if (evidence) evidenceLinks.add(markdownLink(p.path, evidence.path, evidence.head.title));
    }
    if (evidenceLinks.size) body = replaceDerived(body, "provenance", "> [!source]- " + (english ? "Sources and evidence" : "Quellen und Belege") + "\n" + [...evidenceLinks].sort().map((link) => "> - " + link).join("\n"));
    const ledger = JSON.stringify([...added].sort()), seen = await store.read(tracking);
    if (seen?.text !== ledger) await store.write(tracking, ledger, { expected: seen?.sha256 ?? null });
    text2 = projectMetadata(text2.slice(0, parsed.offset) + body);
    if (text2 !== p.source) {
      await save(store, p.path, text2, "wiki-relations", p.sha256);
      updated++;
    }
  }
  return { updated };
}
async function exportGraph(store) {
  const graph = await buildGraph([{ id: "wiki", store }]), projection = graphProjection(graph), data = { format: "llmwiki-graph/1", derived: true, nodes: graphProjection(graph).pages.map((p) => ({ key: p.key, id: p.head.id, wiki: p.wiki, path: p.path, title: p.head.title, type: p.head.type, sha256: p.sha256 })), edges: projection.edges.map((e) => ({ ...e, semantic: Boolean(e.type), origin_page: graph.pages.get(e.source).path })), findings: [...graph.failures, ...graph.findings] };
  const text2 = JSON.stringify(data, null, 2) + "\n", path7 = ".llmwiki/graph.json", seen = await store.read(path7);
  if (seen?.text !== text2) await store.write(path7, text2, { expected: seen?.sha256 ?? null });
  return data;
}
async function exportProjectGraph(root, { bindings = {} } = {}) {
  const { load: load3, context: context2 } = await Promise.resolve().then(() => (init_project2(), project_exports)), { project } = await load3(root), wikis = [], unavailable = [];
  for (const c of project.connections) {
    if (wikis.some((w) => w.id === c.wiki) || unavailable.some((w) => w.wiki === c.wiki)) continue;
    try {
      const value = await context2(root, c.id, { bindings });
      wikis.push({ id: value.wiki.id, label: value.wiki.label, path: value.wiki.path ?? value.wiki.id, store: value.work });
    } catch (error) {
      unavailable.push({ wiki: c.wiki, code: error.code ?? "access", message: error.message });
    }
  }
  const graph = wikis.length ? await buildGraph(wikis, { allowMissingRegister: true }) : { pages: /* @__PURE__ */ new Map(), edges: [], failures: [], findings: [] };
  const data = { format: "llmwiki-project-graph/1", project: project.id, derived: true, wikis: project.folders.filter((f) => f.kind === "wiki").map((w) => ({ id: w.id, label: w.label, path: w.path })), nodes: graphProjection(graph).pages.map((p) => ({ key: p.key, id: p.head.id ?? null, wiki: p.wiki, path: p.path, title: p.head.title || p.path.split("/").at(-1).replace(/\.md$/, ""), type: p.head.type ?? null, sha256: p.sha256 })), edges: graphProjection(graph).edges.filter((e) => e.valid).map((e) => ({ ...e, crossWiki: graph.pages.get(e.source).wiki !== graph.pages.get(e.target).wiki, origin_page: graph.pages.get(e.source).path })), findings: [...unavailable, ...graph.failures, ...graph.findings] };
  data.complete = !data.findings.length;
  const revision = await root.services.hash(JSON.stringify(data)), path7 = ".llmwiki/graph.json", old = await root.read(path7);
  if (old) try {
    const saved = JSON.parse(old.text);
    if (saved.revision === revision) return saved;
  } catch {
  }
  const snapshot4 = { ...data, revision, generated_at: root.services.now() };
  await root.write(path7, JSON.stringify(snapshot4, null, 2) + "\n", { expected: old?.sha256 ?? null });
  return snapshot4;
}
var init_derived = __esm({
  "runtime/derived.mjs"() {
    init_graph();
    init_document();
    init_review();
    init_errors();
    init_links();
    init_links();
  }
});

// runtime/assets/default-register.mjs
var default_register_default;
var init_default_register = __esm({
  "runtime/assets/default-register.mjs"() {
    default_register_default = "---\nregister_version: 1\n---\n\n# Typregister\n\nJede Gattung unten ist eine Zeile. Sie sagt, welche Frage beim Einordnen zu\nbeantworten ist, was ab `stable` bindet, welche Abschnitte der Text tragen\nmuss und welche Kanten von ihr ausgehen d\xFCrfen.\n\n## Genera\n\n### bundle\n- Label: B\xFCndel\n- Question: Beschreibt das Dokument den Leserkreis, die Sprache und die Regeln einer Ablage selbst?\n- Order: 1\n- Classes:\n- Required from stable: language | owner\n- Sections: Zweck | Leserkreis | Registrierte Profile\n- Edges out: references\n- Related required: false\n- Stale interval: 12\n- Origin: core\n\n### source\n- Label: Quelle\n- Question: Liegt die Wahrheit dieses Dokuments au\xDFerhalb des B\xFCndels, in einem Original, das jemand anderes verantwortet?\n- Order: 2\n- Classes: document | article | recording | conversation | dataset | website\n- Required from stable: resource | published | class\n- Sections: Worum es geht | Was daraus \xFCbernommen wurde\n- Edges out: part_of | references | superseded_by | contradicts\n- Related required: true\n- Stale interval: 12\n- Origin: core\n\n### contract\n- Label: Vertrag\n- Question: Legt das Dokument eine Regel fest, an die sich Werkzeuge oder Menschen halten m\xFCssen?\n- Order: 3\n- Classes: schema | policy | interface\n- Required from stable: owner\n- Sections: Geltungsbereich | Regel | Ausnahmen\n- Edges out: refines | references | superseded_by | contradicts\n- Related required: true\n- Stale interval: 6\n- Origin: core\n\n### decision\n- Label: Beschluss\n- Question: H\xE4lt das Dokument fest, dass jemand etwas entschieden hat, mit Zeitpunkt und Grund?\n- Order: 4\n- Classes:\n- Required from stable: decided_at | decided_by\n- Sections: Entscheidung | Begr\xFCndung | Betrachtete Alternativen\n- Edges out: decides | references | superseded_by | contradicts\n- Related required: true\n- Stale interval: null\n- Origin: core\n\n### experience\n- Label: Erfahrung\n- Question: H\xE4lt das Dokument fest, was aus einem konkreten Vorgang gelernt wurde?\n- Order: 5\n- Classes:\n- Required from stable:\n- Sections: Was geschah | Was daraus folgt\n- Edges out: learned_from | part_of | references\n- Related required: true\n- Stale interval: null\n- Origin: core\n\n### process\n- Label: Ablauf\n- Question: Beschreibt das Dokument, wie etwas wiederholt getan wird?\n- Order: 6\n- Classes: routine | event | project\n- Required from stable: owner\n- Sections: Ausl\xF6ser | Schritte | Ergebnis\n- Edges out: part_of | refines | references | superseded_by\n- Related required: true\n- Stale interval: 12\n- Origin: core\n\n### position\n- Label: Haltung\n- Question: Vertritt das Dokument eine eigene Bewertung, die jemand anderes anders sehen k\xF6nnte?\n- Order: 7\n- Classes:\n- Required from stable: owner\n- Sections: Haltung | Begr\xFCndung | Abgrenzung\n- Edges out: contradicts | references | refines | superseded_by\n- Related required: true\n- Stale interval: 12\n- Origin: core\n\n### entity\n- Label: Gegenstand\n- Question: Bezeichnet das Dokument eine benennbare Sache, \xFCber die entschieden wird oder die etwas tut?\n- Order: 8\n- Classes: organization | unit | person | body | system | capability\n- Required from stable: class | owner\n- Sections: Worum es sich handelt\n- Edges out: part_of | refines | references | superseded_by\n- Related required: true\n- Stale interval: 12\n- Origin: core\n\n### concept\n- Label: Konzept\n- Question: Erkl\xE4rt das Dokument, was etwas ist, wie es funktioniert und warum es wichtig ist?\n- Order: 9\n- Classes: cross-cutting\n- Required from stable: aliases\n- Sections: Was ist das | Wie funktioniert es | Warum ist es wichtig\n- Edges out: refines | references | superseded_by | contradicts\n- Related required: false\n- Stale interval: 24\n- Origin: core\n\n### topic\n- Label: Thema\n- Question: Gliedert das Dokument Wissen in einen Bereich, dem anderes zugeh\xF6rt?\n- Order: 10\n- Classes:\n- Required from stable: aliases\n- Sections: Worum es geht\n- Edges out: part_of | references\n- Related required: false\n- Stale interval: 12\n- Origin: core\n\n## Edges\n\n### part_of\n- Definition: The source belongs to the subject or whole represented by the target; this is subject membership, not evidence.\n- Example: A grid-capacity report belongs to the hub for grid planning.\n- Transitive: true\n- Domain: any\n- Range: topic | concept | entity\n\n### refines\n- Definition: The source adds precision or restrictions to the target without replacing its valid statements.\n- Example: A rule for transformers refines the general rule for electrical equipment.\n- Transitive: true\n- Domain: any\n- Range: same\n\n### references\n- Definition: The source uses a specific statement, context or evidence in the target. The reason identifies the relevant passage.\n- Example: A calculation references the measurement table from which its input values were taken.\n- Domain: any\n- Range: any\n\n### contradicts\n- Definition: Source and target assert incompatible statements under the same time and applicability conditions. The reason cites both passages and those conditions.\n- Example: Two reports give incompatible capacity limits for the same asset on the same reference date.\n- Domain: any\n- Range: same\n\n### superseded_by\n- Definition: The target explicitly replaces the source for the stated scope. Publication dates alone do not establish replacement.\n- Example: The 2026 procedure explicitly replaces the 2024 procedure from its effective date.\n- Transitive: true\n- Domain: any\n- Range: same\n\n### decides\n- Definition: The source records a decision about the target, including who decided and why.\n- Example: An approved decision selects the transformer described on the entity page.\n- Domain: decision\n- Range: entity | process | contract | position\n\n### learned_from\n- Definition: The source expresses an insight developed from a passage or observation in the target. Preserve both the passage and the interpretation.\n- Example: An experience page derives a maintenance lesson from the incident report and points at the relevant paragraph.\n- Domain: any\n- Range: source | process\n";
  }
});

// runtime/core/note-contract.mjs
function noteContract({ head, body }, register) {
  const genus = register?.genera.get(head.type), findings = [];
  const add3 = (kind, field) => findings.push({ code: "head_contract_" + kind, field });
  if (!genus || !["stable", "deprecated"].includes(head.status)) return findings;
  for (const key of /* @__PURE__ */ new Set([...genus.required, "sources", "verified", "stale_after"])) {
    const value = head[key];
    if (!present(value)) {
      add3("required", key);
      continue;
    }
    if (["owner", "language", "class", "decided_by"].includes(key) && typeof value !== "string") add3("type", key);
    if (["published", "decided_at", "stale_after"].includes(key) && !date(value)) add3("date", key);
    if (["aliases", "sources"].includes(key) && !strings(value)) add3("type", key);
    if (key === "verified" && (!Array.isArray(value) || !value.every((v) => v && typeof v.by === "string" && v.by.trim() && date(v.at)))) add3("type", key);
  }
  if (head.class !== void 0 && !genus.classes.includes(head.class)) add3("class", "class");
  if (genus.relatedRequired && (!strings(head.related) || !head.related.length) && !relationRows(body).some((r) => r.direction === "out" && r.valid && r.written)) add3("connection", "related");
  for (const section of genus.sections) if (!sectionText(body, [section]).trim()) add3("section", section);
  return findings;
}
function reviewAdvisories({ head }, register, now) {
  const time = date(now), postponed = date(head.postponed_until);
  if (!time || postponed && postponed > time) return [];
  const findings = [], add3 = (code, message, extra = {}) => findings.push({ code, severity: "warning", message, addressee: typeof head.owner === "string" ? head.owner : null, urgency: head.urgency ?? null, ...extra });
  const deadline = date(head.stale_after), interval = register?.genera.get(head.type)?.staleInterval;
  if (deadline && deadline <= time) add3("review_due", "The recorded review date has been reached.", { date: head.stale_after });
  if (interval && deadline) {
    const dates = [date(head.generated?.at), ...Array.isArray(head.verified) ? head.verified.map((v) => date(v?.at)) : []].filter(Boolean);
    if (!dates.length) add3("review_interval_unknown", "The review interval has no recorded starting date.");
    else {
      const start2 = new Date(Math.max(...dates.map((d) => +d))), day = start2.getUTCDate();
      start2.setUTCDate(1);
      start2.setUTCMonth(start2.getUTCMonth() + interval);
      const last = new Date(Date.UTC(start2.getUTCFullYear(), start2.getUTCMonth() + 1, 0)).getUTCDate();
      start2.setUTCDate(Math.min(day, last));
      if (deadline > start2) add3("review_interval_exceeded", "The next review date exceeds the registered interval.", { interval_limit: start2.toISOString() });
    }
  }
  return findings;
}
var present, date, strings;
var init_note_contract = __esm({
  "runtime/core/note-contract.mjs"() {
    init_document();
    present = (value) => typeof value === "string" ? Boolean(value.trim()) : Array.isArray(value) ? value.length > 0 : value && typeof value === "object" ? Object.keys(value).length > 0 : typeof value === "number" ? Number.isFinite(value) : typeof value === "boolean";
    date = (value) => typeof value === "string" && /^\d{4}-\d{2}-\d{2}(?:T.*)?$/.test(value) && Number.isFinite(Date.parse(value)) && (/* @__PURE__ */ new Date(value.slice(0, 10) + "T00:00:00Z")).toISOString().slice(0, 10) === value.slice(0, 10) ? new Date(value) : null;
    strings = (value) => Array.isArray(value) && value.every((v) => typeof v === "string" && v.trim());
  }
});

// runtime/content.mjs
function identity(services) {
  let n = BigInt(Date.parse(services.now()));
  for (const byte of services.random(10)) n = n << 8n | BigInt(byte);
  const alphabet = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
  let id = "";
  for (let i2 = 0; i2 < 26; i2++) {
    id = alphabet[Number(n & 31n)] + id;
    n >>= 5n;
  }
  return id;
}
function document(store, { type, title, description, author, head = {}, body }) {
  for (const [label2, value] of Object.entries({ type, title, description, author })) nonempty(value, label2);
  nonempty(body, "body", 2e6);
  return projectMetadata(newDocument({ id: identity(store.services), type, status: "draft", title, description: description.trim().split(/\s+/).slice(0, 25).join(" "), generated: { by: author, at: store.services.now() }, ...type === "bundle" ? { owner: author } : {}, related: [], ...head }, body));
}
async function createBundle(store, { title, purpose, audience, author, language = "de", preserveExisting = false }) {
  nonempty(purpose, "purpose");
  nonempty(title, "title");
  nonempty(author, "author");
  requireThat(Array.isArray(audience) && audience.length && audience.every((v) => typeof v === "string" && v.trim()), "audience", "Name the reader circle.");
  if (preserveExisting && await store.read("schema/TYPES.md")) readRegister((await store.read("schema/TYPES.md")).text);
  if (!preserveExisting && await store.read("schema/TYPES.md")) {
    readRegister((await store.read("schema/TYPES.md")).text);
    const existing = await store.read("wiki/bundle.md");
    requireThat(existing, "bundle", "An existing register has no bundle page; repair it explicitly.");
    let text2 = patchHead(existing.text, { description: purpose.trim().split(/\s+/).slice(0, 25).join(" "), readers: audience, language });
    const replaceSection = (body, names, title2, value) => {
      const lines = body.split("\n"), start2 = lines.findIndex((line) => names.some((name) => line.trim() === "## " + name));
      if (start2 < 0) return body.trimEnd() + "\n\n## " + title2 + "\n\n" + value + "\n";
      let end = start2 + 1;
      while (end < lines.length && !/^## /.test(lines[end])) end++;
      lines.splice(start2, end - start2, "## " + title2, "", value, "");
      return lines.join("\n");
    };
    text2 = replaceSection(text2, ["Zweck", "Purpose"], "Zweck", purpose);
    text2 = replaceSection(text2, ["Leserkreis", "Readers"], "Leserkreis", audience.join(", "));
    if (text2 !== existing.text) await save(store, "wiki/bundle.md", text2, author, existing.sha256);
    return { created: false, updated: text2 !== existing.text };
  }
  const texts2 = {
    "schema/TYPES.md": store.services.registerText ?? default_register_default,
    "schema/CONTRACT.md": "# Markdown data contract\n\nThe authoritative ontology is [Typenregister](./TYPES.md). Knowledge pages use UTF-8 Markdown with a YAML mapping. Required head: id (ULID), type, status (draft/stable), title and description. Stable pages satisfy the genus requirements and sections. Foreign fields and their comments remain intact.\n\nSources retain the COMPLETE source content under `## Source content`; descriptions and interpretations are separate. `resource` displays only source links. Technical resource values (store, name, sha256, created_at, created_at_basis, modified_at), generated and sources remain in an inert llmwiki:metadata JSON comment directly after YAML. Runtime parsing merges that provenance with visible Properties. Never discard the comment. `generated.at` is the extraction time, never the original creation date. `id` is stable across moves; `sources` cite IDs with optional @^block anchors. Unknown creation dates are null with basis unknown.\n\n## Relationships\n\n| Direction | Type | Target | Reason |\n| --- | --- | --- | --- |\n\nAuthored out rows need a registered type, resolvable target and a content-grounded reason. Only outgoing links belong in related. Incoming links are derived in a closed relation-in callout under Beziehungen/Relations, using Markdown links and vault-operator:incoming-links markers. Original and evidence links also appear in a collapsed source callout; indexes are derived. Contradictions require matching scope/time; dates alone never mean supersession.\n\n## Collaboration\n\nEdits require the exact read baseline and an immutable author event with completion receipt under .llmwiki/reviews. Divergent versions survive until an explicit decision. Detachment and sync never delete content.\n",
    "wiki/bundle.md": document(store, { type: "bundle", title, description: purpose, author, head: { language, readers: audience }, body: "# " + title + "\n\n## Zweck\n\n" + purpose + "\n\n## Leserkreis\n\n" + audience.join(", ") + "\n\n## Registrierte Profile\n\n[Typenregister](../schema/TYPES.md) \xB7 [Datenvertrag](../schema/CONTRACT.md)\n" }),
    "wiki/index.md": document(store, { type: "topic", title: "Verzeichnis", description: "Alle Wissensseiten dieses Wikis.", author, head: { aliases: [] }, body: "# Verzeichnis\n\n## Worum es geht\n\nDie Navigation wird aus den Markdown-Dateien abgeleitet.\n" }),
    "WIKI.md": document(store, { type: "topic", title, description: purpose, author, head: { aliases: [] }, body: "# " + title + "\n\n[Zweck und Leserkreis](./wiki/bundle.md) \xB7 [Verzeichnis](./wiki/index.md)\n" })
  };
  for (const [page, text2] of Object.entries(texts2)) {
    const current2 = await store.read(page);
    requireThat(preserveExisting || !current2, "exists", "Bundle setup would replace an existing file.", { page });
  }
  for (const [page, text2] of Object.entries(texts2)) if (!await store.read(page)) await save(store, page, text2, author, null);
  await refreshIndex(store);
  return { created: true, pages: Object.keys(texts2) };
}
async function refreshIndex(store) {
  await materializeRelations(store);
  const page = "wiki/index.md", current2 = await store.read(page);
  requireThat(current2, "index", "Create the wiki index first.");
  const files2 = (await store.list("")).filter((e) => e.kind === "file" && visibleKnowledge(e.path) && e.path !== page).map((e) => e.path).sort();
  const start2 = "<!-- llmwiki:index:start -->", end = "<!-- llmwiki:index:end -->";
  const groups = /* @__PURE__ */ new Map();
  for (const p of files2) {
    const { head } = parseDocument((await store.read(p)).text);
    if (p === "WIKI.md" || p.startsWith("test/") || head.llmwiki_redirect) continue;
    const group = { bundle: "\xDCber dieses Wiki", topic: "Themen", entity: "Gegenst\xE4nde und Personen", source: "Quellen" }[head.type] || "Weitere Wissensseiten";
    if (!groups.has(group)) groups.set(group, []);
    groups.get(group).push("- " + markdownLink(page, p, head.title) + " \xB7 `" + head.type + "` \u2014 " + String(head.description ?? "").replace(/[\r\n]/g, " "));
  }
  const order = ["\xDCber dieses Wiki", "Themen", "Gegenst\xE4nde und Personen", "Quellen", "Weitere Wissensseiten"];
  const block = start2 + "\n" + order.filter((name) => groups.has(name)).map((name) => "### " + name + "\n\n" + groups.get(name).join("\n")).join("\n\n") + "\n" + end;
  const a = current2.text.indexOf(start2), b = current2.text.indexOf(end);
  requireThat(a === -1 && b === -1 || a >= 0 && b > a && current2.text.indexOf(start2, a + 1) === -1 && current2.text.indexOf(end, b + 1) === -1, "index", "The generated index markers are malformed.");
  const text2 = a < 0 ? current2.text.trimEnd() + "\n\n" + block + "\n" : current2.text.slice(0, a) + block + current2.text.slice(b + end.length);
  if (text2 !== current2.text) await save(store, page, text2, "wiki-index", current2.sha256);
  await exportGraph(store);
  return { updated: text2 !== current2.text, pages: files2.length };
}
async function validateNote(store, { page, text: text2 }, { allowPlainExisting = false, fallbackRegister = false } = {}) {
  relativePath(page);
  requireThat(visibleKnowledge(page), "page", "Knowledge is stored as visible Markdown.");
  const parsed = parseDocument(text2), registered = await store.read("schema/TYPES.md"), register = readRegister(registered?.text ?? (fallbackRegister ? store.services.registerText ?? default_register_default : ""));
  const existing = await store.read(page), prior = existing ? parseDocument(existing.text) : null;
  if (allowPlainExisting && prior && Object.keys(prior.head).length === 0 && Object.keys(parsed.head).length === 0) return { plain: true };
  const sourceFields = ["resource", "extraction", "source_id"];
  if (parsed.head.type === "source" || prior?.head.type === "source" || sourceFields.some((key) => Object.hasOwn(parsed.head, key) || prior && Object.hasOwn(prior.head, key))) {
    requireThat(
      prior && ["id", "type", ...sourceFields].every((key) => JSON.stringify(parsed.head[key]) === JSON.stringify(prior.head[key])) && mirroredContent(parsed.body) === mirroredContent(prior.body),
      "source_ingest_required",
      "Use source.ingest to create or repair a source representation; write may only add editorial content without changing its original mirror or provenance."
    );
  }
  for (const key of ["id", "title", "description", "type", "status"]) nonempty(parsed.head[key], key);
  requireThat(prior?.head.id === parsed.head.id || /^[0-7][0-9A-HJKMNP-TV-Z]{25}$/.test(parsed.head.id), "identity", "New page identities must be valid ULIDs; preserve existing legacy identities during repair.");
  requireThat(parsed.head.description.trim().split(/\s+/).length <= 25, "description", "Use at most 25 words in the description.");
  requireThat(parsed.head.generated?.by && Number.isFinite(Date.parse(parsed.head.generated?.at)), "generated", "Generation metadata must retain author and date.");
  requireThat(Array.isArray(parsed.head.related), "related", "Related must be a Markdown link list.");
  const genus = register.genera.get(parsed.head.type);
  requireThat(genus, "ontology", "Choose a registered document type.");
  requireThat(STATUS_VALUES.includes(parsed.head.status), "status", "Choose draft, stable or deprecated.");
  const findings = noteContract(parsed, register);
  requireThat(!findings.length, "head_contract", "This version is missing required information or sections for its document type.", { page, findings });
  return parsed;
}
async function writeNote(store, { page, text: text2, author, expected }) {
  await validateNote(store, { page, text: text2 });
  const result = await save(store, page, text2, author, expected);
  await refreshIndex(store);
  return { page, sha256: (await store.read(page)).sha256 };
}
async function readingEvidence(store, { head, body }) {
  if (head.extraction) return head.extraction;
  const mirror = mirroredContent(body);
  if (mirror === null || !head.resource?.sha256 || !head.id) return null;
  const record = await store.read(".llmwiki/evidence/" + encodeURIComponent(head.id) + "/" + head.resource.sha256 + "/" + await store.services.hash(mirror) + ".json");
  try {
    return JSON.parse(record?.text ?? "null");
  } catch {
    return null;
  }
}
async function sourceIntegrity(store, parsed) {
  const { head, body } = parsed, findings = [], resource = head.resource, mirror = mirroredContent(body);
  const extraction = await readingEvidence(store, parsed);
  if (!resource || typeof resource !== "object") findings.push("source_provenance_missing");
  if (!head.id) findings.push("source_identity_missing");
  if (!resource || !Object.hasOwn(resource, "created_at_basis")) findings.push("source_dates_missing");
  if (extraction?.complete !== true || !Array.isArray(extraction?.gaps) || extraction.gaps.length) findings.push("source_coverage_unverified");
  const evidence = extraction?.evidence;
  if (evidence?.format !== "llmwiki-reading/1" || !Array.isArray(evidence.initial_gaps) || !Array.isArray(evidence.parts) || !evidence.by) findings.push("source_reading_evidence_missing");
  else if (evidence.initial_gaps.some((g) => !evidence.parts.some((p) => p.code === g.code && p.part === (g.part ?? null) && p.page === (g.page ?? null) && ["transcription", "visual-description", "decorative"].includes(p.kind) && typeof p.content === "string" && p.content.trim() && mirror?.includes(p.content)))) findings.push("source_reading_evidence_incomplete");
  if (mirror === null || !mirror.trim()) findings.push("source_content_missing");
  if (mirror === null || await store.services.hash(mirror) !== extraction?.content_sha256) findings.push("source_mirror_changed");
  if (!/^[a-f0-9]{64}$/.test(resource?.sha256 ?? "") || extraction?.sha256 !== resource.sha256) findings.push("source_provenance_unverified");
  return { complete: findings.length === 0, findings };
}
async function readiness(wikis) {
  const graph = await buildGraph(wikis), findings = [...graph.failures, ...graph.findings], source_pages = [], advisories = [];
  for (const scope of graph.scopes.values()) {
    findings.push(...(await sync.checkClearance(handle(scope.store))).map((f) => ({ ...f, wiki: scope.id })));
    const bundle = await scope.store.read("wiki/bundle.md"), index = await scope.store.read("wiki/index.md");
    const purpose = bundle ? sectionText(parseDocument(bundle.text).body, ["Zweck", "Purpose"]) : "";
    if (!purpose || /Noch nicht geschrieben|Not yet written/i.test(purpose)) findings.push({ code: "bundle_purpose_missing", wiki: scope.id });
    if (!index) findings.push({ code: "directory_missing", wiki: scope.id });
    for (const page of graph.pages.values()) if (page.wiki === scope.id) {
      findings.push(...noteContract(page, scope.register).map((f) => ({ ...f, wiki: scope.id, page: page.path })));
      advisories.push(...reviewAdvisories(page, scope.register, scope.store.services.now()).map((f) => ({ ...f, wiki: scope.id, page: page.path })));
      const issue2 = (code) => findings.push({ code, wiki: scope.id, page: page.path });
      if (!page.head.title || !page.head.description || !scope.register?.genera.has(page.head.type)) issue2("metadata_missing");
      if (!page.head.id) issue2("identity_missing");
      if (!page.head.generated?.by || !Number.isFinite(Date.parse(page.head.generated?.at))) issue2("generated_missing");
      if (String(page.head.description ?? "").trim().split(/\s+/).length > 25) issue2("description_too_long");
      if (["created", "updated", "author", "source_id", "extraction"].some((k) => Object.hasOwn(page.head, k))) issue2("unregistered_generated_fields");
      if (!STATUS_VALUES.includes(page.head.status)) issue2("status_invalid");
      if (page.path !== "wiki/index.md" && !index?.text.includes(markdownLink("wiki/index.md", page.path, page.head.title)) && page.path !== "WIKI.md" && !page.path.startsWith("test/")) issue2("directory_entry_missing");
      if (page.head.type === "source" || page.head.resource) {
        source_pages.push({ wiki: scope.id, page: page.path });
        for (const code of (await sourceIntegrity(scope.store, page)).findings) issue2(code);
      }
      const out = (graph.outgoing.get(page.key) || []).filter((e) => e.type && e.origin === "table" && e.valid), related = new Set(listValue(page.head.related).map((v) => resolvePage(graph, page, bodyLinks(String(v))[0]?.written ?? v).key));
      for (const edge of out) {
        if (!related.has(edge.target)) issue2("related_missing_for_out");
        const target = graph.pages.get(edge.target), incoming = /<!-- vault-operator:incoming-links -->([\s\S]*?)<!-- \/vault-operator:incoming-links -->/.exec(target.body)?.[1] ?? "";
        if (!bodyLinks(incoming).some((r) => resolvePage(graph, target, r.written).key === page.key)) issue2("incoming_relation_missing");
      }
      const incomingEdges = (graph.incoming.get(page.key) || []).filter((e) => e.type && e.origin === "table" && e.valid);
      for (const target of related) if (target && !out.some((e) => e.target === target) && !incomingEdges.some((e) => e.source === target)) issue2("related_reason_missing");
      if (page.head.type === "topic" && !["wiki/index.md", "WIKI.md"].includes(page.path)) {
        const explanation2 = stripNavigation(page.body, { legacy: true }).split(/\r?\n/).filter((l) => !/^\s*(?:#|\||[-*] )/.test(l)).join(" ").trim();
        if (explanation2.split(/\s+/).length < 10) issue2("topic_explanation_missing");
      }
      for (const id of listValue(page.head.sources)) if (!resolveEvidence(graph, id, page.wiki)) issue2("evidence_unresolved");
    }
  }
  return { ready: !findings.length, findings, advisories, pages: graph.pages.size, source_pages };
}
var STATUS_VALUES, visibleKnowledge;
var init_content = __esm({
  "runtime/content.mjs"() {
    init_derived();
    init_default_register();
    init_document();
    init_ontology();
    init_graph();
    init_errors();
    init_review();
    init_note_contract();
    STATUS_VALUES = Object.freeze(["draft", "stable", "deprecated"]);
    visibleKnowledge = (page) => /\.md$/i.test(page) && !page.split("/").some((p) => p.startsWith(".")) && !/^(schema|meta|notices|vermerke)\//.test(page);
  }
});

// runtime/setup-contract.mjs
function setupContract(expected = null) {
  return {
    format: "llmwiki-setup-contract/1",
    answers_schema: schema,
    rules: [
      "Drafts may contain partial answers. Only configure initializes the wiki.",
      "purpose and audience belong to each wikis entry, not the top level.",
      "wiki_folders/source_folders/work_folder are not request fields. Use wikis/sources and wikis[].workPath.",
      "Top-level answers merge; a supplied wikis or sources array replaces that entire array. Preserve previously collected entries.",
      "Draft expected is inspect.draft_sha256 or the previous draft result.sha256. Configure expected is inspect.sha256, null only for an unconfigured project.",
      "Example values are placeholders. Substitute actual user answers; never treat them as consent."
    ],
    requests: {
      draft: { action: "setup.draft", answers: { author: "<author>", editor: "both" }, expected },
      configure: { action: "configure", id: "wissen", label: "<project name>", author: "<author>", editor: "both", wikis: [{ id: "wiki", label: "<wiki name>", path: "Wiki", purpose: "<user purpose>", audience: ["<reader>"] }], sources: [{ id: "quellen", label: "<source name>", path: "Quellen", wikis: ["wiki"] }] }
    }
  };
}
function validateSetupAnswers(answers) {
  const fail = (field, message, expected) => {
    throw new WikiError("setup", message, { field, expected, next_request: { action: "inspect" }, setup_contract: setupContract() });
  };
  const walk = (value, s, field) => {
    const type = value === null ? "null" : Array.isArray(value) ? "array" : typeof value;
    if (![s.type].flat().includes(type)) fail(field, "Invalid setup value at " + field + ".", s.type);
    if (s.enum && !s.enum.includes(value)) fail(field, "Unsupported setup value at " + field + ".", s.enum);
    if (type === "object") for (const [key, item] of Object.entries(value)) {
      if (!Object.hasOwn(s.properties, key)) fail(field + "." + key, "Unknown setup field " + field + "." + key + ". Use the published setup contract.", Object.keys(s.properties));
      walk(item, s.properties[key], field + "." + key);
    }
    if (type === "array") value.forEach((item, i2) => walk(item, s.items, field + "[" + i2 + "]"));
    if (s === location && typeof value === "string" && (/^[\/\\]|^[a-z]:/i.test(value) || value.split(/[\/\\]/).includes(".."))) fail(field, "Use a project-relative path or null with a device binding.", location.description);
  };
  walk(answers, schema, "answers");
}
var text, flag, texts, location, object, wiki, source, schema;
var init_setup_contract = __esm({
  "runtime/setup-contract.mjs"() {
    init_errors();
    text = { type: "string" };
    flag = { type: "boolean" };
    texts = { type: "array", items: text };
    location = { type: ["string", "null"], description: "Project-relative directory, or null with an existing device binding. Never an absolute OS path." };
    object = (properties) => ({ type: "object", additionalProperties: false, properties });
    wiki = object({ id: text, label: text, path: location, workPath: location, purpose: text, audience: texts, writable: flag, shared: flag, icon: text, default_source: { type: ["string", "null"] } });
    source = object({ id: text, label: text, path: location, wikis: texts, writable: flag, icon: text });
    schema = object({ id: text, label: text, author: text, editor: { type: "string", enum: ["builtin", "obsidian", "both"] }, language: { type: "string", enum: ["de", "en"] }, wikis: { type: "array", items: wiki }, sources: { type: "array", items: source } });
  }
});

// runtime/project.mjs
var project_exports = {};
__export(project_exports, {
  WORKSPACE_STATE: () => WORKSPACE_STATE,
  configure: () => configure,
  context: () => context,
  detach: () => detach,
  ensureInstance: () => ensureInstance,
  folderStore: () => folderStore,
  inspect: () => inspect,
  installEditor: () => installEditor,
  load: () => load,
  saveSettings: () => saveSettings,
  selectWorkspace: () => selectWorkspace,
  setupDraft: () => setupDraft,
  syncIdentity: () => syncIdentity,
  validateLocations: () => validateLocations,
  workspaceState: () => workspaceState
});
function validateLocations(root, project, bindings) {
  const clean = (value) => typeof value === "string" ? value.replace(/\\/g, "/").replace(/\/+$/, "") : null;
  const location3 = (f) => f.path === null ? clean(bindings[f.id]?.root) : clean(f.path === "." ? root.root : [root.root, f.path].filter(Boolean).join("/"));
  const overlaps = (a, b) => a !== null && b !== null && (a === b || a === "" || b === "" || a.startsWith(b + "/") || b.startsWith(a + "/"));
  for (const c of project.connections) {
    const folder = (id) => project.folders.find((f) => f.id === id), wiki2 = folder(c.wiki), works = c.works.map(folder);
    for (const work of works) requireThat(!overlaps(location3(wiki2), location3(work)), "binding_overlap", "Wiki storage and working copy must be separate directories.", { wiki: wiki2.id, work: work.id });
    for (const source2 of c.sources.map(folder)) for (const target of [wiki2, ...works]) requireThat(!overlaps(location3(source2), location3(target)), "binding_overlap", "The source binding points inside a wiki/working copy or contains it. Bind the actual original source directory.", { source: source2.id, target: target.id });
  }
}
async function workspaceState(root) {
  const { project } = await load(root), marker = await root.read(INSTANCE), f = await root.read(WORKSPACE_STATE);
  let data = null;
  try {
    data = f ? JSON.parse(f.text) : null;
  } catch {
  }
  return data?.format === "llmwiki-workspace-state/1" && data.project === project.id && data.instance === JSON.parse(marker?.text ?? "null")?.instance && project.connections.some((c) => c.id === data.connection && c.works.includes(data.work)) ? data : null;
}
async function selectWorkspace(root, connection, work) {
  const { project } = await load(root), c = project.connections.find((c2) => c2.id === connection);
  requireThat(c, "connection", "Select a connected wiki.");
  work ??= c.works.length === 1 ? c.works[0] : null;
  requireThat(c.works.includes(work), "work", "Choose an assigned working copy.");
  const marker = await ensureInstance(root, project), seen = await root.read(WORKSPACE_STATE), data = { format: "llmwiki-workspace-state/1", project: project.id, instance: marker.instance, connection, work };
  await root.write(WORKSPACE_STATE, JSON.stringify(data, null, 2) + "\n", { expected: seen?.sha256 ?? null });
  return data;
}
async function legacyBrowserGrant(root, project) {
  const settings = await root.read(NAME);
  requireThat(settings && JSON.stringify(projectSettings.validate(JSON.parse(settings.text))) === JSON.stringify(project), "stale", "Project settings changed before browser recovery.");
  return { format: "llmwiki-browser-migration/1", project: project.id, settings_sha256: settings.sha256, folders: project.folders.map(({ id, kind, path: path7 }) => ({ id, kind, path: path7 })) };
}
async function ensureInstance(root, project, { instance = null, origin = instance ? "setup" : "upgrade" } = {}) {
  const seen = await root.read(INSTANCE);
  if (seen && !instance) {
    const previous = JSON.parse(seen.text);
    requireThat(previous.format === "llmwiki-project-instance/1" && typeof previous.instance === "string" && /^[a-f0-9-]{36}$/i.test(previous.instance), "instance", "The project instance marker is invalid.");
    if (previous.project === project.id) return previous;
  }
  let legacy = false;
  if (origin === "upgrade" && !seen) {
    const starter = await root.read("LLM-Wiki.html");
    requireThat(!isolatedWorkingCopy(project) && !/<meta\s+name="llmwiki-entry-instance"(?:\s|>)/.test(starter?.text ?? ""), "instance", "The project instance marker is missing. Restore its identity before updating this existing starter.");
    const version2 = editorVersion(starter?.text), parts = version2?.match(/^(\d+)\.(\d+)\.(\d+)$/)?.slice(1).map(Number);
    legacy = Boolean(starter) && (!version2 || parts && parts[0] === 0 && (parts[1] < 4 || parts[1] === 4 && parts[2] < 2));
    requireThat(!starter || legacy, "instance", "The existing starter has no verifiable legacy identity. Restore the project instance marker before updating it.");
  }
  const data = { format: "llmwiki-project-instance/1", project: project.id, instance: instance ?? root.services.uuid(), origin };
  if (legacy) data.legacy_browser = await legacyBrowserGrant(root, project);
  await root.write(INSTANCE, JSON.stringify(data, null, 2) + "\n", { expected: seen?.sha256 ?? null });
  return data;
}
async function recoverBrowser(root, project, recovery) {
  const settings = await root.read(NAME), seen = await root.read(INSTANCE);
  requireThat(recovery && typeof recovery === "object" && !Array.isArray(recovery) && settings?.sha256 === recovery.expected, "stale", "Project settings changed; browser recovery requires the exact read baseline.");
  const marker = seen ? JSON.parse(seen.text) : null;
  requireThat(marker?.format === "llmwiki-project-instance/1" && marker.project === project.id && marker.instance === recovery.instance, "instance", "Read the current project instance before recovering browser connections.");
  requireThat((marker.origin === void 0 || marker.origin === "upgrade") && !isolatedWorkingCopy(project), "reset", "A new or fresh setup must not inherit connections from an earlier project instance.");
  const grant = await legacyBrowserGrant(root, project);
  if (JSON.stringify(marker.legacy_browser) !== JSON.stringify(grant)) await root.write(INSTANCE, JSON.stringify({ ...marker, legacy_browser: grant }, null, 2) + "\n", { expected: seen.sha256 });
}
function embeddedJSON(html, id) {
  try {
    const text2 = html?.match(new RegExp('<script type="application/json" id="' + id + '">([\\s\\S]*?)</script>'))?.[1];
    return text2 ? JSON.parse(text2) : null;
  } catch {
    return null;
  }
}
async function inspect(root, { editorHTML = null, bindings = {} } = {}) {
  const file = await root.read(NAME);
  if (file) {
    const project = projectSettings.validate(JSON.parse(file.text)), issues = [];
    for (const c of project.connections) for (const id of c.works) {
      const work = project.folders.find((f) => f.id === id);
      try {
        const store = await folderStore(root, work, { bindings, writable: false }), bundle = await store.read("wiki/bundle.md"), purpose = bundle ? sectionText(parseDocument(bundle.text).body, ["Zweck", "Purpose"]) : "";
        if (!purpose || /Noch nicht geschrieben|Not yet written/i.test(purpose)) issues.push({ connection: c.id, work: id, code: bundle ? "bundle_purpose_missing" : "working_bundle_missing" });
      } catch (error) {
        issues.push({ connection: c.id, work: id, code: "bundle_unreadable", message: error.message });
      }
    }
    const locations = project.folders.map((f) => ({ id: f.id, kind: f.kind, location: f.path === null ? bindings[f.id]?.root ?? null : f.path === "." ? root.root : [root.root, f.path].join("/"), external: f.path === null, binding_available: f.path !== null || Boolean(bindings[f.id]), write_configured: f.writable }));
    const entry = await root.read("LLM-Wiki.html"), version2 = editorVersion(entry?.text), current_version = editorVersion(editorHTML);
    const bindingLocations = Object.fromEntries(locations.filter((f) => f.external && f.location !== null).map((f) => [f.id, f.location]));
    const location3 = entryLocation(root), bindingChanged = JSON.stringify(embeddedJSON(entry?.text, "llmwiki-editor-design")) !== JSON.stringify(embeddedJSON(editorHTML, "llmwiki-editor-design")) || JSON.stringify(embeddedJSON(entry?.text, "llmwiki-entry-binding-locations")) !== JSON.stringify(bindingLocations) || JSON.stringify(embeddedJSON(entry?.text, "llmwiki-entry-location")) !== JSON.stringify(location3) || JSON.stringify(embeddedJSON(entry?.text, "llmwiki-entry-settings")) !== JSON.stringify(project);
    const editor = { exists: Boolean(entry), version: version2, current_version, update_required: Boolean(editorHTML) && (!entry || version2 !== current_version || bindingChanged), ...location3 };
    return { next: issues.length ? "repair_setup" : "choose_task", project, sha256: file.sha256, issues, locations, editor };
  }
  const draft = await root.read(".llmwiki/setup.json"), starter = await root.read("LLM-Wiki.html");
  return { project_root: entryLocation(root).project_root, project_hint: embeddedJSON(starter?.text, "llmwiki-entry-location")?.project_root ?? null, next: "setup", draft: draft ? JSON.parse(draft.text).answers : {}, draft_sha256: draft?.sha256 ?? null, folders: (await root.list("", { recursive: false })).filter((e) => e.kind === "directory").map((e) => e.path), questions: ["editor", "wikis", "sources", "author"], setup_contract: setupContract(draft?.sha256 ?? null) };
}
async function setupDraft(root, answers, expected) {
  validateSetupAnswers(answers);
  const file = await root.read(".llmwiki/setup.json");
  requireThat((file?.sha256 ?? null) === expected, "stale", "Setup answers changed. Read inspect and merge the saved answers before retrying.", { draft_sha256: file?.sha256 ?? null, next_request: { action: "inspect" } });
  const combined = { ...file ? JSON.parse(file.text).answers : {}, ...answers };
  const saved = await root.write(".llmwiki/setup.json", JSON.stringify({ format: "llmwiki-setup/1", answers: combined }, null, 2) + "\n", { expected });
  return { answers: combined, sha256: saved.sha256 };
}
async function load(root) {
  const file = await root.read(NAME);
  requireThat(file, "setup", "Start guided setup before selecting a task.");
  return { project: projectSettings.validate(JSON.parse(file.text)), file };
}
async function saveSettings(root, data, expected, { editorHTML = null, bindings = {} } = {}) {
  projectSettings.validate(data);
  validateLocations(root, data, bindings);
  const seen = await root.read(NAME);
  requireThat((seen?.sha256 ?? null) === expected, "stale", "Project settings changed.");
  await root.write(NAME, JSON.stringify(data, null, 2) + "\n", { expected });
  const verified = await load(root);
  if (editorHTML) await installEditor(root, data, editorHTML, { bindings });
  return { project: verified.project, sha256: verified.file.sha256, settings_verified: true };
}
async function folderStore(root, folder, { bindings = {}, writable = folder.writable } = {}) {
  if (folder.path === null) {
    requireThat(bindings[folder.id], "binding", "Connect this device to the selected folder.", { folder: folder.id });
    return bindings[folder.id].substore("", { writable: writable && folder.kind !== "source" });
  }
  return root.substore(folder.path, { writable: writable && folder.kind !== "source" });
}
async function configure(root, request, { bindings = {}, editorHTML = null } = {}) {
  nonempty(request.author, "author");
  requireThat(Array.isArray(request.wikis) && request.wikis.length, "wiki", "Select at least one wiki.");
  const existing = await root.read(NAME);
  requireThat((existing?.sha256 ?? null) === (request.expected ?? null), "stale", "Project settings changed; reload their exact baseline.");
  requireThat(request.fresh === void 0 || typeof request.fresh === "boolean", "setup", "fresh must be a boolean.");
  const previous = existing ? projectSettings.validate(JSON.parse(existing.text)) : null;
  const newInstance = !existing || request.fresh ? root.services.uuid() : null;
  const project = { format: "llmwiki-project/1", id: request.id, label: request.label, editor: request.editor ?? "builtin", folders: [], connections: [] };
  for (const w of request.wikis) {
    nonempty(w.purpose, "purpose");
    requireThat(Array.isArray(w.audience) && w.audience.length, "audience", "Name the reader circle.");
    const previousWork = previous?.folders.find((f) => f.id === previous.connections.find((c) => c.wiki === w.id)?.works[0]);
    const workId = previousWork?.id ?? "work-" + w.id, workPath = Object.hasOwn(w, "workPath") ? w.workPath : request.fresh ? ".llmwiki/working/" + newInstance + "/" + w.id : previousWork ? previousWork.path : ".llmwiki/working/" + w.id;
    requireThat(!previousWork || request.fresh || workPath === previousWork.path, "relocation", "Use workspace.relocate to preserve an existing working copy when changing its directory.");
    requireThat(w.path !== "." && (w.path === null || w.path !== workPath), "wiki", "Choose a separate wiki directory within or connected to the project.");
    project.folders.push(
      { id: w.id, label: w.label, kind: "wiki", ...w.icon ? { icon: w.icon } : {}, path: w.path, writable: w.writable !== false, readers: w.audience, writers: w.writable === false ? [] : [request.author] },
      { id: workId, label: w.label, kind: "work", path: workPath, writable: true, readers: [request.author], writers: [request.author] }
    );
    const sources = (request.sources ?? []).filter((s) => s.wikis.includes(w.id)).map((s) => s.id);
    project.connections.push({ id: w.id, label: w.label, wiki: w.id, works: [workId], sources, default_source: Object.hasOwn(w, "default_source") ? w.default_source : sources.length === 1 ? sources[0] : null, mode: w.shared ? "gemeinsam" : "eigen" });
  }
  for (const s of request.sources ?? []) project.folders.push({ id: s.id, label: s.label, kind: "source", ...s.icon ? { icon: s.icon } : {}, path: s.path, writable: s.writable === true, readers: [request.author], writers: s.writable === true ? [request.author] : [] });
  projectSettings.validate(project);
  validateLocations(root, project, bindings);
  for (const f of project.folders) {
    if (f.path === null) requireThat(bindings[f.id], "binding", "External folder permission is missing.", { folder: f.id });
    else if (f.kind === "source") await root.substore(f.path, { writable: false });
  }
  if (request.fresh) for (const w of request.wikis.filter((w2) => Object.hasOwn(w2, "workPath"))) {
    const work = project.folders.find((f) => f.id === project.connections.find((c) => c.wiki === w.id).works[0]), store = await folderStore(root, work, { bindings });
    let entries;
    try {
      entries = await store.list("", { hidden: true });
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      entries = [];
    }
    requireThat(!entries.length, "reset", "A fresh setup needs an empty explicitly selected working directory; existing content is preserved.", { work: work.id });
  }
  for (const w of request.wikis) {
    const wiki2 = project.folders.find((f) => f.id === w.id), work = project.folders.find((f) => f.id === project.connections.find((c) => c.wiki === w.id).works[0]);
    if (wiki2.path !== null) await root.mkdir(wiki2.path);
    if (work.path !== null) await root.mkdir(work.path);
    const remote = await folderStore(root, wiki2, { bindings }), local2 = await folderStore(root, work, { bindings });
    const options = { work: handle(local2), remote: handle(remote), identity: syncIdentity(project, wiki2, work) };
    const received = await sync.run({ ...options, canPublish: false });
    requireThat(!received.conflicts.length, "conflict", "Existing working content differs from the selected wiki; resolve it before reconfiguration.", received);
    if (wiki2.writable) {
      await createBundle(local2, { title: w.label, purpose: w.purpose, audience: w.audience, author: request.author, language: request.language ?? "de" });
      const published = await sync.run({ ...options, canPublish: true });
      requireThat(!published.conflicts.length && !published.pending, "sync", "Setup content could not be synchronized.", published);
    } else requireThat(await local2.read("wiki/bundle.md"), "bundle", "Read-only wiki has no bundle.");
  }
  await root.write(NAME, JSON.stringify(project, null, 2) + "\n", { expected: existing?.sha256 ?? null });
  const verified = await load(root);
  requireThat(JSON.stringify(verified.project) === JSON.stringify(project), "settings", "Settings readback failed.");
  await ensureInstance(root, project, { instance: newInstance, origin: request.fresh ? "reset" : existing ? "upgrade" : "setup" });
  if (editorHTML) await installEditor(root, project, editorHTML, { bindings });
  return { project, sha256: verified.file.sha256, entry: editorHTML ? "LLM-Wiki.html" : null };
}
function syncIdentity(project, wiki2, work) {
  return JSON.stringify([project.id, wiki2.id, wiki2.path, work.id, work.path]);
}
async function context(root, connection, { bindings = {}, work: workID } = {}) {
  const { project } = await load(root), active = await workspaceState(root);
  connection ??= active?.connection ?? (project.connections.length === 1 ? project.connections[0].id : null);
  const c = project.connections.find((c2) => c2.id === connection);
  requireThat(c, "connection", "Select a connected wiki.");
  const folder = (id) => project.folders.find((f) => f.id === id), wiki2 = folder(c.wiki), work = folder(workID ?? (active?.connection === c.id ? active.work : null) ?? (c.works.length === 1 ? c.works[0] : null));
  validateLocations(root, { ...project, connections: [c] }, bindings);
  requireThat(work && c.works.includes(work.id), "work", "Working folder is not assigned to this wiki.");
  const sources = [];
  for (const id of c.sources) {
    const f = folder(id);
    try {
      sources.push({ ...f, store: await folderStore(root, f, { bindings, writable: false }) });
    } catch (error) {
      sources.push({ ...f, store: null, error: { code: error.code, message: error.message } });
    }
  }
  return { project, connection: c, wiki: wiki2, workFolder: work, work: await folderStore(root, work, { bindings }), remote: await folderStore(root, wiki2, { bindings }), sources, identity: syncIdentity(project, wiki2, work), canPublish: wiki2.writable };
}
async function detach(root, id, expected, { editorHTML = null, bindings = {} } = {}) {
  const { project, file } = await load(root);
  requireThat(file.sha256 === expected, "stale", "Project settings changed.");
  requireThat(project.folders.some((f) => f.id === id && f.kind !== "work"), "folder", "Select a wiki or source folder.");
  project.folders = project.folders.filter((f) => f.id !== id);
  project.connections = project.connections.filter((c) => c.wiki !== id).map((c) => ({ ...c, sources: c.sources.filter((s) => s !== id), ...c.default_source === id ? { default_source: null } : {} }));
  const used = new Set(project.connections.flatMap((c) => c.works));
  project.folders = project.folders.filter((f) => f.kind !== "work" || used.has(f.id));
  projectSettings.validate(project);
  await root.write(NAME, JSON.stringify(project, null, 2) + "\n", { expected });
  if (editorHTML) await installEditor(root, project, editorHTML, { bindings });
  return { detached: id, deleted: 0, project };
}
async function installEditor(root, project, html, { recover_browser = null, bindings = {} } = {}) {
  const path7 = "LLM-Wiki.html", seen = await root.read(path7), banner = "<!-- Diese Seite wird erzeugt, aus app/ gebaut und nie von Hand ge\xE4ndert. -->";
  requireThat(!seen || seen.text.slice(0, 1024).includes(banner), "entry", "The existing LLM-Wiki.html is not a generated editor.");
  requireThat(html.includes(banner) && html.includes("<head>"), "entry", "Editor template is incomplete.");
  if (recover_browser !== null) await recoverBrowser(root, project, recover_browser);
  const instance = await ensureInstance(root, project);
  const escapeJSON = (value) => JSON.stringify(value).replace(/[&<>]/g, (c) => "\\u" + c.charCodeAt(0).toString(16).padStart(4, "0"));
  const location3 = entryLocation(root);
  const inventory2 = {};
  for (const f of project.folders.filter((f2) => f2.kind !== "wiki")) try {
    const store = await folderStore(root, f, { bindings, writable: false });
    inventory2[f.id] = (await store.list("")).filter((e) => e.kind === "file" && !e.path.split("/").some((p) => p.startsWith(".")) && (f.kind === "source" || /\.md$/i.test(e.path) && !e.path.startsWith("schema/"))).map((e) => ({ name: e.path }));
  } catch {
  }
  const inventoryRevision = await root.services.hash(JSON.stringify(inventory2));
  const bindingNames = Object.fromEntries(project.folders.filter((f) => f.path === null && typeof bindings[f.id]?.root === "string").map((f) => [f.id, bindings[f.id].root.replace(/\\/g, "/").split("/").filter(Boolean).at(-1)]));
  const bindingLocations = Object.fromEntries(project.folders.filter((f) => f.path === null && typeof bindings[f.id]?.root === "string").map((f) => [f.id, bindings[f.id].root]));
  const marker = '<meta name="llmwiki-entry-project" content="' + project.id + '">\n<meta name="llmwiki-entry-instance" content="' + instance.instance + '">\n<script type="application/json" id="llmwiki-entry-settings">' + escapeJSON(project) + '</script>\n<script type="application/json" id="llmwiki-entry-inventory" data-revision="' + inventoryRevision + '">' + escapeJSON(inventory2) + '</script>\n<script type="application/json" id="llmwiki-entry-location">' + escapeJSON(location3) + "</script>";
  const text2 = html.replace("<head>", "<head>\n" + marker + '\n<script type="application/json" id="llmwiki-entry-binding-names">' + escapeJSON(bindingNames) + '</script>\n<script type="application/json" id="llmwiki-entry-binding-locations">' + escapeJSON(bindingLocations) + "</script>");
  if (text2 === seen?.text) return { page: path7, unchanged: true, ...location3 };
  await root.write(path7, text2, { expected: seen?.sha256 ?? null });
  return { page: path7, ...location3 };
}
var NAME, INSTANCE, WORKSPACE_STATE, entryLocation, isolatedWorkingCopy, editorVersion;
var init_project2 = __esm({
  "runtime/project.mjs"() {
    init_review();
    init_content();
    init_errors();
    init_document();
    init_setup_contract();
    NAME = "llmwiki.project.json";
    INSTANCE = ".llmwiki/project-instance.json";
    WORKSPACE_STATE = ".llmwiki/workspace-state.json";
    entryLocation = (root) => root.editorLocation?.() ?? { project_root: null, entry_path: "LLM-Wiki.html", entry_uri: null };
    isolatedWorkingCopy = (project) => project.folders.some((f) => f.kind === "work" && /^\.llmwiki\/working\/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\//i.test(f.path ?? ""));
    editorVersion = (html) => html?.match(/<meta name="llmwiki-editor-version" content="([^"]+)">/)?.[1] ?? null;
  }
});

// runtime/adapters/shadow-node.mjs
var shadow_node_exports = {};
__export(shadow_node_exports, {
  openShadowDatabase: () => openShadowDatabase
});
import fs2 from "node:fs/promises";
import path2 from "node:path";
import os2 from "node:os";
import { createHash as createHash2 } from "node:crypto";
import { DatabaseSync as DatabaseSync2 } from "node:sqlite";
async function openShadowDatabase(root, project, { readOnly = false, cacheRoot, maxBytes = 128 * 1024 * 1024, rebuild = false } = {}) {
  requireThat(!readOnly || !rebuild, "read-only", "A read-only query cannot rebuild the database.");
  requireThat(Number.isSafeInteger(maxBytes) && maxBytes >= 1024 && maxBytes <= 1024 * 1024 * 1024, "shadow_budget", "Choose a cache budget between 1 KiB and 1 GiB.");
  const canonical = await fs2.realpath(root);
  const base = path2.resolve(cacheRoot ?? path2.join(os2.homedir(), process.platform === "darwin" ? "Library/Caches" : ".cache", "llmwiki", "shadow"));
  requireThat(!beneath2(canonical, base), "shadow_location", "The local database must remain outside the project.");
  const name = digest(JSON.stringify([canonical, project]));
  let dir = path2.join(base, name), file = path2.join(dir, "shadow.sqlite");
  if (readOnly) {
    try {
      await fs2.lstat(file);
    } catch (e) {
      if (e.code === "ENOENT") return null;
      throw e;
    }
  } else await fs2.mkdir(dir, { recursive: true, mode: 448 });
  const realBase = await fs2.realpath(base), real = await fs2.realpath(dir);
  requireThat(real === path2.join(realBase, name) && !beneath2(canonical, real), "shadow_location", "The database cache must be outside the project without symbolic links.");
  dir = real;
  file = path2.join(dir, "shadow.sqlite");
  let stat;
  try {
    stat = await fs2.lstat(file);
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
  requireThat(!stat || stat.isFile() && !stat.isSymbolicLink(), "shadow_location", "The database must be a regular private file.");
  if (!readOnly && !stat) {
    const handle2 = await fs2.open(file, "wx", 384);
    await handle2.close();
  }
  const db = new DatabaseSync2(file, { readOnly, allowExtension: false });
  try {
    db.exec("PRAGMA busy_timeout=1500; PRAGMA trusted_schema=OFF;");
    if (!readOnly) {
      await fs2.chmod(file, 384);
      db.exec(`
   PRAGMA journal_mode=DELETE;
   PRAGMA secure_delete=ON;
   CREATE TABLE IF NOT EXISTS state (singleton INTEGER PRIMARY KEY CHECK(singleton=1), version INTEGER NOT NULL, generation INTEGER NOT NULL);
   INSERT OR IGNORE INTO state VALUES(1,1,0);
   CREATE TABLE IF NOT EXISTS documents (wiki TEXT NOT NULL, path TEXT NOT NULL, id TEXT NOT NULL, revision TEXT NOT NULL, data TEXT NOT NULL, PRIMARY KEY(wiki,path));
   CREATE INDEX IF NOT EXISTS document_ids ON documents(wiki,id);
  `);
    }
    requireThat(db.prepare("SELECT version FROM state WHERE singleton=1").get()?.version === 1, "shadow_version", "Unsupported shadow database version.");
    requireThat(Object.values(db.prepare("PRAGMA quick_check").get())[0] === "ok", "shadow_corrupt", "The shadow database is corrupt; rebuild the derived cache.");
    if (!readOnly) {
      const pageSize = db.prepare("PRAGMA page_size").get().page_size;
      db.exec("PRAGMA max_page_count=" + Math.ceil((maxBytes * 1.15 + 65536) / pageSize));
    }
  } catch (error) {
    db.close();
    if (rebuild && (error.code === "shadow_corrupt" || [11, 26].includes(error.errcode))) {
      for (const suffix of ["-journal", "-wal", "-shm"]) {
        let present2 = false;
        try {
          await fs2.lstat(file + suffix);
          present2 = true;
        } catch (e) {
          if (e.code !== "ENOENT") throw e;
        }
        requireThat(!present2, "shadow_busy", "Close active database users before recovering this cache.");
      }
      await fs2.rename(file, file + ".corrupt");
      return openShadowDatabase(root, project, { readOnly: false, cacheRoot, maxBytes });
    }
    throw error;
  }
  return {
    path: file,
    readOnly,
    maxBytes,
    generation: () => db.prepare("SELECT generation FROM state WHERE singleton=1").get().generation,
    documents: (wiki2) => db.prepare("SELECT * FROM documents WHERE wiki=? ORDER BY path").all(wiki2).map((row) => ({ ...row, data: JSON.parse(row.data) })),
    commit(updates, { expected, remove = [], keepWikis = null } = {}) {
      requireThat(!readOnly, "read-only", "The shadow database is read-only.");
      db.exec("BEGIN IMMEDIATE");
      try {
        requireThat(db.prepare("SELECT generation FROM state WHERE singleton=1").get().generation === expected, "shadow_stale", "The shadow database changed during this update. Retry the maintenance action.");
        for (const wiki2 of keepWikis === null ? [] : db.prepare("SELECT DISTINCT wiki FROM documents").all().map((r) => r.wiki).filter((w) => !keepWikis.includes(w))) db.prepare("DELETE FROM documents WHERE wiki=?").run(wiki2);
        for (const r of remove) db.prepare("DELETE FROM documents WHERE wiki=? AND path=?").run(r.wiki, r.path);
        const put = db.prepare("INSERT INTO documents(wiki,path,id,revision,data) VALUES(?,?,?,?,?) ON CONFLICT(wiki,path) DO UPDATE SET id=excluded.id,revision=excluded.revision,data=excluded.data");
        for (const row of updates) put.run(row.wiki, row.path, row.id, row.revision, JSON.stringify(row.data));
        const size = db.prepare("SELECT COALESCE(SUM(length(CAST(data AS BLOB))),0) AS bytes FROM documents").get().bytes;
        requireThat(size <= maxBytes, "shadow_budget", "The structural cache exceeds its configured byte budget.", { bytes: size, maxBytes });
        db.prepare("UPDATE state SET generation=generation+1 WHERE singleton=1").run();
        db.exec("COMMIT");
        return { bytes: size, generation: expected + 1 };
      } catch (error) {
        db.exec("ROLLBACK");
        throw error;
      }
    },
    close: () => db.close()
  };
}
var digest, beneath2;
var init_shadow_node = __esm({
  "runtime/adapters/shadow-node.mjs"() {
    init_errors();
    digest = (s) => createHash2("sha256").update(s).digest("hex");
    beneath2 = (root, file) => file === root || file.startsWith(root + path2.sep);
  }
});

// runtime/node-cli.mjs
import fs6 from "node:fs/promises";

// runtime/editor-launch.mjs
init_project2();
import fs5 from "node:fs/promises";
import path6 from "node:path";
import net from "node:net";

// runtime/node-input.mjs
import path4 from "node:path";

// runtime/adapters/node.mjs
import fs3 from "node:fs/promises";
import { constants } from "node:fs";
import path3 from "node:path";
import { pathToFileURL } from "node:url";
import { createHash as createHash3, randomBytes, randomUUID as randomUUID2 } from "node:crypto";

// runtime/adapters/node-locks.mjs
init_errors();
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { randomUUID, createHash } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
var databases = /* @__PURE__ */ new Map();
var beneath = (root, p) => p === root || p.startsWith(root + path.sep);
function openRegistry(root, target) {
  const shard = createHash("sha256").update(target).digest("hex")[0];
  let entry = databases.get(shard);
  const dir = path.join(os.homedir(), process.platform === "darwin" ? "Library/Caches" : ".cache", "llmwiki", "writers");
  requireThat(!beneath(root, dir), "lock_location", "Writer ownership must be stored outside the project.");
  if (!entry) {
    fs.mkdirSync(dir, { recursive: true, mode: 448 });
    const real = fs.realpathSync(dir);
    requireThat(!fs.lstatSync(dir).isSymbolicLink() && !beneath(root, real), "lock_location", "Writer registry must be a private directory outside the project.");
    fs.chmodSync(dir, 448);
    const registry = path.join(real, "leases-" + shard + ".sqlite");
    let stat;
    try {
      stat = fs.lstatSync(registry);
    } catch (e) {
      if (e.code !== "ENOENT") throw e;
    }
    requireThat(!stat || stat.isFile() && !stat.isSymbolicLink(), "lock_location", "Writer registry must be a regular private file.");
    if (!stat) try {
      fs.closeSync(fs.openSync(registry, "wx", 384));
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
    }
    fs.chmodSync(registry, 384);
    const db = new DatabaseSync(registry, { allowExtension: false });
    try {
      db.exec("PRAGMA busy_timeout=1500; PRAGMA trusted_schema=OFF; PRAGMA journal_mode=DELETE; CREATE TABLE IF NOT EXISTS leases (file TEXT PRIMARY KEY, token TEXT NOT NULL, pid INTEGER NOT NULL, lock TEXT NOT NULL, temporary TEXT NOT NULL);");
      entry = { db, registry };
      databases.set(shard, entry);
    } catch (e) {
      db.close();
      throw e;
    }
  }
  requireThat(!beneath(root, entry.registry), "lock_location", "Writer ownership must remain outside the project.");
  return entry.db;
}
function guarded(db, run) {
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = run();
    db.exec("COMMIT");
    return result;
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}
function busy(clean, reason) {
  return new WikiError("busy", reason === "active" ? "A local writer is saving this file. Wait for it to finish, then retry." : "The retained lock has unknown or conflicting ownership. Close other writers and inspect the lock before any manual recovery.", { path: clean, reason });
}
function readLock(file) {
  let fd2;
  try {
    fd2 = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
    const stat = fs.fstatSync(fd2);
    requireThat(stat.isFile() && stat.size <= 1024, "busy", "The retained lock is not a valid writer record.");
    const raw = fs.readFileSync(fd2, "utf8");
    try {
      return { raw, record: JSON.parse(raw) };
    } catch {
      return { raw, record: null };
    }
  } catch (e) {
    if (e.code === "ENOENT") return null;
    throw e;
  } finally {
    if (fd2 !== void 0) fs.closeSync(fd2);
  }
}
function dead(pid) {
  if (!Number.isSafeInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return false;
  } catch (e) {
    return e.code === "ESRCH";
  }
}
function owned(record, token) {
  return record?.format === "llmwiki-lock/2" && record.token === token;
}
function removeTemporary(file) {
  try {
    const stat = fs.lstatSync(file);
    requireThat(stat.isFile() && !stat.isSymbolicLink(), "busy", "A retained temporary path changed type; inspect it before recovery.");
    fs.unlinkSync(file);
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
}
function acquireWriter({ root, target, lockPath, clean }) {
  const db = openRegistry(root, target), token = randomUUID(), temporary = target + ".llmwiki-" + token + ".tmp";
  guarded(db, () => {
    const prior = db.prepare("SELECT * FROM leases WHERE file=?").get(target);
    if (prior) {
      if (!dead(prior.pid)) throw busy(clean, "active");
      const lock = readLock(prior.lock);
      if (lock && !owned(lock.record, prior.token)) throw busy(clean, "unknown");
      if (lock) fs.unlinkSync(prior.lock);
      removeTemporary(prior.temporary);
      db.prepare("DELETE FROM leases WHERE file=? AND token=?").run(target, prior.token);
    }
    if (readLock(lockPath)) throw busy(clean, "unknown");
    db.prepare("INSERT INTO leases VALUES(?,?,?,?,?)").run(target, token, process.pid, lockPath, temporary);
  });
  try {
    const fd2 = fs.openSync(lockPath, "wx", 384);
    try {
      fs.writeFileSync(fd2, JSON.stringify({ format: "llmwiki-lock/2", token }));
      fs.fsyncSync(fd2);
    } finally {
      fs.closeSync(fd2);
    }
  } catch (e) {
    guarded(db, () => db.prepare("DELETE FROM leases WHERE file=? AND token=?").run(target, token));
    if (e.code === "EEXIST") throw busy(clean, "unknown");
    throw e;
  }
  return { temporary, release() {
    guarded(db, () => {
      const row = db.prepare("SELECT token FROM leases WHERE file=?").get(target), lock = readLock(lockPath);
      if (row?.token !== token || lock && !owned(lock.record, token)) throw busy(clean, "unknown");
      removeTemporary(temporary);
      if (lock) fs.unlinkSync(lockPath);
      db.prepare("DELETE FROM leases WHERE file=? AND token=?").run(target, token);
    });
  } };
}

// runtime/adapters/node.mjs
init_errors();
var nodeServices = {
  hash: async (value) => createHash3("sha256").update(value).digest("hex"),
  random: (size) => new Uint8Array(randomBytes(size)),
  uuid: () => randomUUID2(),
  now: () => (/* @__PURE__ */ new Date()).toISOString()
};
var NodeStore = class _NodeStore {
  constructor(root, { writable = true, maxBytes = 128 * 1024 * 1024, shadowCacheRoot } = {}) {
    requireThat(typeof root === "string" && path3.isAbsolute(root), "root", "Select an absolute project directory.");
    this.root = path3.resolve(root);
    this.writable = writable;
    this.maxBytes = maxBytes;
    this.shadowCacheRoot = shadowCacheRoot;
    this.services = nodeServices;
    this.capabilities = { binary: true, exclusiveCreate: true, cooperativeLocks: true, externalWriterCAS: false };
  }
  async shadowDatabase(project, options = {}) {
    const { openShadowDatabase: openShadowDatabase2 } = await Promise.resolve().then(() => (init_shadow_node(), shadow_node_exports));
    return openShadowDatabase2(this.root, project, { cacheRoot: this.shadowCacheRoot, ...options, readOnly: this.writable === false || options.readOnly === true });
  }
  async fileURL(relative) {
    return pathToFileURL(await this.location(relative)).href;
  }
  editorLocation() {
    const entry_path = path3.join(this.root, "LLM-Wiki.html");
    return { project_root: this.root, entry_path, entry_uri: pathToFileURL(entry_path).href };
  }
  async location(relative = "", { createParent = false } = {}) {
    const clean = relativePath(relative, { root: true });
    const rootStat = await fs3.lstat(this.root);
    requireThat(rootStat.isDirectory() && !rootStat.isSymbolicLink(), "root", "Root must be a directory, not a symbolic link.");
    const parts = clean ? clean.split("/") : [];
    let current2 = this.root;
    for (let i2 = 0; i2 < parts.length; i2++) {
      current2 = path3.join(current2, parts[i2]);
      let stat;
      try {
        stat = await fs3.lstat(current2);
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
        if (createParent && i2 < parts.length - 1) {
          try {
            await fs3.mkdir(current2);
          } catch (e) {
            if (e.code !== "EEXIST") throw e;
          }
          stat = await fs3.lstat(current2);
        } else continue;
      }
      requireThat(!stat.isSymbolicLink(), "symlink", "Symbolic links are not traversed.", { path: clean });
      if (i2 < parts.length - 1) requireThat(stat.isDirectory(), "path", "Parent path is not a directory.", { path: clean });
    }
    return current2;
  }
  async read(relative, { binary = false } = {}) {
    const target = await this.location(relative);
    let handle2;
    try {
      handle2 = await fs3.open(target, constants.O_RDONLY | constants.O_NOFOLLOW);
    } catch (error) {
      if (error.code === "ENOENT") return null;
      throw error;
    }
    try {
      const stat = await handle2.stat();
      requireThat(stat.isFile(), "file", "Select a file.", { path: relative });
      requireThat(stat.size <= this.maxBytes, "size", "File exceeds the reading limit.", { path: relative, size: stat.size });
      const bytes3 = await handle2.readFile();
      const result = {
        path: relative,
        bytes: new Uint8Array(bytes3),
        sha256: await nodeServices.hash(bytes3),
        size: bytes3.length,
        mode: stat.mode & 511,
        modified_at: stat.mtime.toISOString(),
        created_at: stat.birthtimeMs > 0 ? stat.birthtime.toISOString() : null,
        created_at_basis: stat.birthtimeMs > 0 ? "filesystem_birthtime" : "unknown"
      };
      if (!binary) result.text = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes3);
      return result;
    } finally {
      await handle2.close();
    }
  }
  /** Cheap identity for validating a multi-call inventory without rehydrating bytes. */
  async fingerprint(relative) {
    let stat;
    try {
      stat = await fs3.lstat(await this.location(relative));
    } catch (error) {
      if (error.code === "ENOENT") return null;
      throw error;
    }
    requireThat(stat.isFile() && !stat.isSymbolicLink(), "file", "Select a regular file.", { path: relative });
    return [stat.dev, stat.ino, stat.size, stat.mtimeMs, stat.ctimeMs];
  }
  async mkdir(relative) {
    requireThat(this.writable, "read-only", "Source folders are read-only.");
    const target = await this.location(relative + "/.directory-check", { createParent: true });
    return path3.dirname(target);
  }
  async list(relative = "", { recursive = true, hidden = false } = {}) {
    relativePath(relative, { root: true });
    const out = [];
    const visit = async (dir) => {
      const target = await this.location(dir);
      const entries = (await fs3.readdir(target, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name));
      for (const e of entries) {
        if (!hidden && (e.name.startsWith(".") || e.name.startsWith("~$"))) continue;
        const rel = dir ? dir + "/" + e.name : e.name;
        if (e.isSymbolicLink()) {
          out.push({ path: rel, kind: "symlink" });
          continue;
        }
        out.push({ path: rel, kind: e.isDirectory() ? "directory" : "file" });
        if (recursive && e.isDirectory()) await visit(rel);
      }
    };
    await visit(relative);
    return out;
  }
  async write(relative, content, options = {}) {
    requireThat(this.writable, "read-only", "Source folders are read-only.");
    requireThat(Object.hasOwn(options, "expected"), "baseline", "An expected baseline is required before writing.");
    requireThat(options.expected === null || /^[a-f0-9]{64}$/.test(options.expected), "baseline", "Invalid expected baseline.");
    const clean = relativePath(relative), bytes3 = typeof content === "string" ? new TextEncoder().encode(content) : content;
    requireThat(bytes3 instanceof Uint8Array && bytes3.length <= this.maxBytes, "size", "Invalid or oversized write.");
    const lockRel = ".llmwiki/locks/" + await nodeServices.hash(clean) + ".lock";
    const lockPath = await this.location(lockRel, { createParent: true }), canonical = await fs3.realpath(this.root), target = path3.join(canonical, clean);
    const writer = acquireWriter({ root: canonical, target, lockPath, clean });
    try {
      const current2 = await this.read(clean, { binary: true });
      requireThat((current2?.sha256 ?? null) === options.expected, "stale", "The file changed since the expected baseline.", { path: clean, current: current2?.sha256 ?? null });
      await this.location(clean, { createParent: true });
      const temporary = writer.temporary;
      const file = await fs3.open(temporary, "wx", current2?.mode ?? options.mode ?? 438);
      try {
        if (current2?.mode !== void 0) await file.chmod(current2.mode);
        await file.writeFile(bytes3);
        await file.sync();
      } finally {
        await file.close();
      }
      const checked = await this.read(clean, { binary: true });
      requireThat((checked?.sha256 ?? null) === options.expected, "stale", "The file changed before replacement.", { path: clean });
      if (options.expected === null) {
        try {
          await fs3.link(temporary, target);
        } catch (error) {
          if (error.code === "EEXIST") throw new WikiError("stale", "The file was created by another writer.", { path: clean });
          throw error;
        }
        await fs3.unlink(temporary);
      } else await fs3.rename(temporary, target);
      const digest3 = await nodeServices.hash(bytes3), readback = await this.read(clean, { binary: true });
      requireThat(readback?.sha256 === digest3, "mismatch", "The saved file changed during verification.", { path: clean });
      return { saved: true, path: clean, sha256: digest3 };
    } finally {
      writer.release();
    }
  }
  async archive(from, to, expected) {
    requireThat(this.writable, "read-only", "Sources are read-only.");
    const seen = await this.read(from, { binary: true });
    requireThat(seen?.sha256 === expected, "stale", "The original changed before archiving.");
    const target = await this.location(to, { createParent: true }), source2 = await this.location(from);
    const archived = await this.read(to, { binary: true });
    requireThat(!archived || archived.sha256 === expected, "exists", "Archive destination already exists with different content.");
    if (!archived) await fs3.link(source2, target);
    const verified = await this.read(from, { binary: true });
    requireThat(verified?.sha256 === expected, "stale", "The original changed while archiving; both copies are retained.");
    await fs3.unlink(source2);
    requireThat((await this.read(to, { binary: true }))?.sha256 === expected, "mismatch", "Archive verification failed.");
  }
  async substore(relative, options = {}) {
    const root = await this.location(relative, { createParent: false });
    const store = new _NodeStore(root, { ...options, writable: this.writable && options.writable !== false });
    await store.location("");
    return store;
  }
};

// runtime/node-input.mjs
init_errors();
var MAX_REQUEST = 32 * 1024 * 1024;
var flags = /* @__PURE__ */ new Set(["--root", "--input", "--bindings", "--read-only", "--help"]);
function parseArguments(args) {
  const parsed = {};
  for (let i2 = 0; i2 < args.length; i2++) {
    const flag2 = args[i2];
    requireThat(flags.has(flag2), "arguments", "Unknown option: " + flag2 + ". Use --help for supported options.");
    requireThat(!Object.hasOwn(parsed, flag2), "arguments", "Duplicate option: " + flag2);
    if (flag2 === "--read-only" || flag2 === "--help") parsed[flag2] = true;
    else {
      const value = args[++i2];
      requireThat(typeof value === "string" && value.length > 0 && !value.startsWith("--"), "arguments", "Missing value for " + flag2);
      parsed[flag2] = value;
    }
  }
  if (!parsed["--help"]) requireThat(parsed["--root"] && parsed["--input"], "arguments", "Use --root ABSOLUTE_PROJECT --input JSON (or a request file, or - for stdin).");
  return parsed;
}
async function fileText(file, maxBytes) {
  const absolute = path4.resolve(file), store = new NodeStore(path4.dirname(absolute), { writable: false, maxBytes });
  const value = await store.read(path4.basename(absolute));
  requireThat(value, "ENOENT", "Input file does not exist.", { path: absolute });
  return value.text;
}
function json(text2, code, message) {
  try {
    return JSON.parse(text2);
  } catch {
    throw new WikiError(code, message);
  }
}
async function readRequest(input, stdin = process.stdin) {
  let text2;
  if (input === "-") {
    const chunks = [];
    let size = 0;
    for await (const chunk of stdin) {
      const bytes3 = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      size += bytes3.length;
      requireThat(size <= MAX_REQUEST, "input_size", "Request exceeds 32 MiB.");
      chunks.push(bytes3);
    }
    text2 = Buffer.concat(chunks).toString("utf8");
  } else if (/^[\s\uFEFF]*[\[{]/.test(input)) text2 = input;
  else text2 = await fileText(input, MAX_REQUEST);
  requireThat(Buffer.byteLength(text2, "utf8") <= MAX_REQUEST, "input_size", "Request exceeds 32 MiB.");
  const request = json(text2.replace(/^\uFEFF/, ""), "input_json", "Supply valid JSON using --input JSON, --input - or an existing request file inside the granted project.");
  requireThat(request && typeof request === "object" && !Array.isArray(request) && typeof request.action === "string" && request.action.trim(), "input_json", "A JSON object with a nonempty action is required.");
  return request;
}
async function loadBindings(root, { file = null, readOnly = false } = {}) {
  let text2;
  if (file) text2 = await fileText(file, 1024 * 1024);
  else {
    const found = await root.read(".llmwiki/device-bindings.json") ?? await root.read(".llmwiki/bindings.json");
    if (!found) return {};
    text2 = found.text;
  }
  const value = json(text2, "bindings", "Device bindings must contain valid JSON.");
  requireThat(value && typeof value === "object" && !Array.isArray(value), "bindings", "Device bindings must be an object.");
  if (Object.hasOwn(value, "format")) requireThat(value.format === "llmwiki-device-bindings/1", "bindings", "Unknown device binding format.");
  const folders = Object.hasOwn(value, "format") ? value.folders : value;
  requireThat(folders && typeof folders === "object" && !Array.isArray(folders), "bindings", "Device bindings must map folder IDs to absolute host paths.");
  const bindings = {};
  for (const [id, location3] of Object.entries(folders)) {
    requireThat(id && !["__proto__", "constructor", "prototype"].includes(id) && typeof location3 === "string" && path4.isAbsolute(location3), "bindings", "Each device binding needs a folder ID and an absolute host path.", { folder: id });
    bindings[id] = new NodeStore(location3, { writable: !readOnly });
  }
  return bindings;
}

// runtime/editor-launch.mjs
import { spawn, execFile } from "node:child_process";
import { promisify } from "node:util";

// runtime/editor-host.mjs
import http from "node:http";
import fs4 from "node:fs/promises";
import path5 from "node:path";
import { randomBytes as randomBytes2, timingSafeEqual } from "node:crypto";
init_project2();
init_errors();
var ACCESS = ".llmwiki/editor-access.json";
var privatePath = (p) => /(?:^|\/)\.llmwiki\/(?:editor-(?:server|access)(?:\.json|\.log)|device-bindings\.json|bindings\.json|locks(?:\/|$))/.test(p);
var safeJSON = (v) => JSON.stringify(v).replace(/[<>&]/g, (c) => "\\u" + c.charCodeAt(0).toString(16).padStart(4, "0"));
async function createEditorHost(root, { html, port = 0, token = randomBytes2(32).toString("hex"), pickFolder = null, bindingsFile = null } = {}) {
  requireThat(typeof html === "string" && html.includes("<head>"), "editor", "A bundled editor is required.");
  const pending = /* @__PURE__ */ new Map();
  let origin, closed = false;
  async function catalog() {
    const { project } = await load(root), bindings = await loadBindings(root, { file: bindingsFile }), instance = await root.read(".llmwiki/project-instance.json");
    validateLocations(root, project, bindings);
    const folders = [];
    for (const f of project.folders) {
      let store = null, error = null;
      try {
        store = await folderStore(root, f, { bindings, writable: f.kind !== "source" && f.writable });
      } catch (e) {
        error = e.message;
      }
      folders.push({ ...f, writable: f.kind !== "source" && f.writable, root: store?.root ?? bindings[f.id]?.root ?? (f.path !== null ? path5.resolve(root.root, f.path) : null), store, error });
    }
    const scopes2 = [{ id: "$project", label: project.label, kind: "project", root: root.root, writable: true, store: root }, ...folders];
    const fingerprint = await root.services.hash(JSON.stringify([project, instance?.sha256, scopes2.map(({ id, root: root2, writable }) => ({ id, root: root2, writable }))]));
    let grant = null;
    try {
      grant = JSON.parse((await root.read(ACCESS))?.text ?? "null");
    } catch {
    }
    const identity2 = instance?.sha256 ?? null, approved = scopes2.map(({ id, root: root2, kind, writable }) => ({ id, root: root2, kind, writable }));
    const granted = grant?.project === project.id && grant?.instance === identity2 && Array.isArray(grant.scopes) && approved.every((f) => grant.scopes.some((g) => JSON.stringify(g) === JSON.stringify(f)));
    return { project, scopes: scopes2, fingerprint, identity: identity2, approved, granted };
  }
  async function privateWrite(name, data) {
    const previous = await root.read(name);
    await root.write(name, JSON.stringify(data) + "\n", { expected: previous?.sha256 ?? null, mode: 384 });
    await fs4.chmod(await root.location(name), 384);
  }
  async function run(q) {
    const c = await catalog();
    if (q.op === "catalog") return { project: c.project, folders: c.scopes.map(({ store: store2, ...f }) => f), fingerprint: c.fingerprint, granted: c.granted };
    if (q.op === "revoke") {
      await privateWrite(ACCESS, { fingerprint: null });
      return { revoked: true };
    }
    if (q.op === "grant") {
      requireThat(q.fingerprint === c.fingerprint, "stale", "Folder assignments changed. Confirm the current folders.");
      await privateWrite(ACCESS, { fingerprint: c.fingerprint, project: c.project.id, instance: c.identity, scopes: c.approved, confirmed_at: root.services.now() });
      return { granted: true };
    }
    requireThat(c.granted, "grant_required", "Best\xE4tige den Zugriff auf die gespeicherten Ordner.");
    if (q.op === "pick") {
      requireThat(pickFolder, "host_picker", "Dieser Host bietet keine Ordnerauswahl. Verbinde den zus\xE4tzlichen Ordner im Agent-Setup.");
      const selected = await pickFolder();
      if (!selected) return null;
      const store2 = new NodeStore(selected);
      await store2.location("");
      const id = "picked-" + randomBytes2(16).toString("hex");
      pending.set(id, store2);
      return { scope: id, name: path5.basename(store2.root) };
    }
    if (q.op === "bind") {
      requireThat(typeof q.id === "string" && /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/.test(q.id) && !["__proto__", "constructor", "prototype"].includes(q.id), "binding", "Invalid folder ID.");
      const store2 = pending.get(q.scope);
      requireThat(store2, "binding", "Choose the new folder first.");
      requireThat(!c.project.folders.some((f) => f.id === q.id), "binding", "Existing assignments must be changed through the agent setup.");
      const bindings = await loadBindings(root, { file: bindingsFile });
      bindings[q.id] = store2;
      await privateWrite(".llmwiki/device-bindings.json", { format: "llmwiki-device-bindings/1", folders: Object.fromEntries(Object.entries(bindings).map(([id, s]) => [id, s.root])) });
      return { bound: true };
    }
    const scope = c.scopes.find((f) => f.id === q.scope), picked = pending.get(q.scope), store = scope?.store ?? picked;
    requireThat(store, "binding", scope?.error ?? "Folder is not connected.");
    const p = relativePath(q.path ?? "", { root: true });
    requireThat(!privatePath(p), "private", "Editor credentials and device mappings are private.");
    if (q.op === "resolve") {
      const other = c.scopes.find((f) => f.id === q.other)?.store ?? pending.get(q.other);
      requireThat(other, "binding", "Unknown folder.");
      const base = await store.location(p), target2 = await other.location(q.otherPath ?? ""), rel = path5.relative(base, target2);
      return rel === "" ? [] : rel === ".." || rel.startsWith(".." + path5.sep) || path5.isAbsolute(rel) ? null : rel.split(path5.sep);
    }
    if (q.op === "stat") {
      try {
        const s = await fs4.lstat(await store.location(p));
        return { kind: s.isDirectory() ? "directory" : "file" };
      } catch (e) {
        if (e.code === "ENOENT") return null;
        throw e;
      }
    }
    if (q.op === "list") {
      const entries = (await store.list(p, { recursive: false, hidden: true })).filter((e) => e.kind !== "symlink" && !privatePath(e.path));
      return Promise.all(entries.map(async (e) => {
        const s = await fs4.lstat(await store.location(e.path));
        return { ...e, size: s.size, modified: s.mtimeMs };
      }));
    }
    if (q.op === "read") {
      const f = await store.read(p, { binary: true });
      return f ? { data: Buffer.from(f.bytes).toString("base64"), sha256: f.sha256, modified_at: f.modified_at } : null;
    }
    const target = await store.location(p);
    const sourceOverlap = c.scopes.some((f) => f.kind === "source" && f.root && (target === f.root || target.startsWith(f.root + path5.sep)));
    requireThat(scope && scope.writable && !picked && !sourceOverlap, "read-only", "Source folders and unassigned folders are read-only.");
    if (q.op === "mkdir") {
      await store.mkdir(p);
      return { created: true };
    }
    if (q.op === "write") {
      requireThat(typeof q.data === "string" && q.data.length <= 180 * 1024 * 1024, "size", "Invalid or oversized file.");
      const bytes3 = new Uint8Array(Buffer.from(q.data, "base64"));
      if (scope.id === "$project" && p === "llmwiki.project.json") {
        const saved = await saveSettings(root, JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes3)), q.expected, { bindings: await loadBindings(root, { file: bindingsFile }) });
        return { saved: true, sha256: saved.sha256 };
      }
      return store.write(p, bytes3, { expected: q.expected });
    }
    if (q.op === "remove") {
      requireThat(p && !p.split("/").some((v) => v.startsWith(".")), "path", "Only a selected visible file may be moved.");
      const seen = await store.read(p);
      requireThat(seen && seen.sha256 === q.expected, "stale", "The file changed before the move.");
      await store.archive(p, ".llmwiki/editor-archive/" + root.services.uuid() + "/" + path5.basename(p), seen.sha256);
      return { removed: true, archived: true };
    }
    throw Object.assign(Error("Unknown editor operation."), { code: "operation" });
  }
  const server = http.createServer(async (req, res) => {
    const headers = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "Content-Security-Policy": "frame-ancestors 'none'" };
    const reply = (status2, value) => {
      res.writeHead(status2, { ...headers, "Content-Type": "application/json" });
      res.end(JSON.stringify(value));
    };
    try {
      requireThat(req.headers.host === new URL(origin).host, "origin", "Unexpected host.");
      if (req.method === "GET" && req.url === "/") {
        const current2 = await root.read("LLM-Wiki.html");
        const template = current2?.text ?? html;
        const page = template.replace("connect-src 'none'", "connect-src 'self'").replace("<head>", '<head><script type="application/json" id="llmwiki-host">' + safeJSON({ root: root.root }) + "</script>");
        res.writeHead(200, { ...headers, "Content-Type": "text/html; charset=utf-8" });
        res.end(page);
        return;
      }
      requireThat(req.method === "POST" && req.url === "/api", "route", "Unknown route.");
      const actual = Buffer.from(req.headers.authorization ?? ""), expected = Buffer.from("Bearer " + token);
      if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
        reply(401, { ok: false, error: { code: "auth", message: "Open the personal editor start link." } });
        return;
      }
      if (req.headers.origin !== origin) {
        reply(403, { ok: false, error: { code: "origin", message: "Foreign origins are not permitted." } });
        return;
      }
      requireThat(req.headers["content-type"]?.split(";")[0] === "application/json", "content", "JSON required.");
      const chunks = [];
      let size = 0;
      for await (const bytes3 of req) {
        size += bytes3.length;
        requireThat(size <= 180 * 1024 * 1024, "size", "Request too large.");
        chunks.push(bytes3);
      }
      const q = JSON.parse(Buffer.concat(chunks).toString());
      requireThat(q && typeof q === "object" && !Array.isArray(q), "request", "Object required.");
      if (q.op === "stop") {
        reply(200, { ok: true, result: { stopped: true } });
        setImmediate(() => server.close());
        return;
      }
      reply(200, { ok: true, result: await run(q) });
    } catch (e) {
      reply(400, { ok: false, error: { code: e.code ?? "request", message: e.message } });
    }
  });
  server.requestTimeout = 3e4;
  server.headersTimeout = 1e4;
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, "127.0.0.1", resolve);
  });
  origin = "http://127.0.0.1:" + server.address().port;
  return { origin, token, url: origin + "/#" + token, server, close: async () => {
    if (closed) return;
    closed = true;
    server.closeAllConnections();
    await new Promise((resolve) => server.close(resolve));
  } };
}

// runtime/editor-launch.mjs
init_errors();

// runtime/passage-links.mjs
init_errors();
var hex = (x2) => typeof x2 === "string" && /^[a-f0-9]{64}$/.test(x2);
function validatePassage(p) {
  requireThat(p?.version === 1, "citation_link", "Unsupported passage link.");
  for (const key of ["project", "instance", "connection", "work", "wiki"]) requireThat(typeof p[key] === "string" && p[key].length > 0 && p[key].length <= 256, "citation_link", "Invalid passage scope.");
  requireThat(typeof p.page === "string" && p.page.length <= 2048, "citation_link", "Invalid passage path.");
  relativePath(p.page);
  requireThat(hex(p.revision) && hex(p.quote_hash) && (p.document === null || hex(p.document)) && (p.block === null || hex(p.block)), "citation_link", "Invalid passage identity.");
  requireThat([p.start, p.end, p.offset].every(Number.isSafeInteger) && p.start >= 0 && p.end > p.start && p.end <= 128 * 1024 * 1024 && p.offset >= 0 && p.offset <= p.start, "citation_link", "Invalid passage range.");
  return p;
}
function encodePassage(p) {
  validatePassage(p);
  const data = [1, p.project, p.instance, p.connection, p.work, p.wiki, p.page, p.document, p.block, p.revision, p.start, p.end, p.offset, p.quote_hash];
  const encoded = btoa(Array.from(new TextEncoder().encode(JSON.stringify(data)), (b) => String.fromCharCode(b)).join("")).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
  requireThat(encoded.length <= 8192, "citation_link", "Passage address is too long.");
  return encoded;
}
function decodePassage(token) {
  requireThat(typeof token === "string" && token.length > 0 && token.length <= 8192 && /^[A-Za-z0-9_-]+$/.test(token), "citation_link", "Invalid passage link.");
  let a;
  try {
    a = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(atob(token.replaceAll("-", "+").replaceAll("_", "/")), (c) => c.charCodeAt(0))));
  } catch {
    requireThat(false, "citation_link", "Invalid passage encoding.");
  }
  requireThat(Array.isArray(a) && a.length === 14, "citation_link", "Invalid passage fields.");
  const [version2, project, instance, connection, work, wiki2, page, document2, block, revision, start2, end, offset, quote_hash] = a;
  return validatePassage({ version: version2, project, instance, connection, work, wiki: wiki2, page, document: document2, block, revision, start: start2, end, offset, quote_hash });
}

// runtime/citations.mjs
var words = (text2) => String(text2).toLocaleLowerCase().normalize("NFKC").match(/[\p{L}\p{N}]+/gu) ?? [];
var label = (text2) => String(text2).replace(/[\[\]\\\r\n]/g, " ");
async function citation(page, store, question, { start: start2 = 0, end = page.body.length } = {}) {
  const file_href = store.fileURL ? await store.fileURL(page.path) : (store.hostPath ? store.hostPath(page.path) : page.path).split("/").map(encodeURIComponent).join("/");
  const terms = new Set(words(question)), lines = page.body.split("\n"), passages = [];
  let offset = 0, heading = null, fence = null, paragraph = null;
  const finish2 = () => {
    if (!paragraph) return;
    const quote3 = paragraph.lines.join("\n").trimEnd(), tokens = new Set(words(quote3)), score = [...terms].filter((t) => tokens.has(t)).length;
    if (score && paragraph.start < end && paragraph.end > start2) {
      const block = /\^([a-zA-Z0-9-]+)\s*$/.exec(quote3), anchor = block ? "^" + block[1] : paragraph.heading;
      const href2 = file_href + (anchor ? "#" + encodeURIComponent(anchor) : "");
      const sourceOffset = page.offset + paragraph.start;
      passages.push({ quote: quote3, start: paragraph.start, end: paragraph.end, line_start: page.source.slice(0, sourceOffset).split("\n").length, line_end: page.source.slice(0, page.offset + paragraph.end).split("\n").length, anchor: anchor ?? null, anchor_kind: block ? "block" : anchor ? "heading" : null, href: href2, markdown: "[" + label(page.head.title ?? page.path) + "](" + href2 + ")", score });
    }
    paragraph = null;
  };
  for (const line of lines) {
    const marker = /^ {0,3}(`{3,}|~{3,})/.exec(line), h = !fence && /^ {0,3}#{1,6}\s+(.+?)\s*#*\s*$/.exec(line);
    if (marker) {
      finish2();
      if (!fence) fence = marker[1];
      else if (marker[1][0] === fence[0] && marker[1].length >= fence.length) fence = null;
    } else if (h) {
      finish2();
      heading = h[1];
    } else if (!line.trim() || fence || line.startsWith("<!--")) finish2();
    else {
      paragraph ??= { start: offset, end: offset, heading, lines: [] };
      paragraph.lines.push(line);
      paragraph.end = offset + line.length;
    }
    offset += line.length + 1;
  }
  finish2();
  passages.sort((a, b) => b.score - a.score || a.start - b.start);
  const selected = passages.slice(0, 8).map(({ score, ...p }) => p), href = selected[0]?.href ?? file_href;
  return { id: page.head.source_id ?? page.head.id, wiki: page.wiki, page: page.path, title: page.head.title ?? page.path, sha256: page.sha256, file_href, href, markdown: "[" + label(page.head.title ?? page.path) + "](" + href + ")", passages: selected, locator_notice: "Anchors refer only to existing headings or blocks. Quotes, line numbers and SHA-256 identify this file version; lines are not permanent addresses." };
}
async function editorDestination(root, project) {
  let entry = null, marker = null, entryError = null;
  try {
    entry = await root.read("LLM-Wiki.html");
    marker = await root.read(".llmwiki/project-instance.json");
  } catch (error) {
    entryError = error.code ?? "editor_read_error";
  }
  let instance = null;
  try {
    const data = JSON.parse(marker?.text ?? "null");
    if (data?.project === project.id) instance = data.instance;
  } catch {
  }
  const version2 = entry?.text.match(/<meta name="llmwiki-editor-version" content="([^"]+)">/)?.[1], parts = version2?.split(".").map(Number);
  const compatible = parts?.length === 3 && parts.every(Number.isInteger) && (parts[0] > 0 || parts[1] > 4 || parts[1] === 4 && parts[2] >= 23);
  const bound = instance && entry?.text.includes('<meta name="llmwiki-entry-project" content="' + project.id + '">') && entry?.text.includes('<meta name="llmwiki-entry-instance" content="' + instance + '">');
  let href = null;
  try {
    if (entry && root.fileURL) href = await root.fileURL("LLM-Wiki.html");
  } catch (error) {
    entryError = error.code ?? "editor_link_error";
  }
  return { instance, mode: "inline_editor", available: Boolean(href && bound && compatible), reason: entryError ?? (!entry ? "editor_missing" : !bound ? "editor_instance_mismatch" : !compatible ? "editor_update_required" : !href ? "editor_link_unavailable" : null), minimum_editor: "0.4.23", entry_href: href, use: "Place passage.markdown immediately after the supported claim. Keep editor_href intact; never reconstruct a relative wiki path. A bibliography does not replace inline evidence." };
}
async function editorCitations(root, project, contexts, result) {
  const { instance, ...destination } = await editorDestination(root, project), href = destination.entry_href;
  result.citation_links = destination;
  let number = 0;
  for (const citation2 of result.citations) {
    const scope = contexts.find((c) => c.wiki.id === citation2.wiki);
    citation2.file_markdown = citation2.markdown;
    for (const passage of citation2.shadow.passages) {
      passage.number = ++number;
      passage.source_title = citation2.title;
      passage.editor_href = null;
      passage.markdown = null;
      if (!instance || !scope) continue;
      const reference = encodePassage({ version: 1, project: project.id, instance, connection: scope.connection.id, work: scope.workFolder.id, wiki: passage.wiki, page: passage.page, document: passage.document, block: passage.block, revision: passage.revision, start: passage.start, end: passage.end, offset: passage.partial ? passage.start - passage.block_start : 0, quote_hash: await root.services.hash(passage.quote) });
      passage.reference = reference;
      if (result.citation_links.available) {
        passage.editor_href = href + "#passage=" + reference;
        passage.href = passage.editor_href;
        passage.markdown = "[" + passage.number + "](<" + passage.editor_href + ">)";
      }
    }
    citation2.href = citation2.shadow.passages[0]?.editor_href ?? null;
    citation2.markdown = citation2.shadow.passages[0]?.markdown ?? null;
    for (const legacy of citation2.passages) {
      legacy.file_href = legacy.href;
      legacy.file_markdown = legacy.markdown;
      const matches = citation2.shadow.passages.filter((p) => p.quote === legacy.quote && p.line_start === legacy.line_start && p.line_end === legacy.line_end), exact = matches.length === 1 ? matches[0] : null;
      legacy.href = exact?.editor_href ?? null;
      legacy.markdown = exact?.markdown ?? null;
    }
  }
  return result;
}

// runtime/editor-launch.mjs
var localBindingAllowed = true;
var hostOpenTool = true ? null : null;
var profile = true ? "claude-code" : "local";
var exec = promisify(execFile);
var STATE = ".llmwiki/editor-server.json";
var version = true ? "0.4.24" : "development";
async function picker() {
  try {
    if (process.platform === "darwin") return (await exec("/usr/bin/osascript", ["-e", 'POSIX path of (choose folder with prompt "Zus\xE4tzlichen Wiki- oder Quellenordner verbinden")'], { timeout: 12e4 })).stdout.trim();
    if (process.platform === "win32") return (await exec("powershell.exe", ["-NoProfile", "-Command", 'Add-Type -AssemblyName System.Windows.Forms; $picker = New-Object System.Windows.Forms.FolderBrowserDialog; if ($picker.ShowDialog() -eq "OK") { $picker.SelectedPath }'], { timeout: 12e4 })).stdout.trim() || null;
    throw Error("Native folder selection is unavailable on this host. Connect the folder with the agent.");
  } catch (error) {
    if (/User canceled|Benutzer.*abgebrochen|\(-128\)/i.test(error.message)) return null;
    throw error;
  }
}
async function state(root) {
  try {
    return JSON.parse((await root.read(STATE))?.text ?? "null");
  } catch {
    return null;
  }
}
async function probe(data, op = "catalog") {
  if (!data || !/^http:\/\/127\.0\.0\.1:\d+$/.test(data.origin) || !/^[a-f0-9]{64}$/.test(data.token)) return null;
  try {
    const response = await fetch(data.origin + "/api", { method: "POST", headers: { Origin: data.origin, Authorization: "Bearer " + data.token, "Content-Type": "application/json" }, body: JSON.stringify({ op }), signal: AbortSignal.timeout(1e3) });
    const body = await response.json();
    return body.ok ? body.result : null;
  } catch {
    return null;
  }
}
async function openURL(url) {
  if (process.platform === "darwin") await exec("/usr/bin/open", [url]);
  else if (process.platform === "win32") await exec("rundll32.exe", ["url.dll,FileProtocolHandler", url]);
  else await exec("xdg-open", [url]);
}
async function serveEditor(root, html, { bindingsFile = null } = {}) {
  const capability = await editorPreflight(root, { bindingsFile });
  if (capability.status !== "available") return capability;
  const old = await state(root);
  requireThat(!await probe(old), "editor_running", "The editor is already running. Use editor.start.");
  let host;
  const opts = { html, token: old?.token, port: old?.port ?? 0, pickFolder: picker, bindingsFile };
  try {
    host = await createEditorHost(root, opts);
  } catch (error) {
    if (error.code !== "EADDRINUSE") throw error;
    host = await createEditorHost(root, { ...opts, port: 0 });
  }
  const current2 = await root.read(STATE);
  await root.write(STATE, JSON.stringify({ format: "llmwiki-editor-server/1", version, root: root.root, origin: host.origin, port: Number(new URL(host.origin).port), token: host.token, pid: process.pid }) + "\n", { expected: current2?.sha256 ?? null, mode: 384 });
  await fs5.chmod(await root.location(STATE), 384);
  for (const signal of ["SIGTERM", "SIGINT"]) process.once(signal, () => host.close().finally(() => process.exit(0)));
  return { url: host.url, running: true, transport: "loopback", version };
}
var quote = (s) => "'" + s.replace(/'/g, "'\\''") + "'";
async function launcher(root, entry, bindingsFile) {
  const request = JSON.stringify({ action: "editor.start", open: true }), args = [process.execPath, entry, "--root", root.root, "--input", request, ...bindingsFile ? ["--bindings", bindingsFile] : []];
  const windows = process.platform === "win32";
  requireThat(args.every((v) => !/[\r\n]/.test(v) && (!windows || !/%/.test(v))), "launcher", "Paths cannot be safely represented in this platform launcher.");
  const name = windows ? "Editor starten.cmd" : "Editor starten.command";
  const encoded = Buffer.from(JSON.stringify(args.slice(1))).toString("base64");
  const script = "const r=require('node:child_process').spawnSync(process.execPath,JSON.parse(Buffer.from('" + encoded + "','base64').toString()),{stdio:'inherit'});process.exit(r.status??1)";
  const text2 = windows ? '@echo off\r\n"' + process.execPath + '" -e "' + script + '"\r\n' : "#!/bin/sh\nexec " + args.map(quote).join(" ") + "\n";
  const previous = await root.read(name);
  if (previous?.text !== text2) await root.write(name, text2, { expected: previous?.sha256 ?? null });
  if (!windows) await fs5.chmod(await root.location(name), 448);
  return path6.join(root.root, name);
}
async function checkBinding() {
  await new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => server.close((error) => error ? reject(error) : resolve()));
  });
}
var diagnostic = (error) => ({ code: error.code ?? "editor_host", message: String(error.message).replace(/[a-f0-9]{64}/gi, "[redacted]").slice(0, 1e3) });
async function editorPreflight(root, { profile: hostProfile = profile, bindingsFile = null, checkBinding: check = checkBinding } = {}) {
  const bindings = await loadBindings(root, { file: bindingsFile, readOnly: true }), saved = await inspect(root, { bindings });
  const destination = saved.project ? await editorDestination(root, saved.project) : { available: false, reason: "project_missing" };
  const standaloneOpen = destination.available && hostOpenTool && saved.editor?.entry_path ? { tool: hostOpenTool, arguments: { path: saved.editor.entry_path } } : null;
  const folders = saved.locations ?? [], byID = (id) => folders.find((f) => f.id === id);
  const handoff = {
    project_root: root.root,
    entry_path: saved.editor?.entry_path ?? null,
    entry_exists: saved.editor?.exists ?? false,
    obsidian: (saved.project?.connections ?? []).flatMap((c) => c.works.map((id) => ({ connection: c.id, label: c.label, folder: id, path: byID(id)?.location ?? null, binding_available: byID(id)?.binding_available ?? false }))),
    standalone: {
      status: standaloneOpen ? "host_action_required" : destination.available ? "native_tool_required" : "unavailable",
      open: standaloneOpen,
      reason: destination.reason ?? null,
      browsers: ["Chrome", "Edge"],
      browser_verified: false,
      requires_folder_selection: true,
      steps: [{ role: "project", path: root.root }, ...folders.filter((f) => f.external).map((f) => ({ role: f.kind, folder: f.id, path: f.location }))],
      instruction: "Open the canonical HTML in Chrome or Edge. Select its project folder first, then grant only the external folders requested by the editor. Stored settings do not grant browser access; Firefox is not a writable File System Access fallback."
    }
  };
  const issues = [...saved.issues ?? [], ...folders.filter((f) => !f.binding_available).map((f) => ({ code: "binding_missing", folder: f.id }))];
  const base = {
    profile: hostProfile,
    configuration: saved.next === "choose_task" && !issues.length ? "verified" : "incomplete",
    configuration_issues: issues,
    editor_mode: saved.project?.editor ?? null,
    running: false,
    browser_verified: false,
    setup_complete: false,
    process_persistence: "unverified",
    handoff
  };
  if (base.configuration !== "verified") return { ...base, status: "setup_required", reason: { code: "setup", message: "Resume the existing setup and repair its reported missing fields before opening the editor." } };
  if (base.editor_mode === "obsidian") return { ...base, status: "native_editor", next: "Open the configured working-copy path in Obsidian using the host opening tool; verify with the user." };
  if (!localBindingAllowed) return { ...base, status: "unavailable", reason: { code: "local_binding_forbidden", message: "This host profile uses a sandbox with allowLocalBinding:false. It forbids listening on 127.0.0.1; folder sharing does not change that policy." }, next: standaloneOpen ? "The server is unavailable; the standalone editor has a separate valid handoff. Invoke handoff.standalone.open.tool with its exact arguments using the host tool, then check its response. A chat link does not perform this action; do not claim the browser opened without verification." : "Use the guided standalone editor or the configured Obsidian working copy. Do not retry the server or widen sandbox permissions." };
  try {
    await check();
  } catch (error) {
    return { ...base, status: "unavailable", reason: diagnostic(error), next: "Local binding failed in this execution environment. Continue with the guided standalone editor or configured Obsidian working copy; do not claim setup is complete." };
  }
  return { ...base, status: "available", next: "Only start if the browser is on this execution host or an actual host preview is available. A successful socket check proves neither browser access nor process persistence." };
}
async function childDiagnostic(root, offset) {
  const text2 = (await root.read(".llmwiki/editor-server.log"))?.text ?? "";
  for (const line of text2.slice(offset).trim().split("\n").reverse()) try {
    const item = JSON.parse(line);
    if (item.ok === false && item.error) return diagnostic(item.error);
  } catch {
  }
  return { code: "editor_process_exited", message: "The editor process exited before becoming ready. See .llmwiki/editor-server.log for this attempt." };
}
async function startEditor(root, { entry = process.argv[1], bindingsFile = null, open = false, profile: hostProfile = profile, checkBinding: check = checkBinding, openBrowser = openURL } = {}) {
  const preflight = await editorPreflight(root, { profile: hostProfile, bindingsFile, checkBinding: check });
  if (preflight.status !== "available") return preflight;
  let data = await state(root), running = await probe(data);
  if (running && data.version !== version) {
    await probe(data, "stop");
    running = null;
    await new Promise((resolve) => setTimeout(resolve, 150));
  }
  const file = await launcher(root, path6.resolve(entry), bindingsFile);
  if (!running) {
    const offset = ((await root.read(".llmwiki/editor-server.log"))?.text ?? "").length;
    const logPath = await root.location(".llmwiki/editor-server.log", { createParent: true }), log = await fs5.open(logPath, "a", 384);
    let child2, failure2 = null, exited = false;
    try {
      child2 = spawn(process.execPath, [path6.resolve(entry), "--root", root.root, "--input", JSON.stringify({ action: "editor.serve" }), ...bindingsFile ? ["--bindings", bindingsFile] : []], { detached: true, stdio: ["ignore", log.fd, log.fd], windowsHide: true });
      child2.once("error", (error) => {
        failure2 = error;
      });
      child2.once("exit", () => {
        exited = true;
      });
      child2.unref();
    } catch (error) {
      failure2 = error;
    } finally {
      await log.close();
    }
    for (let i2 = 0; i2 < 40 && !failure2 && !exited; i2++) {
      await new Promise((resolve) => setTimeout(resolve, 200));
      data = await state(root);
      if (data?.version === version && await probe(data)) {
        running = true;
        break;
      }
    }
    if (!running) {
      if (child2 && !exited && !failure2) child2.kill();
      return { ...preflight, status: "unavailable", reason: failure2 ? diagnostic(failure2) : exited ? await childDiagnostic(root, offset) : { code: "editor_start_timeout", message: "The editor did not become ready within eight seconds. Process persistence is not established." }, next: "Do not repeat this failed attempt unchanged. Resolve the reported host capability or use the guided standalone/native editor." };
    }
  }
  const url = data.origin + "/#" + data.token;
  let browser_open = { status: "not_requested" };
  if (open) try {
    await openBrowser(url);
    browser_open = { status: "requested" };
  } catch (error) {
    browser_open = { status: "failed", reason: diagnostic(error) };
  }
  return { ...preflight, status: "running", url, launcher: file, version, running: true, browser_open, scope: "This host machine only; remote/container hosts must expose their own browser preview.", permission: "Confirm the configured folders once in the editor.", next: browser_open.status === "failed" ? "Return the personal URL; the browser opener failed." : "Return the personal URL and verify browser access separately. An opening request is not proof that the editor opened." };
}
async function stopEditor(root) {
  const data = await state(root);
  return { stopped: Boolean(await probe(data, "stop")) };
}

// runtime/collection.mjs
init_document();
init_ontology();
init_errors();
init_content();

// runtime/change-set.mjs
init_document();
init_ontology();
init_review();
init_errors();
var encodeBytes = (bytes3) => {
  let text2 = "";
  for (let i2 = 0; i2 < bytes3.length; i2 += 8192) text2 += String.fromCharCode(...bytes3.subarray(i2, i2 + 8192));
  return btoa(text2);
};
var decodeBytes = (text2) => Uint8Array.from(atob(text2), (c) => c.charCodeAt(0));
var payload = (c, value = c.text) => c.encoding === "base64" ? decodeBytes(value) : value;
var journalTarget = (store, c) => store.reviewStore?.(c.page) ?? { store, page: c.page };
var authored = (c) => c.encoding !== "base64" && !c.page.includes(".llmwiki/") && (c.page.endsWith(".md") || c.page.endsWith("schema/FIELDS.json"));
async function finishReceipt(store, c, author, text2, base) {
  const target = journalTarget(store, c), dir = handle(target.store), journal = await reviews.read(dir, target.page), match = (e) => e.text === text2 && e.base === (base ?? "") && e.author === author;
  if (journal.events.some(match)) return;
  const pending = journal.pending.find(match);
  requireThat(pending && await reviews.receipt(dir, pending), "receipt", "The exact write needs its review receipt before completion.", { page: c.page });
}
async function retireRecord(store, c, data) {
  const target = journalTarget(store, c), value = { format: "llmwiki-retirement/1", page: target.page, expected: c.after, author: data.author, stage: data.id }, text2 = JSON.stringify(value), path7 = ".llmwiki/retirements/" + await store.services.hash(text2) + ".json";
  if (!await target.store.read(path7)) await target.store.write(path7, text2, { expected: null });
}
var readImage = (store, c) => store.read(c.page, { binary: c.encoding === "base64" });
var immutable = (data) => Object.fromEntries(["format", "kind", "folder", "label", "author", "changes", "dependencies", "details"].map((k) => [k, data[k]]));
var recordPath = (id) => {
  requireThat(/^[a-f0-9-]{36}$/.test(id), "plan", "Invalid change plan.");
  return ".llmwiki/changes/" + id + ".json";
};
async function proposal(store, { kind, folder = "", label: label2, author, changes, dependencies = [], details = {} }) {
  relativePath(folder, { root: true });
  nonempty(author, "author");
  nonempty(label2, "stage label");
  requireThat(Array.isArray(changes), "changes", "Provide the proposed changes.");
  const seen = /* @__PURE__ */ new Set(), rows = [];
  for (const change of changes) {
    relativePath(change.page);
    requireThat(!seen.has(change.page), "changes", "A stage may change each file only once.");
    seen.add(change.page);
    const before = await readImage(store, change);
    requireThat((before?.sha256 ?? null) === change.expected, "stale", "A proposed file changed.", { page: change.page });
    requireThat(typeof change.text === "string", "changes", "Changes must preserve text files.");
    const old = before ? change.encoding === "base64" ? encodeBytes(before.bytes) : before.text : null;
    if (old === change.text) continue;
    rows.push({ page: change.page, before: old, expected: change.expected, text: change.text, after: await store.services.hash(payload(change)), reversible: change.reversible !== false, ...change.encoding ? { encoding: change.encoding, copy_from: change.copy_from } : {} });
  }
  const data = { format: "llmwiki-changes/1", kind, folder, label: label2, author, changes: rows, dependencies, details };
  return { ...data, token: await store.services.hash(JSON.stringify(data)), complete: false };
}
async function prepareChanges(store, preview, expected) {
  requireThat(expected === preview.token, "stale_preview", "Review the current preview before preparing this stage.");
  const id = store.services.uuid(), data = { ...preview, id, state: "prepared", applied: [], restored: [], pending: null };
  await store.write(recordPath(id), JSON.stringify(data), { expected: null });
  return { id, kind: data.kind, state: data.state, token: data.token, changes: data.changes.length, details: data.details, complete: false, next: "apply or decline" };
}
async function readChanges(store, id, kind) {
  const file = await store.read(recordPath(id));
  requireThat(file, "plan", "Change plan is missing.");
  const data = JSON.parse(file.text);
  requireThat(data.format === "llmwiki-changes/1" && data.id === id && (!kind || data.kind === kind), "plan", "This plan belongs to another operation.");
  requireThat(await store.services.hash(JSON.stringify(immutable(data))) === data.token, "plan_integrity", "The saved proposal changed. Restore its original record.");
  return { data, file };
}
async function persist(store, data, file) {
  return store.write(recordPath(data.id), JSON.stringify(data), { expected: file.sha256 });
}
async function registerInUse(store, c, data) {
  if (!["schema/TYPES.md", "schema/FIELDS.json"].includes(c.page)) return false;
  const types = c.page === "schema/TYPES.md", before = types ? c.before ? [...readRegister(c.before).genera.keys()] : [] : c.before ? JSON.parse(c.before).fields.map((f) => f.name) : [], after = types ? [...readRegister(c.text).genera.keys()] : JSON.parse(c.text).fields.map((f) => f.name), removed = after.filter((f) => !before.includes(f));
  if (!removed.length) return false;
  for (const entry of await store.list("")) {
    if (entry.kind !== "file" || !entry.path.endsWith(".md") || entry.path.startsWith("schema/")) continue;
    const file = await store.read(entry.path), initial = data.details.adopted_pages?.find((p) => p.page === entry.path);
    if (initial?.expected === file?.sha256) continue;
    try {
      const head = parseDocument(file.text).head;
      if (types ? removed.includes(head.type) : removed.some((f) => Object.hasOwn(head, f))) return true;
    } catch {
      return true;
    }
  }
  return false;
}
async function operateChanges(store, { id, step, approved }, kind, { check = async () => {
} } = {}) {
  let { data, file } = await readChanges(store, id, kind);
  const result = (extra = {}) => ({ id, kind: data.kind, state: data.state, details: data.details, changes: data.changes.map((c) => ({ page: c.page, expected: c.expected, after: c.after })), complete: ["applied", "rolled_back", "declined"].includes(data.state), ...extra });
  if (step === "status") return result();
  if (step === "decline") {
    requireThat(data.state === "prepared" || data.state === "declined", "state", "A started stage must be rolled back.");
    data.state = "declined";
    await persist(store, data, file);
    return result();
  }
  requireThat(["apply", "rollback"].includes(step), "step", "Choose preview, prepare, apply, decline, status or rollback.");
  requireThat(approved === true, "approval", "Explicitly approve this stage or its rollback.");
  const checkpoint = async () => {
    await persist(store, data, file);
    file = await store.read(recordPath(id));
  };
  if (step === "apply") {
    requireThat(["prepared", "applying", "applied"].includes(data.state), "state", "A declined or rolled-back stage cannot be applied.");
    if (data.state === "applied") return result();
    await check(data);
    for (let i2 = 0; i2 < data.changes.length; i2++) {
      if (data.applied.includes(i2)) continue;
      const c = data.changes[i2], current2 = await readImage(store, c);
      requireThat((current2?.sha256 ?? null) === (c.apply_expected ?? c.expected) || data.pending === i2 && current2?.sha256 === c.after, "stale", "A file changed after preview.", { page: c.page });
    }
    data.state = "applying";
    await checkpoint();
    for (let i2 = 0; i2 < data.changes.length; i2++) {
      if (data.applied.includes(i2)) continue;
      const c = data.changes[i2], current2 = await readImage(store, c);
      if (!(data.pending === i2 && current2?.sha256 === c.after)) {
        data.pending = i2;
        await checkpoint();
        if (c.encoding === "base64" && store.capabilities?.textWritesOnly) return result({ complete: false, requires_host_copy: { source: store.hostPath?.(c.copy_from) ?? c.copy_from, destination: store.hostPath?.(c.page) ?? c.page, expected: c.after }, next: "Copy these exact bytes with the host file tool, then resume this approved stage." });
        if (authored(c) && data.kind !== "ingest-group") {
          const target = journalTarget(store, c);
          await save(target.store, target.page, c.text, data.author, c.apply_expected ?? c.expected);
        } else await store.write(c.page, payload(c), { expected: c.apply_expected ?? c.expected });
      }
      if (authored(c) && data.kind !== "ingest-group") await finishReceipt(store, c, data.author, c.text, c.before);
      data.applied.push(i2);
      data.pending = null;
      await checkpoint();
    }
    data.state = "applied";
    await checkpoint();
    return result();
  }
  requireThat(["prepared", "applying", "applied", "rolling_back", "rolled_back"].includes(data.state), "state", "This stage cannot be rolled back.");
  if (data.state === "rolled_back") return result();
  if (data.pending !== null && !data.applied.includes(data.pending)) {
    const c = data.changes[data.pending], current2 = await readImage(store, c);
    if (current2?.sha256 === c.after) data.applied.push(data.pending);
    else requireThat((current2?.sha256 ?? null) === (c.apply_expected ?? c.expected), "stale", "An interrupted write changed again.", { page: c.page });
    data.pending = null;
  }
  data.state = "rolling_back";
  await checkpoint();
  const conflicts = [];
  for (const i2 of [.../* @__PURE__ */ new Set([...data.applied, ...data.changes.flatMap((c, i3) => c.prior ? [i3] : [])])].reverse()) {
    if (data.restored.includes(i2)) continue;
    const planned = data.changes[i2], c = data.applied.includes(i2) ? planned : { ...planned, ...planned.prior };
    if (!c.reversible) {
      data.restored.push(i2);
      await checkpoint();
      continue;
    }
    const current2 = await readImage(store, c);
    if (data.rollback_pending === i2 && (current2?.sha256 ?? null) === c.expected) {
      if (c.before === null) requireThat((await store.read(".llmwiki/changes/" + id + "/retired/" + c.page, { binary: c.encoding === "base64" }))?.sha256 === c.after, "archive_missing", "Verify the archived file before completing rollback.", { page: c.page });
      else if (authored(c)) await finishReceipt(store, c, data.author, c.before, c.text);
      data.restored.push(i2);
      data.rollback_pending = null;
      await checkpoint();
      continue;
    }
    if (current2?.sha256 !== c.after) {
      conflicts.push({ page: c.page, code: "later_change", expected: c.after, current: current2?.sha256 ?? null });
      continue;
    }
    if (await registerInUse(store, c, data)) {
      conflicts.push({ page: c.page, code: "register_in_use" });
      continue;
    }
    data.rollback_pending = i2;
    await checkpoint();
    if (c.before === null) {
      await retireRecord(store, c, data);
      const archive = ".llmwiki/changes/" + id + "/retired/" + c.page;
      if (!store.archive) return result({ complete: false, conflicts, requires_host_move: { source: store.hostPath?.(c.page) ?? c.page, destination: store.hostPath?.(archive) ?? archive, expected: c.after }, next: "Archive the exact created file with the host move tool, then resume rollback." });
      await store.archive(c.page, archive, c.after);
    } else if (authored(c)) {
      const target = journalTarget(store, c);
      await save(target.store, target.page, c.before, data.author, c.after);
    } else await store.write(c.page, payload(c, c.before), { expected: c.after });
    data.restored.push(i2);
    data.rollback_pending = null;
    await checkpoint();
  }
  data.state = conflicts.length ? "rolling_back" : "rolled_back";
  await checkpoint();
  return result({ conflicts, complete: !conflicts.length });
}
async function extendChanges(store, id, changes, operation) {
  const { data, file } = await readChanges(store, id, "ingest-group");
  requireThat(data.state === "applied", "state", "Finish applying this group before adding curation writes.");
  for (const next of changes) {
    const i2 = data.changes.findIndex((c) => c.page === next.page), current2 = await store.read(next.page);
    requireThat((current2?.sha256 ?? null) === next.expected, "stale", "Curation changed during preparation.");
    if (i2 >= 0) {
      const previous = data.changes[i2];
      requireThat(previous.after === next.expected, "group_changed", "A later edit belongs to another change; do not fold it into this group.", { page: next.page });
      data.changes[i2] = { ...previous, text: next.text, after: await store.services.hash(next.text), apply_expected: next.expected, prior: { after: previous.after, text: previous.text } };
      data.applied = data.applied.filter((n) => n !== i2);
    } else data.changes.push({ page: next.page, before: current2?.text ?? null, expected: next.expected, text: next.text, after: await store.services.hash(next.text), reversible: next.reversible !== false });
  }
  data.details.operations = [...data.details.operations ?? [], operation];
  data.state = "applying";
  data.token = await store.services.hash(JSON.stringify(immutable(data)));
  await persist(store, data, file);
  return operateChanges(store, { id, step: "apply", approved: true }, "ingest-group");
}

// runtime/collection.mjs
var coreFields = new Set("id type status title description class owner related readers language aliases tags generated sources verified stale_after postponed_until postponed_reason resource source_id extraction superseded_by source_created_at source_modified_at generated_at".split(" "));
var fieldFile = "schema/FIELDS.json";
async function readFields(store) {
  const file = await store.read(fieldFile);
  const data = file ? JSON.parse(file.text) : { format: "llmwiki-fields/1", fields: [] };
  requireThat(data.format === "llmwiki-fields/1" && Array.isArray(data.fields) && data.fields.every((f) => typeof f.name === "string") && new Set(data.fields.map((f) => f.name)).size === data.fields.length, "fields", "Invalid field register.");
  return { file, data };
}
var eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
async function assessCollection(store, { folder = "", readers = [] } = {}) {
  relativePath(folder, { root: true });
  const fields = /* @__PURE__ */ new Map(), pages = [], findings = [], ids = /* @__PURE__ */ new Map(), names = /* @__PURE__ */ new Map();
  let register = null;
  const registered = await store.read("schema/TYPES.md");
  try {
    if (registered) register = readRegister(registered.text);
  } catch (e) {
    findings.push({ page: "schema/TYPES.md", code: e.code ?? "ontology", message: e.message });
  }
  let extensions = [];
  try {
    extensions = (await readFields(store)).data.fields;
  } catch (e) {
    findings.push({ page: fieldFile, code: "fields", message: e.message });
  }
  async function visit(dir) {
    let entries;
    try {
      entries = await store.list(dir, { recursive: false });
    } catch (e) {
      findings.push({ page: dir, code: e.code ?? "read", message: e.message });
      return;
    }
    for (const entry of entries) {
      if (entry.kind === "directory") {
        await visit(entry.path);
        continue;
      }
      if (entry.kind !== "file" || !visibleKnowledge(entry.path)) continue;
      try {
        const file = await store.read(entry.path);
        requireThat(file, "missing", "File disappeared during assessment.");
        const parsed = parseDocument(file.text), head = parsed.visibleHead ?? parsed.head;
        pages.push({ page: entry.path, expected: file.sha256, fields: Object.keys(head), readers });
        for (const [field, value] of Object.entries(head)) {
          if (!fields.has(field)) fields.set(field, { field, known: coreFields.has(field) || extensions.some((f) => f.name === field), values: [] });
          const row = fields.get(field);
          for (const item of Array.isArray(value) ? value : [value]) {
            let v = row.values.find((v2) => eq(v2.value, item));
            if (!v) {
              const allowed = field === "type" ? [...register?.genera.keys() ?? []] : field === "status" ? STATUS_VALUES : field === "class" ? [...new Set([...register?.genera.values() ?? []].flatMap((g) => g.classes))] : extensions.find((f) => f.name === field)?.values;
              v = { value: item, count: 0, registered: allowed ? allowed.some((a) => eq(a, item)) : row.known };
              row.values.push(v);
            }
            v.count++;
          }
        }
        if (head.id) {
          const key = String(head.id);
          ids.set(key, [...ids.get(key) ?? [], entry.path]);
        }
        const name = entry.path.split("/").at(-1);
        names.set(name, [...names.get(name) ?? [], entry.path]);
      } catch (e) {
        pages.push({ page: entry.path, error: { code: e.code ?? "read", message: e.message } });
        findings.push({ page: entry.path, code: e.code ?? "read", message: e.message });
      }
    }
  }
  await visit(folder);
  for (const [id, paths] of ids) if (paths.length > 1) findings.push({ code: "duplicate_id", id, pages: paths });
  for (const [name, paths] of names) if (paths.length > 1) findings.push({ code: "ambiguous_name", name, pages: paths });
  const result = { folder, readers, pages, fields: [...fields.values()].sort((a, b) => a.field.localeCompare(b.field)), findings, register_expected: registered?.sha256 ?? null, complete: !findings.length, read_only: true };
  return { ...result, token: await store.services.hash(JSON.stringify(result)) };
}
function inFolder(page, folder) {
  return visibleKnowledge(page) && (!folder || page.startsWith(folder + "/"));
}
async function checkDependencies(store, data) {
  for (const d of data.dependencies) {
    const f = await store.read(d.page);
    requireThat((f?.sha256 ?? null) === d.expected, "stale", "A preview dependency changed.", { page: d.page });
  }
}
async function collectionUpgrade(store, args) {
  const { step = "preview", folder = "", changes, author, stage } = args;
  if (!["preview", "prepare"].includes(step)) return operateChanges(store, args, "upgrade", { check: (d) => checkDependencies(store, d) });
  relativePath(folder, { root: true });
  requireThat(Array.isArray(changes) && changes.length, "changes", "Choose a nonempty stage.");
  for (const c of changes) {
    requireThat(inFolder(c.page, folder), "scope", "A stage changes only Markdown within its chosen folder.");
    const prior = await store.read(c.page), before = prior ? parseDocument(prior.text) : null, after = parseDocument(c.text);
    for (const key of ["id", "resource", "extraction", "source_id", "sources", "generated"]) requireThat(eq(before?.head[key], after.head[key]), "protected", "Upgrade stages preserve identity and provenance.");
    requireThat(!before?.head.resource || before.body === after.body, "source_ingest_required", "Source mirrors are changed only through source.ingest.");
  }
  const preview = await proposal(store, { kind: "upgrade", folder, label: stage, author, changes });
  return step === "prepare" ? prepareChanges(store, preview, args.expected) : preview;
}
function comments(node, result = []) {
  if (!node || typeof node !== "object") return result;
  for (const key of ["commentBefore", "comment"]) if (node[key]) result.push(node[key]);
  for (const item of node.items ?? []) comments(item, result);
  comments(node.contents, result);
  comments(node.key, result);
  comments(node.value, result);
  return result;
}
function retainComments(before, after) {
  const old = comments(parseDocument(before).yaml), remaining = comments(parseDocument(after).yaml), missing3 = [];
  for (const comment of old) {
    const at = remaining.indexOf(comment);
    if (at >= 0) remaining.splice(at, 1);
    else missing3.push(comment);
  }
  if (!missing3.length) return after;
  const p = parseDocument(after);
  return p.prefix + missing3.flatMap((c) => c.split("\n").map((line) => "#" + line + "\n")).join("") + after.slice(p.prefix.length);
}
function renameField(text2, from, to) {
  if (from === to) return text2;
  const p = parseDocument(text2), pair = p.yaml?.contents.items.find((row) => row.key?.value === from);
  requireThat(pair, "mapping", "The mapped field disappeared.");
  requireThat(!Object.hasOwn(p.visibleHead ?? p.head, to), "mapping", "Two fields would overwrite the same meaning.", { field: from, target: to });
  const start2 = p.prefix.length + pair.key.range[0], end = p.prefix.length + pair.key.range[1];
  return text2.slice(0, start2) + to + text2.slice(end);
}
async function mapCollection(store, args) {
  const { step = "preview", folder = "", mappings, author } = args;
  if (!["preview", "prepare"].includes(step)) return operateChanges(store, args, "mapping", { check: (d) => checkDependencies(store, d) });
  const report = await assessCollection(store, { folder });
  requireThat(report.complete, "assessment", "Resolve unreadable or ambiguous files before mapping.", { findings: report.findings });
  requireThat(Array.isArray(mappings) && mappings.length === report.fields.length && new Set(mappings.map((m) => m.field)).size === mappings.length && report.fields.every((f) => mappings.some((m) => m.field === f.field)), "mapping", "Decide every observed field, including explicit keep decisions.", { fields: report.fields });
  const registered = await store.read("schema/TYPES.md");
  requireThat(registered, "ontology", "Initialize a type register before mapping.");
  const register = readRegister(registered.text), { file: fieldRecord, data: fields } = await readFields(store), changes = [], inherited = /* @__PURE__ */ new Set();
  for (const row of report.fields) {
    const m = mappings.find((m2) => m2.field === row.field);
    requireThat(m.to === "keep" || /^[a-z][a-z0-9_]*$/.test(m.to) && !Object.hasOwn(Object.prototype, m.to) && m.to !== "prototype", "mapping", "Choose a valid target field or keep.");
    if (m.to === "keep") continue;
    requireThat(!["id", "resource", "generated", "sources", "extraction", "source_id"].includes(row.field) && !["id", "resource", "generated", "sources", "extraction", "source_id"].includes(m.to), "mapping", "Identity and technical provenance cannot be remapped.");
    requireThat(coreFields.has(m.to) || fields.fields.some((f) => f.name === m.to), "mapping", "Register an extension field before using it.");
    requireThat(Array.isArray(m.values) && row.values.every((v) => m.values.filter((x2) => eq(x2.from, v.value)).length === 1), "mapping", "Decide every observed value; unknown meanings are never guessed.", { field: row.field });
    for (const v of m.values) {
      if (m.to === "type" && !register.genera.has(v.to)) {
        requireThat(m.inherit === true && v.to === v.from && /^[a-z][a-z0-9_-]*$/.test(v.to), "mapping", "Choose a registered type or explicitly retain an inherited type.");
        inherited.add(v.to);
      }
      if (m.to === "status") requireThat(STATUS_VALUES.includes(v.to), "mapping", "Choose a registered status.");
      if (m.to === "class") requireThat([...register.genera.values()].some((g) => g.classes.includes(v.to)), "mapping", "Choose a registered class.");
    }
  }
  for (const page of report.pages) {
    const file = await store.read(page.page);
    requireThat(file.sha256 === page.expected, "stale", "The collection changed.");
    let text2 = file.text;
    const head = parseDocument(text2).visibleHead ?? parseDocument(text2).head;
    for (const m of mappings) {
      if (m.to === "keep" || !Object.hasOwn(head, m.field)) continue;
      const map = (value) => m.values.find((v) => eq(v.from, value)).to;
      let next = Array.isArray(head[m.field]) ? head[m.field].map(map) : map(head[m.field]);
      if (["type", "status", "class"].includes(m.to)) {
        if (Array.isArray(next)) {
          requireThat(Object.hasOwn(m, "value") && next.includes(m.value), "mapping", "Resolve multiple meanings with one explicit value from the mapped choices.", { page: page.page, field: m.field, choices: next });
          next = m.value;
        }
        requireThat(typeof next === "string", "mapping", "A type, class or status is one registered value.");
      }
      text2 = renameField(text2, m.field, m.to);
      if (!eq(head[m.field], next)) text2 = patchHead(text2, { [m.to]: next });
    }
    text2 = retainComments(file.text, text2);
    const resulting = parseDocument(text2).head;
    if (mappings.some((m) => m.to === "class") && resulting.class && register.genera.has(resulting.type)) requireThat(register.genera.get(resulting.type).classes.includes(resulting.class), "mapping", "The selected class does not belong to the selected type.", { page: page.page });
    changes.push({ page: page.page, expected: file.sha256, text: text2 });
  }
  if (inherited.size) {
    let text2 = registered.text;
    const entries = [...inherited].map((name, i2) => "### " + name + "\n\n- Label: " + name + "\n- Question: \n- Order: " + (Math.max(...[...register.genera.values()].map((g) => g.order)) + i2 + 1) + "\n- Classes: \n- Required from stable: \n- Sections: \n- Edges out: \n- Related required: false\n- Stale interval: null\n- Origin: inherited\n\n").join("");
    text2 = text2.replace("## Edges", entries + "## Edges");
    readRegister(text2);
    changes.unshift({ page: "schema/TYPES.md", expected: registered.sha256, text: text2 });
  }
  const dependencies = [{ page: fieldFile, expected: fieldRecord?.sha256 ?? null }, ...inherited.size ? [] : [{ page: "schema/TYPES.md", expected: registered.sha256 }]];
  const preview = await proposal(store, { kind: "mapping", folder, label: "Vocabulary mapping", author, changes, dependencies, details: { mappings, fields: report.fields, adopted_pages: report.pages.map((p) => ({ page: p.page, expected: p.expected })) } });
  return step === "prepare" ? prepareChanges(store, preview, args.expected) : preview;
}

// runtime/participation.mjs
init_document();
init_errors();
init_content();
init_review();
var explanation = "Participation selects an overview. It grants no access and hides no other page in an accessible wiki. An empty overview means no readable page currently participates; agree on participation and actual folder access.";
async function registerParticipation(store, { field, label: label2, author, expected }) {
  nonempty(author, "author");
  nonempty(label2, "overview label");
  requireThat(/^x_[a-z][a-z0-9_]*$/.test(field) && !/(private|privat|secret|geheim|confidential|vertraulich|permission|berechtigung|restricted|geschützt|public|öffentlich)/i.test(field + " " + label2), "participation", "Use a neutral overview name; participation does not control confidentiality.");
  const { file, data } = await readFields(store);
  requireThat((file?.sha256 ?? null) === expected, "stale", "Read the field register before changing it.");
  requireThat(!data.fields.some((f) => f.name === field), "participation", "The field is already registered.");
  data.fields.push({ name: field, label: label2, kind: "participation", type: "boolean", by: author });
  await save(store, fieldFile, JSON.stringify(data, null, 2) + "\n", author, expected);
  return { registered: true, field, explanation, sha256: (await store.read(fieldFile)).sha256 };
}
async function participationMatches(store, head, field) {
  const { data } = await readFields(store);
  return data.fields.some((f) => f.name === field && f.kind === "participation" && f.type === "boolean") && head[field] === true;
}
async function setParticipation(store, { page, field, value, expected, author }) {
  requireThat(typeof value === "boolean" && visibleKnowledge(page), "participation", "Set participation to true or false on a knowledge page.");
  const { data } = await readFields(store);
  requireThat(data.fields.some((f) => f.name === field && f.kind === "participation"), "participation", "Register this participation field first.");
  const file = await store.read(page);
  requireThat(file && file.sha256 === expected, "stale", "The page changed.");
  await save(store, page, patchHead(file.text, { [field]: value }), author, expected);
  return { page, field, value, sha256: (await store.read(page)).sha256, explanation };
}
async function overview(wikis, field) {
  nonempty(field, "participation field");
  const pages = [], findings = [];
  let registered = false;
  for (const wiki2 of wikis) {
    try {
      const { data } = await readFields(wiki2.store);
      if (!data.fields.some((f) => f.name === field && f.kind === "participation")) continue;
      registered = true;
      for (const entry of await wiki2.store.list("")) if (entry.kind === "file" && visibleKnowledge(entry.path)) try {
        const file = await wiki2.store.read(entry.path), p = parseDocument(file.text);
        if (p.head[field] === true) {
          const current2 = await wiki2.store.read(entry.path);
          requireThat(current2?.sha256 === file.sha256, "stale", "Participating page changed.");
          pages.push({ wiki: wiki2.id, page: entry.path, title: p.head.title ?? entry.path, sha256: file.sha256 });
        }
      } catch (e) {
        findings.push({ wiki: wiki2.id, code: e.code ?? "access" });
      }
    } catch (e) {
      findings.push({ wiki: wiki2.id, code: e.code ?? "access" });
    }
  }
  return { field, pages, registered, complete: !findings.length, findings, explanation };
}

// runtime/published.mjs
var import_yaml2 = __toESM(require_dist(), 1);
init_errors();
init_document();
async function adoptPublished(store, args) {
  const { step = "preview", navigation, author } = args;
  if (!["preview", "prepare", "check"].includes(step)) return operateChanges(store, args, "published", { check: async (data2) => {
    for (const dep of data2.dependencies) requireThat((await store.read(dep.page))?.sha256 === dep.expected, "stale", "Publication navigation changed.");
  } });
  relativePath(navigation);
  const config = await store.read(navigation);
  requireThat(config, "navigation", "Choose the existing navigation configuration.");
  const parsed = (0, import_yaml2.parseDocument)(config.text, { uniqueKeys: true });
  requireThat(!parsed.errors.length, "navigation", "Navigation YAML is invalid.");
  const nav = parsed.toJS({ maxAliasCount: 50 });
  requireThat(Array.isArray(nav?.nav), "navigation", "Provide a MkDocs configuration with an explicit nav list; groups are never inferred.");
  const parent = navigation.split("/").slice(0, -1).join("/"), docs = nav.docs_dir ?? "docs";
  const clean = relativePath(docs, { root: true });
  const folder = [parent, clean].filter(Boolean).join("/"), rows = [], seen = /* @__PURE__ */ new Set();
  function walk(items, groups = []) {
    requireThat(Array.isArray(items), "navigation", "Navigation groups must contain lists.");
    for (const item of items) {
      if (typeof item === "string") {
        add3(item, groups);
        continue;
      }
      requireThat(item && typeof item === "object" && !Array.isArray(item) && Object.keys(item).length === 1, "navigation", "Each navigation entry has one label.");
      const [label2, value] = Object.entries(item)[0];
      if (Array.isArray(value)) walk(value, [...groups, label2]);
      else add3(value, groups);
    }
  }
  function add3(value, groups) {
    requireThat(typeof value === "string", "navigation", "A navigation target must be a file or URL.");
    if (/^https?:\/\//.test(value)) return;
    const page = [folder, value.split("#")[0]].filter(Boolean).join("/");
    relativePath(page);
    requireThat(inFolder(page, folder) && !seen.has(page), "navigation", "Only unique existing Markdown pages can be adopted.");
    seen.add(page);
    rows.push({ page, groups, order: rows.length });
  }
  walk(nav.nav);
  requireThat(rows.length, "navigation", "No local Markdown entries are present.");
  const unlisted = (await store.list(folder)).filter((e) => e.kind === "file" && inFolder(e.path, folder) && !seen.has(e.path)).map((e) => e.path), findings = [], changes = [];
  for (const row of rows) {
    const file2 = await store.read(row.page);
    if (!file2) {
      findings.push({ code: "publication_missing", page: row.page });
      continue;
    }
    const head = parseDocument(file2.text).head;
    if (step === "check" && !Object.hasOwn(head, "publication_group")) findings.push({ code: "publication_not_adopted", page: row.page });
    if (Object.hasOwn(head, "publication_group") && (JSON.stringify(head.publication_group) !== JSON.stringify(row.groups) || head.publication_order !== row.order)) findings.push({ code: "publication_drift", page: row.page, document: { groups: head.publication_group, order: head.publication_order }, navigation: { groups: row.groups, order: row.order }, authority: "document" });
    changes.push({ page: row.page, expected: file2.sha256, text: patchHead(file2.text, { publication_group: row.groups, publication_order: row.order }) });
  }
  if (step === "check") return { navigation, pages: rows, unlisted, findings, complete: !findings.length, read_only: true };
  requireThat(!findings.length, "publication_drift", "Document fields are authoritative after adoption. Reconcile the navigation with them.", { findings });
  const { file, data } = await readFields(store);
  for (const field of [{ name: "publication_group", type: "list", kind: "publication" }, { name: "publication_order", type: "number", kind: "publication" }]) {
    const old = data.fields.find((f) => f.name === field.name);
    requireThat(!old || old.kind === field.kind && old.type === field.type, "fields", "A publication field has a conflicting definition.");
    if (!old) data.fields.push(field);
  }
  changes.unshift({ page: fieldFile, expected: file?.sha256 ?? null, text: JSON.stringify(data, null, 2) + "\n" });
  const preview = await proposal(store, { kind: "published", folder, label: "Adopt published structure", author, changes, dependencies: [{ page: navigation, expected: config.sha256 }], details: { navigation, pages: rows, unlisted, publication_unchanged: true, links: "Existing paths and Markdown body bytes are retained." } });
  return step === "prepare" ? prepareChanges(store, preview, args.expected) : preview;
}

// runtime/adapters/vault.mjs
init_errors();
var encode = (bytes3) => {
  let value = "";
  for (let i2 = 0; i2 < bytes3.length; i2 += 8192) value += String.fromCharCode(...bytes3.subarray(i2, i2 + 8192));
  return btoa(value);
};
var payload2 = (change) => change.encoding === "base64" ? Uint8Array.from(atob(change.data), (c) => c.charCodeAt(0)) : change.text;
var OverlayStore = class _OverlayStore {
  constructor(base, state2 = { changes: /* @__PURE__ */ new Map(), directories: /* @__PURE__ */ new Set(), reads: /* @__PURE__ */ new Map() }, prefix = "", writable = base.writable) {
    this.base = base;
    this.state = state2;
    this.root = base.root + "/" + prefix;
    this.prefix = prefix;
    this.writable = writable;
    this.services = base.services;
    this.capabilities = base.capabilities;
  }
  full(p) {
    const clean = relativePath(p, { root: true });
    return this.prefix ? clean ? this.prefix + "/" + clean : this.prefix : clean;
  }
  hostPath(p) {
    return this.base.hostPath ? this.base.hostPath(this.full(p)) : this.full(p);
  }
  editorLocation() {
    return this.prefix ? null : this.base.editorLocation?.();
  }
  async read(p, options = {}) {
    const key = this.full(p), changed = this.state.changes.get(key);
    if (changed) {
      const value2 = payload2(changed), bytes3 = typeof value2 === "string" ? new TextEncoder().encode(value2) : value2;
      return { path: p, ...options.binary ? {} : { text: new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes3) }, bytes: bytes3, size: bytes3.length, sha256: await this.services.hash(bytes3), created_at: null, created_at_basis: "unknown", modified_at: null };
    }
    const value = await this.base.read(key, options);
    if (!this.state.reads.has(key)) this.state.reads.set(key, { expected: value?.sha256 ?? null, text: value?.text ?? null });
    return value;
  }
  async list(p = "", options = {}) {
    const prefix = this.full(p), found = /* @__PURE__ */ new Map();
    try {
      for (const entry of await this.base.list(prefix, options)) found.set(entry.path, entry);
    } catch (e) {
      if (e.code !== "ENOENT" || !this.state.directories.has(prefix)) throw e;
    }
    for (const [key] of this.state.changes) if (!prefix || key.startsWith(prefix + "/")) found.set(key, { path: key, kind: "file" });
    for (const key of this.state.directories) if (key !== prefix && (!prefix || key.startsWith(prefix + "/"))) found.set(key, { path: key, kind: "directory" });
    return [...found.values()].filter((e) => (options.recursive !== false || !e.path.slice(prefix ? prefix.length + 1 : 0).includes("/")) && (options.hidden || !e.path.slice(prefix ? prefix.length + 1 : 0).split("/").some((p2) => p2.startsWith(".")))).map((e) => ({ ...e, path: this.prefix ? e.path.slice(this.prefix.length + 1) : e.path }));
  }
  async mkdir(p) {
    requireThat(this.writable, "read-only", "Sources are read-only.");
    const parts = this.full(p).split("/");
    for (let i2 = 1; i2 <= parts.length; i2++) this.state.directories.add(parts.slice(0, i2).join("/"));
  }
  async write(p, text2, { expected } = {}) {
    requireThat(this.writable, "read-only", "Sources are read-only.");
    requireThat(typeof text2 === "string" || text2 instanceof Uint8Array, "write", "Supply text or bytes.");
    requireThat(typeof text2 === "string" || !this.capabilities.textWritesOnly, "binary_capability", "This host does not offer binary writes.");
    const seen = await this.read(p, { binary: true });
    requireThat((seen?.sha256 ?? null) === expected, "stale", "Prepared write baseline changed.");
    const key = this.full(p), previous = this.state.changes.get(key);
    this.state.changes.set(key, { page: key, expected: previous ? previous.expected : expected, before: previous ? previous.before : seen ? encode(seen.bytes) : null, beforeEncoding: previous ? previous.beforeEncoding : "base64", ...typeof text2 === "string" ? { text: text2 } : { encoding: "base64", data: encode(text2) } });
    const parent = p.split("/").slice(0, -1).join("/");
    if (parent) await this.mkdir(parent);
    return { saved: true, sha256: await this.services.hash(text2) };
  }
  async substore(p, { writable = true } = {}) {
    return new _OverlayStore(this.base, this.state, this.full(p), this.writable && writable);
  }
};
var segmentBytes = 6 * 1024 * 1024;

// runtime/ingest.mjs
init_content();
init_document();
init_errors();
init_review();
init_links();
function originalLink(fromRoot, toRoot, page, name) {
  if (typeof fromRoot !== "string" || typeof toRoot !== "string") return null;
  const from = fromRoot.replace(/\\/g, "/"), to = toRoot.replace(/\\/g, "/");
  const link = markdownLink(from + "/" + page, to + "/" + name, name.split("/").at(-1));
  if (/^[A-Za-z]:\//.test(to) && from.slice(0, 2).toLowerCase() !== to.slice(0, 2).toLowerCase()) {
    const url = "file:///" + to.slice(0, 2) + "/" + (to.slice(3) + "/" + name).split("/").map((p) => encodeURIComponent(p).replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16))).join("/");
    return link.replace(/\]\(.*\)$/, "](" + url + ")");
  }
  return link;
}
var START = "<!-- llmwiki:source:start -->";
var END = "<!-- llmwiki:source:end -->";
async function inventory(source2, { prefix = "", paths } = {}) {
  if (prefix) relativePath(prefix);
  if (paths) {
    requireThat(Array.isArray(paths), "paths", "Select source paths.");
    paths.forEach((p) => relativePath(p));
  }
  const result = [];
  for (const entry of await source2.store.list(prefix)) if (entry.kind === "file" && (!paths || paths.includes(entry.path))) {
    try {
      const f = await source2.store.read(entry.path, { binary: true });
      result.push({ path: entry.path, sha256: f.sha256, size: f.size, created_at: f.created_at, created_at_basis: f.created_at_basis });
    } catch (error) {
      result.push({ path: entry.path, error: error.message });
    }
  }
  return result;
}
async function ingest(wiki2, source2, name, { author, description, extract: extract2, expected, supplement = null, page = null, expectedPage, linkRoot = wiki2.root } = {}) {
  relativePath(name);
  nonempty(author, "author");
  nonempty(description, "description");
  const original = await source2.store.read(name, { binary: true });
  requireThat(original, "source", "The source file is missing.");
  requireThat(original.sha256 === expected, "stale", "The source changed after it was read.");
  for (const entry of await wiki2.list("")) if (entry.kind === "file" && visibleKnowledge(entry.path)) {
    const parsed2 = parseDocument((await wiki2.read(entry.path)).text), resource = parsed2.head.resource;
    if (resource?.store === source2.id && resource?.name === name && resource?.sha256 === original.sha256 && resource.availability !== "missing" && (await sourceIntegrity(wiki2, parsed2)).complete) {
      if (page === entry.path && expectedPage !== void 0) continue;
      return { state: "already", complete: false, source_complete: true, stored: true, page: entry.path, source_id: parsed2.head.id, next: "workflow.start" };
    }
  }
  const reading2 = await extract2({ bytes: original.bytes, name, metadata: original });
  const initialGaps = structuredClone(reading2.gaps), coverage = [];
  if (supplement) {
    requireThat(supplement.sha256 === original.sha256 && Array.isArray(supplement.coverage) && nonempty(supplement.text, "complete host reading", 2e6), "coverage", "Tie the host reading to the original digest and every unresolved part.");
    for (const gap of reading2.gaps) {
      const c = supplement.coverage.find((c2) => c2.code === gap.code && c2.part === (gap.part ?? null) && c2.page === (gap.page ?? null));
      requireThat(c && typeof c.description === "string" && c.description.trim(), "coverage", "The host reading must address every unresolved part.", gap);
      requireThat(["transcription", "visual-description", "decorative"].includes(c.kind) && typeof c.content === "string" && c.content.trim() && supplement.text.includes(c.content), "coverage", "Each unresolved part needs its own content in the host reading and a kind: transcription, visual-description or decorative.", gap);
      coverage.push({ code: gap.code, part: gap.part ?? null, page: gap.page ?? null, kind: c.kind, description: c.description, content: c.content });
    }
    reading2.text = reading2.text ? reading2.text + "\n\n## Host reading of additional content\n\n" + supplement.text : supplement.text;
    reading2.complete = true;
    reading2.gaps = [];
  }
  if (reading2.complete !== true || reading2.gaps.length) return { state: "coverage_required", complete: false, source_complete: false, stored: false, path: name, sha256: original.sha256, coverage: reading2.gaps, next: "source.read" };
  requireThat(reading2.text.trim(), "source_content", "No source content could be read. Preserve a full host reading before ingestion.", { gaps: reading2.gaps });
  requireThat(!reading2.text.includes(START) && !reading2.text.includes(END), "source", "The original contains reserved extraction markers; preserve them as visible escaped text in a complete host reading.");
  const safe = name.split("/").at(-1).replace(/\.md$/i, "").normalize("NFC").replace(/[\[\]#|<>?*]/g, "_");
  page ??= "wiki/" + safe + " \u2014 " + (await wiki2.services.hash(source2.id + "/" + name)).slice(0, 8) + ".md";
  relativePath(page);
  const seen = await wiki2.read(page);
  requireThat(!seen || seen.sha256 === expectedPage, "exists", "Read the existing source page and supply its exact expectedPage digest to repair/update it.", { page });
  const originLink = originalLink(linkRoot, source2.store.root, page, name);
  const stamp2 = wiki2.services.now(), text2 = document(wiki2, {
    type: "source",
    title: name.split("/").at(-1),
    description,
    author,
    head: {
      class: "document",
      resource: { store: source2.id, name, ...originLink ? { link: originLink } : {}, sha256: original.sha256, size: original.size, ...reading2.metadata },
      generated: { at: stamp2, by: author },
      extraction: { complete: reading2.complete, gaps: reading2.gaps, sha256: original.sha256, content_sha256: await wiki2.services.hash(reading2.text), evidence: { format: "llmwiki-reading/1", by: author, at: stamp2, initial_gaps: initialGaps, parts: coverage } },
      related: []
    },
    body: "# " + name.split("/").at(-1) + "\n\n## Worum es geht\n\n" + description + "\n\n## Was daraus \xFCbernommen wurde\n\nVollst\xE4ndiger Quelleninhalt; Einordnung und abgeleitete Erkenntnisse stehen separat.\n\n" + START + "\n## Source content\n\n" + reading2.text + "\n" + END + "\n"
  });
  const parsed = parseDocument(text2);
  let final = text2, sourceId = parsed.head.id;
  if (seen) {
    const prior = parseDocument(seen.text);
    requireThat(prior.head.type === "source" || prior.head.resource, "source", "Only an existing source page can be repaired by ingestion.");
    sourceId = prior.head.source_id ?? prior.head.id;
    nonempty(sourceId, "existing source identifier");
    const begin = "<!-- llmwiki:source:start -->", end = "<!-- llmwiki:source:end -->";
    requireThat(!reading2.text.includes(begin) && !reading2.text.includes(end), "source", "Source text collides with extraction markers; use a host reading with escaped comment markers.");
    const block = begin + "\n## Source content\n\n" + reading2.text + "\n" + end;
    const a = prior.body.indexOf(begin), b = prior.body.indexOf(end);
    requireThat(a < 0 && b < 0 || a >= 0 && b > a, "source", "Existing source extraction markers are malformed.");
    const body = a < 0 ? prior.body.trimEnd() + "\n\n" + block + "\n" : prior.body.slice(0, a) + block + prior.body.slice(b + end.length);
    requireThat(prior.head.resource?.store === source2.id, "source", "A source update must stay within its original source root.");
    if (prior.head.resource.name !== name) {
      requireThat(!await source2.store.read(prior.head.resource.name, { binary: true }), "source", "The old original still exists; ingest this copy as a separate source.");
      parsed.head.resource.previous_names = [.../* @__PURE__ */ new Set([...prior.head.resource.previous_names ?? [], prior.head.resource.name])];
    } else if (prior.head.resource.previous_names) parsed.head.resource.previous_names = prior.head.resource.previous_names;
    const updates = { description, resource: parsed.head.resource, generated: parsed.head.generated, extraction: parsed.head.extraction };
    const head = patchHead(seen.text, updates);
    final = head.slice(0, parseDocument(head).offset) + body;
  }
  requireThat((await source2.store.read(name, { binary: true })).sha256 === expected, "stale", "The original changed while it was read.");
  const record = parseDocument(final), proof = record.head.extraction;
  const evidencePath = ".llmwiki/evidence/" + encodeURIComponent(record.head.id) + "/" + record.head.resource.sha256 + "/" + proof.content_sha256 + ".json", evidenceText = JSON.stringify(proof, null, 2) + "\n", evidence = await wiki2.read(evidencePath);
  if (evidence && evidence.text !== evidenceText) {
    const history2 = ".llmwiki/evidence/" + encodeURIComponent(record.head.id) + "/history/" + await wiki2.services.hash(evidenceText) + ".json";
    if (!await wiki2.read(history2)) await wiki2.write(history2, evidenceText, { expected: null });
  }
  if (!evidence) await wiki2.write(evidencePath, evidenceText, { expected: null });
  final = removeHeadFields(final, ["extraction", "source_id"]);
  await save(wiki2, page, final, author, seen?.sha256 ?? null);
  await refreshIndex(wiki2);
  return { state: "curation_required", complete: false, source_complete: true, stored: true, page, source_id: sourceId, coverage: reading2.gaps, repaired: Boolean(seen), next: "workflow.start" };
}
async function repairOriginalLinks(wiki2, sources, { linkRoot = wiki2.root, author = "maintain-llm-wiki" } = {}) {
  const changed = [], skipped = [];
  for (const e of await wiki2.list("")) if (e.kind === "file" && visibleKnowledge(e.path)) {
    const seen = await wiki2.read(e.path), parsed = parseDocument(seen.text), resource = parsed.head.resource;
    if (!resource) continue;
    const source2 = sources.find((s) => s.id === resource.store);
    if (!source2?.store) {
      skipped.push({ page: e.path, reason: "source_unavailable" });
      continue;
    }
    let original;
    try {
      original = await source2.store.read(resource.name, { binary: true });
    } catch {
    }
    if (original?.sha256 !== resource.sha256) {
      skipped.push({ page: e.path, reason: "original_changed_or_missing" });
      continue;
    }
    const link = originalLink(linkRoot, source2.store.root, e.path, resource.name);
    if (!link || link === resource.link) continue;
    await save(wiki2, e.path, patchHead(seen.text, { resource: { ...resource, link } }), author, seen.sha256);
    changed.push(e.path);
  }
  return { changed, skipped };
}

// runtime/ingest-groups.mjs
init_errors();
init_content();
var decode = (value) => new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(Uint8Array.from(atob(value), (c) => c.charCodeAt(0)));
async function ingestGroup(c, args, { extract: extract2 } = {}) {
  const { step = "preview", sources, author, label: label2 } = args;
  const check = async (data) => {
    for (const dep of data.dependencies) {
      const source2 = c.sources.find((s) => s.id === dep.source);
      requireThat(source2?.store && (await source2.store.read(dep.path, { binary: true }))?.sha256 === dep.expected, "stale", "A group original changed after preview.", { source: dep.source, path: dep.path });
    }
  };
  if (!["preview", "prepare"].includes(step)) return operateChanges(c.work, args, "ingest-group", { check });
  nonempty(author, "author");
  nonempty(label2, "group label");
  requireThat(Array.isArray(sources) && sources.length && sources.length <= 100, "group", "Choose 1\u2013100 source files per group.");
  const selected = [], seen = /* @__PURE__ */ new Set();
  for (const item of sources) {
    relativePath(item.path);
    const source2 = c.sources.find((s) => s.id === item.source);
    requireThat(source2?.store, "access", "Select an assigned readable original folder.");
    const key = JSON.stringify([source2.id, item.path]);
    requireThat(!seen.has(key), "group", "A source may occur only once per group.");
    seen.add(key);
    const file = await source2.store.read(item.path, { binary: true });
    requireThat(file, "source", "An original is missing.");
    selected.push({ source: source2.id, path: item.path, expected: file.sha256, description: item.description ?? label2, ...item.page ? { page: item.page } : {}, ...item.expectedPage ? { expectedPage: item.expectedPage } : {}, ...item.supplement ? { supplement: item.supplement } : {} });
  }
  const token = await c.work.services.hash(JSON.stringify({ label: label2, author, sources: selected, connection: c.connection, wiki: c.wiki, work: c.workFolder }));
  if (step === "preview") return { token, readers: c.wiki.readers, sources: selected, complete: false, read_only: true, next: "prepare then review the exact changes before apply; no original or knowledge file has changed" };
  requireThat(args.expected === token, "stale_preview", "The selected group changed; review it again.");
  const overlay = new OverlayStore(c.work), outputs = [];
  for (const item of selected) {
    const source2 = c.sources.find((s) => s.id === item.source);
    outputs.push(await ingest(overlay, source2, item.path, { ...item, author, extract: extract2, linkRoot: c.remote.root }));
  }
  const changes = [];
  for (const row of overlay.state.changes.values()) {
    if (row.page === "wiki/index.md" || row.page.startsWith(".llmwiki/graph") || row.page.startsWith(".llmwiki/derived-relations/")) continue;
    requireThat(typeof row.text === "string", "group", "Only text knowledge writes belong to an ingestion group.");
    const before = row.before === null ? null : decode(row.before);
    if (before !== row.text) changes.push({ page: row.page, expected: row.expected, text: row.text, reversible: visibleKnowledge(row.page) || row.page.startsWith(".llmwiki/workflows/") });
  }
  const preview = await proposal(c.work, { kind: "ingest-group", label: label2, author, changes, dependencies: selected.map((s) => ({ source: s.source, path: s.path, expected: s.expected })), details: { sources: selected, outputs, readers: c.wiki.readers, semantic_complete: false, next: "workflow.start; a complete source mirror is not completed semantic integration" } });
  const plan2 = await prepareChanges(c.work, preview, preview.token);
  return { ...plan2, changes: preview.changes.map((c2) => ({ page: c2.page, before: c2.before, after: c2.text, reversible: c2.reversible })), outputs };
}
async function recordGroupOperation(c, args, run) {
  const { data } = await readChanges(c.work, args.group, "ingest-group");
  requireThat(data.state === "applied", "state", "Finish or resume the current group before curation.");
  const overlay = new OverlayStore(c.work), result = await run(overlay), changes = [];
  for (const row of overlay.state.changes.values()) {
    if (row.page === "wiki/index.md" || row.page.startsWith(".llmwiki/graph") || row.page.startsWith(".llmwiki/derived-relations/")) continue;
    requireThat(typeof row.text === "string", "group", "Group curation retains text writes.");
    changes.push({ page: row.page, expected: row.expected, text: row.text, reversible: visibleKnowledge(row.page) || row.page.startsWith(".llmwiki/workflows/") });
  }
  const group = await extendChanges(c.work, args.group, changes, { action: args.action, author: args.author ?? null });
  return { ...result, group };
}

// runtime/sharing.mjs
init_links();
init_project2();
init_document();
init_ontology();
init_graph();
init_content();
init_errors();
init_review();
var facade = (source2, target) => ({ services: source2.services, writable: source2.writable && target.writable, capabilities: target.capabilities, reviewStore: (p) => p.startsWith("target/") ? { store: target, page: p.slice(7) } : { store: source2, page: p.startsWith("source/") ? p.slice(7) : p }, hostPath: (p) => p.startsWith("target/") ? target.hostPath?.(p.slice(7)) ?? p.slice(7) : source2.hostPath?.(p.startsWith("source/") ? p.slice(7) : p) ?? p, read: (p, o) => p.startsWith("target/") ? target.read(p.slice(7), o) : source2.read(p.startsWith("source/") ? p.slice(7) : p, o), write: (p, t, o) => p.startsWith("target/") ? target.write(p.slice(7), t, o) : source2.write(p.startsWith("source/") ? p.slice(7) : p, t, o) });
function clearance(text2, page) {
  const findings = sync.contentClearance(text2, page);
  requireThat(!findings.length, "clearance", "Resolve the sharing findings before transferring this page.", { findings });
}
function scopedText(source2, page, sourceWiki, targetWiki, targetPage, graph, assets) {
  const p = parseDocument(source2), origin = { wiki: sourceWiki, path: page };
  const link = (whole, written, label2) => {
    if (assets.has(written)) return markdownLink(targetPage, assets.get(written), label2);
    const resolved = resolvePage(graph, origin, written), target = graph.pages.get(resolved.key);
    if (!target) return whole;
    const self = target.wiki === sourceWiki && target.path === page;
    const href = (self ? targetWiki : target.wiki) + "/" + (self ? targetPage : target.path);
    return "[" + (label2 || "Referenced document").replace(/[\[\]|\r\n]/g, " ") + "](" + href.split("/").map((part) => encodeURIComponent(part).replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16))).join("/") + (written.includes("#") ? "#" + written.split("#").slice(1).join("#") : "") + ")";
  };
  const convert = (text2) => mapAuthored(text2, (part) => part.replace(/(`+)[^\n]*?\1|\[\[([^\]]+)\]\]|\[([^\]]*)\]\(<?([^\s)>]+)>?\)/g, (whole, code, wiki2, label2, url) => code ? whole : wiki2 ? link(whole, wiki2.split("|")[0], wiki2.split("|")[1]) : link(whole, url, label2)));
  let result = source2;
  for (const key of ["related", "superseded_by"]) if (Array.isArray(p.head[key])) result = patchHead(result, { [key]: p.head[key].map((v) => typeof v === "string" ? convert(v) : v) });
  const updated = parseDocument(result);
  return result.slice(0, updated.offset) + convert(updated.body);
}
async function transfer(root, c, args, options) {
  const { step = "preview" } = args;
  let details;
  if (!["preview", "prepare"].includes(step)) details = (await readChanges(c.work, args.id, "transfer")).data.details;
  const target = await context(root, details?.target.connection ?? args.target_connection, options);
  requireThat(c.wiki.id !== target.wiki.id && c.work.root !== target.work.root, "transfer", "Choose another wiki and working folder.");
  requireThat(c.canPublish && target.canPublish, "read-only", "Both wiki connections need write permission for a transfer.");
  const combined = facade(c.work, target.work);
  const check = async (data) => {
    requireThat(JSON.stringify(data.details.source.readers) === JSON.stringify(c.wiki.readers) && JSON.stringify(data.details.target.readers) === JSON.stringify(target.wiki.readers) && data.details.source.work === c.workFolder.id && data.details.target.work === target.workFolder.id, "stale", "The source, target or reader circle changed.");
    for (const asset of data.details.assets ?? []) requireThat((await c.work.read(asset.source, { binary: true }))?.sha256 === asset.expected, "stale", "A transferred attachment changed.");
    requireThat((await target.work.read("schema/TYPES.md"))?.sha256 === data.details.target_register, "stale", "The target vocabulary changed.");
    for (const change of data.changes) if (change.page.startsWith("target/") && change.encoding !== "base64") clearance(change.text, change.page);
  };
  if (!["preview", "prepare"].includes(step)) {
    requireThat(step !== "rollback", "transfer", "A completed transfer is reversed with a new transfer preview to the original wiki.");
    return operateChanges(combined, args, "transfer", { check });
  }
  const { page, target_page, author } = args;
  relativePath(page);
  relativePath(target_page);
  requireThat(visibleKnowledge(page) && visibleKnowledge(target_page) && !["WIKI.md", "wiki/index.md", "wiki/bundle.md"].includes(page), "transfer", "Choose a knowledge page.");
  const original = await c.work.read(page);
  requireThat(original, "missing", "The page is missing.");
  const parsed = parseDocument(original.text);
  requireThat(parsed.head.id && !parsed.head.llmwiki_redirect, "transfer", "The page must carry one canonical identity.");
  const destination = await target.work.read(target_page), redirectTarget = destination ? parseDocument(destination.text).head.llmwiki_redirect : null;
  requireThat(!destination || redirectTarget?.wiki === c.wiki.id && redirectTarget?.id === parsed.head.id, "exists", "The destination is occupied. Only this content\u2019s own neutral redirect may be replaced.");
  const reg = await target.work.read("schema/TYPES.md");
  requireThat(reg && readRegister(reg.text).genera.has(parsed.head.type), "ontology", "Register this document type in the destination first.");
  if (parsed.head.resource) requireThat(target.sources.some((s) => s.id === parsed.head.resource.store && s.store), "source_scope", "Connect the same original source folder in the target before transferring a source page.");
  const graph = await buildGraph([{ id: c.wiki.id, store: c.work }, { id: target.wiki.id, store: target.work }]);
  requireThat(!graph.findings.some((f) => f.code === "duplicate_id") && !graph.failures.length, "transfer", "Resolve identity/read failures before transfer.");
  const assets = /* @__PURE__ */ new Map(), assetRows = [], assetChanges = [];
  const normalize2 = (value) => {
    const result2 = [];
    for (const p of value.split("/")) {
      if (p === "..") {
        if (!result2.length) return null;
        result2.pop();
      } else if (p && p !== ".") result2.push(p);
    }
    return result2.join("/");
  };
  let authored2 = "";
  mapAuthored(parsed.body, (part) => {
    authored2 += part;
    return part;
  });
  const originalTargets = new Set(bodyLinks(parsed.head.resource?.link ?? "").map((l) => l.written));
  for (const link of bodyLinks(authored2)) {
    if (originalTargets.has(link.written)) continue;
    const written = link.written;
    if (!/\.(?:png|jpe?g|gif|webp|avif|svg|pdf|excalidraw)(?:#.*)?$/i.test(written) || /^(?:[a-z][a-z0-9+.-]*:|\/)/i.test(written)) continue;
    const decoded = decodeURIComponent(written.split("#")[0]), relative = normalize2(page.split("/").slice(0, -1).concat(decoded).join("/"));
    requireThat(relative, "attachment_scope", "An attachment outside this work folder needs an explicit source connection.");
    let source2 = relative, file = await c.work.read(source2, { binary: true });
    if (!file && !decoded.startsWith(".")) {
      source2 = decoded;
      relativePath(source2);
      file = await c.work.read(source2, { binary: true });
    }
    requireThat(file, "attachment", "A linked attachment is missing.", { page: source2 });
    const targetPath = [...target_page.split("/").slice(0, -1), "assets", file.sha256.slice(0, 16) + "-" + source2.split("/").at(-1)].join("/"), prior = await target.work.read(targetPath, { binary: true });
    requireThat(!prior || prior.sha256 === file.sha256, "exists", "An attachment destination differs.");
    assets.set(written, targetPath);
    if (!assetRows.some((a) => a.source === source2)) {
      assetRows.push({ source: source2, target: targetPath, expected: file.sha256 });
      assetChanges.push({ page: "target/" + targetPath, expected: prior?.sha256 ?? null, text: encodeBytes(file.bytes), encoding: "base64", copy_from: "source/" + source2 });
    }
  }
  let text2 = scopedText(original.text, page, c.wiki.id, target.wiki.id, target_page, graph, assets);
  if (parsed.head.resource) {
    const source2 = target.sources.find((s) => s.id === parsed.head.resource.store), link = originalLink(target.remote.root, source2.store.root, target_page, parsed.head.resource.name);
    if (link) {
      const previous = parsed.head.resource.link;
      text2 = patchHead(text2, { resource: { ...parsed.head.resource, link } });
      if (previous) {
        const p = parseDocument(text2);
        text2 = text2.slice(0, p.offset) + mapAuthored(p.body, (part) => part.split(previous).join(link));
      }
    }
  }
  clearance(text2, page);
  const redirect = newDocument({ llmwiki_redirect: { wiki: target.wiki.id, id: parsed.head.id } }, "[Moved document](" + target.wiki.id + "/" + parsed.head.id + ")\n");
  const trace = { format: "llmwiki-transfer/1", source: { connection: c.connection.id, wiki: c.wiki.id, page, work: c.workFolder.id, readers: c.wiki.readers }, target: { connection: target.connection.id, wiki: target.wiki.id, page: target_page, work: target.workFolder.id, readers: target.wiki.readers }, id: parsed.head.id, author, at: args.at ?? c.work.services.now(), expected: original.sha256, assets: assetRows, target_register: reg.sha256 };
  const traceName = await c.work.services.hash(JSON.stringify(trace)), changes = [...assetChanges, { page: "target/" + target_page, expected: destination?.sha256 ?? null, text: text2 }, { page: "source/" + page, expected: original.sha256, text: redirect }];
  if (parsed.head.resource) {
    for (const e of await c.work.list(".llmwiki/evidence/" + encodeURIComponent(parsed.head.id), { hidden: true })) {
      if (e.kind !== "file") continue;
      const file = await c.work.read(e.path);
      clearance(file.text, e.path);
      const prior = await target.work.read(e.path);
      requireThat(!prior || prior.sha256 === file.sha256, "evidence", "Destination evidence differs.");
      if (!prior) changes.unshift({ page: "target/" + e.path, expected: null, text: file.text });
    }
  }
  for (const side of ["source", "target"]) {
    const shared = side === "source" ? { ...trace, target: Object.fromEntries(Object.entries(trace.target).filter(([key]) => key !== "page")), assets: trace.assets.map(({ source: source2, expected }) => ({ source: source2, expected })) } : trace;
    const text3 = JSON.stringify({ ...shared, transfer: traceName });
    changes.push({ page: side + "/.llmwiki/transfers/" + await c.work.services.hash(text3) + ".json", expected: null, text: text3 });
  }
  const preview = await proposal(combined, { kind: "transfer", label: "Transfer one canonical page", author, changes, details: trace });
  const result = { ...preview, at: trace.at, source: trace.source, target: trace.target, losing_access: c.wiki.readers.filter((r) => !target.wiki.readers.includes(r)), gaining_access: target.wiki.readers.filter((r) => !c.wiki.readers.includes(r)), warning: "The target folder controls the new reader circle. Approval transfers the complete page. Old links reveal no target title to readers without target access." };
  return step === "prepare" ? prepareChanges(combined, preview, args.expected) : result;
}

// runtime/shadow.mjs
init_document();
init_errors();
var SHADOW_FORMAT = "llmwiki-shadow/1";
var PARSER_VERSION = "markdown-structure/2";
var hashKey = (services, ...parts) => services.hash(JSON.stringify(parts));
async function parseShadow(source2, services, { maxBytes = 8 * 1024 * 1024 } = {}) {
  requireThat(typeof source2 === "string", "shadow_source", "Supply Markdown text.");
  const bytes3 = new TextEncoder().encode(source2);
  requireThat(bytes3.length <= maxBytes, "shadow_limit", "This document exceeds the structural indexing budget.");
  const parsed = parseDocument(source2), revision = await services.hash(bytes3), lines = [];
  let offset = parsed.offset;
  for (const raw of parsed.body.match(/[^\n]*\n|[^\n]+$/g) ?? []) {
    const original = raw.replace(/\r?\n$/, ""), text2 = offset === 0 ? original.replace(/^\uFEFF/, "") : original;
    lines.push({ text: text2, start: offset, end: offset + original.length });
    offset += raw.length;
  }
  const byteAt = new Uint32Array(source2.length + 1), unicodeAt = new Uint32Array(source2.length + 1), lineAt = new Uint32Array(source2.length + 1);
  let b = 0, u = 0, line = 1;
  for (let i2 = 0; i2 < source2.length; ) {
    const cp = source2.codePointAt(i2), width = cp > 65535 ? 2 : 1;
    byteAt[i2] = b;
    unicodeAt[i2] = u;
    lineAt[i2] = line;
    if (width === 2) {
      byteAt[i2 + 1] = b;
      unicodeAt[i2 + 1] = u;
      lineAt[i2 + 1] = line;
    }
    b += cp <= 127 ? 1 : cp <= 2047 ? 2 : cp <= 65535 ? 3 : 4;
    u++;
    if (cp === 10) line++;
    i2 += width;
  }
  byteAt[source2.length] = b;
  unicodeAt[source2.length] = u;
  lineAt[source2.length] = line;
  const blocks = [], headings = [];
  const atx = (text2) => /^ {0,3}(#{1,6})[ \t]+(.+?)[ \t]*#*[ \t]*$/.exec(text2);
  const fence = (text2) => /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(text2);
  const list = (text2) => /^\s*(?:[-+*]|\d+[.)])[ \t]+/.test(text2);
  const tableRule = (text2) => /^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(text2);
  const special = (i2) => !lines[i2]?.text.trim() || atx(lines[i2].text) || fence(lines[i2].text) || /^\s*<!--/.test(lines[i2].text) || list(lines[i2].text);
  for (let i2 = 0; i2 < lines.length; ) {
    if (!lines[i2].text.trim()) {
      i2++;
      continue;
    }
    if (/^\s*<!--/.test(lines[i2].text)) {
      while (i2 < lines.length && !lines[i2++].text.includes("-->")) {
      }
      continue;
    }
    const first = i2, h = atx(lines[i2].text), f = fence(lines[i2].text), setext = lines[i2 + 1] && /^ {0,3}(=+|-+)\s*$/.exec(lines[i2 + 1].text);
    let kind = "paragraph";
    if (h || setext) {
      kind = "heading";
      const depth = h ? h[1].length : setext[1][0] === "=" ? 1 : 2;
      headings.length = depth - 1;
      headings[depth - 1] = h ? h[2] : lines[i2].text.trim();
      i2 += h ? 1 : 2;
    } else if (f) {
      kind = "code";
      i2++;
      while (i2 < lines.length) {
        const end2 = fence(lines[i2++].text);
        if (end2 && end2[1][0] === f[1][0] && end2[1].length >= f[1].length && !end2[2].trim()) break;
      }
    } else if (tableRule(lines[i2 + 1]?.text ?? "")) {
      kind = "table";
      i2 += 2;
      while (i2 < lines.length && lines[i2].text.trim() && lines[i2].text.includes("|")) i2++;
    } else if (list(lines[i2].text)) {
      kind = "list";
      i2++;
      while (i2 < lines.length && lines[i2].text.trim() && !atx(lines[i2].text) && !fence(lines[i2].text)) i2++;
    } else {
      if (/^\s*(?:!\[[^\]]*\]\([^\n]*\)|!\[\[[^\n]+\]\])\s*$/.test(lines[i2].text)) kind = "image";
      i2++;
      while (i2 < lines.length && !special(i2) && !/^ {0,3}(=+|-+)\s*$/.test(lines[i2].text) && !tableRule(lines[i2 + 1]?.text ?? "")) i2++;
    }
    const start2 = lines[first].start, end = lines[i2 - 1].end, quote3 = source2.slice(start2, end);
    blocks.push({ kind, start: start2, end, byte_start: byteAt[start2], byte_end: byteAt[end], unicode_start: unicodeAt[start2], unicode_end: unicodeAt[end], line_start: lineAt[start2], line_end: lineAt[end], quote: quote3, headings: headings.filter(Boolean), text_hash: await hashKey(services, kind, quote3), occurrence: await hashKey(services, PARSER_VERSION, revision, start2, end) });
  }
  for (let i2 = 0; i2 < blocks.length; i2++) {
    blocks[i2].previous = blocks[i2 - 1]?.occurrence ?? null;
    blocks[i2].next = blocks[i2 + 1]?.occurrence ?? null;
  }
  return { format: SHADOW_FORMAT, parser: PARSER_VERSION, revision, bytes: bytes3.length, source: source2, blocks };
}
async function matchBlocks(previous, blocks, services) {
  const old = /* @__PURE__ */ new Map(), fresh = /* @__PURE__ */ new Map();
  for (const [items, map] of [[previous, old], [blocks, fresh]]) for (const item of items) {
    const found = map.get(item.text_hash) ?? [];
    found.push(item);
    map.set(item.text_hash, found);
  }
  const result = [];
  for (const block of blocks) {
    const candidates = old.get(block.text_hash) ?? [], unique = candidates.length === 1 && fresh.get(block.text_hash).length === 1;
    result.push({ ...block, id: unique ? candidates[0].id : services.uuid(), mapping: unique ? "unchanged" : candidates.length ? "ambiguous" : "new", predecessors: candidates.map((b) => b.id) });
  }
  const oldIndex = new Map(previous.map((p, i2) => [p.id, i2]));
  let left = null;
  for (let right = 0; right < result.length; right++) if (result[right].mapping === "unchanged") {
    if (left !== null) {
      const a = oldIndex.get(result[left].id), b = oldIndex.get(result[right].id), fresh2 = result.slice(left + 1, right), old2 = previous.slice(a + 1, b);
      if (b > a && fresh2.length > 0 && fresh2.length <= 32 && old2.length > 0 && old2.length <= 32 && fresh2.every((x2) => x2.mapping === "new")) for (const block of fresh2) {
        const candidates = old2.filter((p) => p.kind === block.kind && !result.some((r) => r.id === p.id));
        if (candidates.length) {
          block.mapping = "candidate";
          block.predecessors = candidates.map((p) => p.id);
          block.candidate_basis = "unchanged_neighbors";
        }
      }
    }
    left = right;
  }
  for (const block of result) if (previous.length && block.mapping === "new") block.mapping = "unresolved";
  return result;
}
function makeLocator(wiki2, document2, revision, block, range = {}) {
  requireThat(revision.source.slice(block.start, block.end) === block.quote, "shadow_selector", "The quote does not match its original selector.");
  const start2 = range.start ?? block.start, end = range.end ?? block.end, source2 = revision.source;
  const boundary = (i2) => !(i2 > 0 && i2 < source2.length && /[\uD800-\uDBFF]/.test(source2[i2 - 1]) && /[\uDC00-\uDFFF]/.test(source2[i2]));
  requireThat(Number.isSafeInteger(start2) && Number.isSafeInteger(end) && start2 >= block.start && end <= block.end && end > start2 && boundary(start2) && boundary(end), "shadow_selector", "Select a nonempty original range within this block.");
  const partial = start2 !== block.start || end !== block.end, quote3 = source2.slice(start2, end), before = source2.slice(0, start2), through = source2.slice(0, end);
  return {
    format: SHADOW_FORMAT,
    wiki: wiki2,
    document: document2,
    revision: revision.revision,
    parser: revision.parser,
    block: block.id,
    occurrence: block.occurrence,
    quote: quote3,
    start: start2,
    end,
    byte_start: partial ? new TextEncoder().encode(before).length : block.byte_start,
    byte_end: partial ? new TextEncoder().encode(through).length : block.byte_end,
    unicode_start: partial ? [...before].length : block.unicode_start,
    unicode_end: partial ? [...through].length : block.unicode_end,
    line_start: partial ? before.split("\n").length : block.line_start,
    line_end: partial ? through.split("\n").length : block.line_end,
    headings: block.headings,
    prefix: source2.slice(Math.max(0, start2 - 80), start2),
    suffix: source2.slice(end, end + 80),
    ...partial ? { partial: true, block_start: block.start, block_end: block.end } : {}
  };
}
function resolveLocator(locator, current2) {
  requireThat(locator?.format === SHADOW_FORMAT && typeof locator.quote === "string" && Number.isInteger(locator.start) && Number.isInteger(locator.end) && locator.end > locator.start, "shadow_selector", "Invalid quote selector.");
  if (!current2) return { state: "unavailable", quote: locator.quote, current: null };
  if (current2.revision === locator.revision) {
    requireThat(current2.source.slice(locator.start, locator.end) === locator.quote, "shadow_selector", "The quote does not match its original selector.");
    return { state: "current", quote: locator.quote, current: { start: locator.start, end: locator.end, id: locator.block } };
  }
  const successors = current2.blocks.filter((b) => b.id === locator.block).map((b) => {
    if (!locator.partial) return b;
    const start2 = b.start + locator.start - locator.block_start, end = start2 + locator.quote.length;
    return Number.isInteger(start2) && start2 >= b.start && end <= b.end && current2.source.slice(start2, end) === locator.quote ? { ...b, start: start2, end, quote: locator.quote } : null;
  }).filter(Boolean), candidates = current2.blocks.filter((b) => b.predecessors?.includes(locator.block));
  return { state: "historical", quote: locator.quote, current: successors.length === 1 ? successors[0] : null, successor_state: successors.length === 1 ? "unchanged" : candidates.length ? "ambiguous" : "missing", candidates: candidates.map((b) => ({ id: b.id, start: b.start, end: b.end, mapping: b.mapping, basis: b.candidate_basis ?? null })) };
}

// runtime/shadow-project.mjs
init_errors();

// runtime/shadow-exchange.mjs
init_errors();
var IDENTITY_FRAGMENTS = "llmwiki-shadow-identities/2";
var bytes = (text2) => new TextEncoder().encode(text2).length;
var hex2 = (value) => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
async function identityPackages(wiki2, records, services, { maxBatchBytes = 512 * 1024 } = {}) {
  requireThat(Number.isSafeInteger(maxBatchBytes) && maxBatchBytes >= 4096 && maxBatchBytes <= 8 * 1024 * 1024, "shadow_exchange_budget", "Choose a transport package budget between 4 KiB and 8 MiB.", { budget: "maxBatchBytes", limit: maxBatchBytes, next: "Use the default; documents are split automatically. Do not remove Markdown or shared identities." });
  const result = [], serialize = (documents) => JSON.stringify({ format: SHADOW_FORMAT, kind: "identities", wiki: wiki2, documents });
  let group = [], groupBytes = bytes(serialize([]));
  const flush = () => {
    if (group.length) result.push(serialize(group));
    group = [];
    groupBytes = bytes(serialize([]));
  };
  for (const document2 of records) {
    const recordText = JSON.stringify(document2), recordBytes = bytes(recordText);
    if (bytes(serialize([document2])) <= maxBatchBytes) {
      if (group.length >= 1e3 || groupBytes + recordBytes + (group.length ? 1 : 0) > maxBatchBytes) flush();
      groupBytes += recordBytes + (group.length ? 1 : 0);
      group.push(document2);
      continue;
    }
    flush();
    const { blocks, ...meta } = document2, record = await services.hash(recordText), chunks = [];
    let chunk = [];
    const encode3 = (blocks2, part, total) => JSON.stringify({ format: IDENTITY_FRAGMENTS, kind: "identities", wiki: wiki2, fragments: [{ record, part, total, blocks_total: document2.blocks.length, document: { ...meta, blocks: blocks2 } }] });
    const overhead = bytes(encode3([], 2e4, 2e4));
    let size = overhead;
    for (const block of blocks) {
      const n = bytes(JSON.stringify(block));
      requireThat(overhead + n <= maxBatchBytes, "shadow_exchange_budget", "A single block identity exceeds the transport budget.", { wiki: wiki2, path: document2.path, budget: "maxBatchBytes", bytes: overhead + n, limit: maxBatchBytes, next: "Report this identity size; preserve Markdown and shared identities. Rebuild and cache_bytes do not fix transport limits." });
      if (chunk.length && size + n + 1 > maxBatchBytes) {
        chunks.push(chunk);
        chunk = [];
        size = overhead;
      }
      size += n + (chunk.length ? 1 : 0);
      chunk.push(block);
    }
    if (chunk.length) chunks.push(chunk);
    requireThat(chunks.length > 0, "shadow_exchange_budget", "Document metadata exceeds the transport budget.", { wiki: wiki2, path: document2.path, budget: "maxBatchBytes", bytes: recordBytes, limit: maxBatchBytes });
    chunks.forEach((blocks2, part) => result.push(encode3(blocks2, part, chunks.length)));
  }
  flush();
  return result;
}
async function assembleIdentities(packages, services) {
  const records = [], groups = /* @__PURE__ */ new Map(), findings = [];
  for (const data of packages) {
    if (data.format === SHADOW_FORMAT) {
      requireThat(Array.isArray(data.documents) && data.documents.length <= 1e3, "shadow_history", "Invalid identity package.");
      records.push(...data.documents);
      continue;
    }
    requireThat(data.format === IDENTITY_FRAGMENTS && Array.isArray(data.fragments) && data.fragments.length > 0 && data.fragments.length <= 1e3, "shadow_history", "Unsupported identity package version. Update both skills and the editor; retain all shared files.");
    for (const part of data.fragments) {
      requireThat(hex2(part.record) && Number.isSafeInteger(part.part) && Number.isSafeInteger(part.total) && part.total > 0 && part.total <= 2e4 && part.part >= 0 && part.part < part.total && Number.isSafeInteger(part.blocks_total) && part.blocks_total > 0 && part.blocks_total <= 2e4 && Array.isArray(part.document?.blocks) && part.document.blocks.length > 0 && part.document.blocks.length <= part.blocks_total, "shadow_history", "Invalid identity fragment.");
      const { blocks, ...meta } = part.document, signature = JSON.stringify([part.total, part.blocks_total, meta]), group = groups.get(part.record) ?? { signature, parts: /* @__PURE__ */ new Map(), meta, total: part.total, blocks_total: part.blocks_total };
      requireThat(group.signature === signature, "shadow_history", "Conflicting identity fragments. Retain the packages for reconciliation.");
      const previous = group.parts.get(part.part);
      requireThat(!previous || JSON.stringify(previous) === JSON.stringify(blocks), "shadow_history", "Conflicting duplicate identity fragment.");
      group.parts.set(part.part, blocks);
      groups.set(part.record, group);
    }
  }
  for (const [hash, group] of groups) {
    if (group.parts.size !== group.total) {
      findings.push({ code: "shadow_exchange_incomplete", page: group.meta.path, revision: group.meta.revision, record: hash, received: group.parts.size, expected: group.total, message: "Identity transfer is incomplete; refresh or finish sync. Preserve every existing package." });
      continue;
    }
    const blocks = [];
    for (let i2 = 0; i2 < group.total; i2++) blocks.push(...group.parts.get(i2));
    const record = { ...group.meta, blocks };
    requireThat(blocks.length === group.blocks_total && await services.hash(JSON.stringify(record)) === hash, "shadow_history", "Reassembled identity checksum is invalid.");
    records.push(record);
  }
  return { records: [...new Map(records.map((r) => [JSON.stringify(r), r])).values()], findings };
}

// runtime/shadow-project.mjs
init_graph();
var CHANGES = ".llmwiki/shadow/changes";
var PINS = ".llmwiki/shadow/pins";
var hex3 = (value) => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
var eligible = (path7) => /\.md$/i.test(path7) && !navigationPage(path7) && !path7.split("/").some((p) => p.startsWith(".") || p.startsWith("~$")) && !/^(schema|meta|notices|vermerke)\//.test(path7);
var missing2 = (e) => e.code === "ENOENT" || e.name === "NotFoundError";
async function files(store, prefix) {
  try {
    return (await store.list(prefix, { hidden: true })).filter((e) => e.kind === "file");
  } catch (e) {
    if (missing2(e)) return [];
    throw e;
  }
}
var issue = (wiki2, error, page) => ({ wiki: wiki2, ...page ? { page } : {}, code: error.code ?? "shadow_read", message: error.message, ...error.details ? { details: error.details } : {} });
function scopes(wikis) {
  requireThat(Array.isArray(wikis) && new Set(wikis.map((w) => w.id)).size === wikis.length, "shadow_scope", "Select unique accessible wikis.");
}
async function history(wiki2, { maxBytes = 32 * 1024 * 1024 } = {}) {
  const entries = await files(wiki2.store, CHANGES);
  requireThat(entries.length <= 8192, "shadow_history_budget", "The identity history exceeds its scan budget.");
  const packages = [];
  let size = 0;
  for (const entry of entries) {
    const name = entry.path.slice(CHANGES.length + 1);
    requireThat(/^[a-f0-9]{64}\.json$/.test(name), "shadow_history", "Invalid identity package name.");
    const file = await wiki2.store.read(entry.path);
    requireThat(file, "shadow_history", "An identity package disappeared.");
    size += file.size ?? new TextEncoder().encode(file.text).length;
    requireThat(size <= maxBytes, "shadow_history_budget", "The identity history exceeds its byte budget.");
    requireThat(await wiki2.store.services.hash(file.text) === name.slice(0, -5), "shadow_history", "An identity package checksum is invalid.");
    const data = JSON.parse(file.text);
    requireThat(data.kind === "identities" && data.wiki === wiki2.id, "shadow_history", "Invalid identity package scope.");
    packages.push(data);
  }
  const result = await assembleIdentities(packages, wiki2.store.services);
  for (const record of result.records) {
    relativePath(record.path);
    requireThat(eligible(record.path) && hex3(record.id) && (record.revision === null || hex3(record.revision)) && Array.isArray(record.blocks) && record.blocks.length <= 2e4, "shadow_history", "Invalid document identity.");
    for (const block of record.blocks) requireThat(hex3(block.id) && hex3(block.text_hash) && hex3(block.occurrence) && Number.isInteger(block.start) && Number.isInteger(block.end) && block.start >= 0 && block.end > block.start, "shadow_history", "Invalid block identity.");
  }
  const current2 = new Set(result.records.filter((r) => r.parser === PARSER_VERSION).map((r) => JSON.stringify([r.id, r.path, r.revision])));
  result.records = result.records.filter((r) => r.parser === PARSER_VERSION || !current2.has(JSON.stringify([r.id, r.path, r.revision])));
  return result;
}
function identityRecord(row, previous) {
  return {
    id: row.id,
    path: row.path,
    revision: row.revision,
    parser: PARSER_VERSION,
    previous_revision: previous?.revision ?? null,
    previous_path: previous?.path ?? null,
    blocks: row.data.blocks.map(({ id, kind, text_hash, occurrence, start: start2, end, mapping, predecessors, candidate_basis }) => ({ id, kind, text_hash, occurrence, start: start2, end, mapping, predecessors, ...candidate_basis ? { candidate_basis } : {} }))
  };
}
function mapped(parsed, record) {
  const byOccurrence = new Map(record.blocks.map((b) => [b.occurrence, b])), byRange = new Map(record.blocks.map((b) => [JSON.stringify([b.text_hash, b.start, b.end]), b]));
  return { ...parsed, blocks: parsed.blocks.map((b) => {
    const known = record.parser === parsed.parser ? byOccurrence.get(b.occurrence) : byRange.get(JSON.stringify([b.text_hash, b.start, b.end]));
    requireThat(known && known.text_hash === b.text_hash && known.start === b.start && known.end === b.end, "shadow_history", "Stored selectors do not match the current document.");
    return { ...b, id: known.id, mapping: known.mapping, predecessors: known.predecessors ?? [], ...known.candidate_basis ? { candidate_basis: known.candidate_basis } : {} };
  }) };
}
async function currentFiles(wiki2, { maxFiles = 1e4, maxBytes = 64 * 1024 * 1024 } = {}) {
  const entries = (await wiki2.store.list("")).filter((e) => e.kind === "file" && eligible(e.path));
  requireThat(entries.length <= maxFiles, "shadow_budget", "The wiki exceeds the document scan budget.");
  const result = [], findings = [];
  let size = 0;
  for (const e of entries) try {
    const file = await wiki2.store.read(e.path);
    requireThat(file, "shadow_stale", "A listed document disappeared.");
    size += file.size ?? new TextEncoder().encode(file.text).length;
    requireThat(size <= maxBytes, "shadow_budget", "The wiki exceeds the text scan budget.");
    result.push({ ...file, path: e.path });
  } catch (error) {
    findings.push(issue(wiki2.id, error, e.path));
    if (error.code === "shadow_budget") break;
  }
  return { files: result, findings, paths: new Set(entries.map((e) => e.path)) };
}
async function changedFiles(wiki2, cached, options) {
  if (options.paths === void 0 || options.rebuild) return currentFiles(wiki2, options);
  requireThat(Array.isArray(options.paths) && options.paths.length > 0 && options.paths.length <= 1e3, "shadow_paths", "Choose 1\u20131000 known Markdown paths, or omit paths for a full reconciliation.");
  const paths = [...new Set(options.paths.map((p) => relativePath(p)))];
  if (paths.some((p) => !eligible(p) || !cached.some((d) => d.path === p))) return currentFiles(wiki2, options);
  const files2 = [];
  let bytes3 = 0;
  for (const p of paths) {
    const file = await wiki2.store.read(p);
    if (!file) return currentFiles(wiki2, options);
    bytes3 += file.size ?? new TextEncoder().encode(file.text).length;
    requireThat(bytes3 <= (options.maxBytes ?? 64 * 1024 * 1024), "shadow_budget", "The selected paths exceed the text scan budget.");
    files2.push({ ...file, path: p });
  }
  return { files: files2, findings: [], paths: new Set(cached.map((d) => d.path)), full_scan: false };
}
async function publish(wiki2, records, options) {
  const payloads = await identityPackages(wiki2.id, records, wiki2.store.services, options);
  let shared_bytes = 0, packages = 0;
  try {
    for (const text2 of payloads) {
      const name = CHANGES + "/" + await wiki2.store.services.hash(text2) + ".json", seen = await wiki2.store.read(name);
      if (seen) requireThat(seen.text === text2, "shadow_history", "Conflicting identity package.");
      else {
        await wiki2.store.write(name, text2, { expected: null });
        shared_bytes += new TextEncoder().encode(text2).length;
        packages++;
      }
    }
  } catch (error) {
    error.details = { ...error.details, phase: "publish", shared_bytes, packages, next: "Retry shadow.refresh after restoring access. Preserve all existing identity packages and Markdown." };
    throw error;
  }
  return { shared_bytes, packages };
}
async function refreshShadow(wikis, db, options = {}) {
  scopes(wikis);
  requireThat(db && !db.readOnly, "shadow_capability", "Persistent shadow maintenance requires a writable local SQLite host. Browser and Vault use read-only passage retrieval.");
  const expected = db.generation(), updates = [], remove = [], findings = [], batches = [], scans = [];
  let parsedCount = 0, unchanged = 0;
  for (const wiki2 of wikis) try {
    const cached = db.documents(wiki2.id).filter((d) => !d.data.origin || d.data.origin === wiki2.store.root), scan = await changedFiles(wiki2, cached, options), exchange = await history(wiki2, options), past = exchange.records, byPath = new Map(cached.map((d) => [d.path, d])), records = [];
    scans.push(scan.full_scan !== false);
    findings.push(...scan.findings);
    const superseded = new Set(past.filter((r) => r.previous_revision).map((r) => JSON.stringify([r.id, r.previous_path ?? r.path, r.previous_revision]))), terminals = past.filter((r) => r.revision && !superseded.has(JSON.stringify([r.id, r.path, r.revision])));
    const gone = scan.full_scan === false ? [] : terminals.filter((d) => !scan.paths.has(d.path)), claimed = /* @__PURE__ */ new Set();
    for (const file of scan.files) try {
      const previous = byPath.get(file.path), exact = past.filter((r) => r.path === file.path && r.revision === file.sha256 && r.parser === PARSER_VERSION), identities = new Set(exact.map((r) => JSON.stringify([r.id, r.blocks.map((b) => b.id)])));
      requireThat(new Set(past.filter((r) => r.path === file.path && r.revision === file.sha256).map((r) => r.id)).size <= 1, "shadow_ambiguous", "Conflicting document identities cannot be hidden by a coordinate migration.");
      requireThat(identities.size <= 1, "shadow_ambiguous", "Conflicting identity histories exist for this exact file version.");
      if (!exact.length && previous?.revision === file.sha256 && previous.data.source === file.text && previous.data.parser === PARSER_VERSION) {
        records.push(identityRecord(previous, previous.data.identity_previous));
        updates.push(previous);
        unchanged++;
        continue;
      }
      if (!options.rebuild && exact.length && previous?.revision === file.sha256 && previous.data.source === file.text && previous.data.parser === PARSER_VERSION && (!exact.length || exact[0].id === previous.id)) {
        unchanged++;
        continue;
      }
      const parsed = await parseShadow(file.text, wiki2.store.services, options);
      parsedCount++;
      let ancestor = null;
      if (!exact.length) {
        const terminal = terminals.filter((r) => r.path === file.path);
        requireThat(terminal.length <= 1, "shadow_ambiguous", "Concurrent document histories require an explicit file reconciliation.");
        if (terminal.length) ancestor = { ...terminal[0], data: { blocks: terminal[0].blocks } };
      }
      if (!ancestor && !exact.length) {
        const moved = gone.filter((d) => d.revision === file.sha256 && !claimed.has(d.id)), copies = scan.files.filter((f) => f.sha256 === file.sha256 && !terminals.some((r) => r.path === f.path));
        if (moved.length === 1 && copies.length === 1) {
          ancestor = { ...moved[0], data: { blocks: moved[0].blocks } };
          claimed.add(ancestor.id);
        } else if (moved.length) throw Object.assign(new Error("A copy or rename cannot be assigned uniquely."), { code: "shadow_ambiguous" });
      }
      requireThat(!exact.length || !terminals.some((r) => r.id === exact[0].id && r.path !== file.path && scan.files.some((f) => f.path === r.path && f.sha256 === r.revision)), "shadow_ambiguous", "This historical identity is active at another path; a copy cannot reuse it.");
      const id = exact[0]?.id ?? ancestor?.id ?? await wiki2.store.services.hash(JSON.stringify([SHADOW_FORMAT, wiki2.id, file.path, file.sha256]));
      let data;
      if (exact.length) data = mapped(parsed, exact[0]);
      else {
        const blocks = await matchBlocks(ancestor?.data.blocks ?? [], parsed.blocks, wiki2.store.services);
        for (const block of blocks) if (block.mapping !== "unchanged") block.id = await wiki2.store.services.hash(JSON.stringify([id, block.occurrence]));
        data = { ...parsed, blocks };
      }
      data.origin = wiki2.store.root ?? null;
      data.identity_previous = exact.length ? exact[0].previous_revision ? { revision: exact[0].previous_revision, path: exact[0].previous_path } : null : ancestor && (ancestor.revision !== file.sha256 || ancestor.path !== file.path) ? { revision: ancestor.revision, path: ancestor.path } : null;
      const row = { wiki: wiki2.id, path: file.path, id, revision: file.sha256, data };
      requireThat((await wiki2.store.read(file.path))?.sha256 === file.sha256, "shadow_stale", "The document changed during structural indexing.");
      updates.push(row);
      if (!exact.length) records.push(identityRecord(row, data.identity_previous));
    } catch (error) {
      findings.push(issue(wiki2.id, error, file.path));
    }
    for (const old of gone) {
      remove.push({ wiki: wiki2.id, path: old.path });
      if (!claimed.has(old.id)) records.push({ id: old.id, path: old.path, revision: null, parser: PARSER_VERSION, previous_revision: old.revision, previous_path: old.path, blocks: [] });
    }
    for (const old of cached.filter((d) => scan.full_scan !== false && !scan.paths.has(d.path))) if (!remove.some((r) => r.wiki === wiki2.id && r.path === old.path)) remove.push({ wiki: wiki2.id, path: old.path });
    for (const row of updates.filter((r) => r.wiki === wiki2.id)) requireThat((await wiki2.store.read(row.path))?.sha256 === row.revision, "shadow_stale", "The document changed before publishing its identity.");
    findings.push(...exchange.findings.filter((f) => !records.some((r) => r.path === f.page && r.revision === f.revision)).map((f) => ({ wiki: wiki2.id, ...f })));
    batches.push({ wiki: wiki2, records });
  } catch (error) {
    findings.push(issue(wiki2.id, error));
    for (let i2 = updates.length - 1; i2 >= 0; i2--) if (updates[i2].wiki === wiki2.id) updates.splice(i2, 1);
    for (let i2 = remove.length - 1; i2 >= 0; i2--) if (remove[i2].wiki === wiki2.id) remove.splice(i2, 1);
  }
  let shared_bytes = 0, packages = 0;
  for (const batch of batches) try {
    const result = await publish(batch.wiki, batch.records, options);
    shared_bytes += result.shared_bytes;
    packages += result.packages;
  } catch (error) {
    shared_bytes += error.details?.shared_bytes ?? 0;
    packages += error.details?.packages ?? 0;
    findings.push(issue(batch.wiki.id, error, error.details?.path));
    for (let i2 = updates.length - 1; i2 >= 0; i2--) if (updates[i2].wiki === batch.wiki.id) updates.splice(i2, 1);
    for (let i2 = remove.length - 1; i2 >= 0; i2--) if (remove[i2].wiki === batch.wiki.id) remove.splice(i2, 1);
  }
  if (updates.length || remove.length) db.commit(updates, { expected, remove });
  return { complete: findings.length === 0, full_scan: scans.length === wikis.length && scans.every(Boolean), scope: scans.some((s) => !s) ? "paths" : "full", ...scans.some((s) => !s) ? { next: "Known paths checked. Full refresh, workflow completion or sync reconciles external edits, additions, deletions and renames; query independently checks current source bytes." } : {}, parsed: parsedCount, unchanged, updated: updates.length, removed: remove.length, shared_bytes, packages, findings };
}
async function readShadow(wikis, db, options = {}) {
  scopes(wikis);
  const documents = [], findings = [];
  for (const wiki2 of wikis) try {
    const scan = await currentFiles(wiki2, options);
    let exchange = { records: [], findings: [] };
    if (db) try {
      exchange = await history(wiki2, options);
    } catch (error) {
      findings.push(issue(wiki2.id, error));
    }
    const past = exchange.records, cached = new Map((db?.documents(wiki2.id) ?? []).filter((d) => !d.data.origin || d.data.origin === wiki2.store.root).map((d) => [d.path, d]));
    findings.push(...scan.findings, ...exchange.findings.map((f) => ({ wiki: wiki2.id, ...f })));
    for (const file of scan.files) try {
      let old = cached.get(file.path);
      const exact = past.filter((r) => r.path === file.path && r.revision === file.sha256);
      if (!exact.length) old = null;
      if (new Set(exact.map((r) => JSON.stringify([r.id, r.blocks.map((b) => b.id)]))).size > 1) {
        old = null;
        findings.push({ wiki: wiki2.id, page: file.path, code: "shadow_ambiguous", message: "Conflicting identities for this revision; passage retrieval remains unpersisted." });
      }
      if (old?.revision === file.sha256 && old.data.source === file.text && old.data.parser === PARSER_VERSION) documents.push({ ...old, state: "current" });
      else {
        const data = await parseShadow(file.text, wiki2.store.services, options);
        data.blocks = data.blocks.map((b) => ({ ...b, id: null, mapping: "unpersisted", predecessors: [] }));
        documents.push({ wiki: wiki2.id, path: file.path, id: null, revision: file.sha256, data, state: "fallback" });
      }
    } catch (error) {
      findings.push(issue(wiki2.id, error, file.path));
    }
  } catch (error) {
    findings.push(issue(wiki2.id, error));
  }
  return { documents, findings, mode: db ? "sqlite" : "memory", persistent: findings.length === 0 && documents.every((d) => d.state === "current") && Boolean(db) };
}
async function pinQuote(wikis, db, { wiki: wiki2, document: document2, revision, occurrence, start: start2, end, maxBytes = 8 * 1024 * 1024 } = {}) {
  scopes(wikis);
  const scope = wikis.find((w) => w.id === wiki2);
  requireThat(scope && db && !db.readOnly, "shadow_access", "Select an accessible wiki with a maintained local shadow.");
  const rows = db.documents(wiki2).filter((d) => d.id === document2 && d.revision === revision && (!d.data.origin || d.data.origin === scope.store.root));
  requireThat(rows.length === 1, "shadow_quote", "Maintain and select one current document revision before retaining its quote.");
  const row = rows[0], past = (await history(scope)).records, exact = past.filter((r) => r.path === row.path && r.revision === revision);
  requireThat(exact.length && new Set(exact.map((r) => JSON.stringify([r.id, r.blocks.map((b) => b.id)]))).size === 1, "shadow_ambiguous", "Missing or conflicting histories cannot retain an unambiguous quote.");
  const block = row.data.blocks.find((b) => b.occurrence === occurrence);
  requireThat(block, "shadow_quote", "Select a known occurrence.");
  requireThat((await scope.store.read(row.path))?.sha256 === revision, "shadow_stale", "The quoted document changed.");
  const locator = { ...makeLocator(wiki2, document2, row.data, block, { start: start2, end }), page: row.path }, text2 = JSON.stringify({ format: SHADOW_FORMAT, kind: "quote", locator }), id = await scope.store.services.hash(text2), name = PINS + "/" + id + ".json";
  const existing = await scope.store.read(name);
  if (existing) {
    requireThat(existing.text === text2, "shadow_quote", "Conflicting quote record.");
    return { id, locator, shared_bytes: 0 };
  }
  let bytes3 = new TextEncoder().encode(text2).length;
  for (const entry of await files(scope.store, PINS)) {
    const file = await scope.store.read(entry.path);
    bytes3 += file?.size ?? 0;
  }
  requireThat(Number.isSafeInteger(maxBytes) && maxBytes > 0 && bytes3 <= maxBytes, "shadow_pin_budget", "The protected quote budget is full. Existing evidence has been retained.", { bytes: bytes3, maxBytes });
  requireThat((await scope.store.read(row.path))?.sha256 === revision, "shadow_stale", "The quoted document changed before it could be retained.");
  await scope.store.write(name, text2, { expected: null });
  return { id, locator, shared_bytes: new TextEncoder().encode(text2).length };
}
async function resolveQuote(wikis, id) {
  scopes(wikis);
  requireThat(hex3(id), "shadow_quote", "Supply a retained quote identifier.");
  for (const wiki2 of wikis) {
    const pin = await wiki2.store.read(PINS + "/" + id + ".json");
    if (!pin) continue;
    requireThat(await wiki2.store.services.hash(pin.text) === id, "shadow_quote", "The retained quote checksum is invalid.");
    const data = JSON.parse(pin.text), locator = data.locator;
    requireThat(data.format === SHADOW_FORMAT && data.kind === "quote" && locator?.wiki === wiki2.id, "shadow_quote", "The quote is not in this wiki scope.");
    relativePath(locator.page);
    const records = (await history(wiki2)).records, scan = await currentFiles(wiki2);
    requireThat(!scan.findings.length, "shadow_access", "The current wiki cannot be read completely.");
    const candidates = [];
    for (const file2 of scan.files) {
      const recordsForFile = records.filter((r) => r.path === file2.path && r.revision === file2.sha256);
      if (recordsForFile.some((r) => r.id === locator.document)) candidates.push({ file: file2, records: recordsForFile });
    }
    if (candidates.length !== 1) return { id, ...resolveLocator(locator, null), state: "historical", successor_state: candidates.length ? "ambiguous" : scan.files.some((f) => f.path === locator.page) ? "unindexed" : "missing", page: locator.page, wiki: wiki2.id, revision: locator.revision };
    const { file, records: matching } = candidates[0];
    requireThat(new Set(matching.map((r) => JSON.stringify([r.id, r.blocks.map((b) => b.id)]))).size === 1, "shadow_ambiguous", "Conflicting document histories cannot resolve this quote.");
    let current2;
    try {
      current2 = mapped(await parseShadow(file.text, wiki2.store.services), matching[0]);
    } catch (error) {
      if (error.code !== "shadow_history") throw error;
      return { id, ...resolveLocator(locator, null), state: "historical", successor_state: "unindexed", page: locator.page, wiki: wiki2.id, revision: locator.revision, next: "Refresh the shadow to migrate legacy source coordinates; the retained quotation is unchanged." };
    }
    requireThat((await wiki2.store.read(file.path))?.sha256 === file.sha256, "shadow_stale", "The document changed while resolving the quote.");
    return { id, ...resolveLocator(locator, current2), page: file.path, wiki: wiki2.id, revision: locator.revision, current_revision: file.sha256, locator };
  }
  throw Object.assign(new Error("The retained quote is not available in an accessible wiki."), { code: "shadow_access" });
}
async function resolvePassage(wikis, token, { project, instance } = {}) {
  scopes(wikis);
  const p = decodePassage(token);
  requireThat(p.project === project && p.instance === instance, "citation_scope", "This passage belongs to another project instance.");
  const wiki2 = wikis.find((w) => w.id === p.wiki && w.connection === p.connection && w.work === p.work);
  requireThat(wiki2, "citation_scope", "The cited working copy is not connected and accessible.");
  const unavailable = (reason) => ({ state: "unavailable", reason, page: p.page, wiki: p.wiki, revision: p.revision, current: null, quote: null, retained: false });
  const checked = async (file2, start3, end2, state2) => {
    requireThat(start3 >= 0 && end2 <= file2.text.length && end2 > start3, "citation_stale", "The cited range no longer exists.");
    const quote3 = file2.text.slice(start3, end2);
    requireThat(await wiki2.store.services.hash(quote3) === p.quote_hash, "citation_stale", "The passage no longer matches its quoted wording.");
    requireThat((await wiki2.store.read(file2.path))?.sha256 === file2.sha256, "citation_stale", "The document changed while opening the passage.");
    return { state: state2, page: file2.path, wiki: p.wiki, revision: p.revision, current_revision: file2.sha256, quote: quote3, current: { start: start3, end: end2, id: p.block }, retained: false };
  };
  const original = await wiki2.store.read(p.page);
  if (original?.sha256 === p.revision) return checked(original, p.start, p.end, "current");
  if (!p.document || !p.block) return unavailable(original ? "changed" : "missing");
  const records = (await history(wiki2)).records, scan = await currentFiles(wiki2);
  requireThat(!scan.findings.length, "shadow_access", "The wiki cannot be checked completely.");
  const candidates = scan.files.filter((f) => records.some((r) => r.id === p.document && r.path === f.path && r.revision === f.sha256));
  if (candidates.length !== 1) return unavailable(candidates.length ? "ambiguous" : original ? "unindexed" : "missing");
  const file = candidates[0], exact = records.filter((r) => r.path === file.path && r.revision === file.sha256);
  requireThat(new Set(exact.map((r) => JSON.stringify([r.id, r.blocks.map((b) => b.id)]))).size === 1, "shadow_ambiguous", "Conflicting histories cannot resolve this passage.");
  const data = mapped(await parseShadow(file.text, wiki2.store.services), exact[0]), blocks = data.blocks.filter((b) => b.id === p.block);
  if (blocks.length !== 1) return unavailable("changed");
  const block = blocks[0], start2 = block.start + p.offset, end = start2 + p.end - p.start;
  if (end > block.end) return unavailable("changed");
  return checked(file, start2, end, "unchanged_successor");
}

// runtime/intake.mjs
init_errors();
init_document();
var ROOT = ".llmwiki/intakes";
var location2 = (id) => {
  requireThat(typeof id === "string" && /^[a-f0-9]{32}$/.test(id), "intake_required", "Start the guided intake and record the actual uptake decision first.");
  return ROOT + "/" + id + ".json";
};
async function intakeStatus(store, id) {
  const file = await store.read(location2(id));
  requireThat(file, "intake_required", "The uptake record is missing.");
  const data = JSON.parse(file.text);
  requireThat(data.format === "llmwiki-intake/1", "intake_required", "Unknown uptake record.");
  return data;
}
async function startIntake(store, args, source2) {
  const { path: path7, sha256, assessment, compared, topics, author } = args;
  relativePath(path7);
  requireThat(/^[a-f0-9]{64}$/.test(sha256), "digest", "Read the original attachment first.");
  nonempty(author, "author");
  nonempty(assessment, "comparison with existing knowledge");
  requireThat(Array.isArray(compared) && Array.isArray(topics) && topics.length, "triage", "Record compared knowledge and candidate themes.");
  for (const c of compared) {
    const f = await store.read(relativePath(c.page));
    nonempty(c.quote, "comparison quote");
    nonempty(c.reason, "comparison reason");
    requireThat(f && f.sha256 === c.expected && parseDocument(f.text).body.includes(c.quote), "evidence", "Read and quote the actual compared note.");
  }
  for (const t of topics) {
    nonempty(t.title, "theme");
    nonempty(t.reason, "theme reason");
  }
  const data = { format: "llmwiki-intake/1", id: store.services.uuid().replace(/-/g, ""), source: source2, path: path7, sha256, assessment, compared, topics, author, at: store.services.now(), decision: null, decisions: [] };
  await store.write(location2(data.id), JSON.stringify(data, null, 2) + "\n", { expected: null });
  return data;
}
async function decideIntake(store, args) {
  const file = await store.read(location2(args.id));
  requireThat(file, "intake_required", "The uptake record is missing.");
  const data = JSON.parse(file.text), d = args.decision;
  requireThat(data.format === "llmwiki-intake/1", "intake_required", "Unknown uptake record.");
  nonempty(args.author, "responding author");
  nonempty(d?.reply, "actual user reply");
  requireThat(["take", "defer", "decline"].includes(d.choice), "decision", "Choose take, defer or decline.");
  if (d.choice === "take") {
    requireThat(Array.isArray(d.selected) && d.selected.length && new Set(d.selected).size === d.selected.length && d.selected.every((i2) => Number.isInteger(i2) && i2 >= 1 && i2 <= data.topics.length), "topics", "Record the themes selected by the user.");
    requireThat(["elaboration", "entries", "existing", "source-only"].includes(d.form), "form", "Record the agreed result form.");
  }
  for (const c of data.compared) requireThat((await store.read(c.page))?.sha256 === c.expected, "stale", "Compared knowledge changed; repeat the triage.");
  data.decisions ??= data.decision ? [data.decision] : [];
  data.decision = { ...d, author: args.author, at: store.services.now() };
  data.decisions.push(data.decision);
  await store.write(location2(data.id), JSON.stringify(data, null, 2) + "\n", { expected: file.sha256 });
  return data;
}
async function authorizeIntake(store, id, source2, path7, bytes3) {
  const data = await intakeStatus(store, id);
  requireThat(data.source === source2 && data.path === path7 && data.sha256 === await store.services.hash(bytes3), "intake_required", "The confirmed attachment or target differs. Repeat the triage for this target.");
  requireThat(data.decision?.choice === "take", "intake_required", "Wait for the actual uptake decision before storing the original.");
  return data;
}
async function requireDialogMode(store, sources, mode) {
  let files2;
  try {
    files2 = await store.list(ROOT);
  } catch (e) {
    if (e.code === "ENOENT") return;
    throw e;
  }
  for (const page of sources) {
    const head = parseDocument((await store.read(page)).text).head;
    for (const file of files2.filter((e) => e.kind === "file" && e.path.endsWith(".json"))) {
      const intake = JSON.parse((await store.read(file.path)).text);
      if (intake.source === head.resource?.store && intake.path === head.resource?.name && intake.sha256 === head.resource?.sha256 && intake.decision?.choice === "take") requireThat(mode === "appropriate", "dialogue_required", "A chat attachment uses its confirmed appropriation dialogue, not automatic batch integration.");
    }
  }
}

// runtime/note-maintenance.mjs
init_document();
init_errors();

// runtime/assets.mjs
init_document();
init_errors();
init_review();
var imagePath = (p) => /\.(png|jpe?g|gif|webp|avif)$/i.test(p);
function imageType(b) {
  if (b[0] === 137 && String.fromCharCode(...b.slice(1, 8)) === "PNG\r\n\n") return "png";
  if (b[0] === 255 && b[1] === 216 && b[2] === 255) return "jpg";
  if (/^GIF8[79]a/.test(String.fromCharCode(...b.slice(0, 6)))) return "gif";
  if (String.fromCharCode(...b.slice(0, 4)) === "RIFF" && String.fromCharCode(...b.slice(8, 12)) === "WEBP") return "webp";
  if (String.fromCharCode(...b.slice(4, 8)) === "ftyp" && /avif|avis/.test(String.fromCharCode(...b.slice(8, 32)))) return "avif";
  return null;
}
function assetName({ title, sha256, date: date2, extension }) {
  requireThat(/^[a-f0-9]{64}$/.test(sha256) && ["png", "jpg", "gif", "webp", "avif"].includes(extension), "asset", "Invalid image digest or type.");
  requireThat(/^\d{4}-\d{2}-\d{2}$/.test(date2), "date", "Supply the capture date (not an invented meeting date).");
  const slug = (title || "Bild").normalize("NFC").replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-|-$/g, "").slice(0, 90) || "Bild";
  return date2 + "_" + slug + "_" + sha256.slice(0, 8) + "." + extension;
}
function resolveAsset(page, written, files2) {
  let target;
  try {
    target = decodeURIComponent(written.split("|")[0].replace(/^<|>$/g, "").split("#")[0]);
  } catch {
    return null;
  }
  if (!target || /^[a-z]+:|^\/|\\|\x00/i.test(target)) return null;
  const parts = page.split("/").slice(0, -1);
  for (const part of target.split("/")) {
    if (part === "..") {
      if (!parts.length) return null;
      parts.pop();
    } else if (part !== ".") parts.push(part);
  }
  const direct = parts.join("/");
  if (files2.includes(direct)) return direct;
  if (files2.includes(target)) return target;
  if (target.includes("/")) return null;
  const matches = files2.filter((p) => p.split("/").at(-1) === target);
  return matches.length === 1 ? matches[0] : null;
}
async function assetFolder(store) {
  const config = await store.read(".obsidian/app.json");
  if (config) try {
    const name = JSON.parse(config.text).attachmentFolderPath;
    relativePath(name);
    if (!name.split("/").some((p) => p.startsWith("."))) return name;
  } catch {
  }
  const dirs = await store.list("", { recursive: false });
  for (const name of ["_attachments", "Attachments"]) if (dirs.some((e) => e.path === name && e.kind === "directory")) return name;
  return "_attachments";
}
async function reading(store, sha) {
  const file = await store.read(".llmwiki/evidence/images/" + sha + ".json");
  return file ? JSON.parse(file.text) : null;
}
async function embeddedAssets(store, page, text2, entries) {
  const files2 = (entries ?? await store.list("")).filter((e) => e.kind === "file").map((e) => e.path), out = [];
  for (const link of bodyLinks(parseDocument(text2).body).filter((l) => l.embedded)) {
    if (!imagePath(link.written.split("|")[0].split("#")[0])) continue;
    const path7 = resolveAsset(page, link.written, files2), file = path7 ? await store.read(path7, { binary: true }) : null;
    const record = file ? await reading(store, file.sha256) : null;
    out.push({ written: link.written, path: path7, sha256: file?.sha256 ?? null, state: !file ? "missing_or_ambiguous" : !record ? "reading_required" : record.gaps.length ? "coverage_required" : "reviewed", reading: record });
  }
  return out;
}
async function planAssets(store) {
  const entries = await store.list(""), items = /* @__PURE__ */ new Map(), findings = [];
  for (const e of entries) if (e.kind === "file" && /\.md$/i.test(e.path) && !e.path.endsWith(".excalidraw.md")) {
    const file = await store.read(e.path);
    for (const a of await embeddedAssets(store, e.path, file.text, entries)) {
      if (!a.path) {
        findings.push({ page: e.path, ...a });
        continue;
      }
      if (!items.has(a.path)) items.set(a.path, { ...a, pages: [] });
      items.get(a.path).pages.push(e.path);
    }
  }
  return { folder: await assetFolder(store), items: [...items.values()], findings, unreferenced: entries.filter((e) => e.kind === "file" && imagePath(e.path) && !items.has(e.path)).map((e) => ({ path: e.path, state: "unreferenced", next: "Keep the original. Explicitly ingest as a source or embed in a note." })) };
}
async function reviewAsset(store, args) {
  const { path: path7, expected, author, kind } = args;
  relativePath(path7);
  nonempty(author, "author");
  const file = await store.read(path7, { binary: true });
  requireThat(file?.sha256 === expected, "stale", "Read the current image.");
  const extension = imageType(file.bytes);
  requireThat(extension, "image", "Only a recognized raster image can receive an image reading.");
  requireThat(["content", "decorative"].includes(kind), "image", "Classify content or decorative explicitly.");
  nonempty(args.title, "title", 200);
  nonempty(args.description, "description");
  requireThat(Array.isArray(args.gaps) && args.gaps.every((g) => typeof g === "string" && g.trim()), "image", "List unresolved visual gaps explicitly, or use an empty list.");
  if (kind === "content") {
    requireThat(typeof args.transcription === "string", "image", "Provide full transcription (empty only when there is no text).");
    nonempty(args.interpretation, "interpretation");
  }
  const date2 = store.services.now().slice(0, 10), record = { format: "llmwiki-image-reading/1", sha256: expected, original_path: path7, author, at: store.services.now(), kind, title: args.title, description: args.description, transcription: args.transcription ?? "", interpretation: args.interpretation ?? "", gaps: args.gaps, capture_date: date2, capture_date_basis: "integration_date" }, evidence = args.gaps.length ? ".llmwiki/evidence/image-attempts/" + store.services.uuid() + ".json" : ".llmwiki/evidence/images/" + expected + ".json";
  const prior = await store.read(evidence);
  if (prior) {
    const existing = JSON.parse(prior.text);
    requireThat(existing.gaps.length > 0 || JSON.stringify({ ...existing, at: record.at, author: record.author }) === JSON.stringify(record), "image_review_exists", "A completed image reading is immutable. Preserve it and discuss a revised interpretation in the note.");
  }
  await store.write(evidence, JSON.stringify(record, null, 2) + "\n", { expected: prior?.sha256 ?? null });
  return { evidence, complete: !record.gaps.length, suggested_name: assetName({ title: args.title, sha256: expected, date: date2, extension }), next: kind === "content" ? "Include transcription, visual description and separate interpretation in the parent Markdown, then note.review." : "note.review" };
}
async function renameAsset(store, { path: path7, expected, author }) {
  nonempty(author, "author");
  const file = await store.read(path7, { binary: true });
  requireThat(file?.sha256 === expected, "stale", "Read the current attachment.");
  const record = await reading(store, expected);
  requireThat(record && !record.gaps.length, "asset_review_required", "Complete the semantic reading first.");
  const name = assetName({ title: record.title, sha256: expected, date: record.capture_date, extension: imageType(file.bytes) }), to = await assetFolder(store) + "/" + name;
  if (path7 === to) return { path: to, changed: [], original_preserved: true };
  const existing = await store.read(to, { binary: true });
  requireThat(!existing || existing.sha256 === expected, "exists", "The destination has different content.");
  const entries = await store.list(""), files2 = entries.filter((e) => e.kind === "file").map((e) => e.path), edits = [];
  for (const p of files2.filter((p2) => p2.endsWith(".md") && !p2.endsWith(".excalidraw.md"))) {
    const f = await store.read(p), parsed = parseDocument(f.text);
    if (parsed.head.resource) continue;
    const replace = (part) => part.replace(/!\[\[([^\]]+)\]\]|!\[([^\]]*)\]\((<[^>]+>|[^\s)]+)\s*\)/g, (all, wiki2, alt, target) => {
      if (resolveAsset(p, wiki2 ?? target, files2) !== path7) return all;
      const from = p.split("/").slice(0, -1), dest = to.split("/");
      while (from.length && dest[0] === from[0]) {
        from.shift();
        dest.shift();
      }
      const relative = "../".repeat(from.length) + dest.join("/");
      return "![" + (alt ?? record.title).replace(/[\[\]\r\n]/g, "") + "](" + relative.split("/").map(encodeURIComponent).join("/") + ")";
    });
    let fence = null;
    const body = parsed.body.split(/(?<=\n)/).map((line) => {
      const marker = /^ {0,3}(`{3,}|~{3,})/.exec(line);
      if (marker) {
        if (!fence) fence = marker[1];
        else if (marker[1][0] === fence[0] && marker[1].length >= fence.length) fence = null;
        return line;
      }
      if (fence) return line;
      return line.split(/(`+[^`]*`+)/).map((part) => part.startsWith("`") ? part : replace(part)).join("");
    }).join("");
    const text2 = f.text.slice(0, parsed.offset) + body;
    if (text2 !== f.text) edits.push({ page: p, text: text2, expected: f.sha256 });
  }
  if (!existing) await store.write(to, file.bytes, { expected: null });
  const changed = [];
  for (const edit of edits) {
    await save(store, edit.page, edit.text, author, edit.expected);
    changed.push(edit.page);
  }
  return { path: to, changed, original_preserved: true, deleted: 0 };
}

// runtime/note-maintenance.mjs
init_ontology();
init_note_contract();
init_graph();
var ownPage = (path7, head) => /\.md$/i.test(path7) && !path7.split("/").some((p) => p.startsWith(".") || ["schema", "meta", "notices", "vermerke", "_attachments", "Attachments"].includes(p)) && !/(^|\/)(?:bundle|index|WIKI)\.md$/i.test(path7) && !path7.endsWith(".excalidraw.md") && !head.resource;
async function snapshot(store, page, entries) {
  const file = await store.read(page);
  if (!file) return null;
  const parsed = parseDocument(file.text), hash = await store.services.hash(statementText(file.text).trimEnd()), assets = await embeddedAssets(store, page, file.text, entries);
  return { file, parsed, hash, assets };
}
async function ledgerPath(store, page, head) {
  return ".llmwiki/note-reviews/" + await store.services.hash(String(head.id ?? head.uid ?? page)) + ".json";
}
var assetState = (assets) => assets.map((a) => ({ written: a.written, path: a.path, sha256: a.sha256 }));
async function planNotes(store) {
  const entries = await store.list(""), changes = [], advisories = [], registered = await store.read("schema/TYPES.md"), register = registered ? readRegister(registered.text) : null;
  for (const entry of entries) if (entry.kind === "file" && /\.md$/i.test(entry.path)) try {
    const s = await snapshot(store, entry.path, entries);
    if (!s || !ownPage(entry.path, s.parsed.head)) continue;
    advisories.push(...reviewAdvisories(s.parsed, register, store.services.now()).map((f) => ({ ...f, page: entry.path })));
    const prior = await store.read(await ledgerPath(store, entry.path, s.parsed.head)), record = prior ? JSON.parse(prior.text) : null;
    let state2 = !record ? "new" : record.hash !== s.hash ? "changed" : "unchanged";
    if (state2 === "unchanged") {
      if (JSON.stringify(record.assets) !== JSON.stringify(assetState(s.assets))) state2 = "dependency_changed";
      for (const d of record.compared) {
        const file = await store.read(d.page);
        if (!file || await store.services.hash(statementText(file.text).trimEnd()) !== d.hash) state2 = "dependency_changed";
      }
    }
    changes.push({ page: entry.path, expected: s.file.sha256, state: state2, assets: s.assets.map(({ reading: reading2, ...a }) => a), last_review: record?.at ?? null });
  } catch (error) {
    changes.push({ page: entry.path, state: "unreadable", error: { code: error.code, message: error.message } });
  }
  return { changes, advisories, counts: Object.fromEntries(["new", "changed", "unchanged", "dependency_changed", "unreadable"].map((s) => [s, changes.filter((c) => c.state === s).length])), complete: changes.every((c) => c.state === "unchanged") };
}
async function reviewNote(store, args) {
  const { page, expected, author, quote: quote3, assessment, topics, relations, compared } = args;
  relativePath(page);
  nonempty(author, "author");
  nonempty(quote3, "quote");
  nonempty(assessment, "assessment");
  nonempty(topics?.reason, "topic decision");
  nonempty(relations?.reason, "relation decision");
  requireThat(["none", "linked"].includes(relations?.decision) && Array.isArray(compared), "review", "Supply compared pages and a linked/none relation decision.");
  const s = await snapshot(store, page);
  requireThat(s && s.file.sha256 === expected, "stale", "Read the current note before semantic integration.");
  requireThat(ownPage(page, s.parsed.head), "note", "Source mirrors use their source integration workflow.");
  requireThat(s.parsed.body.includes(quote3), "evidence", "The note quote must occur verbatim in its body.");
  const dependencies = [];
  for (const d of compared) {
    relativePath(d.page);
    requireThat(d.page !== page, "evidence", "Compare with another knowledge page.");
    const f = await store.read(d.page);
    requireThat(f && f.sha256 === d.expected, "stale", "A compared page changed.");
    nonempty(d.quote, "comparison quote");
    nonempty(d.reason, "comparison reason");
    requireThat(parseDocument(f.text).body.includes(d.quote), "evidence", "Comparison quotes must be verifiable.");
    dependencies.push({ ...d, hash: await store.services.hash(statementText(f.text).trimEnd()) });
  }
  for (const a of s.assets) {
    requireThat(a.state === "reviewed", "asset_review_required", "Read all non-decorative images and resolve missing or ambiguous embeds first.", { page, asset: a.path ?? a.written, state: a.state });
    if (a.reading.kind === "content") for (const value of [a.reading.transcription, a.reading.description, a.reading.interpretation].filter(Boolean)) requireThat(s.parsed.body.includes(value), "asset_content_missing", "Include the full image reading and its separate interpretation in the note so retrieval can find it.", { asset: a.path });
  }
  if (relations.decision === "linked") {
    const graph = await buildGraph([{ id: "local", store }], { allowMissingRegister: true });
    const edges = graph.edges.filter((e) => e.valid && e.type && graph.pages.get(e.source)?.path === page);
    requireThat(edges.some((e) => dependencies.some((d) => d.page === graph.pages.get(e.target)?.path)), "relation", "A linked decision requires a valid typed relation to an evidenced compared page.");
  } else requireThat(!relationRows(s.parsed.body).some((r) => r.direction === "out"), "relation", "A note with outbound typed relations needs a linked review.");
  const record = { format: "llmwiki-note-review/1", page, hash: s.hash, expected, author, at: store.services.now(), quote: quote3, assessment, topics, relations, compared: dependencies, assets: assetState(s.assets) };
  requireThat((await store.read(page))?.sha256 === expected, "stale", "The note changed during review.");
  for (const d of dependencies) requireThat((await store.read(d.page))?.sha256 === d.expected, "stale", "A comparison changed during review.");
  const name = await ledgerPath(store, page, s.parsed.head), prior = await store.read(name);
  await store.write(name, JSON.stringify(record, null, 2) + "\n", { expected: prior?.sha256 ?? null });
  return { page, integrated: true, evidence: name };
}

// runtime/dispatch.mjs
init_derived();

// runtime/metadata-repair.mjs
init_document();
init_errors();
init_review();
async function repairMetadata(store, { page, expected, author, description, generated }) {
  relativePath(page);
  nonempty(author, "author");
  const seen = await store.read(page);
  requireThat(seen?.sha256 === expected, "stale", "Read the current document before metadata repair.");
  const p = parseDocument(seen.text), before = mirroredContent(p.body);
  requireThat(!p.head.source_id || p.head.source_id === p.head.id, "identity", "Resolve distinct legacy identities explicitly; do not discard a source identifier.");
  const updates = {};
  if (description !== void 0) {
    nonempty(description, "description");
    requireThat(description.trim().split(/\s+/).length <= 25, "description", "Use one concise sentence with at most 25 words.");
    updates.description = description;
  }
  if (!p.head.generated) {
    const known = generated ?? (p.head.created && p.head.author ? { by: p.head.author, at: p.head.created } : null);
    requireThat(known?.by && Number.isFinite(Date.parse(known.at)), "provenance", "Supply evidenced original generation metadata; the repair time is not the creation time.");
    updates.generated = known;
  }
  const archive = ".llmwiki/repairs/metadata/" + seen.sha256 + ".md";
  if (!await store.read(archive)) await store.write(archive, seen.text, { expected: null });
  if (p.head.extraction) {
    requireThat(before !== null && p.head.resource?.sha256, "evidence", "Legacy extraction proof requires its source mirror and original hash.");
    const proof = ".llmwiki/evidence/" + encodeURIComponent(p.head.id) + "/" + p.head.resource.sha256 + "/" + await store.services.hash(before) + ".json", existing = await store.read(proof), text3 = JSON.stringify(p.head.extraction) + "\n";
    requireThat(!existing || JSON.stringify(JSON.parse(existing.text)) === JSON.stringify(p.head.extraction), "evidence", "A different reading already exists.");
    if (!existing) await store.write(proof, text3, { expected: null });
  }
  let text2 = removeHeadFields(patchHead(seen.text, updates), ["created", "updated", "author", "source_id", "extraction"]);
  const bundle = await store.read("wiki/bundle.md");
  if (page !== "wiki/bundle.md" && bundle && p.head.owner === parseDocument(bundle.text).head.owner) text2 = removeHeadFields(text2, ["owner"]);
  requireThat(mirroredContent(parseDocument(text2).body) === before, "mirror", "A metadata repair must preserve the complete source mirror.");
  if (text2 !== seen.text) await save(store, page, text2, author, seen.sha256);
  return { page, changed: text2 !== seen.text, backup: archive, sha256: await store.services.hash(text2) };
}

// runtime/workflow-migration.mjs
init_document();
init_errors();
var digest2 = (store, text2) => {
  const p = parseDocument(text2);
  return store.services.hash(JSON.stringify(p.head) + "\n" + statementText(p.body).replace(/\r\n?/g, "\n").trimEnd());
};
async function migrateWorkflowPaths(store, plan2) {
  let files2;
  try {
    files2 = await store.list(".llmwiki/workflows");
  } catch (e) {
    if (e.code === "ENOENT" || e.name === "NotFoundError") return;
    throw e;
  }
  const changes = new Map(plan2.changes.map((c) => [c.from, c]));
  function rewrite(value, key = "") {
    if (typeof value === "string") return ["quote", "statement", "reason"].includes(key) ? value : plan2.mapping[value] ?? value;
    if (Array.isArray(value)) return value.map((v) => rewrite(v, key));
    if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([k, v]) => [plan2.mapping[k] ?? k, rewrite(v, k)]));
    return value;
  }
  for (const f of files2) if (f.kind === "file" && f.path.endsWith(".json")) {
    const seen = await store.read(f.path), original = JSON.parse(seen.text);
    if (original.format !== "llmwiki-workflow/1") continue;
    const data = rewrite(original);
    for (const [before, after] of [[original.review?.snapshots, data.review?.snapshots], [original.output_snapshots, data.output_snapshots]]) if (before && after) {
      for (const [page, hash] of Object.entries(before)) {
        const change = changes.get(page);
        if (!change || await digest2(store, change.before) !== hash) continue;
        const current2 = await store.read(change.to);
        requireThat(current2, "migration", "A moved workflow page is missing.");
        if (await digest2(store, current2.text) === await digest2(store, change.text)) after[change.to] = await digest2(store, current2.text);
      }
    }
    if (data.review && JSON.stringify(data.review) !== JSON.stringify(original.review)) {
      const prior = data.review.sha256 ?? original.review_sha256, copy = { ...data.review };
      delete copy.sha256;
      data.review.sha256 = await store.services.hash(JSON.stringify(copy));
      data.review_sha256 = data.review.sha256;
      for (const decision of data.decisions || []) if ((decision.review_sha ?? decision.review_sha256) === prior) {
        decision.review_sha = data.review.sha256;
        decision.review_sha256 = data.review.sha256;
      }
    }
    const text2 = JSON.stringify(data, null, 2) + "\n";
    if (JSON.stringify(data) === JSON.stringify(original)) continue;
    const backup = ".llmwiki/moves/" + plan2.id + "/state/" + f.path;
    if (!await store.read(backup)) await store.write(backup, seen.text, { expected: null });
    await store.write(f.path, text2, { expected: seen.sha256 });
  }
}

// runtime/file-management.mjs
init_graph();
init_document();
init_errors();
init_links();
init_links();
init_review();
init_content();
async function planMoves(store, { moves, author }) {
  nonempty(author, "author");
  requireThat(Array.isArray(moves) && moves.length, "moves", "Choose files to move.");
  const graph = await buildGraph([{ id: "wiki", store }]), mapping = {}, targets = /* @__PURE__ */ new Set();
  for (const { from, to } of moves) {
    relativePath(from);
    relativePath(to);
    requireThat(from !== to && visibleKnowledge(from) && visibleKnowledge(to) && !["wiki/bundle.md", "wiki/index.md", "WIKI.md"].includes(from), "move", "Choose an ordinary Markdown document.");
    requireThat(!mapping[from] && !targets.has(to), "move", "Move targets must be unique.");
    requireThat(graph.scopes.get("wiki").paths.has(from), "missing", "Document does not exist: " + from);
    requireThat(!await store.read(to), "exists", "Target already exists: " + to);
    mapping[from] = to;
    targets.add(to);
  }
  const id = store.services.uuid(), changes = [];
  for (const p of graph.pages.values()) {
    const to = mapping[p.path] ?? p.path, text2 = rewriteDocument(p.source, p.path, to, mapping, graph);
    if (to !== p.path || text2 !== p.source) changes.push({ from: p.path, to, before: p.source, expected: p.sha256, text: text2 });
  }
  const aliasFile = await store.read(".llmwiki/identity-aliases.json");
  let identityAliases = null;
  if (aliasFile) {
    const aliases = JSON.parse(aliasFile.text);
    for (const a of aliases.aliases || []) a.path = mapping[a.path] ?? a.path;
    identityAliases = { before: aliasFile.text, expected: aliasFile.sha256, text: JSON.stringify(aliases) };
  }
  const data = { identityAliases, format: "llmwiki-moves/1", id, author, mapping, changes, cursor: 0, complete: false };
  await store.write(".llmwiki/moves/" + id + ".json", JSON.stringify(data), { expected: null });
  return { id, moves, affected: changes.map((c) => ({ from: c.from, to: c.to })), complete: false };
}
async function applyMoves(store, id) {
  requireThat(/^[a-f0-9-]{36}$/.test(id), "move", "Invalid move plan.");
  const path7 = ".llmwiki/moves/" + id + ".json";
  let record = await store.read(path7);
  requireThat(record, "move", "Move plan is missing.");
  const data = JSON.parse(record.text);
  requireThat(data.format === "llmwiki-moves/1" && data.id === id, "move", "Invalid move record.");
  if (data.complete) return data;
  for (const c of data.changes.slice(data.cursor)) {
    const current2 = await store.read(c.from), destination = c.to === c.from ? current2 : await store.read(c.to);
    requireThat(current2?.sha256 === c.expected || !current2 && destination?.text === c.text || c.from === c.to && current2?.text === c.text, "stale", "A document changed after the move was planned.", { page: c.from });
    if (c.to !== c.from) requireThat(!destination || destination.text === c.text, "exists", "Move target changed.", { page: c.to });
  }
  for (; data.cursor < data.changes.length; data.cursor++) {
    const c = data.changes[data.cursor], archive = ".llmwiki/moves/" + id + "/originals/" + c.from;
    if (!await store.read(archive)) await store.write(archive, c.before, { expected: null });
    const dest = await store.read(c.to);
    if (dest?.text !== c.text) await save(store, c.to, c.text, data.author, c.to === c.from ? c.expected : null);
    if (c.to !== c.from && await store.read(c.from)) {
      if (!store.archive) {
        return { complete: false, id, requires_host_move: { source: store.hostPath?.(c.from) ?? c.from, destination: store.hostPath?.(".llmwiki/moves/" + id + "/retired/" + c.from) ?? ".llmwiki/moves/" + id + "/retired/" + c.from, expected: c.expected }, message: "Move the exact original with the host move_file tool, then resume this plan. Never delete it." };
      }
      await store.archive(c.from, ".llmwiki/moves/" + id + "/retired/" + c.from, c.expected);
    }
    const alias = ".llmwiki/path-aliases/" + await store.services.hash(c.from) + ".json", prior = await store.read(alias);
    if (c.from !== c.to) await store.write(alias, JSON.stringify({ from: c.from, to: c.to, id, expected: c.expected }), { expected: prior?.sha256 ?? null });
    const state2 = { ...data, cursor: data.cursor + 1 };
    record = await store.read(path7);
    await store.write(path7, JSON.stringify(state2), { expected: record.sha256 });
  }
  if (data.identityAliases) {
    const p = ".llmwiki/identity-aliases.json", current2 = await store.read(p);
    if (current2?.text !== data.identityAliases.text) {
      const backup = ".llmwiki/moves/" + id + "/state/identity-aliases.json";
      if (!await store.read(backup)) await store.write(backup, data.identityAliases.before, { expected: null });
      await store.write(p, data.identityAliases.text, { expected: data.identityAliases.expected });
    }
  }
  await refreshIndex(store);
  await migrateWorkflowPaths(store, data);
  data.complete = true;
  record = await store.read(path7);
  await store.write(path7, JSON.stringify(data), { expected: record.sha256 });
  return { complete: true, id, moves: data.mapping };
}
async function makeFolder(store, path7) {
  relativePath(path7);
  requireThat(!path7.split("/").some((p) => p.startsWith(".")) && !/^(schema|meta|notices|vermerke)(\/|$)/.test(path7), "folder", "Choose a visible user folder.");
  await store.mkdir(path7);
  return { created: true, path: path7 };
}
async function planFlatWiki(store, { author }) {
  const graph = await buildGraph([{ id: "wiki", store }]);
  const moves = [];
  for (const p of graph.pages.values()) if (/^(sources|topics|entities|concepts)\//.test(p.path)) {
    const name = p.path.split("/").at(-1).normalize("NFC"), suffix = String(p.head.id || p.sha256).slice(-8), to = "wiki/" + name.replace(/\.md$/, "") + " \u2014 " + suffix + ".md";
    moves.push({ from: p.path, to });
  }
  return moves.length ? planMoves(store, { moves, author }) : { complete: true, moves: [] };
}

// runtime/relocate.mjs
init_project2();
init_errors();
async function snapshot2(store) {
  const entries = await store.list("", { hidden: true }), files2 = /* @__PURE__ */ new Map();
  requireThat(!entries.some((e) => e.kind === "symlink"), "symlink", "Working copies with symbolic links cannot be relocated.");
  requireThat(!entries.some((e) => e.kind === "file" && e.path.startsWith(".llmwiki/locks/")), "busy", "Finish active saves before relocating the working copy.");
  for (const e of entries) if (e.kind === "file" && e.path !== ".DS_Store") {
    const file = await store.read(e.path, { binary: true });
    requireThat(file, "stale", "A file disappeared during relocation.");
    files2.set(e.path, file);
  }
  return files2;
}
async function relocate(root, args, { bindings = {}, editorHTML = null } = {}) {
  const { project, file } = await load(root);
  requireThat(file.sha256 === args.expected, "stale", "Reload the exact project settings before relocating.");
  const c = await context(root, args.connection, { bindings, work: args.work }), target = args.target;
  requireThat(target && /^[a-z][a-z0-9_-]*$/.test(target.id) && !project.folders.some((f) => f.id === target.id), "work", "Choose a new, unused working-folder ID.");
  requireThat(target.path === null || typeof target.path === "string", "path", "Choose a bound or project-relative target directory.");
  if (target.path !== null) relativePath(target.path);
  const next = { ...c.workFolder, id: target.id, path: target.path }, destination = await folderStore(root, next, { bindings });
  const clean = (s) => typeof s === "string" ? s.replace(/\\/g, "/").replace(/\/+$/, "") : null;
  const targetRoot = clean(destination.root);
  for (const f of project.folders) {
    const store = await folderStore(root, f, { bindings, writable: false });
    const oldRoot = clean(store.root);
    requireThat(targetRoot !== null && oldRoot !== null, "capability", "This runtime cannot verify directory separation for relocation.");
    requireThat(targetRoot !== "" && oldRoot !== "" && targetRoot !== oldRoot && !targetRoot.startsWith(oldRoot + "/") && !oldRoot.startsWith(targetRoot + "/"), "binding_overlap", "Choose a separate empty working directory.", { folder: f.id });
  }
  const occupied = (await destination.list("", { hidden: true })).filter((e) => e.path !== ".DS_Store");
  requireThat(!occupied.length, "occupied", "The selected working directory is not empty. Its contents are preserved.");
  const original = await snapshot2(c.work), receipt = [];
  for (const [name, seen] of original) {
    const content = destination.capabilities?.textWritesOnly ? seen.text ?? new TextDecoder("utf-8", { fatal: true }).decode(seen.bytes) : seen.bytes ?? seen.text;
    await destination.write(name, content, { expected: null });
    const copied = await destination.read(name, { binary: true });
    requireThat(copied?.sha256 === seen.sha256, "mismatch", "Working-copy verification failed.", { page: name });
    receipt.push({ page: name, sha256: seen.sha256 });
  }
  const wikiIDs = new Set(project.connections.filter((x2) => x2.works.includes(c.workFolder.id)).map((x2) => x2.wiki));
  for (const wikiID of wikiIDs) {
    const wiki2 = project.folders.find((f) => f.id === wikiID), priorIdentity = syncIdentity(project, wiki2, c.workFolder), identity2 = syncIdentity(project, wiki2, next), oldPrefix = ".llmwiki/editor-sync/" + await root.services.hash(priorIdentity) + "/", newPrefix = ".llmwiki/editor-sync/" + await root.services.hash(identity2) + "/";
    for (const [name, seen] of original) if (name.startsWith(oldPrefix) && name.endsWith(".json")) {
      const data = JSON.parse(seen.text ?? new TextDecoder().decode(seen.bytes));
      requireThat(data.format === "llmwiki-editor-sync/1" && data.identity === priorIdentity, "sync", "Invalid sync baseline; relocation stopped.");
      await destination.write(newPrefix + name.slice(oldPrefix.length), JSON.stringify({ ...data, identity: identity2 }), { expected: null });
    }
  }
  const current2 = await snapshot2(c.work);
  requireThat(current2.size === original.size && [...original].every(([p, v]) => current2.get(p)?.sha256 === v.sha256), "stale", "The working copy changed during relocation. The original assignment is preserved.");
  requireThat((await root.read("llmwiki.project.json"))?.sha256 === file.sha256, "stale", "Project settings changed during relocation.");
  const audit = ".llmwiki/relocations/" + root.services.uuid() + ".json";
  await root.write(audit, JSON.stringify({ format: "llmwiki-relocation/1", at: root.services.now(), from: c.workFolder, to: next, files: receipt, deleted: 0 }, null, 2) + "\n", { expected: null });
  project.folders = project.folders.map((f) => f.id === c.workFolder.id ? next : f);
  project.connections = project.connections.map((x2) => ({ ...x2, works: x2.works.map((id) => id === c.workFolder.id ? next.id : id) }));
  const saved = await saveSettings(root, project, file.sha256, { bindings, editorHTML });
  await selectWorkspace(root, c.connection.id, next.id);
  return { ...saved, from: c.workFolder.id, to: next.id, copied: receipt.length, deleted: 0, published: 0, receipt: audit };
}

// runtime/dispatch.mjs
init_project2();
init_content();

// runtime/workflow.mjs
init_graph();
init_document();
init_errors();
init_content();
var FORMAT = "llmwiki-workflow/1";
var ROOT2 = ".llmwiki/workflows";
var normalized = (text2) => String(text2).replace(/\s+/g, " ").trim();
var sessionPath = (id) => {
  requireThat(/^[a-f0-9]{32}$/.test(id), "session", "Invalid integration session.");
  return ROOT2 + "/" + id + ".json";
};
async function load2(store, id) {
  const file = await store.read(sessionPath(id));
  requireThat(file, "session", "Integration session is missing.");
  const data = JSON.parse(file.text);
  requireThat(data.format === FORMAT && data.id === id && ["ingest", "appropriate"].includes(data.mode), "session", "Unknown session format.");
  if (data.review && !data.review.sha256) data.review.sha256 = data.review_sha256;
  for (const d of data.decisions ?? []) if (!d.review_sha) d.review_sha = d.review_sha256;
  return { data, file };
}
async function persist2(store, data, file) {
  data.updated_at = store.services.now();
  await store.write(sessionPath(data.id), JSON.stringify(data, null, 2) + "\n", { expected: file?.sha256 ?? null });
  return data;
}
async function snapshot3(store, page) {
  const file = await store.read(page);
  requireThat(file, "page", "A reviewed page is missing.", { page });
  let text2 = file.text;
  const parsed = parseDocument(text2), ledger = await store.read(".llmwiki/derived-relations/" + encodeURIComponent(parsed.head.id || page) + ".json");
  if (ledger) {
    const managed = JSON.parse(ledger.text);
    if (Array.isArray(managed) && managed.length) text2 = patchHead(text2, { related: listValue(parsed.head.related).filter((v) => !managed.includes(v)) });
  }
  const stable = parseDocument(text2);
  return store.services.hash(JSON.stringify(stable.head) + "\n" + statementText(stable.body).replace(/\r\n?/g, "\n").trimEnd());
}
async function current(store, snapshots) {
  for (const [page, digest3] of Object.entries(snapshots ?? {})) {
    try {
      if (await snapshot3(store, page) !== digest3) return false;
    } catch {
      return false;
    }
  }
  return true;
}
async function quote2(store, record) {
  relativePath(record.page);
  nonempty(record.quote, "quote");
  const file = await store.read(record.page), parsed = file ? parseDocument(file.text) : null;
  const body = parsed?.head.resource ? mirroredContent(parsed.body) : parsed?.body;
  requireThat(typeof body === "string" && normalized(body).includes(normalized(record.quote)), "quote", "The cited quote is not present in the complete source passage.", { page: record.page });
  return record.page;
}
async function topicCandidates(store) {
  const topic_candidates = [];
  for (const e of await store.list("")) if (e.kind === "file" && visibleKnowledge(e.path)) {
    const f = await store.read(e.path), p = parseDocument(f.text);
    if (p.head.type === "topic" && !navigationPage(e.path)) topic_candidates.push({ page: e.path, title: p.head.title, description: p.head.description, expected: f.sha256 });
  }
  return topic_candidates;
}
var replacementMode = (previous, mode) => previous.mode === mode || mode === "appropriate" && previous.mode === "ingest" && previous.review?.policy === 2;
async function start(store, mode, pages, by, { replaces = [] } = {}) {
  requireThat(["ingest", "appropriate"].includes(mode), "mode", "Choose ingest or appropriate.");
  nonempty(by, "author");
  requireThat(Array.isArray(pages) && pages.length, "sources", "Select source pages.");
  const sources = [...new Set(pages)].sort();
  for (const page of sources) {
    relativePath(page);
    const file = await store.read(page);
    requireThat(file && visibleKnowledge(page) && parseDocument(file.text).head.resource, "source", "Integration starts from a complete source representation.", { page });
    const coverage = await sourceIntegrity(store, parseDocument(file.text));
    requireThat(coverage.complete, "coverage", "Complete the source reading with source.ingest before starting integration.", { page, ...coverage });
  }
  await requireDialogMode(store, sources, mode);
  requireThat(Array.isArray(replaces) && new Set(replaces).size === replaces.length, "replacement", "List unique previous integration sessions.");
  for (const id of replaces) {
    const previous = (await load2(store, id)).data;
    requireThat(replacementMode(previous, mode) && previous.sources.every((page) => sources.includes(page)), "replacement", "A successor must review every source of the same integration mode.");
  }
  const topic_candidates = await topicCandidates(store);
  const data = { topic_candidates, format: FORMAT, id: store.services.uuid().replace(/-/g, ""), mode, sources, replaces, by, started_at: store.services.now(), review: null, decisions: [], outputs: [], finished: false };
  return persist2(store, data, null);
}
async function verifyStructure(store, sources, record) {
  const graph = await buildGraph([{ id: "wiki", store }]);
  const edges = graph.edges.filter((e) => e.valid && e.type && !navigationPage(graph.pages.get(e.source).path) && !navigationPage(graph.pages.get(e.target).path));
  for (const page of sources) if (record.sources[page].relations === "linked") requireThat(edges.some((e) => graph.pages.get(e.source).path === page || graph.pages.get(e.target).path === page), "relations", "The declared relationship is missing from the knowledge graph.", { page });
  for (const page of record.topics.pages) requireThat(edges.some((e) => e.type === "part_of" && graph.pages.get(e.target).path === page && sources.includes(graph.pages.get(e.source).path)), "topics", "A reviewed topic needs a part_of relationship from a reviewed source.", { page });
}
async function review(store, id, record, by) {
  const { data, file } = await load2(store, id);
  data.topic_candidates ??= await topicCandidates(store);
  nonempty(by, "author");
  requireThat(record && record.sources && JSON.stringify(Object.keys(record.sources).sort()) === JSON.stringify(data.sources), "review", "Review every source in the session exactly once.");
  const paths = /* @__PURE__ */ new Set([...data.sources, "schema/TYPES.md"]);
  for (const page of data.sources) {
    const sourceFile = await store.read(page), coverage = sourceFile ? await sourceIntegrity(store, parseDocument(sourceFile.text)) : { complete: false };
    requireThat(coverage.complete, "coverage", "Complete the source reading with source.ingest before reviewing integration.", { page, ...coverage });
    const r = record.sources[page];
    nonempty(r.assessment, "assessment");
    nonempty(r.reason, "content-based assessment reason");
    requireThat(["linked", "none"].includes(r.relations) && Array.isArray(r.compared) && Array.isArray(r.evidence), "review", "Record comparison, passages and the relationship decision.");
    requireThat(data.sources.length === 1 || r.compared.some((p) => p !== page && data.sources.includes(p)), "comparison", "Compare each batch source with at least one other source in the batch, including when no relationship is warranted.", { page });
    const quoted = /* @__PURE__ */ new Set();
    for (const e of r.evidence) {
      quoted.add(await quote2(store, e));
      paths.add(e.page);
    }
    for (const p of [page, ...r.compared]) {
      requireThat(quoted.has(p), "quote", "Quote the source and every compared page.", { page: p });
      paths.add(p);
    }
  }
  nonempty(record.topics?.reason, "topic review reason");
  requireThat(Array.isArray(record.topics.pages), "topics", "List topic hubs or justify why none is appropriate.");
  if (data.topic_candidates?.length) {
    requireThat(Array.isArray(record.topics.considered) && record.topics.considered.length, "topics", "Compare existing topic candidates before creating or rejecting hubs.");
    for (const candidate of record.topics.considered) {
      requireThat(data.topic_candidates.some((t) => t.page === candidate.page), "topics", "Choose a topic from the recorded candidates.");
      nonempty(candidate.reason, "topic reuse/rejection reason");
      requireThat(["reuse", "not_relevant"].includes(candidate.decision), "topics", "Record reuse or not_relevant for each examined candidate.");
      const f = await store.read(candidate.page);
      requireThat(f && f.sha256 === candidate.expected, "stale", "Read the current topic candidate.");
      nonempty(candidate.quote, "topic quote");
      requireThat(parseDocument(f.text).body.includes(candidate.quote), "quote", "Quote the actual topic candidate.");
      if (candidate.decision === "reuse") requireThat(record.topics.pages.includes(candidate.page), "topics", "Include reused topics in the membership list.");
      paths.add(candidate.page);
    }
  }
  for (const page of record.topics.pages) {
    const p = await store.read(page);
    requireThat(p && parseDocument(p.text).head.type === "topic" && !["WIKI.md", "wiki/index.md"].includes(page), "topics", "Use content-based topic pages, not the bundle index.");
    paths.add(page);
  }
  requireThat(Array.isArray(record.insights), "insights", "Record the insights developed from the comparison.");
  for (const insight of record.insights) {
    nonempty(insight.statement, "insight");
    requireThat(Array.isArray(insight.evidence) && insight.evidence.length, "evidence", "Each insight needs source passages.");
    for (const e of insight.evidence) {
      await quote2(store, e);
      paths.add(e.page);
    }
  }
  await verifyStructure(store, data.sources, record);
  const snapshots = {};
  for (const page of paths) snapshots[page] = await snapshot3(store, page);
  data.review = { policy: 3, by, at: store.services.now(), snapshots, record };
  data.review.sha256 = await store.services.hash(JSON.stringify(data.review));
  data.review_sha256 = data.review.sha256;
  data.finished = false;
  await persist2(store, data, file);
  return status(store, id);
}
async function status(store, id) {
  const { data } = await load2(store, id);
  let next = "review", outcome = "pending";
  if (data.review?.policy === 3 && await current(store, data.review.snapshots)) {
    next = data.mode === "appropriate" ? "dialogue" : "curate";
    const decision = data.decisions.filter((d) => d.review_sha === data.review.sha256).at(-1);
    if (data.mode === "appropriate" && decision) {
      if (decision.choice === "take") next = "curate";
      else {
        next = "done";
        outcome = decision.choice === "defer" ? "deferred" : "declined";
      }
    }
    if (data.finished && await current(store, data.output_snapshots)) {
      if (data.completion?.outcome === "no_change") {
        next = "done";
        outcome = "no_change";
      } else if (data.review.record.insights.length && data.outputs.length) {
        next = "done";
        outcome = "integrated";
      }
    }
  }
  return { id, topic_candidates: data.topic_candidates ?? await topicCandidates(store), mode: data.mode, next, outcome, complete: outcome === "integrated", resolved: outcome !== "pending", completion: data.completion ?? null, replaces: data.replaces ?? [], sources: data.sources, outputs: data.outputs, review: data.review, decisions: data.decisions };
}
async function decide(store, id, decision, by) {
  const { data, file } = await load2(store, id), s = await status(store, id);
  requireThat(data.mode === "appropriate" && s.next !== "review", "decision", "Review current evidence before the dialogue decision.");
  nonempty(by, "author");
  requireThat(["take", "defer", "decline"].includes(decision.choice), "decision", "Choose take, defer or decline.");
  nonempty(decision.reply, "actual user reply");
  if (decision.choice === "take") {
    requireThat(Array.isArray(decision.selected) && decision.selected.length && decision.selected.every((i2) => Number.isInteger(i2) && i2 > 0 && i2 <= data.review.record.insights.length), "decision", "Select the agreed insights.");
    requireThat(["elaboration", "entries", "existing"].includes(decision.form), "decision", "Choose where the agreed knowledge is recorded.");
  }
  data.decisions.push({ ...decision, by, at: store.services.now(), review_sha: data.review.sha256, review_sha256: data.review.sha256 });
  data.finished = false;
  await persist2(store, data, file);
  return status(store, id);
}
async function finish(store, id, outputs, by, { outcome = "integrated", reason = null } = {}) {
  const { data, file } = await load2(store, id), s = await status(store, id);
  requireThat(s.next === "curate", "workflow", "Complete the " + s.next + " step before finishing integration.");
  nonempty(by, "author");
  requireThat(Array.isArray(outputs), "outputs", "List the curated knowledge pages.");
  requireThat(["integrated", "no_change"].includes(outcome), "outcome", "Choose integrated or explicitly reviewed no_change.");
  await verifyStructure(store, data.sources, data.review.record);
  if (outcome === "no_change") {
    requireThat(data.mode === "ingest" && !outputs.length && !data.review.record.insights.length, "outcome", "No-change closure cannot discard recorded insights or an appropriation decision.");
    nonempty(reason, "no-change reason");
    data.outputs = [];
    data.output_snapshots = {};
    data.finished = true;
    data.completion = { outcome, reason, by, at: store.services.now() };
    await persist2(store, data, file);
    return status(store, id);
  }
  requireThat(data.review.record.insights.length > 0 && outputs.length > 0, "integration", "Integration requires a materialized insight. Use an explicit no_change outcome for a review without integration.");
  const outputPages = [];
  for (const page of outputs) {
    relativePath(page);
    requireThat(visibleKnowledge(page) && !data.sources.includes(page) && !["WIKI.md", "wiki/bundle.md", "wiki/index.md"].includes(page), "outputs", "Record insights separately from source and navigation pages.");
    const p = await store.read(page);
    requireThat(p, "outputs", "An output page is missing.");
    outputPages.push({ page, ...parseDocument(p.text) });
  }
  {
    const decision = s.decisions.filter((d) => d.review_sha === data.review.sha256).at(-1);
    const selected = data.mode === "appropriate" ? decision.selected : data.review.record.insights.map((_, i2) => i2 + 1);
    for (const i2 of selected) {
      const insight = data.review.record.insights[i2 - 1], ids = [];
      for (const e of insight.evidence) {
        const head = parseDocument((await store.read(e.page)).text).head;
        ids.push(head.source_id ?? head.id);
      }
      requireThat(outputPages.some((p) => normalized(p.body).includes(normalized(insight.statement)) && ids.every((id2) => listValue(p.head.sources).some((c) => String(c).split(/[@#]/)[0] === id2))), "outputs", "An accepted insight or its source citation is missing.", { insight: i2 });
    }
  }
  await refreshIndex(store);
  const scope = [{ id: "wiki", label: "Wiki", store }], ready = await readiness(scope);
  requireThat(ready.ready, "readiness", "Wiki integration still has open content or graph gaps.", ready);
  const { buildGraph: buildGraph2 } = await Promise.resolve().then(() => (init_graph(), graph_exports)), graph = await buildGraph2(scope);
  const linked = (from, to) => listValue(from.head.related).some((v) => {
    const m = typeof v === "string" && /^\[[^\]]+\]\(<?([^)>]+)>?\)$/.exec(v.trim());
    return m && resolvePage(graph, from, m[1]).key === to.key;
  });
  for (const output of outputPages) {
    const note = graph.pages.get(JSON.stringify(["wiki", output.page]));
    for (const page of data.sources) {
      const source2 = graph.pages.get(JSON.stringify(["wiki", page]));
      if (listValue(note.head.sources).some((id2) => String(id2).split(/[@#]/)[0] === String(source2.head.source_id ?? source2.head.id))) requireThat(linked(note, source2), "related", "The derived note needs an outgoing Markdown related link to its source; the source lists the incoming backlink.", { source: page, output: output.page });
    }
  }
  for (const page of data.sources) {
    const key = JSON.stringify(["wiki", page]), edges = [...graph.outgoing.get(key) ?? [], ...graph.incoming.get(key) ?? []].filter((e) => e.valid && e.type);
    requireThat(edges.length || data.review.record.sources[page].relations === "none", "relations", "Connect the source with justified relationships or record why none is warranted.", { page });
  }
  const output_snapshots = {};
  for (const page of outputs) output_snapshots[page] = await snapshot3(store, page);
  requireThat(await current(store, data.review.snapshots), "stale", "Reviewed source contents changed during finalization.");
  data.outputs = outputs;
  data.output_snapshots = output_snapshots;
  data.finished = true;
  data.completion = { outcome: "integrated" };
  data.finished_by = by;
  data.finished_at = store.services.now();
  await persist2(store, data, file);
  return status(store, id);
}
async function sessions(store) {
  let entries;
  try {
    entries = await store.list(ROOT2);
  } catch (e) {
    if (e.code === "ENOENT") return [];
    throw e;
  }
  const result = [];
  for (const e of entries) if (e.kind === "file" && /\/[a-f0-9]{32}\.json$/.test(e.path)) try {
    result.push(await status(store, e.path.split("/").at(-1).slice(0, -5)));
  } catch (error) {
    result.push({ path: e.path, error: error.message });
  }
  const byID = new Map(result.filter((s) => s.id).map((s) => [s.id, s]));
  for (const successor of result.filter((s) => s.complete)) {
    if (!successor.complete) continue;
    const pending = [...successor.replaces], visited = /* @__PURE__ */ new Set();
    while (pending.length) {
      const id = pending.pop();
      if (visited.has(id) || id === successor.id) continue;
      visited.add(id);
      const previous = byID.get(id);
      if (!previous || !replacementMode(previous, successor.mode) || !previous.sources.every((p) => successor.sources.includes(p))) continue;
      pending.push(...previous.replaces);
      Object.assign(previous, { next: "done", outcome: "superseded", complete: false, resolved: true, replaced_by: successor.id });
    }
  }
  return result;
}

// runtime/maintenance.mjs
init_document();
init_content();
init_errors();
init_review();
init_graph();
async function plan(store, source2, options = {}) {
  return compareInventory(store, source2, await inventory(source2, options), options);
}
async function compareInventory(store, source2, originals, { prefix = "", paths, listedPaths = null } = {}) {
  if (prefix) relativePath(prefix);
  if (paths) {
    requireThat(Array.isArray(paths), "paths", "Select source-relative paths.");
    paths.forEach((p) => relativePath(p));
  }
  const selected = (p) => (!prefix || p === prefix || p.startsWith(prefix + "/")) && (!paths || paths.includes(p));
  const byName = new Map(originals.map((f) => [f.path, f])), mirrors = [];
  for (const e of await store.list("")) if (e.kind === "file" && visibleKnowledge(e.path)) {
    const f = await store.read(e.path), p = parseDocument(f.text);
    if (p.head.resource?.store === source2.id) mirrors.push({ page: e.path, expectedPage: f.sha256, source_id: p.head.source_id ?? p.head.id, resource: p.head.resource, integrity: await sourceIntegrity(store, p) });
  }
  const known = new Map(mirrors.map((m) => [m.resource.name, m])), changes = [];
  for (const f of originals) {
    const prior = known.get(f.path);
    if (f.error) {
      changes.push({ ...f, state: "unreadable" });
      continue;
    }
    if (prior) {
      changes.push({ ...f, ...prior, state: prior.resource.sha256 !== f.sha256 || prior.resource.availability === "missing" ? "changed" : prior.integrity.complete ? "unchanged" : "repair_required" });
      continue;
    }
    const candidates = [];
    for (const m of mirrors.filter((m2) => m2.resource.sha256 === f.sha256)) if (listedPaths ? !listedPaths.has(m.resource.name) : !await source2.store.read(m.resource.name, { binary: true })) candidates.push(m);
    const unique = (!listedPaths || !originals.some((o) => o.error)) && originals.filter((o) => o.sha256 === f.sha256 && !known.has(o.path)).length === 1;
    changes.push({ ...f, state: candidates.length === 1 && unique ? "renamed" : "new", ...candidates.length === 1 && unique ? candidates[0] : {}, previous_name: candidates.length === 1 && unique ? candidates[0].resource.name : void 0 });
  }
  for (const m of mirrors) if (selected(m.resource.name) && !byName.has(m.resource.name) && !changes.some((c) => c.state === "renamed" && c.page === m.page)) changes.push({ ...m, path: m.resource.name, state: "missing" });
  const reviewable = changes.filter((c) => c.page && c.state !== "unchanged");
  if (reviewable.length) {
    const graph = await buildGraph([{ id: "local", store }], { allowMissingRegister: true });
    const dependents = /* @__PURE__ */ new Map();
    const add3 = (key, page, reason) => {
      if (!dependents.has(key)) dependents.set(key, []);
      dependents.get(key).push({ page, reason });
    };
    for (const p of graph.pages.values()) for (const citation2 of listValue(p.head.sources)) {
      const evidence = resolveEvidence(graph, citation2, p.wiki);
      if (evidence) add3(evidence.key, p, "source citation");
    }
    for (const edge of graph.edges) if (edge.valid && edge.type) add3(edge.target, graph.pages.get(edge.source), "typed relation: " + edge.type);
    for (const change of reviewable) {
      const origin = [...graph.pages.values()].find((p) => p.path === change.page), seen = new Set(origin ? [origin.key] : []), queue2 = origin ? [origin.key] : [];
      change.affected = [];
      while (queue2.length) for (const { page, reason } of dependents.get(queue2.shift()) ?? []) {
        if (seen.has(page.key)) continue;
        seen.add(page.key);
        queue2.push(page.key);
        change.affected.push({ page: page.path, expected: page.sha256, reason, review_required: true });
      }
    }
  }
  return { source: source2.id, scope: { prefix, paths: paths ?? null }, changes, counts: Object.fromEntries(["new", "changed", "unchanged", "repair_required", "renamed", "missing", "unreadable"].map((s) => [s, changes.filter((c) => c.state === s).length])) };
}
async function markMissing(store, source2, { page, expected, author, reason }) {
  nonempty(author, "author");
  nonempty(reason, "reason");
  const f = await store.read(page);
  requireThat(f && f.sha256 === expected, "stale", "Read the current source page.");
  const p = parseDocument(f.text);
  requireThat(p.head.resource?.store === source2.id && !await source2.store.read(p.head.resource.name, { binary: true }), "source", "The original must be absent from this source root.");
  await save(store, page, patchHead(f.text, { resource: { ...p.head.resource, availability: "missing", checked_at: store.services.now(), missing_reason: reason } }), author, expected);
  await refreshIndex(store);
  return { page, preserved: true, deleted: 0, availability: "missing" };
}

// runtime/query.mjs
init_graph();
init_document();
init_errors();
init_content();

// runtime/core/search-terms.mjs
var searchTokens = (text2) => String(text2).toLowerCase().normalize("NFKC").match(/[\p{L}\p{N}]+/gu) ?? [];
function stem(value) {
  if (value.length <= 3) return value;
  value = value.replace(/ß/g, "ss").normalize("NFKD").replace(/\p{M}/gu, "").replace(/ae/g, "a").replace(/oe/g, "o").replace(/ue/g, "u");
  let boundary = value.length;
  for (let i2 = 1; i2 < value.length; i2++) if (/[aeiouy]/.test(value[i2 - 1]) && !/[aeiouy]/.test(value[i2])) {
    boundary = Math.max(3, i2 + 1);
    break;
  }
  for (const suffix of ["ern", "em", "er", "en", "es", "e", "s"]) if (value.endsWith(suffix) && value.length - suffix.length >= boundary) {
    if (suffix === "s" && !/[bdfghklmnrt]/.test(value.at(-2))) continue;
    return value.slice(0, -suffix.length);
  }
  return value;
}
function matchWeight(term, word) {
  if (term === word) return 1;
  if (term.length <= 3 || word.length <= 3) return 0;
  const query2 = stem(term), candidate = stem(word);
  if (query2 === candidate) return 0.8;
  const prefix = candidate.length - query2.length;
  return query2.length >= 5 && prefix >= 2 && prefix <= 20 && candidate.endsWith(query2) ? 0.55 : 0;
}
function termFrequency(term, frequencies) {
  let total = 0;
  for (const [word, count] of frequencies) total += matchWeight(term, word) * count;
  return total;
}
function termPresence(term, words3) {
  let best = 0;
  for (const word of words3) best = Math.max(best, matchWeight(term, word));
  return best;
}
function expansionEvidence(terms, words3, limit = 64) {
  const expansions = [], seen = /* @__PURE__ */ new Set();
  let truncated = false;
  for (const term of terms) for (const word of words3) {
    const weight = matchWeight(term, word), key = term + "\0" + word;
    if (!weight || weight === 1 || seen.has(key)) continue;
    seen.add(key);
    if (expansions.length >= limit) {
      truncated = true;
      continue;
    }
    expansions.push({ query: term, word, kind: weight === 0.8 ? "word-form" : "compound-suffix", weight });
  }
  return { method: "german-conservative/1", weights: { exact: 1, word_form: 0.8, compound_suffix: 0.55 }, expansions, truncated };
}

// runtime/shadow-search.mjs
var shadowTokens = searchTokens;
var stop = new Set("der die das den dem des ein eine einer eines und oder ist sind war waren warum wie was why the a an and or is are was were".split(" "));
var shadowTerms = (text2) => {
  const words3 = [...new Set(shadowTokens(text2))], content = words3.filter((w) => !stop.has(w));
  return content.length ? content : words3;
};
function sectionRanking(documents, question) {
  const terms = shadowTerms(question), sections = [];
  for (const document2 of documents) for (let index = 0; index < document2.data.blocks.length; index++) {
    const block = document2.data.blocks[index];
    if (block.kind === "heading") continue;
    const words3 = shadowTokens(block.quote), frequencies = /* @__PURE__ */ new Map();
    for (const word of words3) frequencies.set(word, (frequencies.get(word) ?? 0) + 1);
    sections.push({ document: document2, block, index, length: words3.length, frequencies, headings: new Set(shadowTokens(block.headings.join(" "))) });
  }
  const average = sections.reduce((n, s) => n + s.length, 0) / Math.max(1, sections.length), counts = new Map(terms.map((t) => [t, sections.filter((s) => termFrequency(t, s.frequencies) > 0).length]));
  for (const section of sections) {
    section.score = 0;
    for (const term of terms) {
      const tf = termFrequency(term, section.frequencies), idf = Math.log(1 + (sections.length - counts.get(term) + 0.5) / (counts.get(term) + 0.5));
      section.score += idf * (tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * section.length / Math.max(1, average))) + termPresence(term, section.headings) * 0.2);
    }
  }
  return sections.filter((s) => s.score > 0).sort((a, b) => b.score - a.score || a.block.start - b.block.start);
}
function sectionWindow(document2, index, budget, bodyOffset = 0, question = "") {
  const blocks = document2.data.blocks, block = blocks[index];
  let start2 = block.start, end = block.end;
  if (end - start2 > budget) {
    const terms = new Set(shadowTerms(question)), matches = [...block.quote.matchAll(/[\p{L}\p{N}]+/gu)].filter((m) => [...terms].some((t) => matchWeight(t, searchTokens(m[0])[0]) > 0));
    let best = -1;
    for (const match of matches) {
      const candidate = Math.max(block.start, Math.min(block.end - budget, block.start + match.index - Math.floor(budget / 4))), score = new Set(shadowTokens(document2.data.source.slice(candidate, candidate + budget)).filter((word) => [...terms].some((t) => matchWeight(t, word) > 0))).size;
      if (score > best) {
        start2 = candidate;
        best = score;
      }
    }
    end = Math.min(block.end, start2 + budget);
    if (start2 > block.start && /[\uDC00-\uDFFF]/.test(document2.data.source[start2])) start2++;
    if (end < block.end && /[\uDC00-\uDFFF]/.test(document2.data.source[end])) end--;
    return { start: start2 - bodyOffset, end: end - bodyOffset, headings: block.headings };
  }
  if (blocks[index + 1] && blocks[index + 1].kind !== "heading" && blocks[index + 1].end - start2 <= budget) end = blocks[index + 1].end;
  if (blocks[index - 1] && end - blocks[index - 1].start <= budget) start2 = blocks[index - 1].start;
  return { start: Math.max(0, start2 - bodyOffset), end: Math.max(0, Math.min(end, start2 + budget) - bodyOffset), headings: block.headings };
}

// runtime/query.mjs
function balancedSeeds(ranked, graph, limit) {
  const groups = /* @__PURE__ */ new Map();
  for (const hit of ranked) {
    const wiki2 = graph.pages.get(hit.key).wiki;
    if (!groups.has(wiki2)) groups.set(wiki2, []);
    groups.get(wiki2).push(hit);
  }
  const hits = [];
  for (let round = 0; hits.length < limit; round++) {
    const candidates = [...groups.values()].map((rows) => rows[round]).filter(Boolean).sort((a, b) => b.score - a.score || a.key.localeCompare(b.key));
    if (!candidates.length) break;
    hits.push(...candidates.slice(0, limit - hits.length));
  }
  const represented = new Set(hits.map((h) => graph.pages.get(h.key).wiki)), omitted = [...groups.keys()].filter((wiki2) => !represented.has(wiki2));
  return { hits, allocation: { policy: "one-per-relevant-wiki-per-round; next-score descending", limit, relevant_wikis: groups.size, represented_wikis: [...represented], omitted_wikis: omitted } };
}
async function query(wikis, { question, filters = {}, limit = 8, hops = 2, max_context_chars = 12e4 } = {}, options = {}) {
  nonempty(question, "question");
  requireThat(Number.isInteger(limit) && limit > 0 && limit <= 100 && Number.isInteger(hops) && hops >= 0 && hops <= 4, "query", "Choose 1\u2013100 seeds and 0\u20134 relationship steps.");
  requireThat(Number.isInteger(max_context_chars) && max_context_chars >= 1e3 && max_context_chars <= 2e6, "query", "Choose a context budget between 1000 and 2000000 characters.");
  requireThat(Object.keys(filters).every((k) => ["wiki", "type", "status", "owner", "class", "tags", "participates"].includes(k)), "filter", "Unknown search filter.");
  if (Object.hasOwn(filters, "participates")) requireThat(typeof filters.participates === "string" && /^x_[a-z][a-z0-9_]*$/.test(filters.participates), "filter", "Use one registered participation field name.");
  const graph = await buildGraph(wikis), terms = shadowTerms(question), docs = [];
  const shadow = options.shadow ?? await readShadow(wikis, null), shadowDocs = new Map(shadow.documents.map((d) => [JSON.stringify([d.wiki, d.path]), d]));
  for (const [key, row] of shadowDocs) {
    const page = graph.pages.get(key);
    if (!page) {
      shadowDocs.delete(key);
      continue;
    }
    if (row.revision !== page.sha256 || row.data.source !== page.source) {
      try {
        const data = await parseShadow(page.source, graph.scopes.get(page.wiki).store.services);
        data.blocks = data.blocks.map((b) => ({ ...b, id: null, mapping: "unpersisted", predecessors: [] }));
        shadowDocs.set(key, { wiki: page.wiki, path: page.path, id: null, revision: page.sha256, data, state: "fallback" });
        shadow.persistent = false;
        shadow.reason = "changed_files";
      } catch (error) {
        shadowDocs.delete(key);
        shadow.findings.push({ wiki: page.wiki, page: page.path, code: error.code ?? "shadow", message: error.message });
      }
    }
  }
  for (const page of graph.pages.values()) {
    if (["WIKI.md", "wiki/index.md", "wiki/bundle.md"].includes(page.path)) continue;
    if (filters.participates && !await participationMatches(graph.scopes.get(page.wiki).store, page.head, filters.participates)) continue;
    if (Object.entries(filters).filter(([k]) => k !== "participates").some(([k, v]) => !listValue(v).some((wanted) => listValue(k === "wiki" ? page.wiki : page.head[k]).includes(wanted)))) continue;
    const title = searchTokens([page.head.title, ...listValue(page.head.aliases)].join(" ")), description = searchTokens(page.head.description ?? ""), body = searchTokens(page.body), frequencies = /* @__PURE__ */ new Map();
    for (const word of body) frequencies.set(word, (frequencies.get(word) ?? 0) + 1);
    docs.push({ page, title, description, frequencies, length: body.length });
  }
  const average = docs.reduce((s, d) => s + d.length, 0) / Math.max(1, docs.length), counts = new Map(terms.map((t) => [t, docs.filter((d) => termFrequency(t, d.frequencies) > 0 || termPresence(t, d.title) > 0 || termPresence(t, d.description) > 0).length]));
  const bestSections = /* @__PURE__ */ new Map();
  for (const section of sectionRanking(docs.map((d) => shadowDocs.get(d.page.key)).filter(Boolean), question)) {
    const key = JSON.stringify([section.document.wiki, section.document.path]);
    if (!bestSections.has(key)) bestSections.set(key, section);
  }
  const ranked = docs.map((d) => {
    let score = 0;
    for (const term of terms) {
      const tf = termFrequency(term, d.frequencies), n = counts.get(term), idf = Math.log(1 + (docs.length - n + 0.5) / (n + 0.5));
      score += idf * (tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * d.length / Math.max(1, average))) + termPresence(term, d.title) * 3 + termPresence(term, d.description) * 1.5);
    }
    return { key: d.page.key, score: score + (bestSections.get(d.page.key)?.score ?? 0) };
  }).filter((r) => r.score > 0).sort((a, b) => b.score - a.score || a.key.localeCompare(b.key));
  const { hits, allocation } = balancedSeeds(ranked, graph, limit), selected = new Set(hits.map((h) => h.key)), routes = new Map(hits.map((h) => [h.key, { kind: "search", depth: 0 }]));
  let frontier = hits.map((h) => h.key);
  for (let depth = 1; depth <= hops; depth++) {
    const next = [];
    for (const key of frontier) for (const edge of [...graph.outgoing.get(key) ?? [], ...graph.incoming.get(key) ?? []]) {
      if (!edge.valid || !edge.type) continue;
      const neighbor = edge.source === key ? edge.target : edge.source;
      if (!selected.has(neighbor)) {
        selected.add(neighbor);
        next.push(neighbor);
        routes.set(neighbor, { kind: "relationship", depth, type: edge.type, reason: edge.reason, via: key });
      }
    }
    frontier = next;
  }
  for (const key of [...selected]) for (const edge of [...graph.outgoing.get(key) ?? [], ...graph.incoming.get(key) ?? []]) if (edge.valid && ["contradicts", "superseded_by"].includes(edge.type)) {
    const other = edge.source === key ? edge.target : edge.source;
    selected.add(other);
    if (!routes.has(other)) routes.set(other, { kind: "counter-reading", type: edge.type, reason: edge.reason, via: key });
  }
  const context2 = [], coverageFindings = allocation.omitted_wikis.length ? [{ code: "wiki_seed_budget", wikis: allocation.omitted_wikis, message: "The seed limit cannot include every relevant wiki. Increase limit or narrow the wiki filter." }] : [], allowance = Math.floor(max_context_chars / Math.max(1, selected.size));
  for (const key of selected) {
    const p = graph.pages.get(key);
    let start2 = 0, end = p.body.length;
    const section = bestSections.get(key), structure = shadowDocs.get(key);
    if (end > allowance) {
      if (section && structure?.revision === p.sha256) {
        ({ start: start2, end } = sectionWindow(structure, section.index, allowance, p.offset, question));
      } else {
        let best = -1;
        for (let offset = 0; offset < p.body.length; offset += Math.max(1, allowance)) {
          const words3 = new Set(searchTokens(p.body.slice(offset, offset + allowance))), score = terms.reduce((n, t) => n + termPresence(t, words3), 0);
          if (score > best) {
            best = score;
            start2 = offset;
          }
        }
        end = Math.min(p.body.length, start2 + allowance);
      }
    }
    const head = structuredClone(p.head);
    if (head.extraction?.evidence) head.extraction.evidence = { format: head.extraction.evidence.format, by: head.extraction.evidence.by, parts: head.extraction.evidence.parts?.length };
    if (p.head.resource) {
      const check = await sourceIntegrity(graph.scopes.get(p.wiki).store, p);
      coverageFindings.push(...check.findings.map((code) => ({ code, wiki: p.wiki, page: p.path })));
    }
    context2.push({ key, wiki: p.wiki, page: p.path, title: p.head.title, head, text: p.body.slice(start2, end), headings: section?.block.headings ?? [], passage: { start: start2, end, total_chars: p.body.length }, truncated: start2 !== 0 || end !== p.body.length, sha256: p.sha256, route: routes.get(key) });
  }
  for (let i2 = context2.length - 1; i2 >= 0; i2--) {
    const c = context2[i2];
    try {
      if ((await graph.scopes.get(c.wiki).store.read(c.page))?.sha256 !== c.sha256) throw Error("The cited document changed during retrieval.");
    } catch (error) {
      coverageFindings.push({ wiki: c.wiki, page: c.page, code: "citation_stale", message: error.message });
      context2.splice(i2, 1);
    }
  }
  const safeKeys = new Set(context2.map((c) => c.key)), relations = graph.edges.filter((e) => e.valid && e.type && safeKeys.has(e.source) && safeKeys.has(e.target));
  const result = {
    question,
    allocation,
    normalization: expansionEvidence(terms, [...new Set(context2.flatMap((c) => searchTokens(c.title + " " + c.text)))]),
    method: "section BM25 + file BM25 + typed graph + counter-reading",
    hits: hits.filter((h) => context2.some((c) => c.key === h.key)).map((h) => ({ ...h, wiki: graph.pages.get(h.key).wiki, page: graph.pages.get(h.key).path })),
    context: context2,
    relations,
    shadow: { mode: shadow.mode, reason: shadow.reason ?? "read_only_fallback", persistent: shadow.persistent, findings: shadow.findings },
    citations: await Promise.all(context2.map(async (p) => {
      const page = graph.pages.get(p.key), c = await citation(page, graph.scopes.get(p.wiki).store, question, p.passage), row = shadowDocs.get(p.key);
      c.passages = c.passages.filter((b) => b.start >= p.passage.start && b.end <= p.passage.end && b.quote.length <= allowance);
      if (row?.revision === p.sha256) {
        const start2 = page.offset + p.passage.start, end = page.offset + p.passage.end;
        const blocks = row.data.blocks.filter((b) => start2 < end && b.kind !== "heading" && b.start < end && b.end > start2).map((b) => {
          const direct = terms.some((t) => termPresence(t, searchTokens(b.quote)) > 0), heading = terms.some((t) => termPresence(t, searchTokens(b.headings.join(" "))) > 0);
          return { block: b, basis: direct ? "text" : heading ? "heading" : p.route.kind === "search" ? "page_context" : "relationship_context", score: Number(direct) * 2 + Number(heading) };
        }).sort((a, b) => b.score - a.score || a.block.start - b.block.start).slice(0, 8);
        c.shadow = { state: row.state, empty_reason: blocks.length ? null : start2 === end ? "context_budget_exhausted" : "no_structural_content_in_context", passages: blocks.map(({ block: b, basis }) => {
          const locator = makeLocator(p.wiki, row.id, row.data, b, { start: Math.max(b.start, start2), end: Math.min(b.end, end) });
          return { ...locator, page: p.page, retrieval_basis: basis, persisted: row.state === "current", pin_request: row.state === "current" ? { action: "shadow.pin", wiki: p.wiki, document: row.id, revision: row.revision, occurrence: b.occurrence, ...locator.partial ? { start: locator.start, end: locator.end } : {} } : null };
        }) };
      } else c.shadow = { state: "unavailable", empty_reason: "structure_unavailable", passages: [] };
      return c;
    })),
    total_matches: ranked.length,
    more_matches: ranked.length > hits.length,
    max_context_chars,
    context_truncated: context2.some((p) => p.truncated),
    next: context2.some((p) => p.truncated) ? "read full cited pages before conclusions" : null,
    complete: graph.failures.length === 0 && graph.findings.length === 0 && !coverageFindings.length && !shadow.findings.length && !context2.some((p) => p.truncated),
    findings: [...graph.failures, ...graph.findings, ...coverageFindings, ...shadow.findings]
  };
  result.shadow.passage_count = result.citations.reduce((n, c) => n + c.shadow.passages.length, 0);
  return result;
}

// runtime/dispatch.mjs
init_graph();
init_document();
init_review();
init_errors();
async function integratedNotePlan(store) {
  const plan2 = await planNotes(store), sessions2 = await sessions(store), reviewed = new Map(sessions2.filter((s) => s.complete).flatMap((s) => [...s.outputs, ...s.review.record.topics.pages].map((page) => [page, s.id])));
  for (const note of plan2.changes) if (note.state !== "unreadable" && note.assets.every((a) => a.state === "reviewed") && reviewed.has(note.page)) {
    note.state = "unchanged";
    note.review_basis = { workflow: reviewed.get(note.page) };
  }
  return { ...plan2, complete: plan2.changes.every((n) => n.state === "unchanged"), counts: Object.fromEntries(Object.keys(plan2.counts).map((s) => [s, plan2.changes.filter((n) => n.state === s).length])) };
}
var queryActions = ["published.check", "collection.assess", "participation.overview", "shadow.status", "shadow.resolve", "inspect", "context", "source.inventory", "source.plan", "source.read", "read", "query", "graph", "readiness", "workflow.status", "workflow.list", "review.read"];
var actions = ["collection.assess", "collection.upgrade", "collection.map", "participation.register", "participation.set", "participation.overview", "published.adopt", "published.check", "ingest.group", "ingest.take_back", "sharing.move", "shadow.rebuild", "shadow.refresh", "shadow.status", "shadow.pin", "shadow.resolve", "intake.start", "intake.decide", "intake.status", "wiki.initialize", "note.plan", "note.review", "attachment.plan", "attachment.review", "attachment.rename", "source.monitor", "graph.refresh", "metadata.repair", "folder.create", "document.move.plan", "document.move.apply", "wiki.flatten.plan", "inspect", "setup.draft", "configure", "settings", "detach", "editor", "context", "workspace.select", "workspace.relocate", "source.plan", "source.missing", "source.store", "source.inventory", "source.read", "source.ingest", "read", "write", "patch", "query", "graph", "index", "readiness", "workflow.start", "workflow.review", "workflow.decide", "workflow.finish", "workflow.status", "workflow.list", "sync", "conflict.resolve", "review.read", "review.respond"];
async function dispatch(root, request, options = {}) {
  const readOnly = root.writable === false;
  requireThat(!readOnly || queryActions.includes(request.action), "read-only", "The query skill is read-only. Setup and changes belong to maintain-llm-wiki.");
  if (request.action === "graph.refresh") return exportProjectGraph(root, options);
  const result = await executeAction(root, request, options);
  const stagedMutation = ["collection.upgrade", "collection.map", "published.adopt", "sharing.move", "ingest.group", "ingest.take_back"].includes(request.action) && ["applying", "applied", "rolling_back", "rolled_back"].includes(result.state) && (["apply", "rollback"].includes(request.step) || request.action === "ingest.take_back");
  if (readOnly && request.action === "inspect") {
    result.runtime.actions = queryActions;
    if (result.project) {
      result.next = "query";
      return result;
    }
    let knowledge = false;
    for (const prefix of ["wiki", ""]) try {
      knowledge ||= (await root.list(prefix, { recursive: false })).some((e) => e.kind === "file" && /\.md$/i.test(e.path));
    } catch (error) {
      if (!["ENOENT", "ENOTDIR"].includes(error.code)) throw error;
    }
    return { next: "locate_project", knowledge_present: knowledge, reason: "No project configuration at this root. This does not mean knowledge is absent.", project_hint: result.project_hint ?? null, runtime: result.runtime };
  }
  if (!readOnly && (stagedMutation || request.action === "participation.set" || ["wiki.initialize", "configure", "settings", "detach", "editor", "write", "patch", "metadata.repair", "document.move.apply", "source.ingest", "source.missing", "index", "workflow.finish", "sync", "conflict.resolve"].includes(request.action)) && await root.read("llmwiki.project.json")) {
    try {
      const snapshot4 = await exportProjectGraph(root, options);
      result.graph = { revision: snapshot4.revision, generated_at: snapshot4.generated_at, complete: snapshot4.complete };
    } catch (error) {
      result.graph_error = { code: error.code ?? "graph", message: error.message };
    }
  }
  if (!readOnly && (stagedMutation || request.action === "participation.set" || ["write", "patch", "index", "source.ingest", "document.move.apply", "workflow.finish", "sync"].includes(request.action)) && await root.read("llmwiki.project.json")) {
    try {
      result.shadow = await executeAction(root, { action: "shadow.refresh", ...request.connection ? { connection: request.connection } : {}, ...["write", "patch"].includes(request.action) && request.connection && result.page ? { paths: [result.page] } : {} }, options);
    } catch (error) {
      result.shadow = { complete: false, code: error.code ?? "shadow", message: error.message };
    }
  }
  return result;
}
async function executeAction(root, request, { bindings = {}, extract: extract2, editorHTML = null } = {}) {
  const { action, connection, ...args } = request;
  requireThat(actions.includes(action), "action", "Unknown action.", { actions });
  if (action === "inspect") return { ...await inspect(root, { editorHTML, bindings }), runtime: { format: "llmwiki-runtime/1", version: true ? "0.4.24" : "development", actions, capabilities: root.capabilities } };
  if (action === "source.monitor") {
    const { project: p } = await load(root), pairs = [], notes = [];
    for (const link of p.connections) try {
      const c2 = await context(root, link.id, { bindings });
      notes.push({ connection: link.id, wiki: link.wiki, plan: await integratedNotePlan(c2.work) });
    } catch (error) {
      notes.push({ connection: link.id, wiki: link.wiki, error: { code: error.code, message: error.message } });
    }
    for (const link of p.connections) {
      try {
        const c2 = await context(root, link.id, { bindings });
        for (const source2 of c2.sources) {
          if (!source2.store) {
            pairs.push({ connection: link.id, wiki: link.wiki, source: source2.id, error: source2.error });
            continue;
          }
          try {
            pairs.push({ connection: link.id, wiki: link.wiki, source: source2.id, plan: await plan(c2.work, source2, {}) });
          } catch (error) {
            pairs.push({ connection: link.id, wiki: link.wiki, source: source2.id, error: { code: error.code, message: error.message } });
          }
        }
      } catch (error) {
        pairs.push({ connection: link.id, wiki: link.wiki, error: { code: error.code, message: error.message } });
      }
    }
    return { pairs, notes, complete: !pairs.some((p2) => p2.error) && notes.every((n) => n.plan?.complete), next: "Process every new, changed and repair_required source in its assigned wiki; preserve unchanged originals. Review every new, changed or dependency_changed own note with note.review; do not infer semantic completion from a graph refresh." };
  }
  if (action === "collection.assess" && !await root.read("llmwiki.project.json")) return assessCollection(root, args);
  if (action === "workspace.relocate") return relocate(root, { ...args, connection }, { bindings, editorHTML });
  if (action === "configure") return configure(root, args, { bindings, editorHTML });
  if (action === "setup.draft") return setupDraft(root, args.answers, args.expected);
  if (action === "settings") return saveSettings(root, args.data, args.expected, { editorHTML, bindings });
  if (action === "detach") return detach(root, args.folder, args.expected, { editorHTML, bindings });
  if (action === "workspace.select") return selectWorkspace(root, connection, args.work);
  if (action === "editor") {
    const { project: p } = await load(root);
    requireThat(editorHTML, "editor", "This host needs the packaged HTML asset.");
    return installEditor(root, p, editorHTML, { ...args, bindings });
  }
  if (action === "participation.overview" || action === "query" || action === "graph" || action === "readiness" || action.startsWith("shadow.")) {
    const { project: p } = await load(root), target = action === "shadow.resolve" && args.reference ? decodePassage(args.reference) : null;
    if (target) {
      const marker = await root.read(".llmwiki/project-instance.json");
      requireThat(target.project === p.id && target.instance === JSON.parse(marker?.text ?? "null")?.instance, "citation_scope", "This passage belongs to another project instance.");
    }
    const selected = args.connections ?? (connection ? [connection] : target ? [target.connection] : p.connections.map((c2) => c2.id)), wikis = [], contexts = [], inaccessible = [];
    for (const id of selected) {
      requireThat(p.connections.some((c2) => c2.id === id), "connection", "Select an existing connection.");
      try {
        const c2 = await context(root, id, { bindings, ...target?.connection === id ? { work: target.work } : {} });
        contexts.push(c2);
        if (!wikis.some((w) => w.id === c2.wiki.id)) wikis.push({ id: c2.wiki.id, label: c2.wiki.label, path: c2.wiki.path ?? c2.wiki.id, connection: c2.connection.id, work: c2.workFolder.id, store: c2.work });
      } catch (error) {
        if (action !== "query" && action !== "participation.overview" && !action.startsWith("shadow.")) throw error;
        inaccessible.push({ connection: id, code: error.code ?? "access", message: error.message });
      }
    }
    if (action === "participation.overview") {
      const result = await overview(wikis, args.field);
      result.findings.push(...inaccessible.map((f) => ({ connection: f.connection, code: f.code })));
      result.complete &&= !inaccessible.length;
      return result;
    }
    if (action === "query" || action.startsWith("shadow.")) {
      requireThat(wikis.length, "access", "No selected wiki is currently accessible. Existing knowledge may still be present.", { findings: inaccessible });
      if (action === "shadow.resolve") {
        if (args.reference) {
          const marker = await root.read(".llmwiki/project-instance.json");
          return resolvePassage(wikis, args.reference, { project: p.id, instance: JSON.parse(marker?.text ?? "null")?.instance });
        }
        return resolveQuote(wikis, args.id);
      }
      const writing = ["shadow.refresh", "shadow.rebuild", "shadow.pin"].includes(action);
      let db = null, cacheError = null;
      try {
        if (root.shadowDatabase) {
          const instance = await root.read(".llmwiki/project-instance.json");
          db = await root.shadowDatabase(p.id + "@" + (instance ? JSON.parse(instance.text).instance : ""), { readOnly: !writing, rebuild: action === "shadow.rebuild", ...args.cache_bytes ? { maxBytes: args.cache_bytes } : {} });
        }
      } catch (error) {
        if (writing) throw error;
        cacheError = { code: error.code ?? "shadow_cache", message: error.message };
      }
      try {
        if (action === "shadow.refresh" || action === "shadow.rebuild") {
          if (!db) return { complete: false, mode: "memory", reason: "sqlite_unavailable", next: "Use a Node host for persistent maintenance; current passage retrieval remains available." };
          const result2 = await refreshShadow(wikis, db, { ...args, rebuild: action === "shadow.rebuild" });
          result2.findings.push(...inaccessible);
          result2.complete &&= !inaccessible.length;
          return result2;
        }
        if (action === "shadow.pin") {
          const pin = await pinQuote(wikis, db, args);
          const href = root.fileURL && await root.read("LLM-Wiki.html") ? await root.fileURL("LLM-Wiki.html") + "#shadow=" + pin.id : null;
          return { ...pin, editor_href: href, markdown: href ? "[Open retained quote](" + href + ")" : null };
        }
        const shadow = await readShadow(wikis, db, args);
        shadow.reason = cacheError ? "cache_unavailable" : !root.shadowDatabase ? "sqlite_unavailable" : !db ? "not_initialized" : shadow.persistent ? "current" : "changed_files";
        if (cacheError) shadow.findings.push(cacheError);
        if (action === "shadow.status") return { mode: shadow.mode, reason: shadow.reason, documents: shadow.documents.length, current: shadow.documents.filter((d) => d.state === "current").length, findings: [...shadow.findings, ...inaccessible] };
        const result = await editorCitations(root, p, contexts, await query(wikis, args, { shadow }));
        if (inaccessible.length) {
          result.findings.push(...inaccessible);
          result.complete = false;
        }
        return result;
      } finally {
        db?.close();
      }
    }
    if (action === "readiness") {
      const knowledge = await readiness(wikis), workflows = await Promise.all(wikis.map(async (w) => ({ wiki: w.id, sessions: await sessions(w.store) }))), blocked_by = [];
      if (!knowledge.ready) blocked_by.push({ code: "knowledge_findings" });
      for (const w of workflows) {
        for (const source2 of knowledge.source_pages.filter((p2) => p2.wiki === w.wiki)) if (!w.sessions.some((s) => s.sources?.includes(source2.page))) blocked_by.push({ code: "workflow_missing", wiki: w.wiki, page: source2.page });
        for (const session of w.sessions) if (session.error) blocked_by.push({ code: "workflow_error", wiki: w.wiki, path: session.path });
        else if (!session.complete && session.outcome !== "superseded") blocked_by.push({ code: "workflow_incomplete", wiki: w.wiki, id: session.id, next: session.next, outcome: session.outcome });
      }
      const notes = [];
      for (const w of wikis) {
        const plan2 = await integratedNotePlan(w.store), pending = plan2.changes.filter((n) => n.state !== "unchanged");
        notes.push({ wiki: w.id, ...plan2, pending });
        for (const n of pending) blocked_by.push({ code: "note_" + n.state, wiki: w.id, page: n.page });
      }
      const differences = [];
      for (const c2 of contexts) {
        const files2 = new Set([...await c2.work.list(""), ...await c2.remote.list("")].filter((e) => e.kind === "file" && (e.path === "schema/FIELDS.json" || /\.md$/i.test(e.path)) && !e.path.split("/").some((p2) => p2.startsWith("."))).map((e) => e.path));
        for (const page of files2) {
          const local2 = await c2.work.read(page), remote = await c2.remote.read(page);
          if (local2?.sha256 !== remote?.sha256) differences.push({ wiki: c2.wiki.id, connection: c2.connection.id, page, local: local2?.sha256 ?? null, remote: remote?.sha256 ?? null });
        }
      }
      const publication = { synchronized: !differences.length, differences };
      if (!publication.synchronized) blocked_by.push({ code: "publication_pending" });
      const originals = [];
      for (const c2 of contexts) for (const item of knowledge.source_pages.filter((p2) => p2.wiki === c2.wiki.id)) {
        const head = parseDocument((await c2.work.read(item.page)).text).head, source2 = c2.sources.find((s) => s.id === head.resource?.store);
        let state2 = "unavailable";
        if (source2?.store) try {
          const original = await source2.store.read(head.resource.name, { binary: true });
          state2 = !original ? head.resource.availability === "missing" ? "missing_acknowledged" : "missing" : original.sha256 === head.resource.sha256 ? "current" : "changed";
        } catch {
        }
        originals.push({ ...item, state: state2 });
        if (!["current", "missing_acknowledged"].includes(state2)) blocked_by.push({ code: "original_" + state2, ...item });
      }
      return { complete: blocked_by.length === 0, blocked_by, knowledge, workflows, publication, originals, notes };
    }
    const graph = await buildGraph(wikis);
    return { nodes: graphProjection(graph).pages.map((p2) => ({ key: p2.key, wiki: p2.wiki, page: p2.path, title: p2.head.title, type: p2.head.type, id: p2.head.id })), edges: graph.edges, findings: [...graph.failures, ...graph.findings] };
  }
  const c = await context(root, connection, { bindings, work: args.work }), store = c.work;
  if (args.group) {
    requireThat(["write", "patch", "workflow.start", "workflow.review", "workflow.decide", "workflow.finish", "source.ingest"].includes(action), "group", "This action cannot be recorded as group curation.");
    return recordGroupOperation(c, { ...args, action }, async (overlay) => {
      const scoped = Object.create(root);
      scoped.substore = async (path7, opts) => path7 === c.workFolder.path ? overlay : root.substore(path7, opts);
      const { group, ...next } = args;
      return executeAction(scoped, { action, connection, ...next }, { bindings: { ...bindings, ...c.workFolder.path === null ? { [c.workFolder.id]: overlay } : {} }, extract: extract2, editorHTML });
    });
  }
  if (action === "collection.assess") {
    if (args.source) {
      const source2 = c.sources.find((s) => s.id === args.source);
      requireThat(source2?.store, "access", "Select an assigned readable source collection.");
      return assessCollection(source2.store, { ...args, readers: source2.readers });
    }
    return assessCollection(store, { ...args, readers: c.wiki.readers });
  }
  if (action === "collection.upgrade") return collectionUpgrade(store, args);
  if (action === "collection.map") return mapCollection(store, args);
  if (action === "published.adopt" || action === "published.check") return adoptPublished(store, { ...args, ...action === "published.check" ? { step: "check" } : {} });
  if (action === "participation.register") return registerParticipation(store, args);
  if (action === "participation.set") return setParticipation(store, args);
  if (action === "sharing.move") return transfer(root, c, args, { bindings });
  if (action === "ingest.group" || action === "ingest.take_back") {
    const result = await ingestGroup(c, { ...args, ...action === "ingest.take_back" ? { step: "rollback" } : {} }, { extract: extract2 });
    if (["applied", "rolled_back"].includes(result.state)) await refreshIndex(store);
    return result;
  }
  if (action === "intake.start") {
    const source2 = c.sources.find((s) => s.id === (args.source ?? c.connection.default_source));
    requireThat(source2, "source", "Choose an assigned source folder.");
    return startIntake(store, args, source2.id);
  }
  if (action === "intake.decide") return decideIntake(store, args);
  if (action === "intake.status") return intakeStatus(store, args.id);
  if (action === "note.plan") return integratedNotePlan(store);
  if (action === "note.review") return reviewNote(store, args);
  if (action === "attachment.plan") return planAssets(store);
  if (action === "attachment.review") return reviewAsset(store, args);
  if (action === "attachment.rename") return renameAsset(store, args);
  if (action === "wiki.initialize") return createBundle(store, { title: c.wiki.label, purpose: args.purpose, audience: args.audience, author: args.author, language: args.language ?? "de", preserveExisting: true });
  if (action === "context") return { project: c.project.id, connection: c.connection, wiki: c.wiki, work: c.workFolder, sources: c.sources.map(({ store: store2, ...f }) => f) };
  if (action.startsWith("source.")) {
    const defaultSource = Object.hasOwn(c.connection, "default_source") ? c.connection.default_source : c.sources.length === 1 ? c.sources[0].id : null;
    const source2 = c.sources.find((s) => s.id === (args.source ?? defaultSource));
    requireThat(source2, "source", "Select a source folder assigned to this wiki or configure its default source.");
    requireThat(source2.store, "binding", "Connect this source root on this device.", { folder: source2.id });
    if (action === "source.inventory") return inventory(source2, args);
    if (action === "source.plan") return plan(store, source2, args);
    if (action === "source.missing") return markMissing(store, source2, args);
    if (action === "source.store") {
      requireThat(source2.writable, "read-only", "Enable adding attachments to this source root in settings first.");
      requireThat(typeof args.text === "string" || Array.isArray(args.bytes) && args.bytes.every((b) => Number.isInteger(b) && b >= 0 && b <= 255), "content", "Provide attachment text or bytes.");
      await authorizeIntake(store, args.intake, source2.id, args.path, args.bytes ? new Uint8Array(args.bytes) : args.text);
      const destination = source2.path === null ? await bindings[source2.id].substore("", { writable: true }) : await root.substore(source2.path, { writable: true });
      const saved = await destination.write(args.path, args.bytes ? new Uint8Array(args.bytes) : args.text, { expected: null });
      return { source: source2.id, path: args.path, sha256: saved.sha256, next: "source.ingest" };
    }
    if (action === "source.read") {
      const file = await source2.store.read(args.path, { binary: true });
      requireThat(file, "source", "The source is missing.");
      return { ...await extract2({ bytes: file.bytes, name: args.path, metadata: file }), path: args.path, sha256: file.sha256 };
    }
    return ingest(store, source2, args.path, { ...args, extract: extract2, linkRoot: c.remote.root });
  }
  if (action === "read") {
    const file = await store.read(args.page);
    requireThat(file, "page", "This knowledge page is missing.");
    return { page: args.page, text: file.text, sha256: file.sha256 };
  }
  if (action === "write") return writeNote(store, args);
  if (action === "patch") {
    const seen = await store.read(args.page);
    requireThat(seen && seen.sha256 === args.expected, "stale", "The note changed.");
    return writeNote(store, { ...args, text: patchHead(seen.text, args.updates) });
  }
  if (action === "metadata.repair") return repairMetadata(store, args);
  if (action === "folder.create") return makeFolder(store, args.path);
  if (action === "document.move.plan") return planMoves(store, args);
  if (action === "wiki.flatten.plan") return planFlatWiki(store, args);
  if (action === "document.move.apply") return applyMoves(store, args.id);
  if (action === "index") {
    const originals = await repairOriginalLinks(store, c.sources, { linkRoot: c.remote.root, author: args.author });
    return { ...await refreshIndex(store), original_links: originals };
  }
  if (action === "workflow.start") return start(store, args.mode, args.pages, args.author, args);
  if (action === "workflow.review") return review(store, args.id, args.record, args.author);
  if (action === "workflow.decide") return decide(store, args.id, args.decision, args.author);
  if (action === "workflow.finish") return finish(store, args.id, args.outputs, args.author, args);
  if (action === "workflow.status") return (await sessions(store)).find((s) => s.id === args.id) ?? status(store, args.id);
  if (action === "workflow.list") return sessions(store);
  const options = { work: handle(store), remote: handle(c.remote), identity: c.identity, canPublish: c.canPublish };
  if (action === "sync") {
    const result = await sync.run(options);
    await exportGraph(store);
    if (c.canPublish) await exportGraph(c.remote);
    return result;
  }
  if (action === "conflict.resolve") {
    await sync.resolve(options, args.conflict, args.text, args.author, args.message);
    return sync.run(options);
  }
  if (action === "review.read") {
    const journal = await reviews.read(handle(store), args.page);
    return { ...journal, incoming: reviews.incoming(journal.events, args.author, args.seen) };
  }
  if (action === "review.respond") {
    const events = (await reviews.read(handle(store), args.page)).events, parent = events.find((e) => e.id === args.id);
    requireThat(parent, "review", "The review event is unavailable.");
    const seen = await store.read(args.page);
    requireThat(seen && seen.sha256 === args.expected, "stale", "Read the current comparison before deciding.");
    if (args.choice === "accept") return reviews.accept(handle(store), parent, seen, args.author);
    requireThat(["reject", "proposal", "comment", "resolve", "reopen"].includes(args.choice), "review", "Choose accept, reject, proposal or comment.");
    const event = reviews.reply(parent, args.choice, args.author, seen.text, args.text ?? seen.text, args.message);
    event.page = args.page;
    await reviews.append(handle(store), event);
    return { recorded: true, event };
  }
}

// node_modules/fast-xml-parser/src/util.js
var nameStartChar = ":A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD";
var nameChar = nameStartChar + "\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040";
var nameRegexp = "[" + nameStartChar + "][" + nameChar + "]*";
var regexName = new RegExp("^" + nameRegexp + "$");
function getAllMatches(string, regex) {
  const matches = [];
  let match = regex.exec(string);
  while (match) {
    const allmatches = [];
    allmatches.startIndex = regex.lastIndex - match[0].length;
    const len = match.length;
    for (let index = 0; index < len; index++) {
      allmatches.push(match[index]);
    }
    matches.push(allmatches);
    match = regex.exec(string);
  }
  return matches;
}
var isName = function(string) {
  const match = regexName.exec(string);
  return !(match === null || typeof match === "undefined");
};
function isExist(v) {
  return typeof v !== "undefined";
}
var DANGEROUS_PROPERTY_NAMES = [
  // '__proto__',
  // 'constructor',
  // 'prototype',
  "hasOwnProperty",
  "toString",
  "valueOf",
  "__defineGetter__",
  "__defineSetter__",
  "__lookupGetter__",
  "__lookupSetter__"
];
var criticalProperties = ["__proto__", "constructor", "prototype"];

// node_modules/fast-xml-parser/src/validator.js
var defaultOptions = {
  allowBooleanAttributes: false,
  //A tag can have attributes without any value
  unpairedTags: []
};
function validate(xmlData, options) {
  options = Object.assign({}, defaultOptions, options);
  const tags = [];
  let tagFound = false;
  let reachedRoot = false;
  if (xmlData[0] === "\uFEFF") {
    xmlData = xmlData.substr(1);
  }
  for (let i2 = 0; i2 < xmlData.length; i2++) {
    if (xmlData[i2] === "<" && xmlData[i2 + 1] === "?") {
      i2 += 2;
      i2 = readPI(xmlData, i2);
      if (i2.err) return i2;
    } else if (xmlData[i2] === "<") {
      let tagStartPos = i2;
      i2++;
      if (xmlData[i2] === "!") {
        i2 = readCommentAndCDATA(xmlData, i2);
        continue;
      } else {
        let closingTag = false;
        if (xmlData[i2] === "/") {
          closingTag = true;
          i2++;
        }
        let tagName = "";
        for (; i2 < xmlData.length && xmlData[i2] !== ">" && xmlData[i2] !== " " && xmlData[i2] !== "	" && xmlData[i2] !== "\n" && xmlData[i2] !== "\r"; i2++) {
          tagName += xmlData[i2];
        }
        tagName = tagName.trim();
        if (tagName[tagName.length - 1] === "/") {
          tagName = tagName.substring(0, tagName.length - 1);
          i2--;
        }
        if (!validateTagName(tagName)) {
          let msg;
          if (tagName.trim().length === 0) {
            msg = "Invalid space after '<'.";
          } else {
            msg = "Tag '" + tagName + "' is an invalid name.";
          }
          return getErrorObject("InvalidTag", msg, getLineNumberForPosition(xmlData, i2));
        }
        const result = readAttributeStr(xmlData, i2);
        if (result === false) {
          return getErrorObject("InvalidAttr", "Attributes for '" + tagName + "' have open quote.", getLineNumberForPosition(xmlData, i2));
        }
        let attrStr = result.value;
        i2 = result.index;
        if (attrStr[attrStr.length - 1] === "/") {
          const attrStrStart = i2 - attrStr.length;
          attrStr = attrStr.substring(0, attrStr.length - 1);
          const isValid = validateAttributeString(attrStr, options);
          if (isValid === true) {
            tagFound = true;
          } else {
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, attrStrStart + isValid.err.line));
          }
        } else if (closingTag) {
          if (!result.tagClosed) {
            return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' doesn't have proper closing.", getLineNumberForPosition(xmlData, i2));
          } else if (attrStr.trim().length > 0) {
            return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' can't have attributes or invalid starting.", getLineNumberForPosition(xmlData, tagStartPos));
          } else if (tags.length === 0) {
            return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' has not been opened.", getLineNumberForPosition(xmlData, tagStartPos));
          } else {
            const otg = tags.pop();
            if (tagName !== otg.tagName) {
              let openPos = getLineNumberForPosition(xmlData, otg.tagStartPos);
              return getErrorObject(
                "InvalidTag",
                "Expected closing tag '" + otg.tagName + "' (opened in line " + openPos.line + ", col " + openPos.col + ") instead of closing tag '" + tagName + "'.",
                getLineNumberForPosition(xmlData, tagStartPos)
              );
            }
            if (tags.length == 0) {
              reachedRoot = true;
            }
          }
        } else {
          const isValid = validateAttributeString(attrStr, options);
          if (isValid !== true) {
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, i2 - attrStr.length + isValid.err.line));
          }
          if (reachedRoot === true) {
            return getErrorObject("InvalidXml", "Multiple possible root nodes found.", getLineNumberForPosition(xmlData, i2));
          } else if (options.unpairedTags.indexOf(tagName) !== -1) {
          } else {
            tags.push({ tagName, tagStartPos });
          }
          tagFound = true;
        }
        for (i2++; i2 < xmlData.length; i2++) {
          if (xmlData[i2] === "<") {
            if (xmlData[i2 + 1] === "!") {
              i2++;
              i2 = readCommentAndCDATA(xmlData, i2);
              continue;
            } else if (xmlData[i2 + 1] === "?") {
              i2 = readPI(xmlData, ++i2);
              if (i2.err) return i2;
            } else {
              break;
            }
          } else if (xmlData[i2] === "&") {
            const afterAmp = validateAmpersand(xmlData, i2);
            if (afterAmp == -1)
              return getErrorObject("InvalidChar", "char '&' is not expected.", getLineNumberForPosition(xmlData, i2));
            i2 = afterAmp;
          } else {
            if (reachedRoot === true && !isWhiteSpace(xmlData[i2])) {
              return getErrorObject("InvalidXml", "Extra text at the end", getLineNumberForPosition(xmlData, i2));
            }
          }
        }
        if (xmlData[i2] === "<") {
          i2--;
        }
      }
    } else {
      if (isWhiteSpace(xmlData[i2])) {
        continue;
      }
      return getErrorObject("InvalidChar", "char '" + xmlData[i2] + "' is not expected.", getLineNumberForPosition(xmlData, i2));
    }
  }
  if (!tagFound) {
    return getErrorObject("InvalidXml", "Start tag expected.", 1);
  } else if (tags.length == 1) {
    return getErrorObject("InvalidTag", "Unclosed tag '" + tags[0].tagName + "'.", getLineNumberForPosition(xmlData, tags[0].tagStartPos));
  } else if (tags.length > 0) {
    return getErrorObject("InvalidXml", "Invalid '" + JSON.stringify(tags.map((t) => t.tagName), null, 4).replace(/\r?\n/g, "") + "' found.", { line: 1, col: 1 });
  }
  return true;
}
function isWhiteSpace(char) {
  return char === " " || char === "	" || char === "\n" || char === "\r";
}
function readPI(xmlData, i2) {
  const start2 = i2;
  for (; i2 < xmlData.length; i2++) {
    if (xmlData[i2] == "?" || xmlData[i2] == " ") {
      const tagname = xmlData.substr(start2, i2 - start2);
      if (i2 > 5 && tagname === "xml") {
        return getErrorObject("InvalidXml", "XML declaration allowed only at the start of the document.", getLineNumberForPosition(xmlData, i2));
      } else if (xmlData[i2] == "?" && xmlData[i2 + 1] == ">") {
        i2++;
        break;
      } else {
        continue;
      }
    }
  }
  return i2;
}
function readCommentAndCDATA(xmlData, i2) {
  if (xmlData.length > i2 + 5 && xmlData[i2 + 1] === "-" && xmlData[i2 + 2] === "-") {
    for (i2 += 3; i2 < xmlData.length; i2++) {
      if (xmlData[i2] === "-" && xmlData[i2 + 1] === "-" && xmlData[i2 + 2] === ">") {
        i2 += 2;
        break;
      }
    }
  } else if (xmlData.length > i2 + 8 && xmlData[i2 + 1] === "D" && xmlData[i2 + 2] === "O" && xmlData[i2 + 3] === "C" && xmlData[i2 + 4] === "T" && xmlData[i2 + 5] === "Y" && xmlData[i2 + 6] === "P" && xmlData[i2 + 7] === "E") {
    let angleBracketsCount = 1;
    for (i2 += 8; i2 < xmlData.length; i2++) {
      if (xmlData[i2] === "<") {
        angleBracketsCount++;
      } else if (xmlData[i2] === ">") {
        angleBracketsCount--;
        if (angleBracketsCount === 0) {
          break;
        }
      }
    }
  } else if (xmlData.length > i2 + 9 && xmlData[i2 + 1] === "[" && xmlData[i2 + 2] === "C" && xmlData[i2 + 3] === "D" && xmlData[i2 + 4] === "A" && xmlData[i2 + 5] === "T" && xmlData[i2 + 6] === "A" && xmlData[i2 + 7] === "[") {
    for (i2 += 8; i2 < xmlData.length; i2++) {
      if (xmlData[i2] === "]" && xmlData[i2 + 1] === "]" && xmlData[i2 + 2] === ">") {
        i2 += 2;
        break;
      }
    }
  }
  return i2;
}
var doubleQuote = '"';
var singleQuote = "'";
function readAttributeStr(xmlData, i2) {
  let attrStr = "";
  let startChar = "";
  let tagClosed = false;
  for (; i2 < xmlData.length; i2++) {
    if (xmlData[i2] === doubleQuote || xmlData[i2] === singleQuote) {
      if (startChar === "") {
        startChar = xmlData[i2];
      } else if (startChar !== xmlData[i2]) {
      } else {
        startChar = "";
      }
    } else if (xmlData[i2] === ">") {
      if (startChar === "") {
        tagClosed = true;
        break;
      }
    }
    attrStr += xmlData[i2];
  }
  if (startChar !== "") {
    return false;
  }
  return {
    value: attrStr,
    index: i2,
    tagClosed
  };
}
function scanAttributeTokens(attrStr) {
  const tokens = [];
  const len = attrStr.length;
  let i2 = 0;
  while (i2 < len) {
    const tokenStart = i2;
    while (i2 < len && isWhiteSpace(attrStr[i2])) i2++;
    if (i2 >= len) break;
    if (attrStr[i2] === "=") {
      i2 = tokenStart + 1;
      continue;
    }
    const leadingWs = attrStr.slice(tokenStart, i2);
    const nameStart = i2;
    while (i2 < len && !isWhiteSpace(attrStr[i2]) && attrStr[i2] !== "=") i2++;
    const name = attrStr.slice(nameStart, i2);
    let equalsGroup;
    let j = i2;
    while (j < len && isWhiteSpace(attrStr[j])) j++;
    if (j < len && attrStr[j] === "=") {
      equalsGroup = attrStr.slice(i2, j + 1);
      i2 = j + 1;
    }
    let quoteChar;
    let value;
    let k = i2;
    while (k < len && isWhiteSpace(attrStr[k])) k++;
    if (k < len && (attrStr[k] === '"' || attrStr[k] === "'")) {
      const valueStart = k + 1;
      const closeIdx = attrStr.indexOf(attrStr[k], valueStart);
      if (closeIdx !== -1) {
        quoteChar = attrStr[k];
        value = attrStr.slice(valueStart, closeIdx);
        i2 = closeIdx + 1;
      }
    }
    const token = { startIndex: tokenStart };
    token[1] = leadingWs;
    token[2] = name;
    token[3] = equalsGroup;
    token[4] = quoteChar !== void 0 ? true : void 0;
    token[5] = quoteChar;
    token[6] = value;
    tokens.push(token);
  }
  return tokens;
}
function validateAttributeString(attrStr, options) {
  const matches = scanAttributeTokens(attrStr);
  const attrNames = {};
  for (let i2 = 0; i2 < matches.length; i2++) {
    if (matches[i2][1].length === 0) {
      return getErrorObject("InvalidAttr", "Attribute '" + matches[i2][2] + "' has no space in starting.", getPositionFromMatch(matches[i2]));
    } else if (matches[i2][3] !== void 0 && matches[i2][4] === void 0) {
      return getErrorObject("InvalidAttr", "Attribute '" + matches[i2][2] + "' is without value.", getPositionFromMatch(matches[i2]));
    } else if (matches[i2][3] === void 0 && !options.allowBooleanAttributes) {
      return getErrorObject("InvalidAttr", "boolean attribute '" + matches[i2][2] + "' is not allowed.", getPositionFromMatch(matches[i2]));
    }
    const attrName = matches[i2][2];
    if (!validateAttrName(attrName)) {
      return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is an invalid name.", getPositionFromMatch(matches[i2]));
    }
    if (!Object.prototype.hasOwnProperty.call(attrNames, attrName)) {
      attrNames[attrName] = 1;
    } else {
      return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is repeated.", getPositionFromMatch(matches[i2]));
    }
  }
  return true;
}
function validateNumberAmpersand(xmlData, i2) {
  let re = /\d/;
  if (xmlData[i2] === "x") {
    i2++;
    re = /[\da-fA-F]/;
  }
  for (; i2 < xmlData.length; i2++) {
    if (xmlData[i2] === ";")
      return i2;
    if (!xmlData[i2].match(re))
      break;
  }
  return -1;
}
function validateAmpersand(xmlData, i2) {
  i2++;
  if (xmlData[i2] === ";")
    return -1;
  if (xmlData[i2] === "#") {
    i2++;
    return validateNumberAmpersand(xmlData, i2);
  }
  let count = 0;
  for (; i2 < xmlData.length; i2++, count++) {
    if (xmlData[i2].match(/\w/) && count < 20)
      continue;
    if (xmlData[i2] === ";")
      break;
    return -1;
  }
  return i2;
}
function getErrorObject(code, message, lineNumber) {
  return {
    err: {
      code,
      msg: message,
      line: lineNumber.line || lineNumber,
      col: lineNumber.col
    }
  };
}
function validateAttrName(attrName) {
  return isName(attrName);
}
function validateTagName(tagname) {
  return isName(tagname);
}
function getLineNumberForPosition(xmlData, index) {
  const lines = xmlData.substring(0, index).split(/\r?\n/);
  return {
    line: lines.length,
    // column number is last line's length + 1, because column numbering starts at 1:
    col: lines[lines.length - 1].length + 1
  };
}
function getPositionFromMatch(match) {
  return match.startIndex + match[1].length;
}

// node_modules/@nodable/entities/src/entities.js
var CURRENCY = {
  cent: "\xA2",
  pound: "\xA3",
  curren: "\xA4",
  yen: "\xA5",
  euro: "\u20AC",
  dollar: "$",
  fnof: "\u0192",
  inr: "\u20B9",
  af: "\u060B",
  birr: "\u1265\u122D",
  peso: "\u20B1",
  rub: "\u20BD",
  won: "\u20A9",
  yuan: "\xA5",
  cedil: "\xB8"
};
var XML = {
  amp: "&",
  apos: "'",
  gt: ">",
  lt: "<",
  quot: '"'
};
var COMMON_HTML = {
  nbsp: "\xA0",
  copy: "\xA9",
  reg: "\xAE",
  trade: "\u2122",
  mdash: "\u2014",
  ndash: "\u2013",
  hellip: "\u2026",
  laquo: "\xAB",
  raquo: "\xBB",
  lsquo: "\u2018",
  rsquo: "\u2019",
  ldquo: "\u201C",
  rdquo: "\u201D",
  bull: "\u2022",
  para: "\xB6",
  sect: "\xA7",
  deg: "\xB0",
  frac12: "\xBD",
  frac14: "\xBC",
  frac34: "\xBE"
};

// node_modules/@nodable/entities/src/EntityDecoder.js
var ENTITY_ACTION = Object.freeze({
  /** Resolve and expand the entity normally. */
  ALLOW: "allow",
  /** Silently skip this entity — it will not be registered. */
  BLOCK: "block",
  /** Throw an error, aborting entity registration entirely. */
  THROW: "throw"
});
var SPECIAL_CHARS = new Set("!?\\\\/[]$%{}^&*()<>|+");
function validateEntityName(name) {
  if (name[0] === "#") {
    throw new Error(`[EntityReplacer] Invalid character '#' in entity name: "${name}"`);
  }
  for (const ch of name) {
    if (SPECIAL_CHARS.has(ch)) {
      throw new Error(`[EntityReplacer] Invalid character '${ch}' in entity name: "${name}"`);
    }
  }
  return name;
}
function mergeEntityMaps(...maps) {
  const out = /* @__PURE__ */ Object.create(null);
  for (const map of maps) {
    if (!map) continue;
    for (const key of Object.keys(map)) {
      const raw = map[key];
      if (typeof raw === "string") {
        out[key] = raw;
      } else if (raw && typeof raw === "object" && raw.val !== void 0) {
        const val = raw.val;
        if (typeof val === "string") {
          out[key] = val;
        }
      }
    }
  }
  return out;
}
var LIMIT_TIER_EXTERNAL = "external";
var LIMIT_TIER_BASE = "base";
var LIMIT_TIER_ALL = "all";
function parseLimitTiers(raw) {
  if (!raw || raw === LIMIT_TIER_EXTERNAL) return /* @__PURE__ */ new Set([LIMIT_TIER_EXTERNAL]);
  if (raw === LIMIT_TIER_ALL) return /* @__PURE__ */ new Set([LIMIT_TIER_ALL]);
  if (raw === LIMIT_TIER_BASE) return /* @__PURE__ */ new Set([LIMIT_TIER_BASE]);
  if (Array.isArray(raw)) return new Set(raw);
  return /* @__PURE__ */ new Set([LIMIT_TIER_EXTERNAL]);
}
var NCR_LEVEL = Object.freeze({ allow: 0, leave: 1, remove: 2, throw: 3 });
var XML10_ALLOWED_C0 = /* @__PURE__ */ new Set([9, 10, 13]);
function parseNCRConfig(ncr) {
  if (!ncr) {
    return { xmlVersion: 1, onLevel: NCR_LEVEL.allow, nullLevel: NCR_LEVEL.remove };
  }
  const xmlVersion = ncr.xmlVersion === 1.1 ? 1.1 : 1;
  const onLevel = NCR_LEVEL[ncr.onNCR] ?? NCR_LEVEL.allow;
  const nullLevel = NCR_LEVEL[ncr.nullNCR] ?? NCR_LEVEL.remove;
  const clampedNull = Math.max(nullLevel, NCR_LEVEL.remove);
  return { xmlVersion, onLevel, nullLevel: clampedNull };
}
var EntityDecoder = class {
  /**
   * @param {object} [options]
   * @param {object|null}  [options.namedEntities]        — extra named entities merged into base map
   * @param {object}  [options.limit]                 — security limits
   * @param {number}       [options.limit.maxTotalExpansions=0]  — 0 = unlimited
   * @param {number}       [options.limit.maxExpandedLength=0]   — 0 = unlimited
   * @param {'external'|'base'|'all'|string[]} [options.limit.applyLimitsTo='external']
   *   Which entity tiers count against the security limits:
   *   - 'external' (default) — only input/runtime + persistent external entities
   *   - 'base'               — only DEFAULT_XML_ENTITIES + namedEntities
   *   - 'all'                — every entity regardless of tier
   *   - string[]             — explicit combination, e.g. ['external', 'base']
   * @param {((resolved: string, original: string) => string)|null} [options.postCheck=null]
   * @param {string[]} [options.remove=[]] — entity names (e.g. ['nbsp', '#13']) to delete (replace with empty string)
   * @param {string[]} [options.leave=[]]  — entity names to keep as literal (unchanged in output)
   * @param {object}   [options.ncr]       — Numeric Character Reference controls
   * @param {1.0|1.1}  [options.ncr.xmlVersion=1.0]
   *   XML version governing which codepoint ranges are restricted:
   *   - 1.0 — C0 controls U+0001–U+001F (except U+0009/000A/000D) are prohibited
   *   - 1.1 — C0 controls are allowed when written as NCRs; C1 (U+007F–U+009F) decoded as-is
   * @param {'allow'|'leave'|'remove'|'throw'} [options.ncr.onNCR='allow']
   *   Base action for numeric references. Severity order: allow < leave < remove < throw.
   *   For codepoint ranges that carry a minimum level (surrogates → remove, XML 1.0 C0 → remove),
   *   the effective action is max(onNCR, rangeMinimum).
   * @param {'remove'|'throw'} [options.ncr.nullNCR='remove']
   *   Action for U+0000 (null). 'allow' and 'leave' are clamped to 'remove' since null is never safe.
   * @param {((name: string, value: string) => 'allow'|'block'|'throw')|null} [options.onExternalEntity=null]
   *   Hook called when an external entity is registered via `setExternalEntities()` or
   *   `addExternalEntity()`. Return `ENTITY_ACTION.ALLOW` to accept the entity,
   *   `ENTITY_ACTION.BLOCK` to silently skip it, or `ENTITY_ACTION.THROW` to abort with an error.
   * @param {((name: string, value: string) => 'allow'|'block'|'throw')|null} [options.onInputEntity=null]
   *   Hook called when an input entity is registered via `addInputEntities()`. Return
   *   `ENTITY_ACTION.ALLOW` to accept, `ENTITY_ACTION.BLOCK` to silently skip, or
   *   `ENTITY_ACTION.THROW` to abort with an error.
   */
  constructor(options = {}) {
    this._limit = options.limit || {};
    this._maxTotalExpansions = this._limit.maxTotalExpansions || 0;
    this._maxExpandedLength = this._limit.maxExpandedLength || 0;
    this._postCheck = typeof options.postCheck === "function" ? options.postCheck : (r) => r;
    this._limitTiers = parseLimitTiers(this._limit.applyLimitsTo ?? LIMIT_TIER_EXTERNAL);
    this._numericAllowed = options.numericAllowed ?? true;
    this._baseMap = mergeEntityMaps(XML, options.namedEntities || null);
    this._externalMap = /* @__PURE__ */ Object.create(null);
    this._inputMap = /* @__PURE__ */ Object.create(null);
    this._totalExpansions = 0;
    this._expandedLength = 0;
    this._removeSet = new Set(options.remove && Array.isArray(options.remove) ? options.remove : []);
    this._leaveSet = new Set(options.leave && Array.isArray(options.leave) ? options.leave : []);
    const ncrCfg = parseNCRConfig(options.ncr);
    this._ncrXmlVersion = ncrCfg.xmlVersion;
    this._ncrOnLevel = ncrCfg.onLevel;
    this._ncrNullLevel = ncrCfg.nullLevel;
    this._onExternalEntity = typeof options.onExternalEntity === "function" ? options.onExternalEntity : null;
    this._onInputEntity = typeof options.onInputEntity === "function" ? options.onInputEntity : null;
  }
  // -------------------------------------------------------------------------
  // Private: registration hook dispatch
  // -------------------------------------------------------------------------
  /**
   * Invoke a registration hook for a single entity name/value pair.
   * Returns true when the entity should be accepted, false when it should be
   * silently skipped (BLOCK), and throws when the hook returns THROW.
   *
   * @param {((name: string, value: string) => 'allow'|'block'|'throw')|null} hook
   * @param {string} name
   * @param {string} value
   * @param {string} context  — used in error messages ('external' | 'input')
   * @returns {boolean}  true = accept, false = skip
   */
  _applyRegistrationHook(hook, name, value, context2) {
    if (!hook) return true;
    const action = hook(name, value);
    if (action === ENTITY_ACTION.BLOCK) return false;
    if (action === ENTITY_ACTION.THROW) {
      throw new Error(
        `[EntityDecoder] Registration of ${context2} entity "&${name};" was rejected by hook`
      );
    }
    return true;
  }
  // -------------------------------------------------------------------------
  // Persistent external entity registration
  // -------------------------------------------------------------------------
  /**
   * Replace the full set of persistent external entities.
   * All keys are validated — throws on invalid characters.
   * If `onExternalEntity` is set, it is called once per entry; entries that
   * return `ENTITY_ACTION.BLOCK` are silently omitted, `ENTITY_ACTION.THROW`
   * aborts the whole call.
   * @param {Record<string, string | { regex?: RegExp, val: string }>} map
   */
  setExternalEntities(map) {
    if (map) {
      for (const key of Object.keys(map)) {
        validateEntityName(key);
      }
    }
    if (!this._onExternalEntity) {
      this._externalMap = mergeEntityMaps(map);
      return;
    }
    const flat = mergeEntityMaps(map);
    const filtered = /* @__PURE__ */ Object.create(null);
    for (const [name, value] of Object.entries(flat)) {
      if (this._applyRegistrationHook(this._onExternalEntity, name, value, "external")) {
        filtered[name] = value;
      }
    }
    this._externalMap = filtered;
  }
  /**
   * Add a single persistent external entity.
   * If `onExternalEntity` is set it is called before the entity is stored;
   * `ENTITY_ACTION.BLOCK` silently skips storage, `ENTITY_ACTION.THROW` raises.
   * @param {string} key
   * @param {string} value
   */
  addExternalEntity(key, value) {
    validateEntityName(key);
    if (typeof value === "string" && value.indexOf("&") === -1) {
      if (this._applyRegistrationHook(this._onExternalEntity, key, value, "external")) {
        this._externalMap[key] = value;
      }
    }
  }
  // -------------------------------------------------------------------------
  // Input / runtime entity registration (per document)
  // -------------------------------------------------------------------------
  /**
   * Inject DOCTYPE entities for the current document.
   * Also resets per-document expansion counters.
   * If `onInputEntity` is set it is called once per entry; entries returning
   * `ENTITY_ACTION.BLOCK` are silently omitted, `ENTITY_ACTION.THROW` aborts.
   * @param {Record<string, string | { regx?: RegExp, regex?: RegExp, val: string }>} map
   */
  addInputEntities(map) {
    this._totalExpansions = 0;
    this._expandedLength = 0;
    if (!this._onInputEntity) {
      this._inputMap = mergeEntityMaps(map);
      return;
    }
    const flat = mergeEntityMaps(map);
    const filtered = /* @__PURE__ */ Object.create(null);
    for (const [name, value] of Object.entries(flat)) {
      if (this._applyRegistrationHook(this._onInputEntity, name, value, "input")) {
        filtered[name] = value;
      }
    }
    this._inputMap = filtered;
  }
  // -------------------------------------------------------------------------
  // Per-document reset
  // -------------------------------------------------------------------------
  /**
   * Wipe input/runtime entities and reset counters.
   * Call this before processing each new document.
   * @returns {this}
   */
  reset() {
    this._inputMap = /* @__PURE__ */ Object.create(null);
    this._totalExpansions = 0;
    this._expandedLength = 0;
    return this;
  }
  // -------------------------------------------------------------------------
  // XML version (can be set after construction, e.g. once parser reads <?xml?>)
  // -------------------------------------------------------------------------
  /**
   * Update the XML version used for NCR classification.
   * Call this as soon as the document's `<?xml version="...">` declaration is parsed.
   * @param {1.0|1.1|number} version
   */
  setXmlVersion(version2) {
    this._ncrXmlVersion = version2 === 1.1 ? 1.1 : 1;
  }
  // -------------------------------------------------------------------------
  // Primary API
  // -------------------------------------------------------------------------
  /**
   * Replace all entity references in `str` in a single pass.
   *
   * @param {string} str
   * @returns {string}
   */
  decode(str) {
    if (typeof str !== "string" || str.length === 0) return str;
    if (str.indexOf("&") === -1) return str;
    const original = str;
    const chunks = [];
    const len = str.length;
    let last = 0;
    let i2 = 0;
    const limitExpansions = this._maxTotalExpansions > 0;
    const limitLength = this._maxExpandedLength > 0;
    const checkLimits = limitExpansions || limitLength;
    while (i2 < len) {
      if (str.charCodeAt(i2) !== 38) {
        i2++;
        continue;
      }
      let j = i2 + 1;
      while (j < len && str.charCodeAt(j) !== 59 && j - i2 <= 32) j++;
      if (j >= len || str.charCodeAt(j) !== 59) {
        i2++;
        continue;
      }
      const token = str.slice(i2 + 1, j);
      if (token.length === 0) {
        i2++;
        continue;
      }
      let replacement;
      let tier;
      if (this._removeSet.has(token)) {
        replacement = "";
        if (tier === void 0) {
          tier = LIMIT_TIER_EXTERNAL;
        }
      } else if (this._leaveSet.has(token)) {
        i2++;
        continue;
      } else if (token.charCodeAt(0) === 35) {
        const ncrResult = this._resolveNCR(token);
        if (ncrResult === void 0) {
          i2++;
          continue;
        }
        replacement = ncrResult;
        tier = LIMIT_TIER_BASE;
      } else {
        const resolved = this._resolveName(token);
        replacement = resolved?.value;
        tier = resolved?.tier;
      }
      if (replacement === void 0) {
        i2++;
        continue;
      }
      if (i2 > last) chunks.push(str.slice(last, i2));
      chunks.push(replacement);
      last = j + 1;
      i2 = last;
      if (checkLimits && this._tierCounts(tier)) {
        if (limitExpansions) {
          this._totalExpansions++;
          if (this._totalExpansions > this._maxTotalExpansions) {
            throw new Error(
              `[EntityReplacer] Entity expansion count limit exceeded: ${this._totalExpansions} > ${this._maxTotalExpansions}`
            );
          }
        }
        if (limitLength) {
          const delta2 = replacement.length - (token.length + 2);
          if (delta2 > 0) {
            this._expandedLength += delta2;
            if (this._expandedLength > this._maxExpandedLength) {
              throw new Error(
                `[EntityReplacer] Expanded content length limit exceeded: ${this._expandedLength} > ${this._maxExpandedLength}`
              );
            }
          }
        }
      }
    }
    if (last < len) chunks.push(str.slice(last));
    const result = chunks.length === 0 ? str : chunks.join("");
    return this._postCheck(result, original);
  }
  // -------------------------------------------------------------------------
  // Private: limit tier check
  // -------------------------------------------------------------------------
  /**
   * Returns true if a resolved entity of the given tier should count
   * against the expansion/length limits.
   * @param {string} tier  — LIMIT_TIER_EXTERNAL | LIMIT_TIER_BASE
   * @returns {boolean}
   */
  _tierCounts(tier) {
    if (this._limitTiers.has(LIMIT_TIER_ALL)) return true;
    return this._limitTiers.has(tier);
  }
  // -------------------------------------------------------------------------
  // Private: entity resolution
  // -------------------------------------------------------------------------
  /**
   * Resolve a named entity token (without & and ;).
   * Priority: inputMap > externalMap > baseMap
   * Returns the resolved value tagged with its limit tier.
   *
   * @param {string} name
   * @returns {{ value: string, tier: string }|undefined}
   */
  _resolveName(name) {
    if (name in this._inputMap) return { value: this._inputMap[name], tier: LIMIT_TIER_EXTERNAL };
    if (name in this._externalMap) return { value: this._externalMap[name], tier: LIMIT_TIER_EXTERNAL };
    if (name in this._baseMap) return { value: this._baseMap[name], tier: LIMIT_TIER_BASE };
    return void 0;
  }
  /**
   * Classify a codepoint and return the minimum action level that must be applied.
   * Returns -1 when no minimum is imposed (normal allow path).
   *
   * Ranges checked (in priority order):
   *   1. U+0000            — null, governed by nullNCR (always ≥ remove)
   *   2. U+D800–U+DFFF     — surrogates, always prohibited (min: remove)
   *   3. U+0001–U+001F \ {0x09,0x0A,0x0D}  — XML 1.0 restricted C0 (min: remove)
   *      (skipped in XML 1.1 — C0 controls are allowed when written as NCRs)
   *
   * @param {number} cp  — codepoint
   * @returns {number}   — minimum NCR_LEVEL value, or -1 for no restriction
   */
  _classifyNCR(cp) {
    if (cp === 0) return this._ncrNullLevel;
    if (cp >= 55296 && cp <= 57343) return NCR_LEVEL.remove;
    if (this._ncrXmlVersion === 1) {
      if (cp >= 1 && cp <= 31 && !XML10_ALLOWED_C0.has(cp)) return NCR_LEVEL.remove;
    }
    return -1;
  }
  /**
   * Execute a resolved NCR action.
   *
   * @param {number} action   — NCR_LEVEL value
   * @param {string} token    — raw token (e.g. '#38') for error messages
   * @param {number} cp       — codepoint, used only for error messages
   * @returns {string|undefined}
   *   - decoded character string  → 'allow'
   *   - ''                        → 'remove'
   *   - undefined                 → 'leave' (caller must skip past '&' only)
   *   - throws Error              → 'throw'
   */
  _applyNCRAction(action, token, cp) {
    switch (action) {
      case NCR_LEVEL.allow:
        return String.fromCodePoint(cp);
      case NCR_LEVEL.remove:
        return "";
      case NCR_LEVEL.leave:
        return void 0;
      // signal: keep literal
      case NCR_LEVEL.throw:
        throw new Error(
          `[EntityDecoder] Prohibited numeric character reference &${token}; (U+${cp.toString(16).toUpperCase().padStart(4, "0")})`
        );
      default:
        return String.fromCodePoint(cp);
    }
  }
  /**
   * Full NCR resolution pipeline for a numeric token.
   *
   * Steps:
   *   1. Parse the codepoint (decimal or hex).
   *   2. Validate the raw codepoint range (NaN, <0, >0x10FFFF).
   *   3. If numericAllowed is false and no minimum restriction applies → leave as-is.
   *   4. Classify the codepoint to find the minimum required action level.
   *   5. Resolve effective action = max(onNCR, minimum).
   *   6. Apply and return.
   *
   * @param {string} token  — e.g. '#38', '#x26', '#X26'
   * @returns {string|undefined}
   *   - string (incl. '')  — replacement ('' = remove)
   *   - undefined          — leave original &token; as-is
   */
  _resolveNCR(token) {
    const second = token.charCodeAt(1);
    let cp;
    if (second === 120 || second === 88) {
      cp = parseInt(token.slice(2), 16);
    } else {
      cp = parseInt(token.slice(1), 10);
    }
    if (Number.isNaN(cp) || cp < 0 || cp > 1114111) return void 0;
    const minimum = this._classifyNCR(cp);
    if (!this._numericAllowed && minimum < NCR_LEVEL.remove) return void 0;
    const effective = minimum === -1 ? this._ncrOnLevel : Math.max(this._ncrOnLevel, minimum);
    return this._applyNCRAction(effective, token, cp);
  }
};

// node_modules/fast-xml-parser/src/xmlparser/OptionsBuilder.js
var defaultOnDangerousProperty = (name) => {
  if (DANGEROUS_PROPERTY_NAMES.includes(name)) {
    return "__" + name;
  }
  return name;
};
var defaultOptions2 = {
  preserveOrder: false,
  attributeNamePrefix: "@_",
  attributesGroupName: false,
  textNodeName: "#text",
  ignoreAttributes: true,
  removeNSPrefix: false,
  // remove NS from tag name or attribute name if true
  allowBooleanAttributes: false,
  //a tag can have attributes without any value
  //ignoreRootElement : false,
  parseTagValue: true,
  parseAttributeValue: false,
  trimValues: true,
  //Trim string values of tag and attributes
  cdataPropName: false,
  numberParseOptions: {
    hex: true,
    leadingZeros: true,
    eNotation: true,
    unicode: false
  },
  tagValueProcessor: function(tagName, val) {
    return val;
  },
  attributeValueProcessor: function(attrName, val) {
    return val;
  },
  stopNodes: [],
  //nested tags will not be parsed even for errors
  alwaysCreateTextNode: false,
  isArray: () => false,
  commentPropName: false,
  unpairedTags: [],
  processEntities: true,
  htmlEntities: false,
  entityDecoder: null,
  ignoreDeclaration: false,
  ignorePiTags: false,
  transformTagName: false,
  transformAttributeName: false,
  updateTag: function(tagName, jPath, attrs) {
    return tagName;
  },
  // skipEmptyListItem: false
  captureMetaData: false,
  maxNestedTags: 100,
  strictReservedNames: true,
  jPath: true,
  // if true, pass jPath string to callbacks; if false, pass matcher instance
  onDangerousProperty: defaultOnDangerousProperty
};
function validatePropertyName(propertyName, optionName) {
  if (typeof propertyName !== "string") {
    return;
  }
  const normalized2 = propertyName.toLowerCase();
  if (DANGEROUS_PROPERTY_NAMES.some((dangerous) => normalized2 === dangerous.toLowerCase())) {
    throw new Error(
      `[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`
    );
  }
  if (criticalProperties.some((dangerous) => normalized2 === dangerous.toLowerCase())) {
    throw new Error(
      `[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`
    );
  }
}
function normalizeProcessEntities(value, htmlEntities) {
  if (typeof value === "boolean") {
    return {
      enabled: value,
      // true or false
      maxEntitySize: 1e4,
      maxExpansionDepth: 1e4,
      maxTotalExpansions: Infinity,
      maxExpandedLength: 1e5,
      maxEntityCount: 1e3,
      allowedTags: null,
      tagFilter: null,
      appliesTo: "all"
    };
  }
  if (typeof value === "object" && value !== null) {
    return {
      enabled: value.enabled !== false,
      maxEntitySize: Math.max(1, value.maxEntitySize ?? 1e4),
      maxExpansionDepth: Math.max(1, value.maxExpansionDepth ?? 1e4),
      maxTotalExpansions: Math.max(1, value.maxTotalExpansions ?? Infinity),
      maxExpandedLength: Math.max(1, value.maxExpandedLength ?? 1e5),
      maxEntityCount: Math.max(1, value.maxEntityCount ?? 1e3),
      allowedTags: value.allowedTags ?? null,
      tagFilter: value.tagFilter ?? null,
      appliesTo: value.appliesTo ?? "all"
    };
  }
  return normalizeProcessEntities(true);
}
var buildOptions = function(options) {
  const built = Object.assign({}, defaultOptions2, options);
  const propertyNameOptions = [
    { value: built.attributeNamePrefix, name: "attributeNamePrefix" },
    { value: built.attributesGroupName, name: "attributesGroupName" },
    { value: built.textNodeName, name: "textNodeName" },
    { value: built.cdataPropName, name: "cdataPropName" },
    { value: built.commentPropName, name: "commentPropName" }
  ];
  for (const { value, name } of propertyNameOptions) {
    if (value) {
      validatePropertyName(value, name);
    }
  }
  if (built.onDangerousProperty === null) {
    built.onDangerousProperty = defaultOnDangerousProperty;
  }
  built.processEntities = normalizeProcessEntities(built.processEntities, built.htmlEntities);
  built.unpairedTagsSet = new Set(built.unpairedTags);
  if (built.stopNodes && Array.isArray(built.stopNodes)) {
    built.stopNodes = built.stopNodes.map((node) => {
      if (typeof node === "string" && node.startsWith("*.")) {
        return ".." + node.substring(2);
      }
      return node;
    });
  }
  return built;
};

// node_modules/fast-xml-parser/src/xmlparser/xmlNode.js
var METADATA_SYMBOL;
if (typeof Symbol !== "function") {
  METADATA_SYMBOL = "@@xmlMetadata";
} else {
  METADATA_SYMBOL = /* @__PURE__ */ Symbol("XML Node Metadata");
}
var XmlNode = class {
  constructor(tagname) {
    this.tagname = tagname;
    this.child = [];
    this[":@"] = /* @__PURE__ */ Object.create(null);
  }
  add(key, val) {
    if (key === "__proto__") key = "#__proto__";
    this.child.push({ [key]: val });
  }
  addChild(node, startIndex) {
    if (node.tagname === "__proto__") node.tagname = "#__proto__";
    if (node[":@"] && Object.keys(node[":@"]).length > 0) {
      this.child.push({ [node.tagname]: node.child, [":@"]: node[":@"] });
    } else {
      this.child.push({ [node.tagname]: node.child });
    }
    this.addStartIndex(startIndex);
  }
  addStartIndex(startIndex) {
    if (startIndex !== void 0) {
      this.child[this.child.length - 1][METADATA_SYMBOL] = { startIndex };
    }
  }
  addEndIndex(endIndex) {
    const lastChild = this.child[this.child.length - 1];
    if (lastChild !== void 0 && lastChild[METADATA_SYMBOL] !== void 0 && lastChild[METADATA_SYMBOL].endIndex === void 0) {
      lastChild[METADATA_SYMBOL].endIndex = endIndex;
    }
  }
  /** symbol used for metadata */
  static getMetaDataSymbol() {
    return METADATA_SYMBOL;
  }
};

// node_modules/xml-naming/src/index.js
var nameStartChar10 = ":A-Za-z_\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u0486\u0488-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD";
var nameChar10 = nameStartChar10 + "\\-\\.\\d\xB7\u0300-\u036F\u203F-\u2040";
var nameStartChar11 = ":A-Za-z_\xC0-\u02FF\u0370-\u037D\u037F-\u0486\u0488-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}";
var nameChar11 = nameStartChar11 + "\\-\\.\\d\xB7\u0300-\u036F\u0487\u203F-\u2040";
var buildRegexes = (startChar, char, flags2 = "") => {
  const ncStart = startChar.replace(":", "");
  const ncChar = char.replace(":", "");
  const ncNamePat = `[${ncStart}][${ncChar}]*`;
  return {
    name: new RegExp(`^[${startChar}][${char}]*$`, flags2),
    ncName: new RegExp(`^${ncNamePat}$`, flags2),
    qName: new RegExp(`^${ncNamePat}(?::${ncNamePat})?$`, flags2),
    nmToken: new RegExp(`^[${char}]+$`, flags2),
    nmTokens: new RegExp(`^[${char}]+(?:\\s+[${char}]+)*$`, flags2)
  };
};
var regexes10 = buildRegexes(nameStartChar10, nameChar10);
var regexes11 = buildRegexes(nameStartChar11, nameChar11, "u");
var nameStartCharAscii = ":A-Za-z_";
var nameCharAscii = nameStartCharAscii + "\\-\\.\\d";
var regexesAscii = buildRegexes(nameStartCharAscii, nameCharAscii);
var getRegexes = (xmlVersion = "1.0", asciiOnly = false) => {
  if (asciiOnly) return regexesAscii;
  return xmlVersion === "1.1" ? regexes11 : regexes10;
};
var qName = (str, { xmlVersion = "1.0", asciiOnly = false } = {}) => getRegexes(xmlVersion, asciiOnly).qName.test(str);

// node_modules/fast-xml-parser/src/xmlparser/DocTypeReader.js
var DocTypeReader = class {
  constructor(options, xmlVersion) {
    this.suppressValidationErr = !options;
    this.options = options;
    this.xmlVersion = xmlVersion || 1;
  }
  setXmlVersion(xmlVersion = 1) {
    this.xmlVersion = xmlVersion;
  }
  readDocType(xmlData, i2) {
    const entities = /* @__PURE__ */ Object.create(null);
    let entityCount = 0;
    if (xmlData[i2 + 3] === "O" && xmlData[i2 + 4] === "C" && xmlData[i2 + 5] === "T" && xmlData[i2 + 6] === "Y" && xmlData[i2 + 7] === "P" && xmlData[i2 + 8] === "E") {
      i2 = i2 + 9;
      let angleBracketsCount = 1;
      let hasBody = false, comment = false;
      let quoteChar = null;
      let exp = "";
      for (; i2 < xmlData.length; i2++) {
        if (quoteChar !== null) {
          if (xmlData[i2] === quoteChar) quoteChar = null;
          exp += xmlData[i2];
          continue;
        }
        if (!hasBody && !comment && (xmlData[i2] === '"' || xmlData[i2] === "'")) {
          quoteChar = xmlData[i2];
          exp += xmlData[i2];
          continue;
        }
        if (xmlData[i2] === "<" && !comment) {
          if (hasBody && hasSeq(xmlData, "!ENTITY", i2)) {
            i2 += 7;
            let entityName, val;
            [entityName, val, i2] = this.readEntityExp(xmlData, i2 + 1, this.suppressValidationErr);
            if (val.indexOf("&") === -1) {
              if (this.options.enabled !== false && this.options.maxEntityCount != null && entityCount >= this.options.maxEntityCount) {
                throw new Error(
                  `Entity count (${entityCount + 1}) exceeds maximum allowed (${this.options.maxEntityCount})`
                );
              }
              entities[entityName] = val;
              entityCount++;
            }
          } else if (hasBody && hasSeq(xmlData, "!ELEMENT", i2)) {
            i2 += 8;
            const { index } = this.readElementExp(xmlData, i2 + 1);
            i2 = index;
          } else if (hasBody && hasSeq(xmlData, "!ATTLIST", i2)) {
            i2 += 8;
          } else if (hasBody && hasSeq(xmlData, "!NOTATION", i2)) {
            i2 += 9;
            const { index } = this.readNotationExp(xmlData, i2 + 1, this.suppressValidationErr);
            i2 = index;
          } else if (hasSeq(xmlData, "!--", i2)) comment = true;
          else throw new Error(`Invalid DOCTYPE`);
          angleBracketsCount++;
          exp = "";
        } else if (xmlData[i2] === ">") {
          if (comment) {
            if (xmlData[i2 - 1] === "-" && xmlData[i2 - 2] === "-") {
              comment = false;
              angleBracketsCount--;
            }
          } else {
            angleBracketsCount--;
          }
          if (angleBracketsCount === 0) {
            break;
          }
        } else if (xmlData[i2] === "[") {
          hasBody = true;
        } else {
          exp += xmlData[i2];
        }
      }
      if (quoteChar !== null || angleBracketsCount !== 0) {
        throw new Error(`Unclosed DOCTYPE`);
      }
    } else {
      throw new Error(`Invalid Tag instead of DOCTYPE`);
    }
    return { entities, i: i2 };
  }
  readEntityExp(xmlData, i2) {
    i2 = skipWhitespace(xmlData, i2);
    const startIndex = i2;
    while (i2 < xmlData.length && !/\s/.test(xmlData[i2]) && xmlData[i2] !== '"' && xmlData[i2] !== "'") {
      i2++;
    }
    let entityName = xmlData.substring(startIndex, i2);
    validateEntityName2(entityName, { xmlVersion: this.xmlVersion });
    i2 = skipWhitespace(xmlData, i2);
    if (!this.suppressValidationErr) {
      if (xmlData.substring(i2, i2 + 6).toUpperCase() === "SYSTEM") {
        throw new Error("External entities are not supported");
      } else if (xmlData[i2] === "%") {
        throw new Error("Parameter entities are not supported");
      }
    }
    let entityValue = "";
    [i2, entityValue] = this.readIdentifierVal(xmlData, i2, "entity");
    if (this.options.enabled !== false && this.options.maxEntitySize != null && entityValue.length > this.options.maxEntitySize) {
      throw new Error(
        `Entity "${entityName}" size (${entityValue.length}) exceeds maximum allowed size (${this.options.maxEntitySize})`
      );
    }
    i2--;
    return [entityName, entityValue, i2];
  }
  readNotationExp(xmlData, i2) {
    i2 = skipWhitespace(xmlData, i2);
    const startIndex = i2;
    while (i2 < xmlData.length && !/\s/.test(xmlData[i2])) {
      i2++;
    }
    let notationName = xmlData.substring(startIndex, i2);
    !this.suppressValidationErr && validateEntityName2(notationName, { xmlVersion: this.xmlVersion });
    i2 = skipWhitespace(xmlData, i2);
    const identifierType = xmlData.substring(i2, i2 + 6).toUpperCase();
    if (!this.suppressValidationErr && identifierType !== "SYSTEM" && identifierType !== "PUBLIC") {
      throw new Error(`Expected SYSTEM or PUBLIC, found "${identifierType}"`);
    }
    i2 += identifierType.length;
    i2 = skipWhitespace(xmlData, i2);
    let publicIdentifier = null;
    let systemIdentifier = null;
    if (identifierType === "PUBLIC") {
      [i2, publicIdentifier] = this.readIdentifierVal(xmlData, i2, "publicIdentifier");
      i2 = skipWhitespace(xmlData, i2);
      if (xmlData[i2] === '"' || xmlData[i2] === "'") {
        [i2, systemIdentifier] = this.readIdentifierVal(xmlData, i2, "systemIdentifier");
      }
    } else if (identifierType === "SYSTEM") {
      [i2, systemIdentifier] = this.readIdentifierVal(xmlData, i2, "systemIdentifier");
      if (!this.suppressValidationErr && !systemIdentifier) {
        throw new Error("Missing mandatory system identifier for SYSTEM notation");
      }
    }
    return { notationName, publicIdentifier, systemIdentifier, index: --i2 };
  }
  readIdentifierVal(xmlData, i2, type) {
    let identifierVal = "";
    const startChar = xmlData[i2];
    if (startChar !== '"' && startChar !== "'") {
      throw new Error(`Expected quoted string, found "${startChar}"`);
    }
    i2++;
    const startIndex = i2;
    while (i2 < xmlData.length && xmlData[i2] !== startChar) {
      i2++;
    }
    identifierVal = xmlData.substring(startIndex, i2);
    if (xmlData[i2] !== startChar) {
      throw new Error(`Unterminated ${type} value`);
    }
    i2++;
    return [i2, identifierVal];
  }
  readElementExp(xmlData, i2) {
    i2 = skipWhitespace(xmlData, i2);
    const startIndex = i2;
    while (i2 < xmlData.length && !/\s/.test(xmlData[i2])) {
      i2++;
    }
    let elementName = xmlData.substring(startIndex, i2);
    if (!this.suppressValidationErr && !qName(elementName, { xmlVersion: this.xmlVersion })) {
      throw new Error(`Invalid element name: "${elementName}"`);
    }
    i2 = skipWhitespace(xmlData, i2);
    let contentModel = "";
    if (xmlData[i2] === "E" && hasSeq(xmlData, "MPTY", i2)) i2 += 4;
    else if (xmlData[i2] === "A" && hasSeq(xmlData, "NY", i2)) i2 += 2;
    else if (xmlData[i2] === "(") {
      i2++;
      const startIndex2 = i2;
      while (i2 < xmlData.length && xmlData[i2] !== ")") {
        i2++;
      }
      contentModel = xmlData.substring(startIndex2, i2);
      if (xmlData[i2] !== ")") {
        throw new Error("Unterminated content model");
      }
    } else if (!this.suppressValidationErr) {
      throw new Error(`Invalid Element Expression, found "${xmlData[i2]}"`);
    }
    return {
      elementName,
      contentModel: contentModel.trim(),
      index: i2
    };
  }
  readAttlistExp(xmlData, i2) {
    i2 = skipWhitespace(xmlData, i2);
    let startIndex = i2;
    while (i2 < xmlData.length && !/\s/.test(xmlData[i2])) {
      i2++;
    }
    let elementName = xmlData.substring(startIndex, i2);
    validateEntityName2(elementName, { xmlVersion: this.xmlVersion });
    i2 = skipWhitespace(xmlData, i2);
    startIndex = i2;
    while (i2 < xmlData.length && !/\s/.test(xmlData[i2])) {
      i2++;
    }
    let attributeName = xmlData.substring(startIndex, i2);
    if (!validateEntityName2(attributeName, { xmlVersion: this.xmlVersion })) {
      throw new Error(`Invalid attribute name: "${attributeName}"`);
    }
    i2 = skipWhitespace(xmlData, i2);
    let attributeType = "";
    if (xmlData.substring(i2, i2 + 8).toUpperCase() === "NOTATION") {
      attributeType = "NOTATION";
      i2 += 8;
      i2 = skipWhitespace(xmlData, i2);
      if (xmlData[i2] !== "(") {
        throw new Error(`Expected '(', found "${xmlData[i2]}"`);
      }
      i2++;
      let allowedNotations = [];
      while (i2 < xmlData.length && xmlData[i2] !== ")") {
        const startIndex2 = i2;
        while (i2 < xmlData.length && xmlData[i2] !== "|" && xmlData[i2] !== ")") {
          i2++;
        }
        let notation = xmlData.substring(startIndex2, i2);
        notation = notation.trim();
        if (!validateEntityName2(notation, { xmlVersion: this.xmlVersion })) {
          throw new Error(`Invalid notation name: "${notation}"`);
        }
        allowedNotations.push(notation);
        if (xmlData[i2] === "|") {
          i2++;
          i2 = skipWhitespace(xmlData, i2);
        }
      }
      if (xmlData[i2] !== ")") {
        throw new Error("Unterminated list of notations");
      }
      i2++;
      attributeType += " (" + allowedNotations.join("|") + ")";
    } else {
      const startIndex2 = i2;
      while (i2 < xmlData.length && !/\s/.test(xmlData[i2])) {
        i2++;
      }
      attributeType += xmlData.substring(startIndex2, i2);
      const validTypes = ["CDATA", "ID", "IDREF", "IDREFS", "ENTITY", "ENTITIES", "NMTOKEN", "NMTOKENS"];
      if (!this.suppressValidationErr && !validTypes.includes(attributeType.toUpperCase())) {
        throw new Error(`Invalid attribute type: "${attributeType}"`);
      }
    }
    i2 = skipWhitespace(xmlData, i2);
    let defaultValue = "";
    if (xmlData.substring(i2, i2 + 8).toUpperCase() === "#REQUIRED") {
      defaultValue = "#REQUIRED";
      i2 += 8;
    } else if (xmlData.substring(i2, i2 + 7).toUpperCase() === "#IMPLIED") {
      defaultValue = "#IMPLIED";
      i2 += 7;
    } else {
      [i2, defaultValue] = this.readIdentifierVal(xmlData, i2, "ATTLIST");
    }
    return {
      elementName,
      attributeName,
      attributeType,
      defaultValue,
      index: i2
    };
  }
};
var skipWhitespace = (data, index) => {
  while (index < data.length && /\s/.test(data[index])) {
    index++;
  }
  return index;
};
function hasSeq(data, seq, i2) {
  for (let j = 0; j < seq.length; j++) {
    if (seq[j] !== data[i2 + j + 1]) return false;
  }
  return true;
}
function validateEntityName2(name, xmlVersion) {
  if (qName(name, { xmlVersion }))
    return name;
  else
    throw new Error(`Invalid entity name ${name}`);
}

// node_modules/anynum/digitTable.js
var SCRIPT_ZEROS = [
  // Basic Latin (ASCII) — included for completeness / pass-through
  48,
  // 0-9
  // Arabic scripts
  1632,
  // Arabic-Indic ٠١٢٣٤٥٦٧٨٩
  1776,
  // Extended Arabic-Indic (Urdu/Persian/Sindhi) ۰۱۲۳
  // Indic scripts
  2406,
  // Devanagari ०१२३४५६७८९
  2534,
  // Bengali ০১২৩৪৫৬৭৮৯
  2662,
  // Gurmukhi ੦੧੨੩੪੫੬੭੮੯
  2790,
  // Gujarati ૦૧૨૩૪૫૬૭૮૯
  2918,
  // Odia ୦୧୨୩୪୫୬୭୮୯
  3046,
  // Tamil ௦௧௨௩௪௫௬௭௮௯
  3174,
  // Telugu ౦౧౨౩౪౫౬౭౮౯
  3302,
  // Kannada ೦೧೨೩೪೫೬೭೮೯
  3430,
  // Malayalam ൦൧൨൩൪൫൬൭൮൯
  3558,
  // Sinhala Archaic ෦෧෨෩෪෫෬෭෮෯
  // Southeast Asian scripts
  3664,
  // Thai ๐๑๒๓๔๕๖๗๘๙
  3792,
  // Lao ໐໑໒໓໔໕໖໗໘໙
  3872,
  // Tibetan ༠༡༢༣༤༥༦༧༨༩
  4160,
  // Myanmar ၀၁၂၃၄၅၆၇၈၉
  4240,
  // Myanmar Shan ႐႑႒႓႔႕႖႗႘႙
  6112,
  // Khmer ០១២៣៤៥៦៧៨៩
  6160,
  // Mongolian ᠐᠑᠒᠓᠔᠕᠖᠗᠘᠙
  6470,
  // Limbu ᥆᥇᥈᥉᥊᥋᥌᥍᥎᥏
  6608,
  // New Tai Lue ᧐᧑᧒᧓᧔᧕᧖᧗᧘᧙
  6784,
  // Tai Tham Hora ᪀᪁᪂᪃᪄᪅᪆᪇᪈᪉
  6800,
  // Tai Tham Tham ᪐᪑᪒᪓᪔᪕᪖᪗᪘᪙
  6992,
  // Balinese ᭐᭑᭒᭓᭔᭕᭖᭗᭘᭙
  7088,
  // Sundanese ᮰᮱᮲᮳᮴᮵᮶᮷᮸᮹
  7232,
  // Lepcha ᱀᱁᱂᱃᱄᱅᱆᱇᱈᱉
  7248,
  // Ol Chiki ᱐᱑᱒᱓᱔᱕᱖᱗᱘᱙
  // Fullwidth (CJK context)
  65296,
  // Fullwidth ０１２３４５６７８９
  // Mathematical digit variants (Unicode math block)
  120782,
  // Mathematical Bold
  120792,
  // Mathematical Double-Struck
  120802,
  // Mathematical Sans-Serif
  120812,
  // Mathematical Sans-Serif Bold
  120822,
  // Mathematical Monospace
  // Other scripts
  66720,
  // Osmanya 𐒠𐒡𐒢𐒣𐒤𐒥𐒦𐒧𐒨𐒩
  68912,
  // Hanifi Rohingya 𐴰𐴱𐴲𐴳𐴴𐴵𐴶𐴷𐴸𐴹
  69734,
  // Brahmi 𑁦𑁧𑁨𑁩𑁪𑁫𑁬𑁭𑁮𑁯
  69872,
  // Sora Sompeng 𑃰𑃱𑃲𑃳𑃴𑃵𑃶𑃷𑃸𑃹
  69942,
  // Chakma 𑄶𑄷𑄸𑄹𑄺𑄻𑄼𑄽𑄾𑄿
  70096,
  // Sharada 𑇐𑇑𑇒𑇓𑇔𑇕𑇖𑇗𑇘𑇙
  70384,
  // Khudawadi 𑋰𑋱𑋲𑋳𑋴𑋵𑋶𑋷𑋸𑋹
  70736,
  // Newa 𑑐𑑑𑑒𑑓𑑔𑑕𑑖𑑗𑑘𑑙
  70864,
  // Tirhuta 𑓐𑓑𑓒𑓓𑓔𑓕𑓖𑓗𑓘𑓙
  71248,
  // Modi 𑙐𑙑𑙒𑙓𑙔𑙕𑙖𑙗𑙘𑙙
  71360,
  // Takri 𑛀𑛁𑛂𑛃𑛄𑛅𑛆𑛇𑛈𑛉
  71472,
  // Ahom 𑜰𑜱𑜲𑜳𑜴𑜵𑜶𑜷𑜸𑜹
  71904,
  // Warang Citi 𑣠𑣡𑣢𑣣𑣤𑣥𑣦𑣧𑣨𑣩
  72016,
  // Dives Akuru 𑥐𑥑𑥒𑥓𑥔𑥕𑥖𑥗𑥘𑥙
  72688,
  // Khitan Small Script 𑯰𑯱𑯲𑯳𑯴𑯵𑯶𑯷𑯸𑯹
  72784,
  // Bhaiksuki 𑱐𑱑𑱒𑱓𑱔𑱕𑱖𑱗𑱘𑱙
  73040,
  // Masaram Gondi 𑵐𑵑𑵒𑵓𑵔𑵕𑵖𑵗𑵘𑵙
  73120,
  // Gunjala Gondi 𑶠𑶡𑶢𑶣𑶤𑶥𑶦𑶧𑶨𑶩
  73552,
  // Kawi 𑽐𑽑𑽒𑽓𑽔𑽕𑽖𑽗𑽘𑽙
  92768,
  // Mro 𖩠𖩡𖩢𖩣𖩤𖩥𖩦𖩧𖩨𖩩
  92864,
  // Tangsa 𖫀𖫁𖫂𖫃𖫄𖫅𖫆𖫇𖫈𖫉
  93008,
  // Pahawh Hmong 𖭐𖭑𖭒𖭓𖭔𖭕𖭖𖭗𖭘𖭙
  123200,
  // Nyiakeng Puachue Hmong 𞅀𞅁𞅂𞅃𞅄𞅅𞅆𞅇𞅈𞅉
  123632,
  // Wancho 𞋰𞋱𞋲𞋳𞋴𞋵𞋶𞋷𞋸𞋹
  124144,
  // Nag Mundari 𞓰𞓱𞓲𞓳𞓴𞓵𞓶𞓷𞓸𞓹
  125264,
  // Adlam 𞥐𞥑𞥒𞥓𞥔𞥕𞥖𞥗𞥘𞥙
  130032
  // Segmented digit symbols 🯰🯱🯲🯳🯴🯵🯶🯷🯸🯹
];
var NOT_DIGIT = 255;
var HIGH_MAP = /* @__PURE__ */ new Map();
var LOW_MAX = 65535;
var LOW_MIN = 1632;
var TABLE_OFFSET = LOW_MIN;
var TABLE_SIZE = LOW_MAX - LOW_MIN + 1;
var TABLE = new Uint8Array(TABLE_SIZE).fill(NOT_DIGIT);
for (const zero of SCRIPT_ZEROS) {
  for (let d = 0; d < 10; d++) {
    const cp = zero + d;
    if (cp <= LOW_MAX) {
      TABLE[cp - TABLE_OFFSET] = d;
    } else {
      HIGH_MAP.set(cp, d);
    }
  }
}

// node_modules/anynum/anynum.js
var CHAR_0 = 48;
var CHAR_9 = 57;
var CHAR_MINUS = 45;
var MINUS_SET = /* @__PURE__ */ new Set([8722, 65293, 65123]);
function anynum(str) {
  if (typeof str !== "string") return str;
  const len = str.length;
  if (len === 0) return str;
  let firstHit = -1;
  for (let i2 = 0; i2 < len; i2++) {
    const cc = str.charCodeAt(i2);
    if (cc >= CHAR_0 && cc <= CHAR_9 || cc === CHAR_MINUS) continue;
    if (cc < TABLE_OFFSET) {
      if (MINUS_SET.has(cc)) {
        firstHit = i2;
        break;
      }
      continue;
    }
    if (cc >= 55296 && cc <= 56319) {
      if (i2 + 1 < len) {
        const low = str.charCodeAt(i2 + 1);
        if (low >= 56320 && low <= 57343) {
          const cp = 65536 + (cc - 55296 << 10) + (low - 56320);
          if (HIGH_MAP.has(cp)) {
            firstHit = i2;
            break;
          }
        }
      }
      continue;
    }
    if (TABLE[cc - TABLE_OFFSET] !== NOT_DIGIT || MINUS_SET.has(cc)) {
      firstHit = i2;
      break;
    }
  }
  if (firstHit === -1) return str;
  const chars = [];
  if (firstHit > 0) chars.push(str.slice(0, firstHit));
  for (let i2 = firstHit; i2 < len; i2++) {
    const cc = str.charCodeAt(i2);
    if (cc >= CHAR_0 && cc <= CHAR_9 || cc === CHAR_MINUS) {
      chars.push(str[i2]);
      continue;
    }
    if (cc < TABLE_OFFSET) {
      chars.push(MINUS_SET.has(cc) ? "-" : str[i2]);
      continue;
    }
    if (cc >= 55296 && cc <= 56319) {
      if (i2 + 1 < len) {
        const low = str.charCodeAt(i2 + 1);
        if (low >= 56320 && low <= 57343) {
          const cp = 65536 + (cc - 55296 << 10) + (low - 56320);
          const d2 = HIGH_MAP.get(cp);
          if (d2 !== void 0) {
            chars.push(String.fromCharCode(d2 + 48));
            i2++;
            continue;
          }
        }
      }
      chars.push(str[i2]);
      continue;
    }
    if (MINUS_SET.has(cc)) {
      chars.push("-");
      continue;
    }
    const d = TABLE[cc - TABLE_OFFSET];
    chars.push(d !== NOT_DIGIT ? String.fromCharCode(d + 48) : str[i2]);
  }
  return chars.join("");
}
var anynum_default = anynum;

// node_modules/strnum/strnum.js
var hexRegex = /^[-+]?0x[a-fA-F0-9]+$/;
var binRegex = /^0b[01]+$/;
var octRegex = /^0o[0-7]+$/;
var numRegex = /^([\-\+])?(0*)([0-9]*(\.[0-9]*)?)$/;
var consider = {
  hex: true,
  binary: false,
  octal: false,
  leadingZeros: true,
  decimalPoint: ".",
  eNotation: true,
  //skipLike: /regex/,
  infinity: "original",
  // "null", "infinity" (Infinity type), "string" ("Infinity" (the string literal))
  unicode: false
};
function toNumber(str, options = {}) {
  options = Object.assign({}, consider, options);
  if (!str || typeof str !== "string") return str;
  let trimmedStr = str.trim();
  if (trimmedStr.length === 0) return str;
  else if (options.skipLike !== void 0 && options.skipLike.test(trimmedStr)) return str;
  else if (trimmedStr === "0") return 0;
  if (options.unicode) {
    trimmedStr = anynum_default(trimmedStr);
    if (trimmedStr === "0") return 0;
  }
  if (options.hex && hexRegex.test(trimmedStr)) {
    return parse_int(trimmedStr, 16);
  } else if (options.binary && binRegex.test(trimmedStr)) {
    return parse_int(trimmedStr, 2);
  } else if (options.octal && octRegex.test(trimmedStr)) {
    return parse_int(trimmedStr, 8);
  } else if (!isFinite(trimmedStr)) {
    return handleInfinity(str, Number(trimmedStr), options);
  } else if (trimmedStr.includes("e") || trimmedStr.includes("E")) {
    return resolveEnotation(str, trimmedStr, options);
  } else {
    const match = numRegex.exec(trimmedStr);
    if (match) {
      const sign = match[1] || "";
      const leadingZeros = match[2];
      let numTrimmedByZeros = trimZeros(match[3]);
      const decimalAdjacentToLeadingZeros = sign ? (
        // 0., -00., 000.
        str[leadingZeros.length + 1] === "."
      ) : str[leadingZeros.length] === ".";
      if (!options.leadingZeros && (leadingZeros.length > 1 || leadingZeros.length === 1 && !decimalAdjacentToLeadingZeros)) {
        return str;
      } else {
        const num = Number(trimmedStr);
        const parsedStr = String(num);
        if (num === 0) return num;
        if (parsedStr.search(/[eE]/) !== -1) {
          if (options.eNotation) return num;
          else return str;
        } else if (trimmedStr.indexOf(".") !== -1) {
          if (parsedStr === "0") return num;
          else if (parsedStr === numTrimmedByZeros) return num;
          else if (parsedStr === `${sign}${numTrimmedByZeros}`) return num;
          else return str;
        }
        let n = leadingZeros ? numTrimmedByZeros : trimmedStr;
        if (leadingZeros) {
          return n === parsedStr || sign + n === parsedStr ? num : str;
        } else {
          return n === parsedStr || n === sign + parsedStr ? num : str;
        }
      }
    } else {
      return str;
    }
  }
}
var eNotationRegx = /^([-+])?(0*)(\d*(\.\d*)?[eE][-\+]?\d+)$/;
function resolveEnotation(str, trimmedStr, options) {
  if (!options.eNotation) return str;
  const notation = trimmedStr.match(eNotationRegx);
  if (notation) {
    let sign = notation[1] || "";
    const eChar = notation[3].indexOf("e") === -1 ? "E" : "e";
    const leadingZeros = notation[2];
    const eAdjacentToLeadingZeros = sign ? (
      // 0E.
      str[leadingZeros.length + 1] === eChar
    ) : str[leadingZeros.length] === eChar;
    if (leadingZeros.length > 1 && eAdjacentToLeadingZeros) return str;
    else if (leadingZeros.length === 1 && (notation[3].startsWith(`.${eChar}`) || notation[3][0] === eChar)) {
      return Number(trimmedStr);
    } else if (leadingZeros.length > 0) {
      if (options.leadingZeros && !eAdjacentToLeadingZeros) {
        trimmedStr = (notation[1] || "") + notation[3];
        return Number(trimmedStr);
      } else return str;
    } else {
      return Number(trimmedStr);
    }
  } else {
    return str;
  }
}
function trimZeros(numStr) {
  if (numStr && numStr.indexOf(".") !== -1) {
    let end = numStr.length;
    while (end > 0 && numStr.charCodeAt(end - 1) === 48) end--;
    numStr = numStr.slice(0, end);
    if (numStr === ".") numStr = "0";
    else if (numStr[0] === ".") numStr = "0" + numStr;
    else if (numStr[numStr.length - 1] === ".") numStr = numStr.substring(0, numStr.length - 1);
    return numStr;
  }
  return numStr;
}
function parse_int(numStr, base) {
  const str = numStr.trim();
  if (base === 2 || base === 8) numStr = str.substring(2);
  if (parseInt) return parseInt(numStr, base);
  else if (Number.parseInt) return Number.parseInt(numStr, base);
  else if (window && window.parseInt) return window.parseInt(numStr, base);
  else throw new Error("parseInt, Number.parseInt, window.parseInt are not supported");
}
function handleInfinity(str, num, options) {
  const isPositive = num === Infinity;
  switch (options.infinity.toLowerCase()) {
    case "null":
      return null;
    case "infinity":
      return num;
    // Return Infinity or -Infinity
    case "string":
      return isPositive ? "Infinity" : "-Infinity";
    case "original":
    default:
      return str;
  }
}

// node_modules/fast-xml-parser/src/ignoreAttributes.js
function getIgnoreAttributesFn(ignoreAttributes) {
  if (typeof ignoreAttributes === "function") {
    return ignoreAttributes;
  }
  if (Array.isArray(ignoreAttributes)) {
    return (attrName) => {
      for (const pattern of ignoreAttributes) {
        if (typeof pattern === "string" && attrName === pattern) {
          return true;
        }
        if (pattern instanceof RegExp && pattern.test(attrName)) {
          return true;
        }
      }
    };
  }
  return () => false;
}

// node_modules/path-expression-matcher/src/Expression.js
var Expression = class {
  /**
   * Create a new Expression
   * @param {string} pattern - Pattern string (e.g., "root.users.user", "..user[id]")
   * @param {Object} options - Configuration options
   * @param {string} options.separator - Path separator (default: '.')
   */
  constructor(pattern, options = {}, data) {
    this.pattern = pattern;
    this.separator = options.separator || ".";
    this.segments = this._parse(pattern);
    this.data = data;
    this._hasDeepWildcard = this.segments.some((seg) => seg.type === "deep-wildcard");
    this._hasAttributeCondition = this.segments.some((seg) => seg.attrName !== void 0);
    this._hasPositionSelector = this.segments.some((seg) => seg.position !== void 0);
  }
  /**
   * Parse pattern string into segments
   * @private
   * @param {string} pattern - Pattern to parse
   * @returns {Array} Array of segment objects
   */
  _parse(pattern) {
    const segments = [];
    let i2 = 0;
    let currentPart = "";
    while (i2 < pattern.length) {
      if (pattern[i2] === this.separator) {
        if (i2 + 1 < pattern.length && pattern[i2 + 1] === this.separator) {
          if (currentPart.trim()) {
            segments.push(this._parseSegment(currentPart.trim()));
            currentPart = "";
          }
          segments.push({ type: "deep-wildcard" });
          i2 += 2;
        } else {
          if (currentPart.trim()) {
            segments.push(this._parseSegment(currentPart.trim()));
          }
          currentPart = "";
          i2++;
        }
      } else {
        currentPart += pattern[i2];
        i2++;
      }
    }
    if (currentPart.trim()) {
      segments.push(this._parseSegment(currentPart.trim()));
    }
    return segments;
  }
  /**
   * Parse a single segment
   * @private
   * @param {string} part - Segment string (e.g., "user", "ns::user", "user[id]", "ns::user:first")
   * @returns {Object} Segment object
   */
  _parseSegment(part) {
    const segment = { type: "tag" };
    let bracketContent = null;
    let withoutBrackets = part;
    const bracketMatch = part.match(/^([^\[]+)(\[[^\]]*\])(.*)$/);
    if (bracketMatch) {
      withoutBrackets = bracketMatch[1] + bracketMatch[3];
      if (bracketMatch[2]) {
        const content = bracketMatch[2].slice(1, -1);
        if (content) {
          bracketContent = content;
        }
      }
    }
    let namespace = void 0;
    let tagAndPosition = withoutBrackets;
    if (withoutBrackets.includes("::")) {
      const nsIndex = withoutBrackets.indexOf("::");
      namespace = withoutBrackets.substring(0, nsIndex).trim();
      tagAndPosition = withoutBrackets.substring(nsIndex + 2).trim();
      if (!namespace) {
        throw new Error(`Invalid namespace in pattern: ${part}`);
      }
    }
    let tag = void 0;
    let positionMatch = null;
    if (tagAndPosition.includes(":")) {
      const colonIndex = tagAndPosition.lastIndexOf(":");
      const tagPart = tagAndPosition.substring(0, colonIndex).trim();
      const posPart = tagAndPosition.substring(colonIndex + 1).trim();
      const isPositionKeyword = ["first", "last", "odd", "even"].includes(posPart) || /^nth\(\d+\)$/.test(posPart);
      if (isPositionKeyword) {
        tag = tagPart;
        positionMatch = posPart;
      } else {
        tag = tagAndPosition;
      }
    } else {
      tag = tagAndPosition;
    }
    if (!tag) {
      throw new Error(`Invalid segment pattern: ${part}`);
    }
    segment.tag = tag;
    if (namespace) {
      segment.namespace = namespace;
    }
    if (bracketContent) {
      if (bracketContent.includes("=")) {
        const eqIndex = bracketContent.indexOf("=");
        segment.attrName = bracketContent.substring(0, eqIndex).trim();
        segment.attrValue = bracketContent.substring(eqIndex + 1).trim();
      } else {
        segment.attrName = bracketContent.trim();
      }
    }
    if (positionMatch) {
      const nthMatch = positionMatch.match(/^nth\((\d+)\)$/);
      if (nthMatch) {
        segment.position = "nth";
        segment.positionValue = parseInt(nthMatch[1], 10);
      } else {
        segment.position = positionMatch;
      }
    }
    return segment;
  }
  /**
   * Get the number of segments
   * @returns {number}
   */
  get length() {
    return this.segments.length;
  }
  /**
   * Check if expression contains deep wildcard
   * @returns {boolean}
   */
  hasDeepWildcard() {
    return this._hasDeepWildcard;
  }
  /**
   * Check if expression has attribute conditions
   * @returns {boolean}
   */
  hasAttributeCondition() {
    return this._hasAttributeCondition;
  }
  /**
   * Check if expression has position selectors
   * @returns {boolean}
   */
  hasPositionSelector() {
    return this._hasPositionSelector;
  }
  /**
   * Get string representation
   * @returns {string}
   */
  toString() {
    return this.pattern;
  }
};

// node_modules/path-expression-matcher/src/ExpressionSet.js
var ExpressionSet = class {
  constructor() {
    this._byDepthAndTag = /* @__PURE__ */ new Map();
    this._wildcardByDepth = /* @__PURE__ */ new Map();
    this._deepWildcards = [];
    this._deepByTerminalTag = /* @__PURE__ */ new Map();
    this._patterns = /* @__PURE__ */ new Set();
    this._sealed = false;
  }
  /**
   * Add an Expression to the set.
   * Duplicate patterns (same pattern string) are silently ignored.
   *
   * @param {import('./Expression.js').default} expression - A pre-constructed Expression instance
   * @returns {this} for chaining
   * @throws {TypeError} if called after seal()
   *
   * @example
   * set.add(new Expression('root.users.user'));
   * set.add(new Expression('..script'));
   */
  add(expression) {
    if (this._sealed) {
      throw new TypeError(
        "ExpressionSet is sealed. Create a new ExpressionSet to add more expressions."
      );
    }
    if (this._patterns.has(expression.pattern)) return this;
    this._patterns.add(expression.pattern);
    if (expression.hasDeepWildcard()) {
      const lastSeg2 = expression.segments[expression.segments.length - 1];
      if (lastSeg2 && lastSeg2.type !== "deep-wildcard" && lastSeg2.tag !== "*") {
        const tag2 = lastSeg2.tag;
        if (!this._deepByTerminalTag.has(tag2)) this._deepByTerminalTag.set(tag2, []);
        this._deepByTerminalTag.get(tag2).push(expression);
      } else {
        this._deepWildcards.push(expression);
      }
      return this;
    }
    const depth = expression.length;
    const lastSeg = expression.segments[expression.segments.length - 1];
    const tag = lastSeg?.tag;
    if (!tag || tag === "*") {
      if (!this._wildcardByDepth.has(depth)) this._wildcardByDepth.set(depth, []);
      this._wildcardByDepth.get(depth).push(expression);
    } else {
      const key = `${depth}:${tag}`;
      if (!this._byDepthAndTag.has(key)) this._byDepthAndTag.set(key, []);
      this._byDepthAndTag.get(key).push(expression);
    }
    return this;
  }
  /**
   * Add multiple expressions at once.
   *
   * @param {import('./Expression.js').default[]} expressions - Array of Expression instances
   * @returns {this} for chaining
   *
   * @example
   * set.addAll([
   *   new Expression('root.users.user'),
   *   new Expression('root.config.setting'),
   * ]);
   */
  addAll(expressions) {
    for (const expr of expressions) this.add(expr);
    return this;
  }
  /**
   * Check whether a pattern string is already present in the set.
   *
   * @param {import('./Expression.js').default} expression
   * @returns {boolean}
   */
  has(expression) {
    return this._patterns.has(expression.pattern);
  }
  /**
   * Number of expressions in the set.
   * @type {number}
   */
  get size() {
    return this._patterns.size;
  }
  /**
   * Seal the set against further modifications.
   * Useful to prevent accidental mutations after config is built.
   * Calling add() or addAll() on a sealed set throws a TypeError.
   *
   * @returns {this}
   */
  seal() {
    this._sealed = true;
    return this;
  }
  /**
   * Whether the set has been sealed.
   * @type {boolean}
   */
  get isSealed() {
    return this._sealed;
  }
  /**
   * Test whether the matcher's current path matches any expression in the set.
   *
   * Evaluation order (cheapest → most expensive):
   *  1. Exact depth + tag bucket  — O(1) lookup, typically 0–2 expressions
   *  2. Depth-only wildcard bucket — O(1) lookup, rare
   *  3. Deep-wildcard list         — always checked, but usually small
   *
   * @param {import('./Matcher.js').default} matcher - Matcher instance (or readOnly view)
   * @returns {boolean} true if any expression matches the current path
   *
   * @example
   * if (stopNodes.matchesAny(matcher)) {
   *   // handle stop node
   * }
   */
  matchesAny(matcher) {
    return this.findMatch(matcher) !== null;
  }
  /**
  * Find and return the first Expression that matches the matcher's current path.
  *
  * Uses the same evaluation order as matchesAny (cheapest → most expensive):
  *  1. Exact depth + tag bucket
  *  2. Depth-only wildcard bucket
  *  3. Deep-wildcard list
  *
  * @param {import('./Matcher.js').default} matcher - Matcher instance (or readOnly view)
  * @returns {import('./Expression.js').default | null} the first matching Expression, or null
  *
  * @example
  * const expr = stopNodes.findMatch(matcher);
  * if (expr) {
  *   // access expr.config, expr.pattern, etc.
  * }
  */
  findMatch(matcher) {
    const depth = matcher.getDepth();
    const tag = matcher.getCurrentTag();
    const exactKey = `${depth}:${tag}`;
    const exactBucket = this._byDepthAndTag.get(exactKey);
    if (exactBucket) {
      for (let i2 = 0; i2 < exactBucket.length; i2++) {
        if (matcher.matches(exactBucket[i2])) return exactBucket[i2];
      }
    }
    const wildcardBucket = this._wildcardByDepth.get(depth);
    if (wildcardBucket) {
      for (let i2 = 0; i2 < wildcardBucket.length; i2++) {
        if (matcher.matches(wildcardBucket[i2])) return wildcardBucket[i2];
      }
    }
    const deepBucket = this._deepByTerminalTag.get(tag);
    if (deepBucket) {
      for (let i2 = 0; i2 < deepBucket.length; i2++) {
        if (matcher.matches(deepBucket[i2])) return deepBucket[i2];
      }
    }
    for (let i2 = 0; i2 < this._deepWildcards.length; i2++) {
      if (matcher.matches(this._deepWildcards[i2])) return this._deepWildcards[i2];
    }
    return null;
  }
};

// node_modules/path-expression-matcher/src/Matcher.js
var MatcherView = class {
  /**
   * @param {Matcher} matcher - The parent Matcher instance to read from.
   */
  constructor(matcher) {
    this._matcher = matcher;
  }
  /**
   * Get the path separator used by the parent matcher.
   * @returns {string}
   */
  get separator() {
    return this._matcher.separator;
  }
  /**
   * Get current tag name.
   * @returns {string|undefined}
   */
  getCurrentTag() {
    const path7 = this._matcher.path;
    return path7.length > 0 ? path7[path7.length - 1].tag : void 0;
  }
  /**
   * Get current namespace.
   * @returns {string|undefined}
   */
  getCurrentNamespace() {
    const path7 = this._matcher.path;
    return path7.length > 0 ? path7[path7.length - 1].namespace : void 0;
  }
  /**
   * Get current node's attribute value.
   * @param {string} attrName
   * @returns {*}
   */
  getAttrValue(attrName) {
    const path7 = this._matcher.path;
    if (path7.length === 0) return void 0;
    return path7[path7.length - 1].values?.[attrName];
  }
  /**
   * Check if current node has an attribute.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAttr(attrName) {
    const path7 = this._matcher.path;
    if (path7.length === 0) return false;
    const current2 = path7[path7.length - 1];
    return current2.values !== void 0 && attrName in current2.values;
  }
  /**
   * Get the value of a "kept" attribute from the nearest ancestor (or
   * current node) that declared it via `push(tag, attrs, ns, { keep: [...] })`.
   * @param {string} attrName
   * @returns {*}
   */
  getAnyParentAttr(attrName) {
    return this._matcher.getAnyParentAttr(attrName);
  }
  /**
   * Check whether any ancestor (or the current node) kept the given
   * attribute via `push(tag, attrs, ns, { keep: [...] })`.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAnyParentAttr(attrName) {
    return this._matcher.hasAnyParentAttr(attrName);
  }
  /**
   * Get current node's sibling position (child index in parent).
   * @returns {number}
   */
  getPosition() {
    const path7 = this._matcher.path;
    if (path7.length === 0) return -1;
    return path7[path7.length - 1].position ?? 0;
  }
  /**
   * Get current node's repeat counter (occurrence count of this tag name).
   * @returns {number}
   */
  getCounter() {
    const path7 = this._matcher.path;
    if (path7.length === 0) return -1;
    return path7[path7.length - 1].counter ?? 0;
  }
  /**
   * Get current node's sibling index (alias for getPosition).
   * @returns {number}
   * @deprecated Use getPosition() or getCounter() instead
   */
  getIndex() {
    return this.getPosition();
  }
  /**
   * Get current path depth.
   * @returns {number}
   */
  getDepth() {
    return this._matcher.path.length;
  }
  /**
   * Get path as string.
   * @param {string} [separator] - Optional separator (uses default if not provided)
   * @param {boolean} [includeNamespace=true]
   * @returns {string}
   */
  toString(separator, includeNamespace = true) {
    return this._matcher.toString(separator, includeNamespace);
  }
  /**
   * Get path as array of tag names.
   * @returns {string[]}
   */
  toArray() {
    return this._matcher.path.map((n) => n.tag);
  }
  /**
   * Match current path against an Expression.
   * @param {Expression} expression
   * @returns {boolean}
   */
  matches(expression) {
    return this._matcher.matches(expression);
  }
  /**
   * Match any expression in the given set against the current path.
   * @param {ExpressionSet} exprSet
   * @returns {boolean}
   */
  matchesAny(exprSet) {
    return exprSet.matchesAny(this._matcher);
  }
};
var Matcher = class {
  /**
   * Create a new Matcher.
   * @param {Object} [options={}]
   * @param {string} [options.separator='.'] - Default path separator
   */
  constructor(options = {}) {
    this.separator = options.separator || ".";
    this.path = [];
    this.siblingStacks = [];
    this._pathStringCache = null;
    this._view = new MatcherView(this);
    this._keptAttrs = [];
  }
  /**
   * Push a new tag onto the path.
   * @param {string} tagName
   * @param {Object|null} [attrValues=null]
   * @param {string|null} [namespace=null]
   * @param {Object|null} [options=null]
   * @param {string[]} [options.keep] - Names of attributes (from attrValues)
   */
  push(tagName, attrValues = null, namespace = null, options = null) {
    this._pathStringCache = null;
    if (this.path.length > 0) {
      this.path[this.path.length - 1].values = void 0;
    }
    const currentLevel = this.path.length;
    let level = this.siblingStacks[currentLevel];
    if (!level) {
      level = { counts: /* @__PURE__ */ new Map(), total: 0 };
      this.siblingStacks[currentLevel] = level;
    }
    const siblingKey = namespace ? `${namespace}:${tagName}` : tagName;
    const counter = level.counts.get(siblingKey) || 0;
    const position = level.total;
    level.counts.set(siblingKey, counter + 1);
    level.total++;
    const node = {
      tag: tagName,
      position,
      counter
    };
    if (namespace !== null && namespace !== void 0) {
      node.namespace = namespace;
    }
    if (attrValues !== null && attrValues !== void 0) {
      node.values = attrValues;
    }
    this.path.push(node);
    const depth = this.path.length;
    const keep = options !== null ? options.keep : null;
    if (keep !== null && keep !== void 0 && keep.length > 0 && attrValues) {
      for (let i2 = 0; i2 < keep.length; i2++) {
        const name = keep[i2];
        if (attrValues[name] !== void 0) {
          this._keptAttrs.push({ depth, name, value: attrValues[name] });
        }
      }
    }
  }
  /**
   * Pop the last tag from the path.
   * @returns {Object|undefined} The popped node
   */
  pop() {
    if (this.path.length === 0) return void 0;
    this._pathStringCache = null;
    const node = this.path.pop();
    if (this.siblingStacks.length > this.path.length + 1) {
      this.siblingStacks.length = this.path.length + 1;
    }
    const poppedDepth = this.path.length + 1;
    while (this._keptAttrs.length > 0 && this._keptAttrs[this._keptAttrs.length - 1].depth >= poppedDepth) {
      this._keptAttrs.pop();
    }
    return node;
  }
  /**
   * Update current node's attribute values.
   * Useful when attributes are parsed after push.
   * @param {Object} attrValues
   */
  updateCurrent(attrValues) {
    if (this.path.length > 0) {
      const current2 = this.path[this.path.length - 1];
      if (attrValues !== null && attrValues !== void 0) {
        current2.values = attrValues;
      }
    }
  }
  /**
   * Get current tag name.
   * @returns {string|undefined}
   */
  getCurrentTag() {
    return this.path.length > 0 ? this.path[this.path.length - 1].tag : void 0;
  }
  /**
   * Get current namespace.
   * @returns {string|undefined}
   */
  getCurrentNamespace() {
    return this.path.length > 0 ? this.path[this.path.length - 1].namespace : void 0;
  }
  /**
   * Get current node's attribute value.
   * @param {string} attrName
   * @returns {*}
   */
  getAttrValue(attrName) {
    if (this.path.length === 0) return void 0;
    return this.path[this.path.length - 1].values?.[attrName];
  }
  /**
   * Check if current node has an attribute.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAttr(attrName) {
    if (this.path.length === 0) return false;
    const current2 = this.path[this.path.length - 1];
    return current2.values !== void 0 && attrName in current2.values;
  }
  /**
   * Get the value of a "kept" attribute from the nearest ancestor (or
   * current node) that declared it via `push(tag, attrs, ns, { keep: [...] })`.
   * Unlike getAttrValue(), this works regardless of how deep the path has
   * gone since the attribute was pushed — but only for attribute names that
   * were explicitly marked with `keep` at push time. Cost is proportional to
   * the number of currently-kept attributes (typically 0-3), not path depth.
   * @param {string} attrName
   * @returns {*} the value, or undefined if no ancestor kept this attribute
   */
  getAnyParentAttr(attrName) {
    const kept = this._keptAttrs;
    for (let i2 = kept.length - 1; i2 >= 0; i2--) {
      if (kept[i2].name === attrName) return kept[i2].value;
    }
    return void 0;
  }
  /**
   * Check whether any ancestor (or the current node) kept the given
   * attribute via `push(tag, attrs, ns, { keep: [...] })`.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAnyParentAttr(attrName) {
    const kept = this._keptAttrs;
    for (let i2 = kept.length - 1; i2 >= 0; i2--) {
      if (kept[i2].name === attrName) return true;
    }
    return false;
  }
  /**
   * Get current node's sibling position (child index in parent).
   * @returns {number}
   */
  getPosition() {
    if (this.path.length === 0) return -1;
    return this.path[this.path.length - 1].position ?? 0;
  }
  /**
   * Get current node's repeat counter (occurrence count of this tag name).
   * @returns {number}
   */
  getCounter() {
    if (this.path.length === 0) return -1;
    return this.path[this.path.length - 1].counter ?? 0;
  }
  /**
   * Get current node's sibling index (alias for getPosition).
   * @returns {number}
   * @deprecated Use getPosition() or getCounter() instead
   */
  getIndex() {
    return this.getPosition();
  }
  /**
   * Get current path depth.
   * @returns {number}
   */
  getDepth() {
    return this.path.length;
  }
  /**
   * Get path as string.
   * @param {string} [separator] - Optional separator (uses default if not provided)
   * @param {boolean} [includeNamespace=true]
   * @returns {string}
   */
  toString(separator, includeNamespace = true) {
    const sep2 = separator || this.separator;
    const isDefault = sep2 === this.separator && includeNamespace === true;
    if (isDefault) {
      if (this._pathStringCache !== null) {
        return this._pathStringCache;
      }
      const result = this.path.map(
        (n) => n.namespace ? `${n.namespace}:${n.tag}` : n.tag
      ).join(sep2);
      this._pathStringCache = result;
      return result;
    }
    return this.path.map(
      (n) => includeNamespace && n.namespace ? `${n.namespace}:${n.tag}` : n.tag
    ).join(sep2);
  }
  /**
   * Get path as array of tag names.
   * @returns {string[]}
   */
  toArray() {
    return this.path.map((n) => n.tag);
  }
  /**
   * Reset the path to empty.
   */
  reset() {
    this._pathStringCache = null;
    this.path = [];
    this.siblingStacks = [];
    this._keptAttrs = [];
  }
  /**
   * Match current path against an Expression.
   * @param {Expression} expression
   * @returns {boolean}
   */
  matches(expression) {
    const segments = expression.segments;
    if (segments.length === 0) {
      return false;
    }
    if (expression.hasDeepWildcard()) {
      return this._matchWithDeepWildcard(segments);
    }
    return this._matchSimple(segments);
  }
  /**
   * @private
   */
  _matchSimple(segments) {
    if (this.path.length !== segments.length) {
      return false;
    }
    for (let i2 = 0; i2 < segments.length; i2++) {
      if (!this._matchSegment(segments[i2], this.path[i2], i2 === this.path.length - 1)) {
        return false;
      }
    }
    return true;
  }
  /**
   * @private
   */
  _matchWithDeepWildcard(segments) {
    let pathIdx = this.path.length - 1;
    let segIdx = segments.length - 1;
    while (segIdx >= 0 && pathIdx >= 0) {
      const segment = segments[segIdx];
      if (segment.type === "deep-wildcard") {
        segIdx--;
        if (segIdx < 0) {
          return true;
        }
        const nextSeg = segments[segIdx];
        let found = false;
        for (let i2 = pathIdx; i2 >= 0; i2--) {
          if (this._matchSegment(nextSeg, this.path[i2], i2 === this.path.length - 1)) {
            pathIdx = i2 - 1;
            segIdx--;
            found = true;
            break;
          }
        }
        if (!found) {
          return false;
        }
      } else {
        if (!this._matchSegment(segment, this.path[pathIdx], pathIdx === this.path.length - 1)) {
          return false;
        }
        pathIdx--;
        segIdx--;
      }
    }
    return segIdx < 0;
  }
  /**
   * @private
   */
  _matchSegment(segment, node, isCurrentNode) {
    if (segment.tag !== "*" && segment.tag !== node.tag) {
      return false;
    }
    if (segment.namespace !== void 0) {
      if (segment.namespace !== "*" && segment.namespace !== node.namespace) {
        return false;
      }
    }
    if (segment.attrName !== void 0) {
      if (!isCurrentNode) {
        return false;
      }
      if (!node.values || !(segment.attrName in node.values)) {
        return false;
      }
      if (segment.attrValue !== void 0) {
        if (String(node.values[segment.attrName]) !== String(segment.attrValue)) {
          return false;
        }
      }
    }
    if (segment.position !== void 0) {
      if (!isCurrentNode) {
        return false;
      }
      const counter = node.counter ?? 0;
      if (segment.position === "first" && counter !== 0) {
        return false;
      } else if (segment.position === "odd" && counter % 2 !== 1) {
        return false;
      } else if (segment.position === "even" && counter % 2 !== 0) {
        return false;
      } else if (segment.position === "nth" && counter !== segment.positionValue) {
        return false;
      }
    }
    return true;
  }
  /**
   * Match any expression in the given set against the current path.
   * @param {ExpressionSet} exprSet
   * @returns {boolean}
   */
  matchesAny(exprSet) {
    return exprSet.matchesAny(this);
  }
  /**
   * Create a snapshot of current state.
   * @returns {Object}
   */
  snapshot() {
    return {
      path: this.path.map((node) => ({ ...node })),
      siblingStacks: this.siblingStacks.map((level) => level ? { counts: new Map(level.counts), total: level.total } : level),
      keptAttrs: this._keptAttrs.map((entry) => ({ ...entry }))
    };
  }
  /**
   * Restore state from snapshot.
   * @param {Object} snapshot
   */
  restore(snapshot4) {
    this._pathStringCache = null;
    this.path = snapshot4.path.map((node) => ({ ...node }));
    this.siblingStacks = snapshot4.siblingStacks.map((level) => level ? { counts: new Map(level.counts), total: level.total } : level);
    this._keptAttrs = (snapshot4.keptAttrs || []).map((entry) => ({ ...entry }));
  }
  /**
   * Return the read-only {@link MatcherView} for this matcher.
   *
   * The same instance is returned on every call — no allocation occurs.
   * It always reflects the current parser state and is safe to pass to
   * user callbacks without risk of accidental mutation.
   *
   * @returns {MatcherView}
   *
   * @example
   * const view = matcher.readOnly();
   * // pass view to callbacks — it stays in sync automatically
   * view.matches(expr);       // ✓
   * view.getCurrentTag();     // ✓
   * // view.push(...)         // ✗ method does not exist — caught by TypeScript
   */
  readOnly() {
    return this._view;
  }
};

// node_modules/is-unsafe/src/contexts/html.js
var HTML_PATTERNS = [
  {
    id: "html-script-open",
    description: "<script opening tag",
    pattern: /<script[\s>/]/i
  },
  {
    id: "html-script-close",
    description: "</script closing tag",
    pattern: /<\/script[\s>]/i
  },
  {
    id: "html-javascript-protocol",
    description: "javascript: URI scheme (with optional whitespace/encoding)",
    // Handles j&#x61;vascript:, j\u0061vascript:, and whitespace variants
    pattern: /j[\t\n\r ]*a[\t\n\r ]*v[\t\n\r ]*a[\t\n\r ]*s[\t\n\r ]*c[\t\n\r ]*r[\t\n\r ]*i[\t\n\r ]*p[\t\n\r ]*t[\t\n\r ]*:/i
  },
  {
    id: "html-vbscript-protocol",
    description: "vbscript: URI scheme",
    pattern: /vbscript[\t\n\r ]*:/i
  },
  {
    id: "html-data-html",
    description: "data:text/html URI \u2014 can execute scripts in browsers",
    pattern: /data[\t\n\r ]*:[\t\n\r ]*text\/html/i
  },
  {
    id: "html-data-xhtml",
    description: "data:application/xhtml+xml URI",
    pattern: /data[\t\n\r ]*:[\t\n\r ]*application\/xhtml/i
  },
  {
    id: "html-data-svg",
    description: "data:image/svg+xml URI \u2014 can execute scripts",
    pattern: /data[\t\n\r ]*:[\t\n\r ]*image\/svg\+xml/i
  },
  {
    id: "html-inline-event-handler",
    description: "Inline event handler attributes: onclick=, onerror=, onload=, etc.",
    // \bon ensures we match a word boundary so "phonetic=" is not caught
    pattern: /\bon\w{1,30}\s*=/i
  },
  {
    id: "html-entity-obfuscated-script",
    description: "HTML-entity-encoded <script (e.g. &#x3C;script or &lt;script)",
    // Entities include optional trailing semicolon: &#x3C; or &#x3C (both valid in HTML5)
    pattern: /(?:&#x0*3[Cc];?|&#0*60;?|&lt;)\s*script/i
  },
  {
    id: "html-entity-obfuscated-javascript",
    description: 'HTML-entity-encoded javascript: (partial \u2014 catches common &#106; or &#x6a; for "j")',
    pattern: /(?:&#x0*6[Aa];?|&#0*106;?)\s*(?:&#x0*61;?|a)[\s\S]{0,80}script\s*:/i
  },
  {
    id: "html-style-expression",
    description: "CSS expression() \u2014 IE-era code execution in style attributes",
    pattern: /style[\s\S]{0,20}expression\s*\(/i
  },
  {
    id: "html-object-embed",
    description: "<object or <embed tags that can load active content",
    pattern: /<(?:object|embed)[\s>/]/i
  },
  {
    id: "html-base-tag",
    description: "<base href= \u2014 can hijack all relative URLs on a page",
    pattern: /<base[\s>]/i
  },
  {
    id: "html-meta-refresh",
    description: '<meta http-equiv="refresh" \u2014 can redirect users',
    pattern: /<meta[\s\S]{0,40}http-equiv[\s\S]{0,20}refresh/i
  },
  {
    id: "html-srcdoc",
    description: "srcdoc= attribute on iframes \u2014 embeds HTML that can run scripts",
    pattern: /srcdoc\s*=/i
  },
  {
    id: "html-iframe",
    description: "<iframe tag",
    pattern: /<iframe[\s>/]/i
  },
  {
    id: "html-form",
    description: "<form tag \u2014 can be used for phishing / credential harvesting injection",
    pattern: /<form[\s>/]/i
  }
];
var html_default = HTML_PATTERNS;

// node_modules/is-unsafe/src/contexts/xml.js
var XML_PATTERNS = [
  {
    id: "xml-cdata-injection",
    description: "CDATA section injection: <![CDATA[ breaks out of text node context",
    pattern: /<!\[CDATA\[/i
  },
  {
    id: "xml-cdata-close",
    description: "CDATA close sequence: ]]> can terminate an enclosing CDATA section",
    pattern: /\]\]>/
  },
  {
    id: "xml-processing-instruction",
    description: "XML processing instruction: <?xml-stylesheet or <?php etc.",
    pattern: /<\?(?:xml[\- ]|php|asp)/i
  },
  {
    id: "xml-doctype-injection",
    description: "DOCTYPE declaration embedded in content \u2014 can define entities",
    // Match <!DOCTYPE followed by end-of-string, whitespace, or [ (internal subset)
    pattern: /<!DOCTYPE(?:[\s[]|$)/i
  },
  {
    id: "xml-entity-system",
    description: "SYSTEM keyword \u2014 used in external entity declarations (XXE)",
    pattern: /\bSYSTEM\s+["']/i
  },
  {
    id: "xml-entity-public",
    description: "PUBLIC keyword \u2014 used in external entity declarations (XXE)",
    pattern: /\bPUBLIC\s+["']/i
  },
  {
    id: "xml-entity-declaration",
    description: "<!ENTITY declaration \u2014 defines entities, potential XXE or entity expansion",
    pattern: /<!ENTITY[\s%]/i
  },
  {
    id: "xml-billion-laughs",
    description: "Entity reference chaining / billion laughs: repeated &eX; style references",
    // Heuristic: 3+ consecutive entity refs suggests expansion attack
    pattern: /(?:&\w{1,20};){3,}/
  },
  {
    id: "xml-namespace-confusion",
    description: "xmlns: attribute injection \u2014 can redefine namespaces to confuse parsers",
    // pattern: /\bxmlns\s*(?::\w{1,40})?\s*=/i,
    pattern: /\bxmlns(?::\w{1,40})?\s*=/i
  },
  {
    id: "xml-comment-injection",
    description: "<!-- comment injection \u2014 can hide content from some parsers",
    pattern: /<!--/
  },
  {
    id: "xml-comment-close",
    description: "--> closes an enclosing XML comment",
    pattern: /-->/
  },
  {
    id: "xml-pi-close",
    description: "?> closes an enclosing processing instruction",
    pattern: /\?>/
  }
];
var xml_default = XML_PATTERNS;

// node_modules/is-unsafe/src/contexts/svg.js
var SVG_PATTERNS = [
  {
    id: "svg-script-element",
    description: "<script element inside SVG executes JavaScript",
    pattern: /<script[\s>/]/i
  },
  {
    id: "svg-xlink-href-javascript",
    description: "xlink:href with javascript: \u2014 classic SVG XSS via <a> or <use>",
    pattern: /xlink\s*:\s*href\s*=\s*["']?\s*javascript\s*:/i
  },
  {
    id: "svg-href-javascript",
    description: "href= with javascript: in SVG context (<a>, <animate>, etc.)",
    pattern: /href\s*=\s*["']?\s*javascript\s*:/i
  },
  {
    id: "svg-foreignobject",
    description: "<foreignObject embeds HTML inside SVG \u2014 can execute scripts",
    pattern: /<foreignObject[\s>/]/i
  },
  {
    id: "svg-use-external",
    description: "<use xlink:href or href pointing to external resource (non-fragment URL)",
    // Match <use with href= where the value starts with a non-# character (external URL)
    // [\"'][^#] catches quoted values not starting with #; [^\"'#\s>] catches unquoted
    pattern: /<use[\s\S]{0,60}(?:xlink\s*:\s*)?href\s*=\s*(?:["'][^#]|[^"'#\s>])/i
  },
  {
    id: "svg-animate-href",
    description: '<animate attributeName="href" \u2014 can dynamically change href to javascript:',
    pattern: /<animate[\s\S]{0,80}attributeName\s*=\s*["'][\s]*href["']/i
  },
  {
    id: "svg-animate-xlinkhref",
    description: '<animate attributeName="xlink:href"',
    pattern: /<animate[\s\S]{0,80}attributeName\s*=\s*["'][\s]*xlink\s*:\s*href["']/i
  },
  {
    id: "svg-set-javascript",
    description: '<set to="javascript:..." \u2014 sets an attribute to a javascript: URI',
    pattern: /<set[\s\S]{0,80}to\s*=\s*["']?\s*javascript\s*:/i
  },
  {
    id: "svg-event-handler",
    description: "SVG-specific event handler attributes: onload=, onerror=, onactivate=, etc.",
    pattern: /\bon(?:load|error|activate|begin|end|repeat|focus|blur|click|mouse\w{1,20}|key\w{1,20})\s*=/i
  },
  {
    id: "svg-handler-generic",
    description: "Generic on* handler catch-all for SVG attributes",
    pattern: /\bon\w{1,30}\s*=/i
  },
  {
    id: "svg-filter-feimage",
    description: "<feImage href= \u2014 filter primitive that can load external resources",
    pattern: /<feImage[\s\S]{0,80}(?:xlink\s*:\s*)?href\s*=/i
  },
  {
    id: "svg-image-external",
    description: "<image xlink:href with http/https or javascript protocol",
    pattern: /<image[\s\S]{0,80}(?:xlink\s*:\s*)?href\s*=\s*["']?\s*(?:https?|javascript)\s*:/i
  },
  {
    id: "svg-style-javascript",
    description: "style= attribute containing javascript: (e.g. background:url(javascript:...))",
    pattern: /style\s*=[\s\S]{0,60}javascript\s*:/i
  }
];
var svg_default = SVG_PATTERNS;

// node_modules/is-unsafe/src/contexts/sql.js
var SQL_PATTERNS = [
  {
    id: "sql-block-comment-open",
    description: "SQL block comment open: /* ... */ \u2014 unusual in legitimate user text",
    pattern: /\/\*/
  },
  {
    id: "sql-union-select",
    description: "UNION SELECT \u2014 most common SQL injection aggregation attack",
    pattern: /\bUNION\s{1,20}(?:ALL\s{1,20})?SELECT\b/i
  },
  {
    id: "sql-drop-table",
    description: "DROP TABLE \u2014 destructive DDL injection",
    pattern: /\bDROP\s{1,20}TABLE\b/i
  },
  {
    id: "sql-drop-database",
    description: "DROP DATABASE \u2014 destructive DDL injection",
    pattern: /\bDROP\s{1,20}DATABASE\b/i
  },
  {
    id: "sql-insert-into",
    description: "INSERT INTO \u2014 data injection",
    pattern: /\bINSERT\s{1,20}INTO\b/i
  },
  {
    id: "sql-delete-from",
    description: "DELETE FROM \u2014 data deletion injection",
    pattern: /\bDELETE\s{1,20}FROM\b/i
  },
  {
    id: "sql-update-set",
    description: "UPDATE ... SET \u2014 data modification injection",
    // Allows arbitrary content between UPDATE and SET (table name, alias, etc.)
    pattern: /\bUPDATE\b[\s\S]{1,60}\bSET\b/i
  },
  {
    id: "sql-exec-xp",
    description: "EXEC xp_ \u2014 MSSQL extended stored procedure execution",
    pattern: /\bEXEC(?:UTE)?\s{1,20}xp_/i
  },
  {
    id: "sql-tautology-string",
    description: `Classic string tautology: ' OR '1'='1 or " OR "1"="1"`,
    // Last quote is optional — injection may truncate it: ' OR '1'='1--
    pattern: /'\s{0,10}OR\s{0,10}'[^']{0,20}'\s*=\s*'[^']{0,20}/i
  },
  {
    id: "sql-tautology-numeric",
    description: "Numeric tautology: OR 1=1",
    pattern: /\bOR\s{1,10}1\s*=\s*1\b/i
  },
  {
    id: "sql-always-true-zero",
    description: "Numeric tautology: OR 0=0",
    pattern: /\bOR\s{1,10}0\s*=\s*0\b/i
  },
  {
    id: "sql-sleep-benchmark",
    description: "Time-based blind injection: SLEEP() or BENCHMARK()",
    pattern: /\b(?:SLEEP|BENCHMARK)\s*\(/i
  },
  {
    id: "sql-waitfor-delay",
    description: "MSSQL time-based blind injection: WAITFOR DELAY",
    pattern: /\bWAITFOR\s{1,20}DELAY\b/i
  },
  {
    id: "sql-char-function",
    description: "CHAR() function \u2014 used to obfuscate injected strings",
    pattern: /\bCHAR\s*\(\s*\d{1,3}/i
  },
  {
    id: "sql-information-schema",
    description: "INFORMATION_SCHEMA \u2014 reconnaissance query for table/column enumeration",
    pattern: /\bINFORMATION_SCHEMA\b/i
  }
];
var sql_default = SQL_PATTERNS;

// node_modules/is-unsafe/src/contexts/shell.js
var SHELL_PATTERNS = [
  {
    id: "shell-path-traversal-unix",
    description: "Unix path traversal: ../  \u2014 climbing the directory tree",
    pattern: /\.\.\//
  },
  {
    id: "shell-path-traversal-windows",
    description: "Windows path traversal: ..\\ \u2014 climbing the directory tree",
    pattern: /\.\.\\/
  },
  {
    id: "shell-path-traversal-encoded",
    description: "URL-encoded path traversal: %2e%2e or %2f variants",
    pattern: /%2e%2e|%2f\.\.|\.\.%2f/i
  },
  {
    id: "shell-null-byte",
    description: "Null byte injection: \\x00 or %00 \u2014 truncates strings in C-backed functions",
    pattern: /\x00|%00/
  },
  {
    id: "shell-semicolon",
    description: "Semicolon command separator: cmd1; cmd2",
    pattern: /;/
  },
  {
    id: "shell-pipe",
    description: "Pipe operator: cmd1 | cmd2",
    pattern: /\|/
  },
  {
    id: "shell-and-operator",
    description: "AND operator: cmd1 && cmd2",
    pattern: /&&/
  },
  {
    id: "shell-or-operator",
    description: "OR operator: cmd1 || cmd2",
    pattern: /\|\|/
  },
  {
    id: "shell-backtick",
    description: "Backtick command substitution: `cmd`",
    pattern: /`/
  },
  {
    id: "shell-dollar-paren",
    description: "Dollar-paren command substitution: $(cmd)",
    pattern: /\$\(/
  },
  {
    id: "shell-dollar-brace",
    description: "Dollar-brace variable expansion: ${var} \u2014 can be abused for injection",
    pattern: /\$\{/
  },
  {
    id: "shell-redirect-out",
    description: "Output redirection: cmd > file or cmd >> file",
    pattern: />{1,2}/
  },
  {
    id: "shell-redirect-in",
    description: "Input redirection: cmd < file",
    pattern: /</
  },
  {
    id: "shell-newline-injection",
    description: "Newline injection: \\n or \\r \u2014 can inject new shell commands",
    pattern: /[\n\r]/
  },
  {
    id: "shell-glob-star",
    description: "Glob expansion: * or ? \u2014 can expand to unintended files",
    // Only flag when combined with path separators to reduce false positives
    pattern: /[/\\][*?]/
  },
  {
    id: "shell-absolute-root",
    description: "Absolute root path injection: string starting with / or \\ (Windows UNC)",
    pattern: /^(?:\/|\\\\)/
  },
  {
    id: "shell-windows-drive",
    description: "Windows drive letter path injection: C:\\ or D:/",
    pattern: /^[a-zA-Z]:[/\\]/
  },
  {
    id: "shell-curl-wget",
    description: "curl/wget with URL or flags \u2014 can exfiltrate data or download payloads",
    // Require a URL scheme (http/https/ftp) or a flag (-) to reduce false positives
    // "curl is a tool" won't match; "curl http://..." or "curl -s ..." will
    pattern: /\b(?:curl|wget)\s+(?:https?:\/\/|ftp:\/\/|-)/i
  }
];
var shell_default = SHELL_PATTERNS;

// node_modules/is-unsafe/src/contexts/redos.js
var REDOS_PATTERNS = [
  {
    id: "redos-nested-quantifier-plus",
    description: "Nested + quantifier inside a group with outer quantifier: (a+)+, (.+b)*, etc.",
    // Matches any group containing a + quantifier, with an outer * or + — catches (a+)+, (.+b)*, etc.
    pattern: /\([^)]*\+[^)]*\)[+*]/
  },
  {
    id: "redos-nested-quantifier-star",
    description: "Nested * quantifier: (a*)* or (a*)+ \u2014 catastrophic backtracking",
    pattern: /\([^)]*\*[^)]*\)[*+]/
  },
  {
    id: "redos-nested-groups",
    description: "Doubly nested quantified groups: ((a+)+) \u2014 guaranteed catastrophic",
    pattern: /\(\([^)]{0,40}\)[+*]\)[+*]/
  },
  {
    id: "redos-alternation-overlap",
    description: "Overlapping alternation under quantifier: (a|a)+ \u2014 ambiguous NFA paths",
    // Detect repeated identical alternatives under a quantifier
    pattern: /\(([^|()]{1,20})\|(?:\1)(?:\|[^|()]{1,20}){0,5}\)[+*?]{1,2}/
  },
  {
    id: "redos-star-plus-concat",
    description: "(x*x)+ pattern \u2014 triggers super-linear backtracking",
    pattern: /\([^)]{0,10}\*[^)]{0,10}\)[+*]/
  },
  {
    id: "redos-dot-star-greedy",
    description: "(.*){n,} or (.+){n,} \u2014 repeated greedy dot quantifiers",
    pattern: /\(\.[*+]\)\{?\d/
  },
  {
    id: "redos-large-repetition",
    description: "Very large fixed or range repetition count {1000,} or {1000,n} \u2014 denial of service via backtracking",
    // Matches { followed by 4+ digits (≥1000), then optional ,digits }
    pattern: /\{\d{4,}(?:,\d*)?\}/
  },
  {
    id: "redos-catastrophic-alternation",
    description: "Long alternation with many similar branches \u2014 polynomial backtracking risk",
    // Heuristic: 10+ pipe-separated alternatives in a single group
    pattern: /\([^)]{0,200}(?:\|[^|)]{0,50}){9,}\)/
  }
];
var redos_default = REDOS_PATTERNS;

// node_modules/is-unsafe/src/contexts/nosql.js
var sep = `["'\\s]*:`;
var NOSQL_PATTERNS = [
  // ─── MongoDB $ operator injection ────────────────────────────────────────
  {
    id: "nosql-where-operator",
    description: "$where \u2014 executes arbitrary JavaScript server-side in MongoDB",
    pattern: new RegExp(`\\$where${sep}`, "i")
  },
  {
    id: "nosql-ne-operator",
    description: '$ne \u2014 "not equal" operator used to bypass equality checks',
    pattern: new RegExp(`\\$ne${sep}`, "i")
  },
  {
    id: "nosql-gt-operator",
    description: '$gt \u2014 "greater than" used to bypass password/value checks',
    pattern: new RegExp(`\\$gte?${sep}`, "i")
  },
  {
    id: "nosql-lt-operator",
    description: '$lt / $lte \u2014 "less than" bypass variants',
    pattern: new RegExp(`\\$lte?${sep}`, "i")
  },
  {
    id: "nosql-regex-operator",
    description: "$regex \u2014 can be used to extract data character by character (blind injection)",
    pattern: new RegExp(`\\$regex${sep}`, "i")
  },
  {
    id: "nosql-or-operator",
    description: "$or \u2014 logical OR; used to create always-true conditions",
    pattern: new RegExp(`\\$or${sep}\\s*\\[`, "i")
  },
  {
    id: "nosql-and-operator",
    description: "$and \u2014 logical AND operator injection",
    pattern: new RegExp(`\\$and${sep}\\s*\\[`, "i")
  },
  {
    id: "nosql-nor-operator",
    description: "$nor \u2014 logical NOR operator injection",
    pattern: new RegExp(`\\$nor${sep}\\s*\\[`, "i")
  },
  {
    id: "nosql-exists-operator",
    description: "$exists \u2014 can enumerate fields to determine schema",
    pattern: new RegExp(`\\$exists${sep}`, "i")
  },
  {
    id: "nosql-in-operator",
    description: "$in \u2014 matches any value in a list; can enumerate values",
    pattern: new RegExp(`\\$in${sep}\\s*\\[`, "i")
  },
  {
    id: "nosql-expr-operator",
    description: "$expr \u2014 allows aggregation expressions in queries (MongoDB 3.6+)",
    pattern: new RegExp(`\\$expr${sep}`, "i")
  },
  {
    id: "nosql-function-operator",
    description: "$function \u2014 executes arbitrary JavaScript in MongoDB 4.4+",
    pattern: new RegExp(`\\$function${sep}`, "i")
  },
  {
    id: "nosql-accumulator-operator",
    description: "$accumulator \u2014 custom aggregation with arbitrary JS execution",
    pattern: new RegExp(`\\$accumulator${sep}`, "i")
  },
  // ─── Prototype pollution ─────────────────────────────────────────────────
  {
    id: "nosql-proto-pollution",
    description: "__proto__ \u2014 prototype pollution via object key injection",
    pattern: /__proto__/
  },
  {
    id: "nosql-constructor-prototype",
    description: "constructor.prototype \u2014 alternative prototype pollution vector (dot notation or JSON key)",
    // Matches dot-notation (obj.constructor.prototype) and JSON key adjacency
    // ("constructor": {"prototype": ...})
    pattern: /constructor[\s"':.,{\[]*prototype/i
  },
  {
    id: "nosql-proto-bracket",
    description: '["__proto__"] \u2014 bracket-notation prototype pollution',
    pattern: /\[["']__proto__["']\]/
  }
];
var nosql_default = NOSQL_PATTERNS;

// node_modules/is-unsafe/src/contexts/log.js
var LOG_PATTERNS = [
  // ─── CRLF / newline injection ─────────────────────────────────────────────
  {
    id: "log-crlf-injection",
    description: "CRLF injection: literal \\r or \\n embeds fake log lines",
    pattern: /[\r\n]/
  },
  {
    id: "log-url-encoded-crlf",
    description: "URL-encoded CRLF: %0d, %0a, %0D, %0A \u2014 decoded by some log parsers",
    pattern: /%0[dDaA]/
  },
  {
    id: "log-unicode-newline",
    description: "Unicode newline variants: U+2028 (line separator), U+2029 (paragraph separator)",
    pattern: /[\u2028\u2029]/
  },
  // ─── Log4Shell / JNDI injection (CVE-2021-44228) ─────────────────────────
  {
    id: "log-log4shell-jndi",
    description: "Log4Shell: ${jndi:...} triggers remote code execution in Apache Log4j",
    pattern: /\$\{jndi\s*:/i
  },
  {
    id: "log-log4shell-obfuscated",
    description: "Obfuscated Log4Shell: ${::-j}... lookup-bypass prefix used to evade WAF detection",
    // ${::- is the Log4j lookup-bypass escape sequence; presence alone is suspicious
    pattern: /\$\{::-/
  },
  {
    id: "log-log4j-lookup",
    description: "Log4j lookup syntax: ${env:...}, ${sys:...}, ${ctx:...} \u2014 data exfiltration",
    pattern: /\$\{(?:env|sys|ctx|main|map|sd|web|docker|k8s|spring)\s*:/i
  },
  // ─── Server-Side Template Injection (SSTI) in log messages ───────────────
  {
    id: "log-ssti-double-brace",
    description: "SSTI double-brace: {{expression}} \u2014 Jinja2, Twig, Handlebars, etc.",
    pattern: /\{\{[\s\S]{0,80}\}\}/
  },
  {
    id: "log-ssti-hash-brace",
    description: "SSTI hash-brace: #{expression} \u2014 Thymeleaf, Velocity, Ruby ERB",
    pattern: /#\{[\s\S]{0,80}\}/
  },
  {
    id: "log-ssti-dollar-brace",
    description: "SSTI/EL injection: ${expression with operators or method calls} \u2014 JSP EL, Freemarker, SpEL",
    // Require that the ${...} content looks like an expression, not a plain variable name.
    // Flags if the content contains: . ( * + operators, or known SSTI keywords.
    // This avoids flagging ${PATH}, ${HOME} etc. (plain shell variables).
    pattern: /\$\{[^}]*(?:\.|\(|\*|\+|\bclass\b|\bruntime\b|\bprocess\b|\bexec\b)[^}]{0,80}\}/i
  },
  {
    id: "log-ssti-percent-tag",
    description: "SSTI ERB/ASP tag: <%= expression %> \u2014 Ruby ERB, ASP",
    pattern: /<%=[\s\S]{0,80}%>/
  },
  // ─── Null byte ────────────────────────────────────────────────────────────
  {
    id: "log-null-byte",
    description: "Null byte: \\x00 or %00 \u2014 can truncate log entries in C-backed loggers",
    pattern: /\x00|%00/
  },
  // ─── ANSI escape injection ────────────────────────────────────────────────
  {
    id: "log-ansi-escape",
    description: "ANSI escape sequence: ESC[ \u2014 can manipulate terminal output when logs are tailed",
    pattern: /\x1b\[/
  }
];
var log_default = LOG_PATTERNS;

// node_modules/is-unsafe/src/contexts/sql-strict.js
var SQL_STRICT_EXTRA = [
  {
    id: "sql-line-comment",
    description: "SQL line comment: -- followed by whitespace or end of string",
    pattern: /--(?:\s|$)/
  },
  {
    id: "sql-stacked-query",
    description: "Stacked queries: semicolon immediately followed by a SQL keyword",
    pattern: /;\s{0,10}(?:SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC)\b/i
  },
  {
    id: "sql-hex-encoding",
    description: "Hex-encoded string injection: 0x41414141 style (MySQL)",
    pattern: /\b0x[0-9a-f]{4,}/i
  }
];
var SQL_STRICT_PATTERNS = [...sql_default, ...SQL_STRICT_EXTRA];
var sql_strict_default = SQL_STRICT_PATTERNS;

// node_modules/is-unsafe/src/index.js
html_default.label = "HTML";
xml_default.label = "XML";
svg_default.label = "SVG";
sql_default.label = "SQL";
sql_strict_default.label = "SQL-STRICT";
shell_default.label = "SHELL";
redos_default.label = "REDOS";
nosql_default.label = "NOSQL";
log_default.label = "LOG";
var VALID_CONTEXTS = Object.freeze({
  HTML: html_default,
  XML: xml_default,
  SVG: svg_default,
  SQL: sql_default,
  "SQL-STRICT": sql_strict_default,
  SHELL: shell_default,
  REDOS: redos_default,
  NOSQL: nosql_default,
  LOG: log_default
});
function assertString(value) {
  if (typeof value !== "string") {
    throw new TypeError(
      `is-unsafe: first argument must be a string, got ${typeof value}`
    );
  }
}
function assertContext(context2) {
  if (context2 instanceof RegExp) return;
  if (Array.isArray(context2)) {
    if (context2.length === 0) {
      throw new TypeError("is-unsafe: context must not be an empty array");
    }
    if (Array.isArray(context2[0])) {
      for (const list of context2) {
        if (!Array.isArray(list) || list.length === 0) {
          throw new TypeError(
            "is-unsafe: each context in the array must be a non-empty pattern array (PatternList)"
          );
        }
      }
    }
    return;
  }
  throw new TypeError(
    `is-unsafe: second argument must be a PatternList (e.g. HTML), an array of PatternLists (e.g. [HTML, XML]), or a RegExp. Got: ${typeof context2}`
  );
}
function normalise(context2) {
  if (context2 instanceof RegExp) return { lists: null, regex: context2 };
  if (Array.isArray(context2[0])) return { lists: context2, regex: null };
  return { lists: [context2], regex: null };
}
function matchList(value, list) {
  const label2 = list.label ?? "CUSTOM";
  for (const rule of list) {
    if (rule.pattern.test(value)) {
      return { context: label2, id: rule.id, description: rule.description, pattern: rule.pattern };
    }
  }
  return null;
}
function isUnsafe(value, context2) {
  assertString(value);
  assertContext(context2);
  const { lists, regex } = normalise(context2);
  if (regex) return regex.test(value);
  for (const list of lists) {
    if (matchList(value, list) !== null) return true;
  }
  return false;
}

// node_modules/fast-xml-parser/src/xmlparser/OrderedObjParser.js
function extractRawAttributes(prefixedAttrs, options) {
  if (!prefixedAttrs) return {};
  const attrs = options.attributesGroupName ? prefixedAttrs[options.attributesGroupName] : prefixedAttrs;
  if (!attrs) return {};
  const rawAttrs = {};
  for (const key in attrs) {
    if (key.startsWith(options.attributeNamePrefix)) {
      const rawName = key.substring(options.attributeNamePrefix.length);
      rawAttrs[rawName] = attrs[key];
    } else {
      rawAttrs[key] = attrs[key];
    }
  }
  return rawAttrs;
}
function extractNamespace(rawTagName) {
  if (!rawTagName || typeof rawTagName !== "string") return void 0;
  const colonIndex = rawTagName.indexOf(":");
  if (colonIndex !== -1 && colonIndex > 0) {
    const ns = rawTagName.substring(0, colonIndex);
    if (ns !== "xmlns") {
      return ns;
    }
  }
  return void 0;
}
var OrderedObjParser = class {
  constructor(options, externalEntities) {
    this.options = options;
    this.currentNode = null;
    this.tagsNodeStack = [];
    this.parseXml = parseXml;
    this.parseTextData = parseTextData;
    this.resolveNameSpace = resolveNameSpace;
    this.buildAttributesMap = buildAttributesMap;
    this.isItStopNode = isItStopNode;
    this.replaceEntitiesValue = replaceEntitiesValue;
    this.readStopNodeData = readStopNodeData;
    this.saveTextToParentTag = saveTextToParentTag;
    this.addChild = addChild;
    this.ignoreAttributesFn = getIgnoreAttributesFn(this.options.ignoreAttributes);
    this.entityExpansionCount = 0;
    this.currentExpandedLength = 0;
    this.doctypefound = false;
    let namedEntities = { ...XML };
    if (this.options.entityDecoder) {
      this.entityDecoder = this.options.entityDecoder;
    } else {
      if (typeof this.options.htmlEntities === "object") namedEntities = this.options.htmlEntities;
      else if (this.options.htmlEntities === true) namedEntities = { ...COMMON_HTML, ...CURRENCY };
      this.entityDecoder = new EntityDecoder({
        namedEntities: { ...namedEntities, ...externalEntities },
        numericAllowed: this.options.htmlEntities,
        limit: {
          maxTotalExpansions: this.options.processEntities.maxTotalExpansions,
          maxExpandedLength: this.options.processEntities.maxExpandedLength,
          applyLimitsTo: this.options.processEntities.appliesTo
        },
        // onExternalEntity: (name, value) => isUnsafe(value) ? 'block' : 'allow',
        onInputEntity: (name, value) => (
          //TODO: VALID_CONTEXTS.HTML should be set only if this.options.htmlEntities
          isUnsafe(value, [html_default, xml_default]) ? ENTITY_ACTION.BLOCK : ENTITY_ACTION.ALLOW
        )
        //postCheck: resolved => resolved
      });
    }
    this.matcher = new Matcher();
    this.readonlyMatcher = this.matcher.readOnly();
    this.isCurrentNodeStopNode = false;
    this.stopNodeExpressionsSet = new ExpressionSet();
    const stopNodesOpts = this.options.stopNodes;
    if (stopNodesOpts && stopNodesOpts.length > 0) {
      for (let i2 = 0; i2 < stopNodesOpts.length; i2++) {
        const stopNodeExp = stopNodesOpts[i2];
        if (typeof stopNodeExp === "string") {
          this.stopNodeExpressionsSet.add(new Expression(stopNodeExp));
        } else if (stopNodeExp instanceof Expression) {
          this.stopNodeExpressionsSet.add(stopNodeExp);
        }
      }
      this.stopNodeExpressionsSet.seal();
    }
  }
};
function parseTextData(val, tagName, jPath, dontTrim, hasAttributes, isLeafNode, escapeEntities) {
  const options = this.options;
  if (val !== void 0) {
    if (options.trimValues && !dontTrim) {
      val = val.trim();
    }
    if (val.length > 0) {
      if (!escapeEntities) val = this.replaceEntitiesValue(val, tagName, jPath);
      const jPathOrMatcher = options.jPath ? jPath.toString() : jPath;
      const newval = options.tagValueProcessor(tagName, val, jPathOrMatcher, hasAttributes, isLeafNode);
      if (newval === null || newval === void 0) {
        return val;
      } else if (typeof newval !== typeof val || newval !== val) {
        return newval;
      } else if (options.trimValues) {
        return parseValue(val, options.parseTagValue, options.numberParseOptions);
      } else {
        const trimmedVal = val.trim();
        if (trimmedVal === val) {
          return parseValue(val, options.parseTagValue, options.numberParseOptions);
        } else {
          return val;
        }
      }
    }
  }
}
function resolveNameSpace(tagname) {
  if (this.options.removeNSPrefix) {
    const tags = tagname.split(":");
    const prefix = tagname.charAt(0) === "/" ? "/" : "";
    if (tags[0] === "xmlns") {
      return "";
    }
    if (tags.length === 2) {
      tagname = prefix + tags[1];
    }
  }
  return tagname;
}
var attrsRegx = new RegExp(`([^\\s=]+)\\s*(=\\s*(['"])([\\s\\S]*?)\\3)?`, "gm");
function buildAttributesMap(attrStr, jPath, tagName, force = false) {
  const options = this.options;
  if (force === true || options.ignoreAttributes !== true && typeof attrStr === "string") {
    const matches = getAllMatches(attrStr, attrsRegx);
    const len = matches.length;
    const attrs = {};
    const processedVals = new Array(len);
    let hasRawAttrs = false;
    const rawAttrsForMatcher = {};
    for (let i2 = 0; i2 < len; i2++) {
      const attrName = this.resolveNameSpace(matches[i2][1]);
      const oldVal = matches[i2][4];
      if (attrName.length && oldVal !== void 0) {
        let val = oldVal;
        if (options.trimValues) val = val.trim();
        val = this.replaceEntitiesValue(val, tagName, this.readonlyMatcher);
        processedVals[i2] = val;
        rawAttrsForMatcher[attrName] = val;
        hasRawAttrs = true;
      }
    }
    if (hasRawAttrs && typeof jPath === "object" && jPath.updateCurrent) {
      jPath.updateCurrent(rawAttrsForMatcher);
    }
    const jPathStr = options.jPath ? jPath.toString() : this.readonlyMatcher;
    let hasAttrs = false;
    for (let i2 = 0; i2 < len; i2++) {
      const attrName = this.resolveNameSpace(matches[i2][1]);
      if (this.ignoreAttributesFn(attrName, jPathStr)) continue;
      let aName = options.attributeNamePrefix + attrName;
      if (attrName.length) {
        if (options.transformAttributeName) {
          aName = options.transformAttributeName(aName);
        }
        aName = sanitizeName(aName, options);
        if (matches[i2][4] !== void 0) {
          const oldVal = processedVals[i2];
          const newVal = options.attributeValueProcessor(attrName, oldVal, jPathStr);
          if (newVal === null || newVal === void 0) {
            attrs[aName] = oldVal;
          } else if (typeof newVal !== typeof oldVal || newVal !== oldVal) {
            attrs[aName] = newVal;
          } else {
            attrs[aName] = parseValue(oldVal, options.parseAttributeValue, options.numberParseOptions);
          }
          hasAttrs = true;
        } else if (options.allowBooleanAttributes) {
          attrs[aName] = true;
          hasAttrs = true;
        }
      }
    }
    if (!hasAttrs) return;
    if (options.attributesGroupName && !options.preserveOrder) {
      const attrCollection = {};
      attrCollection[options.attributesGroupName] = attrs;
      return attrCollection;
    }
    return attrs;
  }
}
var parseXml = function(xmlData) {
  xmlData = xmlData.replace(/\r\n?/g, "\n");
  const xmlObj = new XmlNode("!xml");
  let currentNode = xmlObj;
  let textData = "";
  this.matcher.reset();
  this.entityDecoder.reset();
  this.entityExpansionCount = 0;
  this.currentExpandedLength = 0;
  this.doctypefound = false;
  const options = this.options;
  const docTypeReader = new DocTypeReader(options.processEntities);
  const xmlLen = xmlData.length;
  for (let i2 = 0; i2 < xmlLen; i2++) {
    const ch = xmlData[i2];
    if (ch === "<") {
      const c1 = xmlData.charCodeAt(i2 + 1);
      if (c1 === 47) {
        const closeIndex = findClosingIndex(xmlData, ">", i2, "Closing Tag is not closed.");
        let tagName = xmlData.substring(i2 + 2, closeIndex).trim();
        if (options.removeNSPrefix) {
          const colonIndex = tagName.indexOf(":");
          if (colonIndex !== -1) {
            tagName = tagName.substr(colonIndex + 1);
          }
        }
        tagName = transformTagName(options.transformTagName, tagName, "", options).tagName;
        if (currentNode) {
          textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
        }
        const lastTagName = this.matcher.getCurrentTag();
        if (tagName && options.unpairedTagsSet.has(tagName)) {
          throw new Error(`Unpaired tag can not be used as closing tag: </${tagName}>`);
        }
        if (lastTagName && options.unpairedTagsSet.has(lastTagName)) {
          this.matcher.pop();
          this.tagsNodeStack.pop();
        }
        this.matcher.pop();
        this.isCurrentNodeStopNode = false;
        currentNode = this.tagsNodeStack.pop() || xmlObj;
        if (options.captureMetaData && currentNode) {
          currentNode.addEndIndex(closeIndex + 1);
        }
        textData = "";
        i2 = closeIndex;
      } else if (c1 === 63) {
        let tagData = readTagExp(xmlData, i2, false, "?>");
        if (!tagData) throw new Error("Pi Tag is not closed.");
        textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
        const attsMap = this.buildAttributesMap(tagData.tagExp, this.matcher, tagData.tagName, true);
        if (attsMap) {
          const ver = attsMap[this.options.attributeNamePrefix + "version"];
          this.entityDecoder.setXmlVersion(Number(ver) || 1);
          docTypeReader.setXmlVersion(Number(ver) || 1);
        }
        if (options.ignoreDeclaration && tagData.tagName === "?xml" || options.ignorePiTags) {
        } else {
          const childNode = new XmlNode(tagData.tagName);
          childNode.add(options.textNodeName, "");
          if (tagData.tagName !== tagData.tagExp && tagData.attrExpPresent && options.ignoreAttributes !== true) {
            childNode[":@"] = attsMap;
          }
          this.addChild(currentNode, childNode, this.readonlyMatcher, i2);
          if (options.captureMetaData) {
            currentNode.addEndIndex(tagData.closeIndex + 2);
          }
        }
        i2 = tagData.closeIndex + 1;
      } else if (c1 === 33 && xmlData.charCodeAt(i2 + 2) === 45 && xmlData.charCodeAt(i2 + 3) === 45) {
        const endIndex = findClosingIndex(xmlData, "-->", i2 + 4, "Comment is not closed.");
        if (options.commentPropName) {
          const comment = xmlData.substring(i2 + 4, endIndex - 2);
          textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
          currentNode.add(options.commentPropName, [{ [options.textNodeName]: comment }]);
        }
        i2 = endIndex;
      } else if (c1 === 33 && xmlData.charCodeAt(i2 + 2) === 68) {
        if (this.doctypefound) throw new Error("Multiple DOCTYPE declarations found.");
        this.doctypefound = true;
        const result = docTypeReader.readDocType(xmlData, i2);
        this.entityDecoder.addInputEntities(result.entities);
        i2 = result.i;
      } else if (c1 === 33 && xmlData.charCodeAt(i2 + 2) === 91) {
        const closeIndex = findClosingIndex(xmlData, "]]>", i2, "CDATA is not closed.") - 2;
        const tagExp = xmlData.substring(i2 + 9, closeIndex);
        textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
        let val = this.parseTextData(tagExp, currentNode.tagname, this.readonlyMatcher, true, false, true, true);
        if (val == void 0) val = "";
        if (options.cdataPropName) {
          currentNode.add(options.cdataPropName, [{ [options.textNodeName]: tagExp }]);
        } else {
          currentNode.add(options.textNodeName, val);
        }
        i2 = closeIndex + 2;
      } else {
        let result = readTagExp(xmlData, i2, options.removeNSPrefix);
        if (!result) {
          const context2 = xmlData.substring(Math.max(0, i2 - 50), Math.min(xmlLen, i2 + 50));
          throw new Error(`readTagExp returned undefined at position ${i2}. Context: "${context2}"`);
        }
        let tagName = result.tagName;
        const rawTagName = result.rawTagName;
        let tagExp = result.tagExp;
        let attrExpPresent = result.attrExpPresent;
        let closeIndex = result.closeIndex;
        ({ tagName, tagExp } = transformTagName(options.transformTagName, tagName, tagExp, options));
        if (options.strictReservedNames && (tagName === options.commentPropName || tagName === options.cdataPropName || tagName === options.textNodeName || tagName === options.attributesGroupName)) {
          throw new Error(`Invalid tag name: ${tagName}`);
        }
        if (currentNode && textData) {
          if (currentNode.tagname !== "!xml") {
            textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher, false);
          }
        }
        const lastTag = currentNode;
        if (lastTag && options.unpairedTagsSet.has(lastTag.tagname)) {
          currentNode = this.tagsNodeStack.pop();
          this.matcher.pop();
        }
        let isSelfClosing = false;
        if (tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1) {
          isSelfClosing = true;
          if (tagName[tagName.length - 1] === "/") {
            tagName = tagName.substr(0, tagName.length - 1);
            tagExp = tagName;
          } else {
            tagExp = tagExp.substr(0, tagExp.length - 1);
          }
          attrExpPresent = tagName !== tagExp;
        }
        let prefixedAttrs = null;
        let rawAttrs = {};
        let namespace = void 0;
        namespace = extractNamespace(rawTagName);
        if (tagName !== xmlObj.tagname) {
          this.matcher.push(tagName, {}, namespace);
        }
        if (tagName !== tagExp && attrExpPresent) {
          prefixedAttrs = this.buildAttributesMap(tagExp, this.matcher, tagName);
          if (prefixedAttrs) {
            rawAttrs = extractRawAttributes(prefixedAttrs, options);
          }
        }
        if (tagName !== xmlObj.tagname) {
          this.isCurrentNodeStopNode = this.isItStopNode();
        }
        const startIndex = i2;
        if (this.isCurrentNodeStopNode) {
          let tagContent = "";
          if (isSelfClosing) {
            i2 = result.closeIndex;
          } else if (options.unpairedTagsSet.has(tagName)) {
            i2 = result.closeIndex;
          } else {
            const result2 = this.readStopNodeData(xmlData, rawTagName, closeIndex + 1);
            if (!result2) throw new Error(`Unexpected end of ${rawTagName}`);
            i2 = result2.i;
            tagContent = result2.tagContent;
          }
          const childNode = new XmlNode(tagName);
          if (prefixedAttrs) {
            childNode[":@"] = prefixedAttrs;
          }
          childNode.add(options.textNodeName, tagContent);
          this.matcher.pop();
          this.isCurrentNodeStopNode = false;
          this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
          if (options.captureMetaData) {
            currentNode.addEndIndex(i2 + 1);
          }
        } else {
          if (isSelfClosing) {
            ({ tagName, tagExp } = transformTagName(options.transformTagName, tagName, tagExp, options));
            const childNode = new XmlNode(tagName);
            if (prefixedAttrs) {
              childNode[":@"] = prefixedAttrs;
            }
            this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
            if (options.captureMetaData) {
              currentNode.addEndIndex(closeIndex + 1);
            }
            this.matcher.pop();
            this.isCurrentNodeStopNode = false;
          } else if (options.unpairedTagsSet.has(tagName)) {
            const childNode = new XmlNode(tagName);
            if (prefixedAttrs) {
              childNode[":@"] = prefixedAttrs;
            }
            this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
            if (options.captureMetaData) {
              currentNode.addEndIndex(result.closeIndex + 1);
            }
            this.matcher.pop();
            this.isCurrentNodeStopNode = false;
            i2 = result.closeIndex;
            continue;
          } else {
            const childNode = new XmlNode(tagName);
            if (this.tagsNodeStack.length > options.maxNestedTags) {
              throw new Error("Maximum nested tags exceeded");
            }
            this.tagsNodeStack.push(currentNode);
            if (prefixedAttrs) {
              childNode[":@"] = prefixedAttrs;
            }
            this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
            currentNode = childNode;
          }
          textData = "";
          i2 = closeIndex;
        }
      }
    } else {
      textData += xmlData[i2];
    }
  }
  return xmlObj.child;
};
function addChild(currentNode, childNode, matcher, startIndex) {
  if (!this.options.captureMetaData) startIndex = void 0;
  const jPathOrMatcher = this.options.jPath ? matcher.toString() : matcher;
  const result = this.options.updateTag(childNode.tagname, jPathOrMatcher, childNode[":@"]);
  if (result === false) {
  } else if (typeof result === "string") {
    childNode.tagname = result;
    currentNode.addChild(childNode, startIndex);
  } else {
    currentNode.addChild(childNode, startIndex);
  }
}
function replaceEntitiesValue(val, tagName, jPath) {
  const entityConfig = this.options.processEntities;
  if (!entityConfig || !entityConfig.enabled) {
    return val;
  }
  if (entityConfig.allowedTags) {
    const jPathOrMatcher = this.options.jPath ? jPath.toString() : jPath;
    const allowed = Array.isArray(entityConfig.allowedTags) ? entityConfig.allowedTags.includes(tagName) : entityConfig.allowedTags(tagName, jPathOrMatcher);
    if (!allowed) {
      return val;
    }
  }
  if (entityConfig.tagFilter) {
    const jPathOrMatcher = this.options.jPath ? jPath.toString() : jPath;
    if (!entityConfig.tagFilter(tagName, jPathOrMatcher)) {
      return val;
    }
  }
  return this.entityDecoder.decode(val);
}
function saveTextToParentTag(textData, parentNode, matcher, isLeafNode) {
  if (textData) {
    if (isLeafNode === void 0) isLeafNode = parentNode.child.length === 0;
    textData = this.parseTextData(
      textData,
      parentNode.tagname,
      matcher,
      false,
      parentNode[":@"] ? Object.keys(parentNode[":@"]).length !== 0 : false,
      isLeafNode
    );
    if (textData !== void 0 && textData !== "")
      parentNode.add(this.options.textNodeName, textData);
    textData = "";
  }
  return textData;
}
function isItStopNode() {
  if (this.stopNodeExpressionsSet.size === 0) return false;
  return this.matcher.matchesAny(this.stopNodeExpressionsSet);
}
function tagExpWithClosingIndex(xmlData, i2, closingChar = ">") {
  let attrBoundary = 0;
  const len = xmlData.length;
  const closeCode0 = closingChar.charCodeAt(0);
  const closeCode1 = closingChar.length > 1 ? closingChar.charCodeAt(1) : -1;
  let result = "";
  let segmentStart = i2;
  for (let index = i2; index < len; index++) {
    const code = xmlData.charCodeAt(index);
    if (attrBoundary) {
      if (code === attrBoundary) attrBoundary = 0;
    } else if (code === 34 || code === 39) {
      attrBoundary = code;
    } else if (code === closeCode0) {
      if (closeCode1 !== -1) {
        if (xmlData.charCodeAt(index + 1) === closeCode1) {
          result += xmlData.substring(segmentStart, index);
          return { data: result, index };
        }
      } else {
        result += xmlData.substring(segmentStart, index);
        return { data: result, index };
      }
    } else if (code === 9 && !attrBoundary) {
      result += xmlData.substring(segmentStart, index) + " ";
      segmentStart = index + 1;
    }
  }
}
function findClosingIndex(xmlData, str, i2, errMsg) {
  const closingIndex = xmlData.indexOf(str, i2);
  if (closingIndex === -1) {
    throw new Error(errMsg);
  } else {
    return closingIndex + str.length - 1;
  }
}
function findClosingChar(xmlData, char, i2, errMsg) {
  const closingIndex = xmlData.indexOf(char, i2);
  if (closingIndex === -1) throw new Error(errMsg);
  return closingIndex;
}
function readTagExp(xmlData, i2, removeNSPrefix, closingChar = ">") {
  const result = tagExpWithClosingIndex(xmlData, i2 + 1, closingChar);
  if (!result) return;
  let tagExp = result.data;
  const closeIndex = result.index;
  const separatorIndex = tagExp.search(/\s/);
  let tagName = tagExp;
  let attrExpPresent = true;
  if (separatorIndex !== -1) {
    tagName = tagExp.substring(0, separatorIndex);
    tagExp = tagExp.substring(separatorIndex + 1).trimStart();
  }
  const rawTagName = tagName;
  if (removeNSPrefix) {
    const colonIndex = tagName.indexOf(":");
    if (colonIndex !== -1) {
      tagName = tagName.substr(colonIndex + 1);
      attrExpPresent = tagName !== result.data.substr(colonIndex + 1);
    }
  }
  return {
    tagName,
    tagExp,
    closeIndex,
    attrExpPresent,
    rawTagName
  };
}
function readStopNodeData(xmlData, tagName, i2) {
  const startIndex = i2;
  let openTagCount = 1;
  const xmllen = xmlData.length;
  for (; i2 < xmllen; i2++) {
    if (xmlData[i2] === "<") {
      const c1 = xmlData.charCodeAt(i2 + 1);
      if (c1 === 47) {
        const closeIndex = findClosingChar(xmlData, ">", i2, `${tagName} is not closed`);
        let closeTagName = xmlData.substring(i2 + 2, closeIndex).trim();
        if (closeTagName === tagName) {
          openTagCount--;
          if (openTagCount === 0) {
            return {
              tagContent: xmlData.substring(startIndex, i2),
              i: closeIndex
            };
          }
        }
        i2 = closeIndex;
      } else if (c1 === 63) {
        const closeIndex = findClosingIndex(xmlData, "?>", i2 + 1, "StopNode is not closed.");
        i2 = closeIndex;
      } else if (c1 === 33 && xmlData.charCodeAt(i2 + 2) === 45 && xmlData.charCodeAt(i2 + 3) === 45) {
        const closeIndex = findClosingIndex(xmlData, "-->", i2 + 3, "StopNode is not closed.");
        i2 = closeIndex;
      } else if (c1 === 33 && xmlData.charCodeAt(i2 + 2) === 91) {
        const closeIndex = findClosingIndex(xmlData, "]]>", i2, "StopNode is not closed.") - 2;
        i2 = closeIndex;
      } else {
        const tagData = readTagExp(xmlData, i2, false);
        if (tagData) {
          const openTagName = tagData && tagData.tagName;
          if (openTagName === tagName && tagData.tagExp[tagData.tagExp.length - 1] !== "/") {
            openTagCount++;
          }
          i2 = tagData.closeIndex;
        }
      }
    }
  }
}
function parseValue(val, shouldParse, options) {
  if (shouldParse && typeof val === "string") {
    const newval = val.trim();
    if (newval === "true") return true;
    else if (newval === "false") return false;
    else return toNumber(val, options);
  } else {
    if (isExist(val)) {
      return val;
    } else {
      return "";
    }
  }
}
function transformTagName(fn, tagName, tagExp, options) {
  if (fn) {
    const newTagName = fn(tagName);
    if (tagExp === tagName) {
      tagExp = newTagName;
    }
    tagName = newTagName;
  }
  tagName = sanitizeName(tagName, options);
  return { tagName, tagExp };
}
function sanitizeName(name, options) {
  if (criticalProperties.includes(name)) {
    throw new Error(`[SECURITY] Invalid name: "${name}" is a reserved JavaScript keyword that could cause prototype pollution`);
  } else if (DANGEROUS_PROPERTY_NAMES.includes(name)) {
    return options.onDangerousProperty(name);
  }
  return name;
}

// node_modules/fast-xml-parser/src/xmlparser/node2json.js
var METADATA_SYMBOL2 = XmlNode.getMetaDataSymbol();
function stripAttributePrefix(attrs, prefix) {
  if (!attrs || typeof attrs !== "object") return {};
  if (!prefix) return attrs;
  const rawAttrs = {};
  for (const key in attrs) {
    if (key.startsWith(prefix)) {
      const rawName = key.substring(prefix.length);
      rawAttrs[rawName] = attrs[key];
    } else {
      rawAttrs[key] = attrs[key];
    }
  }
  return rawAttrs;
}
function prettify(node, options, matcher, readonlyMatcher) {
  return compress(node, options, matcher, readonlyMatcher);
}
function compress(arr, options, matcher, readonlyMatcher) {
  let text2;
  const compressedObj = {};
  for (let i2 = 0; i2 < arr.length; i2++) {
    const tagObj = arr[i2];
    const property = propName(tagObj);
    if (property !== void 0 && property !== options.textNodeName) {
      const rawAttrs = stripAttributePrefix(
        tagObj[":@"] || {},
        options.attributeNamePrefix
      );
      matcher.push(property, rawAttrs);
    }
    if (property === options.textNodeName) {
      if (text2 === void 0) text2 = tagObj[property];
      else text2 += "" + tagObj[property];
    } else if (property === void 0) {
      continue;
    } else if (tagObj[property]) {
      let val = compress(tagObj[property], options, matcher, readonlyMatcher);
      const isLeaf = isLeafTag(val, options);
      if (Object.keys(val).length === 0 && options.alwaysCreateTextNode) {
        val[options.textNodeName] = "";
      }
      if (tagObj[":@"]) {
        assignAttributes(val, tagObj[":@"], readonlyMatcher, options);
      } else if (Object.keys(val).length === 1 && val[options.textNodeName] !== void 0 && !options.alwaysCreateTextNode) {
        val = val[options.textNodeName];
      } else if (Object.keys(val).length === 0) {
        if (options.alwaysCreateTextNode) val[options.textNodeName] = "";
        else val = "";
      }
      if (tagObj[METADATA_SYMBOL2] !== void 0 && typeof val === "object" && val !== null) {
        val[METADATA_SYMBOL2] = tagObj[METADATA_SYMBOL2];
      }
      if (compressedObj[property] !== void 0 && Object.prototype.hasOwnProperty.call(compressedObj, property)) {
        if (!Array.isArray(compressedObj[property])) {
          compressedObj[property] = [compressedObj[property]];
        }
        compressedObj[property].push(val);
      } else {
        const jPathOrMatcher = options.jPath ? readonlyMatcher.toString() : readonlyMatcher;
        if (options.isArray(property, jPathOrMatcher, isLeaf)) {
          compressedObj[property] = [val];
        } else {
          compressedObj[property] = val;
        }
      }
      if (property !== void 0 && property !== options.textNodeName) {
        matcher.pop();
      }
    }
  }
  if (typeof text2 === "string") {
    if (text2.length > 0) compressedObj[options.textNodeName] = text2;
  } else if (text2 !== void 0) compressedObj[options.textNodeName] = text2;
  return compressedObj;
}
function propName(obj) {
  const keys = Object.keys(obj);
  for (let i2 = 0; i2 < keys.length; i2++) {
    const key = keys[i2];
    if (key !== ":@") return key;
  }
}
function assignAttributes(obj, attrMap, readonlyMatcher, options) {
  if (attrMap) {
    const keys = Object.keys(attrMap);
    const len = keys.length;
    for (let i2 = 0; i2 < len; i2++) {
      const atrrName = keys[i2];
      const rawAttrName = atrrName.startsWith(options.attributeNamePrefix) ? atrrName.substring(options.attributeNamePrefix.length) : atrrName;
      const jPathOrMatcher = options.jPath ? readonlyMatcher.toString() + "." + rawAttrName : readonlyMatcher;
      if (options.isArray(atrrName, jPathOrMatcher, true, true)) {
        obj[atrrName] = [attrMap[atrrName]];
      } else {
        obj[atrrName] = attrMap[atrrName];
      }
    }
  }
}
function isLeafTag(obj, options) {
  const { textNodeName } = options;
  const propCount = Object.keys(obj).length;
  if (propCount === 0) {
    return true;
  }
  if (propCount === 1 && (obj[textNodeName] || typeof obj[textNodeName] === "boolean" || obj[textNodeName] === 0)) {
    return true;
  }
  return false;
}

// node_modules/fast-xml-parser/src/xmlparser/XMLParser.js
var XMLParser = class {
  constructor(options) {
    this.externalEntities = {};
    this.options = buildOptions(options);
  }
  /**
   * Parse XML dats to JS object 
   * @param {string|Uint8Array} xmlData 
   * @param {boolean|Object} validationOption 
   */
  parse(xmlData, validationOption) {
    if (typeof xmlData !== "string" && xmlData.toString) {
      xmlData = xmlData.toString();
    } else if (typeof xmlData !== "string") {
      throw new Error("XML data is accepted in String or Bytes[] form.");
    }
    if (validationOption) {
      if (validationOption === true) validationOption = {};
      const result = validate(xmlData, validationOption);
      if (result !== true) {
        throw Error(`${result.err.msg}:${result.err.line}:${result.err.col}`);
      }
    }
    const orderedObjParser = new OrderedObjParser(this.options, this.externalEntities);
    const orderedResult = orderedObjParser.parseXml(xmlData);
    if (this.options.preserveOrder || orderedResult === void 0) return orderedResult;
    else return prettify(orderedResult, this.options, orderedObjParser.matcher, orderedObjParser.readonlyMatcher);
  }
  /**
   * Add Entity which is not by default supported by this library
   * @param {string} key 
   * @param {string} value 
   */
  addEntity(key, value) {
    if (value.indexOf("&") !== -1) {
      throw new Error("Entity value can't have '&'");
    } else if (key.indexOf("&") !== -1 || key.indexOf(";") !== -1) {
      throw new Error("An entity must be set without '&' and ';'. Eg. use '#xD' for '&#xD;'");
    } else if (value === "&") {
      throw new Error("An entity with value '&' is not permitted");
    } else {
      this.externalEntities[key] = value;
    }
  }
  /**
   * Returns a Symbol that can be used to access the metadata
   * property on a node.
   * 
   * If Symbol is not available in the environment, an ordinary property is used
   * and the name of the property is here returned.
   * 
   * The XMLMetaData property is only present when `captureMetaData`
   * is true in the options.
   */
  static getMetaDataSymbol() {
    return XmlNode.getMetaDataSymbol();
  }
};

// node_modules/fast-xml-parser/src/fxp.js
var XMLValidator = {
  validate
};

// node_modules/fflate/esm/index.mjs
import { createRequire } from "module";
var require2 = createRequire("/");
var _a;
var Worker;
var isMarkedAsUntransferable;
try {
  _a = require2("worker_threads"), Worker = _a.Worker, isMarkedAsUntransferable = _a.isMarkedAsUntransferable;
} catch (e) {
}
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]);
var fdeb = new u8([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]);
var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
var freb = function(eb, start2) {
  var b = new u16(31);
  for (var i2 = 0; i2 < 31; ++i2) {
    b[i2] = start2 += 1 << eb[i2 - 1];
  }
  var r = new i32(b[30]);
  for (var i2 = 1; i2 < 30; ++i2) {
    for (var j = b[i2]; j < b[i2 + 1]; ++j) {
      r[j] = j - b[i2] << 5 | i2;
    }
  }
  return { b, r };
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (i = 0; i < 32768; ++i) {
  x = (i & 43690) >> 1 | (i & 21845) << 1;
  x = (x & 52428) >> 2 | (x & 13107) << 2;
  x = (x & 61680) >> 4 | (x & 3855) << 4;
  rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var x;
var i;
var hMap = (function(cd, mb, r) {
  var s = cd.length;
  var i2 = 0;
  var l = new u16(mb);
  for (; i2 < s; ++i2) {
    if (cd[i2])
      ++l[cd[i2] - 1];
  }
  var le = new u16(mb);
  for (i2 = 1; i2 < mb; ++i2) {
    le[i2] = le[i2 - 1] + l[i2 - 1] << 1;
  }
  var co;
  if (r) {
    co = new u16(1 << mb);
    var rvb = 15 - mb;
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        var sv = i2 << 4 | cd[i2];
        var r_1 = mb - cd[i2];
        var v = le[cd[i2] - 1]++ << r_1;
        for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
          co[rev[v] >> rvb] = sv;
        }
      }
    }
  } else {
    co = new u16(s);
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        co[i2] = rev[le[cd[i2] - 1]++] >> 15 - cd[i2];
      }
    }
  }
  return co;
});
var flt = new u8(288);
for (i = 0; i < 144; ++i)
  flt[i] = 8;
var i;
for (i = 144; i < 256; ++i)
  flt[i] = 9;
var i;
for (i = 256; i < 280; ++i)
  flt[i] = 7;
var i;
for (i = 280; i < 288; ++i)
  flt[i] = 8;
var i;
var fdt = new u8(32);
for (i = 0; i < 32; ++i)
  fdt[i] = 5;
var i;
var flrm = /* @__PURE__ */ hMap(flt, 9, 1);
var fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
var max = function(a) {
  var m = a[0];
  for (var i2 = 1; i2 < a.length; ++i2) {
    if (a[i2] > m)
      m = a[i2];
  }
  return m;
};
var bits = function(d, p, m) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
  return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
  if (s == null || s < 0)
    s = 0;
  if (e == null || e > v.length)
    e = v.length;
  return new u8(v.subarray(s, e));
};
var ec = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
];
var err = function(ind, msg, nt) {
  var e = new Error(msg || ec[ind]);
  e.code = ind;
  if (Error.captureStackTrace)
    Error.captureStackTrace(e, err);
  if (!nt)
    throw e;
  return e;
};
var inflt = function(dat, st, buf, dict) {
  var sl = dat.length, dl = dict ? dict.length : 0;
  if (!sl || st.f && !st.l)
    return buf || new u8(0);
  var noBuf = !buf;
  var resize = noBuf || st.i != 2;
  var noSt = st.i;
  if (noBuf)
    buf = new u8(sl * 3);
  var cbuf = function(l2) {
    var bl = buf.length;
    if (l2 > bl) {
      var nbuf = new u8(Math.max(bl * 2, l2));
      nbuf.set(buf);
      buf = nbuf;
    }
  };
  var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
  var tbts = sl * 8;
  do {
    if (!lm) {
      final = bits(dat, pos, 1);
      var type = bits(dat, pos + 1, 3);
      pos += 3;
      if (!type) {
        var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
        if (t > sl) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + l);
        buf.set(dat.subarray(s, t), bt);
        st.b = bt += l, st.p = pos = t * 8, st.f = final;
        continue;
      } else if (type == 1)
        lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
      else if (type == 2) {
        var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
        var tl = hLit + bits(dat, pos + 5, 31) + 1;
        pos += 14;
        var ldt = new u8(tl);
        var clt = new u8(19);
        for (var i2 = 0; i2 < hcLen; ++i2) {
          clt[clim[i2]] = bits(dat, pos + i2 * 3, 7);
        }
        pos += hcLen * 3;
        var clb = max(clt), clbmsk = (1 << clb) - 1;
        var clm = hMap(clt, clb, 1);
        for (var i2 = 0; i2 < tl; ) {
          var r = clm[bits(dat, pos, clbmsk)];
          pos += r & 15;
          var s = r >> 4;
          if (s < 16) {
            ldt[i2++] = s;
          } else {
            var c = 0, n = 0;
            if (s == 16)
              n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i2 - 1];
            else if (s == 17)
              n = 3 + bits(dat, pos, 7), pos += 3;
            else if (s == 18)
              n = 11 + bits(dat, pos, 127), pos += 7;
            while (n--)
              ldt[i2++] = c;
          }
        }
        var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
        lbt = max(lt);
        dbt = max(dt);
        lm = hMap(lt, lbt, 1);
        dm = hMap(dt, dbt, 1);
      } else
        err(1);
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
    }
    if (resize)
      cbuf(bt + 131072);
    var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
    var lpos = pos;
    for (; ; lpos = pos) {
      var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
      pos += c & 15;
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
      if (!c)
        err(2);
      if (sym < 256)
        buf[bt++] = sym;
      else if (sym == 256) {
        lpos = pos, lm = null;
        break;
      } else {
        var add3 = sym - 254;
        if (sym > 264) {
          var i2 = sym - 257, b = fleb[i2];
          add3 = bits(dat, pos, (1 << b) - 1) + fl[i2];
          pos += b;
        }
        var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
        if (!d)
          err(3);
        pos += d & 15;
        var dt = fd[dsym];
        if (dsym > 3) {
          var b = fdeb[dsym];
          dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
        }
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + 131072);
        var end = bt + add3;
        if (bt < dt) {
          var shift = dl - dt, dend = Math.min(dt, end);
          if (shift + bt < 0)
            err(3);
          for (; bt < dend; ++bt)
            buf[bt] = dict[shift + bt];
        }
        for (; bt < end; ++bt)
          buf[bt] = buf[bt - dt];
      }
    }
    st.l = lm, st.p = lpos, st.b = bt, st.f = final;
    if (lm)
      final = 1, st.m = lbt, st.d = dm, st.n = dbt;
  } while (!final);
  return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var et = /* @__PURE__ */ new u8(0);
var b2 = function(d, b) {
  return d[b] | d[b + 1] << 8;
};
var b4 = function(d, b) {
  return (d[b] | d[b + 1] << 8 | d[b + 2] << 16 | d[b + 3] << 24) >>> 0;
};
var b8 = function(d, b) {
  return b4(d, b) + b4(d, b + 4) * 4294967296;
};
function inflateSync(data, opts) {
  return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
var tds = 0;
try {
  td.decode(et, { stream: true });
  tds = 1;
} catch (e) {
}
var dutf8 = function(d) {
  for (var r = "", i2 = 0; ; ) {
    var c = d[i2++];
    var eb = (c > 127) + (c > 223) + (c > 239);
    if (i2 + eb > d.length)
      return { s: r, r: slc(d, i2 - 1) };
    if (!eb)
      r += String.fromCharCode(c);
    else if (eb == 3) {
      c = ((c & 15) << 18 | (d[i2++] & 63) << 12 | (d[i2++] & 63) << 6 | d[i2++] & 63) - 65536, r += String.fromCharCode(55296 | c >> 10, 56320 | c & 1023);
    } else if (eb & 1)
      r += String.fromCharCode((c & 31) << 6 | d[i2++] & 63);
    else
      r += String.fromCharCode((c & 15) << 12 | (d[i2++] & 63) << 6 | d[i2++] & 63);
  }
};
function strFromU8(dat, latin1) {
  if (latin1) {
    var r = "";
    for (var i2 = 0; i2 < dat.length; i2 += 16384)
      r += String.fromCharCode.apply(null, dat.subarray(i2, i2 + 16384));
    return r;
  } else if (td) {
    return td.decode(dat);
  } else {
    var _a2 = dutf8(dat), s = _a2.s, r = _a2.r;
    if (r.length)
      err(8);
    return s;
  }
}
var slzh = function(d, b) {
  return b + 30 + b2(d, b + 26) + b2(d, b + 28);
};
var zh = function(d, b, z) {
  var fnl = b2(d, b + 28), efl = b2(d, b + 30), fn = strFromU8(d.subarray(b + 46, b + 46 + fnl), !(b2(d, b + 8) & 2048)), es = b + 46 + fnl;
  var _a2 = z64hs(d, es, efl, z, b4(d, b + 20), b4(d, b + 24), b4(d, b + 42)), sc = _a2[0], su = _a2[1], off = _a2[2];
  return [b2(d, b + 10), sc, su, fn, es + efl + b2(d, b + 32), off];
};
var z64hs = function(d, b, l, z, sc, su, off) {
  var nsc = sc == 4294967295, nsu = su == 4294967295, noff = off == 4294967295, e = b + l;
  var nf = nsc + nsu + noff;
  if (z && nf) {
    for (; b + 4 < e; b += 4 + b2(d, b + 2)) {
      if (b2(d, b) == 1) {
        return [
          nsc ? b8(d, b + 4 + 8 * nsu) : sc,
          nsu ? b8(d, b + 4) : su,
          noff ? b8(d, b + 4 + 8 * (nsu + nsc)) : off,
          1
        ];
      }
    }
    if (z < 2)
      err(13);
  }
  return [sc, su, off, 0];
};
function unzipSync(data, opts) {
  var files2 = {};
  var e = data.length - 22;
  for (; b4(data, e) != 101010256; --e) {
    if (!e || data.length - e > 65558)
      err(13);
  }
  ;
  var c = b2(data, e + 8);
  if (!c)
    return {};
  var o = b4(data, e + 16);
  var z = b4(data, e - 20) == 117853008;
  if (z) {
    var ze = b4(data, e - 12);
    z = b4(data, ze) == 101075792;
    if (z) {
      c = b4(data, ze + 32);
      o = b4(data, ze + 48);
    }
  }
  var fltr = opts && opts.filter;
  for (var i2 = 0; i2 < c; ++i2) {
    var _a2 = zh(data, o, z), c_2 = _a2[0], sc = _a2[1], su = _a2[2], fn = _a2[3], no = _a2[4], off = _a2[5], b = slzh(data, off);
    o = no;
    if (!fltr || fltr({
      name: fn,
      size: sc,
      originalSize: su,
      compression: c_2
    })) {
      if (!c_2)
        files2[fn] = slc(data, b, b + sc);
      else if (c_2 == 8)
        files2[fn] = inflateSync(data.subarray(b, b + sc), { out: new u8(su) });
      else
        err(14, "unknown compression type " + c_2);
    }
  }
  return files2;
}

// runtime/readers/archive.mjs
init_errors();
var crcTable = Uint32Array.from({ length: 256 }, (_, i2) => {
  let n = i2;
  for (let j = 0; j < 8; j++) n = n & 1 ? 3988292384 ^ n >>> 1 : n >>> 1;
  return n >>> 0;
});
function crc32(bytes3) {
  let n = 4294967295;
  for (const byte of bytes3) n = crcTable[(n ^ byte) & 255] ^ n >>> 8;
  return (n ^ 4294967295) >>> 0;
}
function openArchive(bytes3, { maxBytes = 128 * 1024 * 1024, maxFiles = 2e4 } = {}) {
  requireThat(bytes3 instanceof Uint8Array && bytes3.length <= maxBytes, "archive", "Archive exceeds the input limit.");
  const view = new DataView(bytes3.buffer, bytes3.byteOffset, bytes3.byteLength), files2 = /* @__PURE__ */ new Map();
  let end = -1;
  for (let at2 = bytes3.length - 22; at2 >= Math.max(0, bytes3.length - 65557); at2--) if (view.getUint32(at2, true) === 101010256) {
    end = at2;
    break;
  }
  requireThat(end >= 0, "archive", "Invalid ZIP directory.");
  const count = view.getUint16(end + 10, true), start2 = view.getUint32(end + 16, true), directorySize = view.getUint32(end + 12, true);
  requireThat(count > 0 && count <= maxFiles && count !== 65535 && start2 + directorySize <= end && view.getUint16(end + 4, true) === 0 && view.getUint16(end + 6, true) === 0, "archive", "Unsupported ZIP64, split or oversized archive.");
  let at = start2, total = 0;
  for (let i2 = 0; i2 < count; i2++) {
    requireThat(at + 46 <= end && view.getUint32(at, true) === 33639248, "archive", "Corrupt ZIP entry.");
    const flags2 = view.getUint16(at + 8, true), size = view.getUint32(at + 24, true), nameLength = view.getUint16(at + 28, true), extra = view.getUint16(at + 30, true), comment = view.getUint16(at + 32, true), crc = view.getUint32(at + 16, true);
    requireThat(!(flags2 & 1) && at + 46 + nameLength + extra + comment <= end, "archive", "Encrypted or corrupt ZIP entry.");
    const name = new TextDecoder("utf-8", { fatal: true }).decode(bytes3.subarray(at + 46, at + 46 + nameLength));
    const canonical = name.endsWith("/") ? name.slice(0, -1) : name;
    relativePath(canonical);
    requireThat(!files2.has(name), "archive", "Duplicate ZIP filename.", { name });
    total += size;
    requireThat(total <= maxBytes, "archive", "Archive expands beyond the reading limit.");
    files2.set(name, { size, crc });
    at += 46 + nameLength + extra + comment;
  }
  const extracted = unzipSync(bytes3, { filter: (file) => !file.name.endsWith("/") });
  for (const [name, payload3] of Object.entries(extracted)) {
    const entry = files2.get(name);
    requireThat(entry && entry.size === payload3.length && entry.crc === crc32(payload3), "archive", "ZIP size or checksum mismatch.", { name });
  }
  requireThat(Object.keys(extracted).length === [...files2.keys()].filter((n) => !n.endsWith("/")).length, "archive", "Archive is incomplete.");
  return extracted;
}

// runtime/readers/index.mjs
init_errors();
var textTypes = /* @__PURE__ */ new Set(["md", "markdown", "txt", "csv", "tsv", "json", "yaml", "yml", "xml", "log"]);
var decoder = () => new TextDecoder("utf-8", { fatal: true });
var stamp = (value) => value && Number.isFinite(Date.parse(value)) ? new Date(value).toISOString() : null;
var local = (tag) => tag.split(":").pop();
function parseXml2(bytes3) {
  const text2 = decoder().decode(bytes3);
  requireThat(!/<!\s*(DOCTYPE|ENTITY)/i.test(text2), "xml", "DTD and entity declarations are not accepted.");
  requireThat(XMLValidator.validate(text2) === true, "xml", "Malformed source XML.");
  const parser = new XMLParser({ preserveOrder: true, ignoreAttributes: false, removeNSPrefix: false, parseTagValue: false, parseAttributeValue: false, trimValues: false });
  function nodes(values, inherited = {}) {
    return values.map((value) => {
      const tag = Object.keys(value).find((k) => k !== ":@"), raw = Object.fromEntries(Object.entries(value[":@"] ?? {}).map(([k, v]) => [k.replace(/^@_/, ""), v])), namespaces = { ...inherited };
      for (const [key, uri] of Object.entries(raw)) if (key.startsWith("xmlns:")) namespaces[key.slice(6)] = uri;
      const attrs = {};
      for (const [key, v] of Object.entries(raw)) {
        if (key === "xmlns" || key.startsWith("xmlns:")) continue;
        const prefix = key.includes(":") ? key.split(":")[0] : null;
        const relationship = prefix && (prefix === "r" || /\/relationships$/.test(namespaces[prefix] ?? ""));
        attrs[relationship ? "r:" + local(key) : local(key)] = v;
      }
      return { tag: local(tag), attrs, children: Array.isArray(value[tag]) ? nodes(value[tag], namespaces) : [], text: tag === "#text" ? String(value[tag]) : "" };
    });
  }
  return { tag: "root", attrs: {}, children: nodes(parser.parse(text2)), text: "" };
}
function descendants(node, tag) {
  const out = [];
  if (node.tag === tag) out.push(node);
  for (const child2 of node.children) out.push(...descendants(child2, tag));
  return out;
}
function words2(node) {
  if (node.tag === "#text") return node.text;
  if (node.tag === "tab") return "	";
  if (["br", "cr"].includes(node.tag)) return "\n";
  return node.children.map(words2).join("");
}
var child = (node, tag) => node.children.find((n) => n.tag === tag);
var plain = (node) => descendants(node, "t").map(words2).join("");
function table(rows) {
  if (!rows.length) return "";
  const width = Math.max(...rows.map((r) => r.length)), escape = (v) => String(v ?? "").replace(/\\/g, "\\\\").replace(/\|/g, "\\|").replace(/\r?\n/g, "<br>");
  const lines = rows.map((row) => "| " + Array.from({ length: width }, (_, i2) => escape(row[i2])).join(" | ") + " |");
  lines.splice(1, 0, "| " + Array(width).fill("---").join(" | ") + " |");
  return lines.join("\n");
}
function resolvePart(part, target) {
  requireThat(!/^(?:[a-z][a-z0-9+.-]*:|\/)/i.test(target) && !/[\\\x00]/.test(target), "xml", "Invalid package relationship.");
  const out = part.split("/").slice(0, -1);
  for (const p of target.split("/")) {
    if (p === "..") {
      requireThat(out.length, "xml", "Relationship leaves the document.");
      out.pop();
    } else if (p && p !== ".") out.push(p);
  }
  return out.join("/");
}
function rels(files2, part) {
  const pieces = part.split("/"), name = pieces.pop(), rel = [...pieces, "_rels", name + ".rels"].join("/");
  if (!files2[rel]) return /* @__PURE__ */ new Map();
  return new Map(descendants(parseXml2(files2[rel]), "Relationship").map((r) => [r.attrs.Id, { ...r.attrs, path: r.attrs.TargetMode === "External" ? null : resolvePart(part, r.attrs.Target) }]));
}
function metadata(files2, original) {
  const out = { created_at: original?.created_at ?? null, created_at_basis: original?.created_at_basis ?? "unknown", modified_at: original?.modified_at ?? null };
  if (files2["docProps/core.xml"]) {
    const doc = parseXml2(files2["docProps/core.xml"]), created = stamp(words2(descendants(doc, "created")[0] ?? { children: [] })), modified = stamp(words2(descendants(doc, "modified")[0] ?? { children: [] }));
    if (created) {
      out.created_at = created;
      out.created_at_basis = "document_metadata";
    }
    if (modified) out.modified_at = modified;
  }
  return out;
}
function office(files2, ext, original) {
  const gaps = [], parts = [];
  for (const name of Object.keys(files2)) {
    if (/\/(media|embeddings)\//.test(name)) gaps.push({ code: "visual_content", part: name, message: "Read this embedded object and supply its complete relevant content." });
    if (/vbaProject|activeX/i.test(name)) gaps.push({ code: "active_content", part: name, message: "Active content is preserved in the original and is never executed." });
  }
  if (ext === "docx") {
    requireThat(files2["word/document.xml"], "format", "DOCX has no document body.");
    const relationships = rels(files2, "word/document.xml");
    const inline = (node) => {
      if (node.tag === "footnoteReference") return "[^footnote-" + node.attrs.id + "]";
      if (node.tag === "endnoteReference") return "[^endnote-" + node.attrs.id + "]";
      if (node.tag === "delText") return "[Deleted: " + words2(node) + "]";
      if (node.tag === "hyperlink") {
        const content = node.children.map(inline).join(""), ref = relationships.get(node.attrs["r:id"] ?? node.attrs.id);
        return ref?.TargetMode === "External" ? "[" + content + "](" + ref.Target + ")" : content;
      }
      if (node.tag === "#text" || ["tab", "br", "cr"].includes(node.tag)) return words2(node);
      return node.children.map(inline).join("");
    };
    const render = (node) => {
      if (node.tag === "p") return inline(node) + "\n\n";
      if (node.tag === "tbl") return table(node.children.filter((c) => c.tag === "tr").map((row) => row.children.filter((c) => c.tag === "tc").map((cell) => cell.children.map(render).join("").trim()))) + "\n\n";
      return node.children.map(render).join("");
    };
    const document2 = parseXml2(files2["word/document.xml"]);
    parts.push(render(document2).trim());
    for (const name of Object.keys(files2).filter((n) => /^word\/(footnotes|endnotes|comments|header\d*|footer\d*)\.xml$/.test(n)).sort()) {
      const extra = parseXml2(files2[name]), kind = /word\/(footnotes|endnotes)\.xml$/.exec(name)?.[1]?.slice(0, -1);
      if (kind) {
        for (const note of descendants(extra, kind)) if (Number(note.attrs.id) >= 0) parts.push("[^" + kind + "-" + note.attrs.id + "]: " + render(note).trim().replace(/\n/g, "\n    "));
      } else parts.push("## " + name + "\n\n" + render(extra).trim());
    }
    for (const node of [...descendants(document2, "oMath"), ...descendants(document2, "altChunk")]) gaps.push({ code: "special_content", part: node.tag, message: "Read the mathematical or embedded document content." });
    if (descendants(document2, "numPr").length) gaps.push({ code: "list_numbering", part: "word/document.xml", message: "Verify generated list numbers and their hierarchy against the original." });
  } else if (["pptx", "potx"].includes(ext)) {
    requireThat(files2["ppt/presentation.xml"], "format", "PPTX has no presentation.");
    const pres = parseXml2(files2["ppt/presentation.xml"]), relations = rels(files2, "ppt/presentation.xml");
    const slides = child(child(pres, "presentation") ?? pres, "sldIdLst")?.children.filter((n) => n.tag === "sldId") ?? [];
    requireThat(slides.length, "format", "Presentation has no ordered slides.");
    for (const [index, slide] of slides.entries()) {
      const target = relations.get(slide.attrs["r:id"] ?? slide.attrs.id)?.path;
      requireThat(target && files2[target], "format", "Presentation slide relationship is missing.");
      const doc = parseXml2(files2[target]);
      const paragraphs = descendants(doc, "p").map((n) => words2(n)).filter(Boolean);
      parts.push("## Slide " + (index + 1) + "\n\n" + paragraphs.join("\n\n"));
      for (const ref of rels(files2, target).values()) if (ref.path && /notesSlide$/.test(ref.Type ?? "")) {
        requireThat(files2[ref.path], "format", "Speaker notes are missing.");
        parts.push("### Speaker notes\n\n" + descendants(parseXml2(files2[ref.path]), "p").map(words2).join("\n\n"));
      }
      if (descendants(doc, "chart").length) gaps.push({ code: "visual_content", part: target, message: "Read the chart and its underlying data." });
      if (descendants(doc, "cxnSp").length || descendants(doc, "grpSp").length || descendants(doc, "spPr").some((s) => child(s, "solidFill") || child(s, "gradFill")))
        gaps.push({ code: "visual_structure", part: target, message: "Read spatial grouping, connectors and color meaning on this slide; paragraph text alone does not preserve this structure." });
    }
  } else {
    requireThat(files2["xl/workbook.xml"], "format", "XLSX has no workbook.");
    const book = parseXml2(files2["xl/workbook.xml"]), relations = rels(files2, "xl/workbook.xml");
    if (files2["xl/styles.xml"]) {
      const styles = parseXml2(files2["xl/styles.xml"]);
      for (const format of descendants(styles, "numFmt")) parts.push("Number format " + format.attrs.numFmtId + ": " + format.attrs.formatCode);
    }
    const date1904 = descendants(book, "workbookPr")[0]?.attrs.date1904;
    if (date1904) parts.push("Workbook date system: " + (["1", "true"].includes(date1904) ? "1904" : "1900"));
    const strings2 = files2["xl/sharedStrings.xml"] ? descendants(parseXml2(files2["xl/sharedStrings.xml"]), "si").map(plain) : [];
    for (const sheet of descendants(book, "sheet")) {
      const target = relations.get(sheet.attrs["r:id"] ?? sheet.attrs.id)?.path;
      requireThat(target && files2[target], "format", "Worksheet relationship is missing.");
      const doc = parseXml2(files2[target]), rows = [["Cell", "Content", "Formula"]];
      for (const cell of descendants(doc, "c")) {
        const value = words2(child(cell, "v") ?? { children: [] }), formula = words2(child(cell, "f") ?? { children: [] });
        let content;
        if (cell.attrs.t === "s") {
          content = strings2[Number(value)];
          requireThat(content !== void 0, "format", "Shared string reference is missing.");
        } else if (cell.attrs.t === "inlineStr") content = plain(cell);
        else if (cell.attrs.t === "b") content = value === "1" ? "TRUE" : "FALSE";
        else content = value;
        rows.push([cell.attrs.r ?? "", content, formula]);
        if (child(cell, "f")?.attrs.t === "shared" && !gaps.some((g) => g.code === "shared_formula" && g.part === target)) gaps.push({ code: "shared_formula", part: target, message: "Verify the shared formulas in this sheet, starting with " + cell.attrs.r + "." });
        if (cell.attrs.s !== void 0 && cell.attrs.t !== "s" && cell.attrs.t !== "inlineStr" && !gaps.some((g) => g.code === "formatted_cell" && g.part === target)) gaps.push({ code: "formatted_cell", part: target, message: "Verify displayed numeric/date values in this sheet; raw cell values are preserved." });
      }
      parts.push("## " + sheet.attrs.name + (sheet.attrs.state ? " (" + sheet.attrs.state + ")" : "") + "\n\n" + table(rows));
      for (const merged of descendants(doc, "mergeCell")) parts.push("Merged cells: " + merged.attrs.ref);
      if (descendants(doc, "drawing").length) gaps.push({ code: "visual_content", part: target, message: "Read the sheet drawing or chart." });
    }
    for (const name of Object.keys(files2).filter((n) => /^xl\/(comments|threadedComments\/).+\.xml$/.test(n))) parts.push("## " + name + "\n\n" + plain(parseXml2(files2[name])));
  }
  return { text: parts.join("\n\n"), metadata: metadata(files2, original), gaps };
}
async function extractSource({ bytes: bytes3, name, metadata: original = {}, readPDF: readPDF2 = null }) {
  const metadata2 = { created_at: original.created_at ?? null, created_at_basis: original.created_at_basis ?? "unknown", modified_at: original.modified_at ?? null };
  try {
    requireThat(bytes3 instanceof Uint8Array && bytes3.length <= 128 * 1024 * 1024, "size", "Select a source within the 128 MiB reading limit.");
    const ext = String(name).split(".").pop().toLowerCase();
    let result;
    if (textTypes.has(ext)) result = { text: decoder().decode(bytes3), metadata: metadata2, gaps: [] };
    else if (["docx", "xlsx", "pptx", "potx"].includes(ext)) result = office(openArchive(bytes3), ext, metadata2);
    else if (["png", "jpg", "jpeg", "gif", "webp", "avif"].includes(ext)) return { text: "", complete: false, metadata: metadata2, gaps: [{ code: "visual_content", part: name, message: "Read the full image through host vision: complete transcription, visual description, separate interpretation and explicit unreadable regions. Never infer completion from a filename." }] };
    else if (ext === "pdf" && readPDF2) result = await readPDF2(bytes3, metadata2);
    else return { text: "", complete: false, metadata: metadata2, gaps: [{ code: ext === "pdf" ? "parser_missing" : "unsupported_format", message: "A complete host reading is required for this format." }] };
    if (!result.text.trim()) result.gaps.push({ code: "empty_content", message: "No readable source content." });
    if (result.text.includes("\uFFFD")) result.gaps.push({ code: "replacement_characters", message: "The extraction contains undecodable characters." });
    return { ...result, complete: result.gaps.length === 0 };
  } catch (error) {
    return { text: "", complete: false, metadata: metadata2, gaps: [{ code: error.code ?? "reading_failed", message: error.message }] };
  }
}

// runtime/readers/node.mjs
init_errors();
import { fileURLToPath } from "node:url";
async function readPDF(bytes3, metadata2 = {}) {
  const pdfjs = await import("./pdf/pdf.mjs");
  const assets = new URL(true ? "./pdf/" : "../../node_modules/pdfjs-dist/", import.meta.url);
  requireThat(new TextDecoder().decode(bytes3.subarray(0, 1024)).includes("%PDF-"), "format", "Source is not a PDF.");
  const task = pdfjs.getDocument({
    data: bytes3.slice(),
    useSystemFonts: false,
    disableFontFace: true,
    isEvalSupported: false,
    useWorkerFetch: false,
    verbosity: 0,
    stopAtErrors: true,
    cMapUrl: fileURLToPath(new URL("cmaps/", assets)),
    cMapPacked: true,
    standardFontDataUrl: fileURLToPath(new URL("standard_fonts/", assets)),
    wasmUrl: fileURLToPath(new URL("wasm/", assets))
  });
  let doc;
  try {
    doc = await task.promise;
    const parts = [], gaps = [];
    for (let n = 1; n <= doc.numPages; n++) {
      const page = await doc.getPage(n), content = await page.getTextContent({ includeMarkedContent: false, disableNormalization: true });
      let text2 = "", previousY = null;
      for (const item of content.items) {
        if (!Object.hasOwn(item, "str")) continue;
        const y = item.transform?.[5];
        if (previousY !== null && y !== void 0 && Math.abs(y - previousY) > 3 && !text2.endsWith("\n")) text2 += "\n";
        text2 += item.str + (item.hasEOL ? "\n" : " ");
        previousY = y;
      }
      parts.push("## Page " + n + "\n\n" + text2.trim());
      if (!text2.trim()) gaps.push({ code: "page_without_text", page: n, message: "Read this page visually or with OCR." });
      let operators;
      try {
        operators = await page.getOperatorList();
      } catch (error) {
        gaps.push({ code: "visual_read_failed", page: n, message: error.message });
        operators = { fnArray: [] };
      }
      const imageOps = /* @__PURE__ */ new Set([pdfjs.OPS.paintImageXObject, pdfjs.OPS.paintInlineImageXObject, pdfjs.OPS.paintImageMaskXObject]);
      if (operators.fnArray.some((op) => imageOps.has(op))) gaps.push({ code: "visual_content", page: n, message: "Read the images on this page and record their relevant content." });
      if (operators.fnArray.includes(pdfjs.OPS.constructPath)) gaps.push({ code: "vector_content", page: n, message: "Check the vector drawings, charts or table layout on this page." });
      const annotations = await page.getAnnotations();
      for (const note of annotations) if (note.contentsObj?.str) parts.push("### Annotation (page " + n + ")\n\n" + note.contentsObj.str);
      page.cleanup();
    }
    const details = await doc.getMetadata().catch(() => null), info = details?.info ?? {};
    const date2 = /^D:(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(Z|[+-]\d{2}'?\d{2}'?)?/.exec(info.CreationDate ?? "");
    if (date2) {
      const [, y, m, d, h, min, s, zone = "Z"] = date2, normalizedZone = zone === "Z" ? "Z" : zone.replace(/'/g, "").replace(/([+-]\d{2})(\d{2})/, "$1:$2"), stamp2 = `${y}-${m}-${d}T${h}:${min}:${s}${normalizedZone}`;
      if (Number.isFinite(Date.parse(stamp2))) metadata2 = { ...metadata2, created_at: new Date(stamp2).toISOString(), created_at_basis: "document_metadata" };
    }
    return { text: parts.join("\n\n"), metadata: metadata2, gaps };
  } finally {
    await task.destroy();
  }
}
var extract = (source2) => extractSource({ ...source2, readPDF });

// runtime/node-cli.mjs
init_setup_contract();

// runtime/node-monitor.mjs
init_project2();
init_errors();
var CHECKPOINT = ".llmwiki/source-monitor.json";
var FORMAT2 = "llmwiki-source-monitor/1";
var OUTPUT_BYTES = 24 * 1024;
var MAX_CHECKPOINT_BYTES = 32 * 1024 * 1024;
var bytes2 = (value) => new TextEncoder().encode(JSON.stringify(value)).length;
function integer(value, fallback, min, max2, name) {
  value ??= fallback;
  requireThat(Number.isInteger(value) && value >= min && value <= max2, "monitor_budget", `${name} must be an integer from ${min} to ${max2}.`);
  return value;
}
function failure(error) {
  return { code: error.code ?? "monitor", message: error.message, details: error.details ?? {} };
}
async function timed(operation, ms, details) {
  let timer;
  try {
    return await Promise.race([Promise.resolve().then(operation), new Promise((_, reject) => {
      timer = setTimeout(() => reject(new WikiError("monitor_read_timeout", "Reading exceeded this call\u2019s budget; the item remains unresolved.", details)), ms);
    })]);
  } finally {
    clearTimeout(timer);
  }
}
function boundedStore(store, guard) {
  return new Proxy(store, { get(target, key) {
    if (["read", "list", "fingerprint"].includes(key)) return (...args) => guard(() => target[key](...args), { operation: key, path: args[0] ?? "", store: target.root });
    if (key === "substore") return async (...args) => boundedStore(await guard(() => target.substore(...args), { operation: "substore", path: args[0], store: target.root }), guard);
    const value = Reflect.get(target, key);
    return typeof value === "function" ? value.bind(target) : value;
  } });
}
var sourcePaths = async (store) => (await store.list("")).filter((e) => e.kind === "file").map((e) => e.path).sort();
var sameNames = (a, b) => a.length === b.length && a.every((name, i2) => name === b[i2]);
function queue(state2, kind, value) {
  if (value.error) {
    state2.scan_ok = false;
    state2.maintenance_complete = false;
  }
  if (value.plan) {
    if ((value.plan.changes ?? []).some((c) => c.state === "unreadable")) state2.scan_ok = false;
    if (value.plan.complete === false || (value.plan.changes ?? []).some((c) => c.state !== "unchanged")) state2.maintenance_complete = false;
  }
  state2.queue.push({ kind, value });
}
function deliver(state2, maxItems) {
  const out = { pairs: [], notes: [] };
  let count = 0;
  while (state2.queue.length && count < maxItems) {
    const { kind, value } = state2.queue[0], plan2 = value.plan;
    if (!plan2) {
      if (bytes2(out) + bytes2(value) > OUTPUT_BYTES && count) break;
      out[kind].push(value);
      state2.queue.shift();
      count++;
      continue;
    }
    const fragment = { ...value, plan: { ...plan2, changes: [], advisories: [], total_counts: plan2.counts, counts: Object.fromEntries(Object.keys(plan2.counts ?? {}).map((k) => [k, 0])), page_complete: false } };
    out[kind].push(fragment);
    let added = 0;
    for (const field of ["changes", "advisories"]) while (plan2[field]?.length && count < maxItems) {
      const item = plan2[field][0];
      fragment.plan[field].push(item);
      if (bytes2(out) > OUTPUT_BYTES) {
        fragment.plan[field].pop();
        if (!count) {
          out[kind].pop();
          out[kind].push({ connection: value.connection, wiki: value.wiki, source: value.source, error: { code: "monitor_item_too_large", message: "Read this item separately; its full findings exceed the response budget.", details: { path: item.path ?? item.page ?? null } } });
          plan2[field].shift();
          state2.scan_ok = false;
          state2.maintenance_complete = false;
          count++;
        } else if (!added) out[kind].pop();
        return out;
      }
      plan2[field].shift();
      count++;
      added++;
      if (field === "changes" && item.state) fragment.plan.counts[item.state] = (fragment.plan.counts[item.state] ?? 0) + 1;
    }
    if (!plan2.changes?.length && !plan2.advisories?.length) {
      fragment.plan.page_complete = true;
      state2.queue.shift();
      if (!added) count++;
    }
  }
  return out;
}
async function monitor(root, request, { bindings = {} } = {}) {
  const budget = integer(request.budget_ms, 2e4, 100, 2e4, "budget_ms"), readTimeout = Math.min(integer(request.read_timeout_ms, 2e3, 25, 5e3, "read_timeout_ms"), Math.floor(budget / 4));
  const maxFiles = integer(request.max_files, 128, 1, 256, "max_files"), maxItems = integer(request.max_items, 64, 1, 128, "max_items");
  const deadline = Date.now() + budget;
  let readTimedOut = false, readFailure = null;
  const guard = (operation, details) => {
    if (readFailure) throw readFailure;
    const remaining = deadline - Date.now();
    if (remaining <= 0) throw new WikiError("monitor_read_timeout", "This call\u2019s read budget is exhausted.", details);
    return timed(operation, Math.min(readTimeout, remaining), details).catch((error) => {
      if (error.code === "monitor_read_timeout") {
        readTimedOut = true;
        readFailure ??= error;
      }
      throw error;
    });
  };
  const guarded2 = boundedStore(root, guard), bound = Object.fromEntries(Object.entries(bindings).map(([id, store]) => [id, boundedStore(store, guard)]));
  const { project, file } = await load(guarded2), seen = await guarded2.read(CHECKPOINT);
  const identity2 = await root.services.hash(JSON.stringify({ root: root.root, project: file.sha256, bindings: Object.entries(bindings).map(([id, s]) => [id, s.root]).sort() }));
  let state2;
  if (request.cursor !== void 0) {
    requireThat(typeof request.cursor === "string" && /^[a-f0-9]{64}$/.test(request.cursor), "monitor_cursor", "Use the exact returned cursor.");
    requireThat(seen?.sha256 === request.cursor, "monitor_stale", "The monitor checkpoint changed or is missing. Start source.monitor again without a cursor.");
    const checkpoint = JSON.parse(seen.text);
    requireThat(checkpoint.format === FORMAT2 && checkpoint.identity === identity2 && Date.now() - checkpoint.started_at < 24 * 60 * 60 * 1e3, "monitor_stale", "The project, bindings or scan age changed. Start a fresh monitor without a cursor.");
    state2 = checkpoint;
  } else {
    const tasks = project.connections.map((link) => ({ kind: "notes", connection: link.id, wiki: link.wiki }));
    for (const link of project.connections) for (const source2 of link.sources) tasks.push({ kind: "pairs", connection: link.id, wiki: link.wiki, source: source2 });
    state2 = { format: FORMAT2, identity: identity2, started_at: Date.now(), tasks, task: 0, current: null, queue: [], scan_ok: true, maintenance_complete: true, files_scanned: 0 };
  }
  let filesRead = 0;
  while (!state2.queue.length && state2.task < state2.tasks.length && !readTimedOut && Date.now() < deadline && filesRead < maxFiles) {
    const task = state2.tasks[state2.task], ids = { connection: task.connection, wiki: task.wiki, ...task.source ? { source: task.source } : {} };
    try {
      const c = await context(guarded2, task.connection, { bindings: bound });
      if (task.kind === "notes") {
        const plan3 = await timed(() => integratedNotePlan(c.work), Math.max(1, deadline - Date.now()), { operation: "notes", connection: task.connection });
        queue(state2, "notes", { ...ids, plan: plan3 });
        state2.task++;
        continue;
      }
      const source2 = c.sources.find((s) => s.id === task.source);
      if (!source2?.store) throw new WikiError(source2?.error?.code ?? "binding", source2?.error?.message ?? "Source store unavailable.");
      if (!state2.current) state2.current = { files: await sourcePaths(source2.store), originals: [], phase: "scan", validated: 0 };
      const scan = state2.current;
      if (scan.phase === "scan") {
        while (scan.originals.length < scan.files.length && filesRead < maxFiles && deadline - Date.now() > readTimeout && !readTimedOut) {
          const name = scan.files[scan.originals.length];
          try {
            const before = await source2.store.fingerprint(name), f = await source2.store.read(name, { binary: true });
            requireThat(f, "monitor_source_changed", "The listed source disappeared during this scan.", { path: name });
            const version2 = await source2.store.fingerprint(name);
            requireThat(JSON.stringify(before) === JSON.stringify(version2), "monitor_source_changed", "The source changed while it was read.", { path: name });
            scan.originals.push({ path: name, sha256: f.sha256, size: f.size, created_at: f.created_at, created_at_basis: f.created_at_basis, version: version2 });
          } catch (error) {
            scan.originals.push({ path: name, error: error.message, code: error.code ?? "read" });
            state2.scan_ok = false;
            state2.maintenance_complete = false;
          }
          filesRead++;
          state2.files_scanned++;
        }
        if (scan.originals.length === scan.files.length) scan.phase = "validate";
        break;
      }
      requireThat(sameNames(scan.files, await sourcePaths(source2.store)), "monitor_source_changed", "The source directory changed during this scan. Start a fresh monitor; no missing or renamed state was inferred.");
      if (scan.phase === "validate") {
        let checked = 0;
        while (scan.validated < scan.originals.length && checked < 512 && deadline - Date.now() > readTimeout) {
          const original = scan.originals[scan.validated];
          if (!original.error) requireThat(JSON.stringify(await source2.store.fingerprint(original.path)) === JSON.stringify(original.version), "monitor_source_changed", "A source changed after an earlier scan page. Start a fresh monitor.", { path: original.path });
          scan.validated++;
          checked++;
        }
        if (scan.validated === scan.originals.length) scan.phase = "compare";
        break;
      }
      const plan2 = await timed(() => compareInventory(c.work, source2, scan.originals.map(({ version: version2, ...item }) => item), { listedPaths: new Set(scan.files) }), Math.max(1, deadline - Date.now()), { operation: "source_plan", ...ids });
      queue(state2, "pairs", { ...ids, plan: plan2 });
      state2.current = null;
      state2.task++;
    } catch (error) {
      queue(state2, task.kind, { ...ids, error: failure(error) });
      state2.current = null;
      state2.task++;
    }
  }
  const output = deliver(state2, maxItems), scanFinished = state2.task === state2.tasks.length, deliveryComplete = scanFinished && !state2.queue.length;
  const pending = !deliveryComplete;
  const result = {
    ...output,
    scan_finished: scanFinished,
    scan_complete: scanFinished && state2.scan_ok,
    delivery_complete: deliveryComplete,
    complete: deliveryComplete && state2.scan_ok && state2.maintenance_complete,
    progress: { files_read: filesRead, files_scanned: state2.files_scanned, tasks_finished: state2.task, tasks_total: state2.tasks.length, ...state2.current ? { source: state2.tasks[state2.task].source, source_files: state2.current.files.length, source_files_scanned: state2.current.originals.length, phase: state2.current.phase, source_files_validated: state2.current.validated } : {} },
    next_request: null,
    next: pending ? "Continue with next_request until delivery_complete. Retain every response." : "Process all delivered source and note findings. Unreadable items remain unresolved; this scan never acknowledges maintenance."
  };
  if (readTimedOut) {
    result.read_timeout = true;
    result.unresolved = state2.current?.originals.filter((f) => f.code === "monitor_read_timeout").slice(-1).map((f) => ({ source: state2.tasks[state2.task].source, path: f.path, error: f.error })) ?? [];
  }
  const text2 = JSON.stringify(state2) + "\n";
  requireThat(new TextEncoder().encode(text2).length <= MAX_CHECKPOINT_BYTES, "monitor_checkpoint_limit", "The monitor checkpoint exceeds 32 MiB. The scan remains incomplete.");
  const saved = await root.write(CHECKPOINT, text2, { expected: seen?.sha256 ?? null });
  if (pending) result.next_request = { action: "source.monitor", cursor: saved.sha256, budget_ms: budget, read_timeout_ms: readTimeout, max_files: maxFiles, max_items: maxItems };
  return result;
}

// runtime/node-process.mjs
import { spawn as spawn2 } from "node:child_process";
var MESSAGE = "llmwiki-runtime-result/1";
var runtimeWorker = () => process.env.LLMWIKI_RUNTIME_WORKER === "1" && typeof process.send === "function";
function sendRuntimeResult(value, code) {
  process.send({ type: MESSAGE, value, code });
}
function superviseRuntime(args, request = null) {
  return new Promise((resolve) => {
    let settled = false, stderr = "", timer, child2;
    const finish2 = (value, code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (child2 && !child2.killed) child2.kill("SIGKILL");
      resolve({ value, code });
    };
    const details = { action: request?.action ?? "request", complete: false, partial_changes_possible: !args["--read-only"] && !["inspect", "query", "read", "context", "graph", "source.monitor"].includes(request?.action ?? "request"), next: "Do not repeat with shell suffixes or temporary redirects. Read current state before retrying an interrupted mutation." };
    const fail = (code, message, extra = {}) => finish2({ ok: false, error: { code, message, details: { ...details, ...extra } } }, 1);
    try {
      child2 = spawn2(process.execPath, [...process.execArgv, process.argv[1], "--root", args["--root"], ...args["--bindings"] ? ["--bindings", args["--bindings"]] : [], ...args["--read-only"] ? ["--read-only"] : [], "--input", request ? "-" : args["--input"]], {
        env: { ...process.env, LLMWIKI_RUNTIME_WORKER: "1" },
        stdio: ["pipe", "ignore", "pipe", "ipc"]
      });
      timer = setTimeout(() => fail(request?.action === "source.monitor" ? "monitor_timeout" : "runtime_timeout", "The worker could not return a verified result within 35 seconds. The operation remains incomplete."), 35e3);
      child2.stderr.on("data", (data) => {
        stderr = (stderr + data.toString()).slice(-4e3);
      });
      child2.on("message", (message) => {
        if (message?.type === MESSAGE && typeof message.value?.ok === "boolean" && [0, 1].includes(message.code)) finish2(message.value, message.code);
      });
      child2.on("error", (error) => fail("runtime_worker", error.message));
      child2.on("exit", (code, signal) => {
        if (!settled) fail("runtime_worker", "The runtime worker ended before returning a result.", { exit_code: code, signal, stderr });
      });
      child2.stdin.on("error", (error) => {
        if (!settled) fail("runtime_worker", error.message);
      });
      child2.stdin.end(request ? JSON.stringify(request) : void 0);
    } catch (error) {
      fail("runtime_worker", error.message);
    }
  });
}

// runtime/node-budget.mjs
init_errors();
function integer2(value, fallback, min, max2, name) {
  value ??= fallback;
  requireThat(Number.isInteger(value) && value >= min && value <= max2, "runtime_budget", `${name} must be an integer from ${min} to ${max2}.`);
  return value;
}
function nodeBudget(request = {}) {
  const budget = integer2(request.budget_ms, 2e4, 100, 2e4, "budget_ms"), readTimeout = Math.min(integer2(request.read_timeout_ms, 15e3, 25, 15e3, "read_timeout_ms"), Math.max(25, budget - 250));
  const deadline = Date.now() + budget, stores = /* @__PURE__ */ new Map();
  let failure2 = null, observer = null, mutated = false;
  function check(details = {}) {
    if (failure2) throw failure2;
    if (Date.now() >= deadline) throw failure2 = new WikiError("runtime_budget", "This call reached its time budget; the operation is incomplete.", details);
  }
  async function read(operation, details) {
    check(details);
    let timer;
    const remaining = deadline - Date.now(), callLimit = remaining <= readTimeout;
    try {
      return await Promise.race([Promise.resolve().then(operation), new Promise((_, reject) => {
        timer = setTimeout(() => {
          failure2 ??= new WikiError(callLimit ? "runtime_budget" : "runtime_read_timeout", callLimit ? "This call reached its time budget; the operation is incomplete." : "A filesystem read did not finish in time. This operation is incomplete.", details);
          reject(failure2);
        }, Math.max(1, Math.min(readTimeout, remaining)));
      })]);
    } finally {
      clearTimeout(timer);
    }
  }
  function wrap(store) {
    const key = store.root + "|" + store.writable;
    if (stores.has(key)) return stores.get(key);
    const proxy = new Proxy(store, { get(target, key2) {
      if (["read", "list", "fingerprint"].includes(key2)) return async (...args) => {
        const details = { operation: key2, path: args[0] ?? "", store: target.root };
        const result = await read(async () => {
          let before = observer && key2 === "read" ? await target.fingerprint(args[0]) : void 0;
          check(details);
          let value2;
          try {
            value2 = await target[key2](...args);
          } catch (error) {
            if (observer && key2 === "list" && error.code === "ENOENT") await observer({ kind: "list", store: target, path: args[0] ?? "", options: args[1] ?? {}, value: null });
            throw error;
          }
          if (observer && key2 === "read") {
            check(details);
            let after = await target.fingerprint(args[0]);
            if (JSON.stringify(before) !== JSON.stringify(after)) {
              check(details);
              before = after;
              value2 = await target.read(...args);
              check(details);
              after = await target.fingerprint(args[0]);
            }
            requireThat(JSON.stringify(before) === JSON.stringify(after), "sync_changed", "A file changed while being read.", details);
            await observer({ kind: "file", store: target, path: args[0], value: after });
          } else if (observer && key2 === "list") await observer({ kind: "list", store: target, path: args[0] ?? "", options: args[1] ?? {}, value: value2 });
          return value2;
        }, details);
        check(details);
        return result;
      };
      if (key2 === "substore") return async (...args) => wrap(await read(() => target.substore(...args), { operation: key2, path: args[0], store: target.root }));
      if (["write", "archive", "mkdir"].includes(key2)) return async (...args) => {
        check({ operation: key2, path: args[0], store: target.root });
        mutated = true;
        const value2 = await target[key2](...args);
        if (observer) await observer({ kind: key2, store: target, args, value: value2 });
        return value2;
      };
      const value = Reflect.get(target, key2);
      return typeof value === "function" ? value.bind(target) : value;
    } });
    stores.set(key, proxy);
    return proxy;
  }
  return { wrap, read, check, get failure() {
    return failure2;
  }, get mutated() {
    return mutated;
  }, get remaining() {
    return Math.max(0, deadline - Date.now());
  }, budget, readTimeout, observe(fn) {
    observer = fn;
  } };
}

// runtime/node-sync.mjs
init_project2();
init_review();
init_derived();
init_errors();
var FORMAT3 = "llmwiki-node-sync/1";
var LIMIT = 32 * 1024 * 1024;
var json2 = (v) => JSON.stringify(v);
var equal = (a, b) => json2(a) === json2(b);
var ordered = (items) => items === null ? null : items.map(({ path: path7, kind }) => ({ path: path7, kind })).sort((a, b) => a.path.localeCompare(b.path) || a.kind.localeCompare(b.kind));
var empty = () => ({ copied: 0, published: 0, pending: 0, pending_details: [], conflicts: [] });
var encode2 = (v) => v instanceof Set ? { type: "set", values: [...v] } : v === void 0 ? null : v;
var decode2 = (v) => v?.type === "set" ? new Set(v.values) : v;
function delta(before, after) {
  return { copied: after.copied - before.copied, published: after.published - before.published, pending: after.pending - before.pending, pending_details: after.pending_details.slice(before.pending_details.length), conflicts: after.conflicts.slice(before.conflicts.length) };
}
function add2(target, value) {
  for (const key of ["copied", "published", "pending"]) target[key] += value[key];
  for (const key of ["pending_details", "conflicts"]) target[key].push(...value[key]);
}
function changedList(dep, name, kind, remove = false) {
  const prefix = dep.path ? dep.path + "/" : "";
  if (!name.startsWith(prefix)) return;
  const parts = name.slice(prefix.length).split("/");
  if (!dep.options.hidden && parts.some((p) => p.startsWith(".") || p.startsWith("~$"))) return;
  if (remove) {
    if (dep.value) dep.value = dep.value.filter((e) => e.path !== name);
    return;
  }
  dep.value ??= [];
  let current2 = dep.path;
  for (let i2 = 0; i2 < parts.length; i2++) {
    current2 = current2 ? current2 + "/" + parts[i2] : parts[i2];
    if (dep.options.recursive === false && i2 > 0) break;
    if (!dep.value.some((e) => e.path === current2)) dep.value.push({ path: current2, kind: i2 === parts.length - 1 ? kind : "directory" });
  }
  dep.value = ordered(dep.value);
}
async function nodeSync(root, request, { bindings = {} } = {}) {
  const scope = nodeBudget(request), maxSteps = integer2(request.max_steps, 64, 1, 256, "max_steps"), guarded2 = scope.wrap(root);
  const bound = Object.fromEntries(Object.entries(bindings).map(([id, store]) => [id, scope.wrap(store)]));
  const { file } = await load(guarded2), c = await context(guarded2, request.connection, { bindings: bound });
  const connection = c.connection.id, checkpoint = ".llmwiki/sync/" + await root.services.hash(connection) + ".json", seen = await guarded2.read(checkpoint);
  const marker = await guarded2.read(".llmwiki/project-instance.json");
  const identity2 = await root.services.hash(json2({ project: file.sha256, instance: marker?.sha256, root: root.root, connection, work: c.work.root, remote: c.remote.root, canPublish: c.canPublish, bindings: Object.entries(bindings).map(([id, s]) => [id, s.root]).sort() }));
  let state2;
  if (request.cursor !== void 0) {
    requireThat(typeof request.cursor === "string" && /^[a-f0-9]{64}$/.test(request.cursor) && seen?.sha256 === request.cursor, "sync_stale", "The sync checkpoint changed. Start a fresh sync without a cursor; keep existing knowledge and journals.");
    state2 = JSON.parse(seen.text);
    requireThat(state2.format === FORMAT3 && state2.identity === identity2 && Date.now() - state2.started_at < 864e5, "sync_stale", "Project, binding or sync age changed. Start a fresh sync.");
  } else state2 = { format: FORMAT3, identity: identity2, started_at: Date.now(), phase: "sync", steps: {}, result: empty() };
  if (request.detail) {
    requireThat(request.cursor, "sync_detail", "A detail request needs the returned cursor.");
    const { kind, index, field, offset = 0 } = request.detail;
    requireThat(["conflicts", "pending_details", "shadow_findings"].includes(kind) && Number.isInteger(index) && index >= 0, "sync_detail", "Use the returned detail request.");
    const item = (kind === "shadow_findings" ? state2.shadow?.findings : state2.result[kind])?.[index];
    requireThat(item, "sync_detail", "Finding is unavailable.");
    if (field === void 0) return { complete: false, detail: { ...Object.fromEntries(Object.entries(item).filter(([k]) => !["mine", "base", "theirs"].includes(k))), fields: Object.fromEntries(["mine", "base", "theirs"].map((k) => [k, typeof item[k] === "string" ? item[k].length : null])) }, next: "Read each text field in bounded chunks using detail.field and detail.offset before an explicit conflict decision." };
    requireThat(["mine", "base", "theirs"].includes(field) && Number.isInteger(offset) && offset >= 0, "sync_detail", "Choose a text field and a non-negative offset.");
    const value = item[field] ?? null;
    return { complete: false, detail: { kind, index, field, offset, text: value === null ? null : value.slice(offset, offset + 4096), length: value?.length ?? 0, next_offset: value && offset + 4096 < value.length ? offset + 4096 : null } };
  }
  const stores = /* @__PURE__ */ new Map([[c.work.root, c.work], [c.remote.root, c.remote]]);
  let active = null, steps = 0, blocked = null;
  const depKey = (d) => json2([d.store, d.kind, d.path, d.options]);
  scope.observe(async (event) => {
    if (!active) return;
    if (event.kind === "file" || event.kind === "list") {
      const dep = { kind: event.kind, store: event.store.root, path: event.path, ...event.kind === "list" ? { options: event.options, value: ordered(event.value) } : { value: event.value } };
      active.set(depKey(dep), dep);
      return;
    }
    const changes = event.kind === "archive" ? [[event.args[0], null], [event.args[1], "file"]] : [[event.args[0], event.kind === "mkdir" ? "directory" : "file"]];
    for (const [name, kind] of changes) {
      if (kind !== "directory") {
        const value = kind === null ? null : await scope.read(() => event.store.fingerprint(name), { operation: "write_verification", path: name, store: event.store.root });
        const dep = { kind: "file", store: event.store.root, path: name, value };
        active.set(depKey(dep), dep);
      }
      for (const deps of [active.values(), ...Object.values(state2.steps).map((s) => s.deps)]) for (const dep of deps) if (dep.kind === "list" && dep.store === event.store.root) changedList(dep, name, kind, kind === null);
    }
  });
  async function valid(unit) {
    for (const dep of unit.deps) {
      const store = stores.get(dep.store);
      if (!store) return false;
      let value;
      try {
        value = dep.kind === "file" ? await store.fingerprint(dep.path) : ordered(await store.list(dep.path, dep.options));
      } catch (error) {
        if (error.code === "ENOENT") value = null;
        else throw error;
      }
      if (!equal(value, dep.value)) return false;
    }
    return true;
  }
  async function step(key, fn, result2) {
    scope.check();
    const unit = state2.steps[key];
    if (unit && await valid(unit)) {
      if (result2 && unit.delta) add2(result2, unit.delta);
      return decode2(unit.value);
    }
    if (steps >= maxSteps || scope.remaining < Math.min(1e3, scope.readTimeout)) throw new WikiError("sync_yield", "Continue the sync with a fresh call budget.");
    delete state2.steps[key];
    active = /* @__PURE__ */ new Map();
    const before = result2 ? structuredClone(result2) : null;
    try {
      const value = await fn();
      scope.check();
      state2.steps[key] = { deps: [...active.values()], value: encode2(value), ...result2 ? { delta: delta(before, result2) } : {} };
      steps++;
      return value;
    } finally {
      active = null;
    }
  }
  try {
    if (state2.phase === "sync") {
      state2.result = await sync.run({ work: handle(c.work), remote: handle(c.remote), identity: c.identity, canPublish: c.canPublish, step });
      scope.check();
      state2.phase = "work_graph";
    } else if (state2.phase === "work_graph") {
      await exportGraph(c.work);
      scope.check();
      state2.phase = c.canPublish ? "remote_graph" : "project_graph";
    } else if (state2.phase === "remote_graph") {
      await exportGraph(c.remote);
      scope.check();
      state2.phase = "project_graph";
    } else if (state2.phase === "project_graph") {
      const graph = await exportProjectGraph(guarded2, { bindings: bound });
      scope.check();
      state2.graph = { revision: graph.revision, generated_at: graph.generated_at, complete: graph.complete };
      state2.phase = "shadow";
    } else if (state2.phase === "shadow") {
      state2.shadow = await dispatch(guarded2, { action: "shadow.refresh", connection }, { bindings: bound });
      scope.check();
      state2.phase = "done";
    }
  } catch (error) {
    error = scope.failure ?? error;
    if (!["sync_yield", "runtime_budget", "runtime_read_timeout", "sync_changed"].includes(error.code)) throw error;
    if (["runtime_read_timeout", "sync_changed"].includes(error.code)) blocked = { code: error.code, message: error.message, details: error.details };
  }
  scope.observe(null);
  const findings = { conflicts: [], pending_details: [], shadow_findings: [] }, all = ["conflicts", "pending_details", "shadow_findings"].flatMap((kind) => (kind === "shadow_findings" ? state2.shadow?.findings ?? [] : state2.result[kind]).map((item, index) => ({ kind, index, item })));
  let deliveryComplete = false;
  if (state2.phase === "done") {
    state2.delivered ??= 0;
    while (state2.delivered < all.length) {
      const { kind, index, item } = all[state2.delivered], entry = Buffer.byteLength(json2(item)) <= 4096 ? item : { page: item.page, reason: item.reason ?? item.code ?? "conflict", detail_request: { action: "sync", connection, cursor: "0".repeat(64), detail: { kind, index } } };
      findings[kind].push(entry);
      if (Buffer.byteLength(json2(findings)) > 16 * 1024) {
        findings[kind].pop();
        break;
      }
      state2.delivered++;
    }
    deliveryComplete = state2.delivered === all.length;
  }
  const text2 = json2(state2) + "\n";
  requireThat(Buffer.byteLength(text2) <= LIMIT, "sync_checkpoint_limit", "Sync checkpoint exceeds 32 MiB. Sync remains incomplete.");
  const saved = await root.write(checkpoint, text2, { expected: seen?.sha256 ?? null });
  for (const list of Object.values(findings)) for (const item of list) if (item.detail_request) item.detail_request.cursor = saved.sha256;
  const next = deliveryComplete ? null : { action: "sync", connection, cursor: saved.sha256, budget_ms: scope.budget, read_timeout_ms: scope.readTimeout, max_steps: maxSteps };
  const result = { ...state2.result, conflicts: findings.conflicts, pending_details: findings.pending_details, complete: deliveryComplete && !state2.result.pending && !state2.result.conflicts.length && state2.graph?.complete !== false && state2.shadow?.complete !== false, sync_complete: state2.phase !== "sync", delivery_complete: deliveryComplete, findings_total: all.length, progress: { phase: state2.phase, steps_completed: steps, steps_saved: Object.keys(state2.steps).length }, graph: state2.graph, shadow: state2.shadow ? { ...state2.shadow, findings: findings.shadow_findings } : void 0, next_request: blocked ? null : next, ...blocked ? { blocked, resume_request: next } : {}, next: blocked ? "The named file remains unreadable. Retry resume_request once; if the same file blocks again, report it and stop. Never bypass clearance or change sandbox grants." : next ? "Continue next_request until it is null. Sync and derived maintenance are not finished yet." : "Review all conflicts, pending items and incomplete graph/shadow findings before maintenance can be considered complete." };
  return result;
}

// runtime/node-cli.mjs
var supervised = runtimeWorker();
var responded = false;
var activeScope = null;
function respond(value, code = 0) {
  if (responded) return;
  responded = true;
  const text2 = JSON.stringify(value) + "\n";
  if (supervised && runtimeWorker()) sendRuntimeResult(value, code);
  else if (supervised) process.stdout.write(text2, () => process.exit(code));
  else {
    process.stdout.write(text2);
    process.exitCode = code;
  }
}
try {
  const args = parseArguments(process.argv.slice(2)), readOnly = true;
  let delegated = false, loadedRequest = null;
  if (!args["--help"] && !runtimeWorker() && args["--input"] !== "-" && !/^[\s\uFEFF]*[\[{]/.test(args["--input"])) {
    supervised = true;
    const outcome = await superviseRuntime({ ...args, ...readOnly ? { "--read-only": true } : {} });
    if (outcome.value.run_editor?.action === "editor.serve") loadedRequest = outcome.value.run_editor;
    else {
      respond(outcome.value, outcome.code);
      delegated = true;
    }
  }
  if (!delegated) {
    const request = args["--help"] ? null : loadedRequest ?? await readRequest(args["--input"]);
    if (runtimeWorker() && !readOnly && request?.action === "editor.serve") {
      respond({ ok: true, run_editor: request });
    } else {
      if (args["--help"] || request.action === "help") {
        const help = { usage: `node wiki.mjs --root ABSOLUTE_PROJECT --input '{"action":"inspect"}'`, input: "JSON object, existing file path, or - for stdin", bindings: "Optional --bindings FILE; otherwise project .llmwiki/device-bindings.json, then legacy .llmwiki/bindings.json", actions: readOnly ? queryActions : [...actions, "help", "editor.preflight", "editor.start", "editor.stop", "editor.serve"], minimum_node: "22.13.0", python: false, runtime_limits: { budget_ms: 2e4, read_timeout_ms: 15e3, worker_timeout_ms: 35e3, recovery: "Read structured errors; never retry with shell suffixes or temporary redirects.", ...!readOnly ? { sync: "Follow every next_request, including derived maintenance and finding delivery. A blocked file has a separate resume_request; retry once only." } : { query: "A read timeout is incomplete retrieval. Preserve the question and retry at most once; never infer no matching knowledge." } }, shadow_contract: { status: { action: "shadow.status" }, resolve: { action: "shadow.resolve", id: "<quote-id>" }, passage: { action: "shadow.resolve", reference: "<passage.reference>" }, ...!readOnly ? { refresh: { action: "shadow.refresh" }, known_paths: { action: "shadow.refresh", connection: "<connection>", paths: ["<existing.md>"] }, reconciliation: "full_scan:false checks only requested paths; finish maintenance with a full refresh or sync.", rebuild: { action: "shadow.rebuild" }, budgets: { cache_bytes: "SQLite only; default 128 MiB", maxBatchBytes: "Transport package only; default 512 KiB, automatic splitting, 4 KiB\u20138 MiB", maxBytes: "On shadow.pin: retained-quote budget only" }, recovery: "Retry refresh after updating both skills. Never delete shared identity packages or move Markdown to bypass limits. Rebuild is for cache recovery, not transport limits." } : {}, compatibility: "Inline passage links require editor 0.4.23 or newer; partial quotes require both skills and editor 0.4.21 or newer; older whole-block pins remain supported." }, ...!readOnly ? { setup_contract: setupContract() } : {} };
        if (args["--help"]) process.stdout.write(JSON.stringify(help) + "\n");
        else respond({ ok: true, result: help });
      } else {
        const root = new NodeStore(args["--root"], { writable: !readOnly });
        if (readOnly && !queryActions.includes(request.action)) throw Error("The query skill is read-only. Use maintain-llm-wiki for this action.");
        supervised = request.action !== "editor.serve";
        if (supervised && !runtimeWorker()) {
          const outcome = await superviseRuntime({ ...args, ...readOnly ? { "--read-only": true } : {} }, request);
          respond(outcome.value, outcome.code);
        } else {
          const scope = activeScope = nodeBudget(request), guarded2 = scope.wrap(root);
          const bindings = await scope.read(() => loadBindings(guarded2, { file: args["--bindings"], readOnly }), { operation: "bindings", path: args["--bindings"] ?? ".llmwiki/device-bindings.json" });
          const bound = Object.fromEntries(Object.entries(bindings).map(([id, store]) => [id, scope.wrap(store)]));
          let editorHTML = null;
          try {
            if (!["source.monitor", "sync"].includes(request.action)) editorHTML = await scope.read(() => fs6.readFile(new URL(true ? "../assets/app.html" : "./assets/app.html", import.meta.url), "utf8"), { operation: "editor_asset" });
          } catch (error) {
            if (error.code !== "ENOENT") throw error;
          }
          const result = request.action === "source.monitor" ? await monitor(root, request, { bindings }) : request.action === "sync" ? await nodeSync(root, request, { bindings }) : request.action === "editor.preflight" ? await editorPreflight(guarded2, { bindingsFile: args["--bindings"] }) : request.action === "editor.start" ? await startEditor(guarded2, { bindingsFile: args["--bindings"], open: request.open === true }) : request.action === "editor.serve" ? await serveEditor(root, editorHTML, { bindingsFile: args["--bindings"] }) : request.action === "editor.stop" ? await stopEditor(guarded2) : await dispatch(guarded2, request, { bindings: bound, extract, editorHTML });
          if (!["source.monitor", "sync"].includes(request.action)) scope.check();
          if (request.action === "inspect" && !readOnly) result.runtime.node_actions = ["editor.preflight", "editor.start", "editor.stop", "editor.serve"];
          respond({ ok: true, result });
        }
      }
    }
  }
} catch (error) {
  error = activeScope?.failure ?? error;
  respond({ ok: false, error: { code: error.code ?? "request", message: error.message, details: { ...error.details, ...activeScope?.failure ? { complete: false, partial_changes_possible: activeScope.mutated } : {} } } }, 1);
}
