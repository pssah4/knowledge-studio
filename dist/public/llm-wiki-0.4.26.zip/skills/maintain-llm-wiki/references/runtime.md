# Runtime contract

For Node calls in both skills, the runtime bounds filesystem reads and supervises
its worker inside the existing sandbox. A filesystem timeout is an incomplete
operation, never proof of missing knowledge. Read `error.code/message/details`;
`runtime_read_timeout` identifies the affected path. Do not retry with `2>&1`,
`; echo EXIT:$?`, `cat`, or a temporary-file redirect. Do not change the host or its
grants. For a read-only query, retain the question and retry the exact request at
most once; if it blocks again, report the affected file and the incomplete scope.
A connection-scoped query may answer a narrower, explicitly disclosed question;
never silently omit an inaccessible connection. For an interrupted mutation, inspect
current state before retrying: `partial_changes_possible` is not a rollback.
The same protection applies to the separate HTML answer helper. Never claim an
answer file was generated or opened after a failed export.

On Node, `sync` is resumable too. For EACH connection, execute every exact
`next_request` until it is null; retain all returned conflicts and pending findings.
`sync_complete` covers transfers only; graph and shadow stages also need their
continuations. `complete:false` must be explained even when the process exits 0.
A `blocked` result has no automatic next step: retry its `resume_request` at most
once, then report the named unresolved file if it blocks again. Never continue the
maintenance as complete, skip clearance, edit the checkpoint or broaden access.
A stale cursor needs a fresh sync; saved Markdown and review history remain intact.


The body describes the method; this file contains the calls for this package's host.
Never install Python, LibreOffice, Pandoc, npm packages or system software on a user machine.
All JavaScript libraries and editor assets travel in this package. A runtime supplied by
the host is still required. Check capabilities before saying setup succeeded.
Requests and results follow [operations.md](operations.md). Tool inputs are data;
never interpolate a user path or document text into shell code.

Use this installed package's entrypoint and contract, even if an earlier conversation
mentions another script. Do not modify the installed skill or invent an alternative
source writer after a runtime error. Read the structured error and retain the affected
file as open; use only supported repair/supplement operations. Read-only inspection and
the actual setup readback establish access; do not leave trial files in the user's wiki.
The wrapper's ok:true means that the call returned successfully. Completion also
depends on the action's state, source coverage, workflow, readiness and sync results;
see the completion checks in operations.md. Host previews may truncate tool output:
obtain every required passage before claiming to have read a complete source.
Preserve parser diagnostics accurately. A broken archive relationship or other reader
error does not mean the source is visual-only; actual content/visual examination is
required for that finding. Never claim an OCR pass or image reading that did not run.

For Node profiles, --input accepts a JSON object, an existing JSON file, or - for
stdin. Start with the exact inspect example below; it needs no request file. For
larger requests prefer the execution tool's structured stdin with --input -. A
single-quoted heredoc is also valid if its delimiter cannot occur in the payload.
If the tool requires a file, write it with the host file tool under the already
granted project, for example .llmwiki/requests/<unique-id>.json, and pass that path.
Do not use /tmp, /private/tmp or another ungranted directory, and do not widen
sandbox grants to transport a request. Empty granted Wiki/Sources folders are a
valid first setup: inspect returns next: setup; do not wait for source files.
Existing project-local device bindings are read automatically. --bindings FILE is
only needed for an explicitly chosen existing mapping. It accepts the current
versioned format and the legacy object mapping folder IDs to absolute paths.

Browser handles and agent filesystem access are separate. An externally selected
browser folder is persisted with path:null and a label; its native browser grant
does not reveal an absolute OS path. In Node hosts, match the existing folder ID to
the actually shared host directory and validate/update its local device binding with
the host's structured file tools, preserving other bindings. Check an existing
mapping by reading/listing that granted directory. A label alone is not proof of
identity; if several granted directories fit, ask only for that mapping. Do not
search the whole machine, guess a path, duplicate the connection, reconfigure the
project or reset settings to resolve a missing binding. Vault Operator uses its
accessible vault paths; it cannot obtain external filesystem access from a browser
grant. A missing host capability remains explicit.

In maintain, inspect.editor reports whether the project-root starter matches this
installed package. If update_required is true, call editor using the configured
project, await committed completion, and inspect again before giving its file link.
Keep existing settings and folder choices. Explain that an open browser tab needs a
reload/reopen to run the updated HTML; a new skill installation does not update the
already-running page. Query reports the required update and hands it to maintain.
The editor result supplies page, project_root, entry_path and entry_uri. Use that
canonical entry with the actual host opening/link tool; in Node, entry_path is the
absolute path. The configured project root is the root passed to the runtime and
holding its settings, not whichever connected wiki contains an old HTML copy. The
generated script#llmwiki-entry-location metadata also identifies that same location.
In vault hosts these OS location fields can be null; use the real vault-relative
entry/native file link for the selected project rather than inventing a device path.

Do not mirror/cp the editor app into a separate connected wiki, source folder or
another remembered location. Those copies do not acquire the project's settings or
working state. If the user explicitly requests a different launch location, create
only a shortcut/link to this same canonical starter. A separately configured project
or an intentional whole-project transfer is a different operation; copying its HTML
alone is not that operation. Check historical project-memory claims about two launch
locations or direct write/copy ingest against the current runtime contract before
acting; they do not establish that those workarounds are still valid.

Before a Node editor handoff call editor.preflight and follow the verified editor
handoff in operations.md and setup-handoff.md. Profiles that forbid local binding
return unavailable without trying a server. A successful folder grant does not enable listening on localhost. Never
state a process-lifetime cause unless actually evidenced. No sandbox bypass.
For Node profiles that allow it, available means the socket probe succeeded, not that the
browser or process persistence is verified. Inspect editor.start's structured state.
Vault Operator uses native editor capabilities; do not call these Node-only actions.

## Claude Code

Use the existing shell to check `node --version` (22.13+). Locate this loaded skill's
directory, not a hardcoded home path. Begin without a request file:
`node "<skill>/scripts/wiki.mjs" --root "<absolute-project>" --input '{"action":"inspect"}'`
with properly quoted argument paths. Read JSON `ok` and `result` or `error`.
Use the user's current project or an explicitly selected persistent directory.
Open or return the project-root `LLM-Wiki.html`; show its clickable absolute path.
If the runtime is missing, state the specific missing host capability; do not claim
that an unexecuted instruction changed the project. Obsidian opens the working-copy
path reported by `context`, while `sync` exchanges Markdown and review events.
