---
register_version: 1
---

# Typregister

Jede Gattung unten ist eine Zeile. Sie sagt, welche Frage beim Einordnen zu
beantworten ist, was ab `stable` bindet, welche Abschnitte der Text tragen
muss und welche Kanten von ihr ausgehen dürfen.

## Genera

### bundle
- Label: Bündel
- Question: Beschreibt das Dokument den Leserkreis, die Sprache und die Regeln einer Ablage selbst?
- Order: 1
- Classes:
- Required from stable: language | owner
- Sections: Zweck | Leserkreis | Registrierte Profile
- Edges out: references
- Related required: false
- Stale interval: 12
- Origin: core

### source
- Label: Quelle
- Question: Liegt die Wahrheit dieses Dokuments außerhalb des Bündels, in einem Original, das jemand anderes verantwortet?
- Order: 2
- Classes: document | article | recording | conversation | dataset | website
- Required from stable: resource | published | class
- Sections: Worum es geht | Was daraus übernommen wurde
- Edges out: part_of | references | superseded_by | contradicts
- Related required: true
- Stale interval: 12
- Origin: core

### contract
- Label: Vertrag
- Question: Legt das Dokument eine Regel fest, an die sich Werkzeuge oder Menschen halten müssen?
- Order: 3
- Classes: schema | policy | interface
- Required from stable: owner
- Sections: Geltungsbereich | Regel | Ausnahmen
- Edges out: refines | references | superseded_by | contradicts
- Related required: true
- Stale interval: 6
- Origin: core

### decision
- Label: Beschluss
- Question: Hält das Dokument fest, dass jemand etwas entschieden hat, mit Zeitpunkt und Grund?
- Order: 4
- Classes:
- Required from stable: decided_at | decided_by
- Sections: Entscheidung | Begründung | Betrachtete Alternativen
- Edges out: decides | references | superseded_by | contradicts
- Related required: true
- Stale interval: null
- Origin: core

### experience
- Label: Erfahrung
- Question: Hält das Dokument fest, was aus einem konkreten Vorgang gelernt wurde?
- Order: 5
- Classes:
- Required from stable:
- Sections: Was geschah | Was daraus folgt
- Edges out: learned_from | part_of | references
- Related required: true
- Stale interval: null
- Origin: core

### process
- Label: Ablauf
- Question: Beschreibt das Dokument, wie etwas wiederholt getan wird?
- Order: 6
- Classes: routine | event | project
- Required from stable: owner
- Sections: Auslöser | Schritte | Ergebnis
- Edges out: part_of | refines | references | superseded_by
- Related required: true
- Stale interval: 12
- Origin: core

### position
- Label: Haltung
- Question: Vertritt das Dokument eine eigene Bewertung, die jemand anderes anders sehen könnte?
- Order: 7
- Classes:
- Required from stable: owner
- Sections: Haltung | Begründung | Abgrenzung
- Edges out: contradicts | references | refines | superseded_by
- Related required: true
- Stale interval: 12
- Origin: core

### entity
- Label: Gegenstand
- Question: Bezeichnet das Dokument eine benennbare Sache, über die entschieden wird oder die etwas tut?
- Order: 8
- Classes: organization | unit | person | body | system | capability
- Required from stable: class | owner
- Sections: Worum es sich handelt
- Edges out: part_of | refines | references | superseded_by
- Related required: true
- Stale interval: 12
- Origin: core

### concept
- Label: Konzept
- Question: Erklärt das Dokument, was etwas ist, wie es funktioniert und warum es wichtig ist?
- Order: 9
- Classes: cross-cutting
- Required from stable: aliases
- Sections: Was ist das | Wie funktioniert es | Warum ist es wichtig
- Edges out: refines | references | superseded_by | contradicts
- Related required: false
- Stale interval: 24
- Origin: core

### topic
- Label: Thema
- Question: Gliedert das Dokument Wissen in einen Bereich, dem anderes zugehört?
- Order: 10
- Classes:
- Required from stable: aliases
- Sections: Worum es geht
- Edges out: part_of | references
- Related required: false
- Stale interval: 12
- Origin: core

## Edges

### part_of
- Definition: The source belongs to the subject or whole represented by the target; this is subject membership, not evidence.
- Example: A grid-capacity report belongs to the hub for grid planning.
- Transitive: true
- Domain: any
- Range: topic | concept | entity

### refines
- Definition: The source adds precision or restrictions to the target without replacing its valid statements.
- Example: A rule for transformers refines the general rule for electrical equipment.
- Transitive: true
- Domain: any
- Range: same

### references
- Definition: The source uses a specific statement, context or evidence in the target. The reason identifies the relevant passage.
- Example: A calculation references the measurement table from which its input values were taken.
- Domain: any
- Range: any

### contradicts
- Definition: Source and target assert incompatible statements under the same time and applicability conditions. The reason cites both passages and those conditions.
- Example: Two reports give incompatible capacity limits for the same asset on the same reference date.
- Domain: any
- Range: same

### superseded_by
- Definition: The target explicitly replaces the source for the stated scope. Publication dates alone do not establish replacement.
- Example: The 2026 procedure explicitly replaces the 2024 procedure from its effective date.
- Transitive: true
- Domain: any
- Range: same

### decides
- Definition: The source records a decision about the target, including who decided and why.
- Example: An approved decision selects the transformer described on the entity page.
- Domain: decision
- Range: entity | process | contract | position

### learned_from
- Definition: The source expresses an insight developed from a passage or observation in the target. Preserve both the passage and the interpretation.
- Example: An experience page derives a maintenance lesson from the incident report and points at the relevant paragraph.
- Domain: any
- Range: source | process
